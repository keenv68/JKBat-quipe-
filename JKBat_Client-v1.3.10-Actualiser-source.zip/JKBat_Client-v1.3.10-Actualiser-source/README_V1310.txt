JKBat Client v1.3.10 — bouton Actualiser

Base : v1.3.9 Documents retirés.

Ajout :
- bouton ↻ Actualiser dans l'en-tête de l'espace client ;
- rafraîchit demandes, messages, documents, rendez-vous et profil ;
- indicateur visuel pendant l'actualisation ;
- message de confirmation après mise à jour ;
- gestion hors-ligne ;
- masqué sur l'écran de connexion.

Aucun changement SQL/Supabase requis.
