JKBat'Services v1.3.7
- Ajout de l'onglet Fiches d’intervention dans Mes documents.
- Les fiches envoyées depuis JKBat Pro et JKBat Équipe sont séparées des rapports.
- Ouverture PDF, notifications push, médias et barre Android conservés.
