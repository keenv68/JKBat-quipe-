JKBat Client / Services v1.3.8
- Nouvelle icône Android Client blanche / or / verte.
- Libellé du lanceur Android : JKBat Client.
- L'identité JKBat'Services à l'intérieur de l'application est conservée.
- Aucune modification fonctionnelle des fiches d'intervention ou messages.
