JKBat Client v1.3.9
- Les documents retirés par JKBat Pro ne sont plus affichés dans l’espace client.
- Compatibilité avec le nouveau champ client_visible.
- Repli compatible avec l’ancien schéma si le SQL v1.0.21 n’est pas encore appliqué.
