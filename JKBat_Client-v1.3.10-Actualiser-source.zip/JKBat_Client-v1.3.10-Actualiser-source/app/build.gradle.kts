plugins { id("com.android.application") }

android {
    namespace = "com.jkbat.services.client.v11"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jkbat.services.client"
        minSdk = 23
        targetSdk = 35
        versionCode = 140
        versionName = "1.3.10"
    }
    signingConfigs {
        create("jkbatRelease") {
            val ks = System.getenv("JKBAT_KEYSTORE_FILE") ?: "jkbat-services-release.jks"
            storeFile = rootProject.file(ks)
            storePassword = System.getenv("JKBAT_KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("JKBAT_KEY_ALIAS") ?: "jkbat-services"
            keyPassword = System.getenv("JKBAT_KEYSTORE_PASSWORD") ?: ""
        }
    }
    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
        getByName("release") { signingConfig = signingConfigs.getByName("jkbatRelease"); isMinifyEnabled = false }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.18.0"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("androidx.core:core:1.15.0")
}
