package com.jkbat.services.client.v11;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public class JkbatFirebaseMessagingService extends FirebaseMessagingService {
  private static final String CHANNEL="jkbat_client";
  @Override public void onNewToken(String token){super.onNewToken(token);getSharedPreferences("jkbat_client_push",MODE_PRIVATE).edit().putString("fcm_token",token).apply();MainActivity a=MainActivity.getInstance();if(a!=null)a.onFcmTokenAvailable(token);}
  @Override public void onMessageReceived(RemoteMessage msg){
    super.onMessageReceived(msg);Map<String,String>d=msg.getData();String title=d.get("title"),body=d.get("body"),screen=d.get("screen");
    if((title==null||title.isEmpty())&&msg.getNotification()!=null)title=msg.getNotification().getTitle();
    if((body==null||body.isEmpty())&&msg.getNotification()!=null)body=msg.getNotification().getBody();
    if(title==null||title.isEmpty())title="JKBat'Services";if(body==null||body.isEmpty())body="Une nouvelle information est disponible.";if(screen==null||screen.isEmpty())screen="home";
    createChannel();Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("screen",screen);
    int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=23)flags|=PendingIntent.FLAG_IMMUTABLE;PendingIntent pi=PendingIntent.getActivity(this,703,i,flags);
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);b.setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi).setDefaults(Notification.DEFAULT_ALL);
    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()&0x7fffffff),b.build());
  }
  private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"JKBat'Services",NotificationManager.IMPORTANCE_HIGH);c.setDescription("Messages, documents, rendez-vous et demandes JKBat");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
}
