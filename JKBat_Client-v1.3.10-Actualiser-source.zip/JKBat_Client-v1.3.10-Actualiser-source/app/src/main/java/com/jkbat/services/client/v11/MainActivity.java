package com.jkbat.services.client.v11;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private static final int REQ_FILE=5107, REQ_NOTIF=4207;
  private static MainActivity instance;
  private WebView webView;
  private ValueCallback<Uri[]> fileCallback;
  private Uri selectedUri;
  private boolean pageReady=false;
  private String pendingFcmToken, pendingScreen;
  private int navInsetCssPx=0;

  public static MainActivity getInstance(){return instance;}

  @Override protected void onCreate(Bundle b){
    super.onCreate(b); instance=this;
    try{getWindow().setNavigationBarColor(Color.WHITE);getWindow().setStatusBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);}catch(Exception ignored){}
    webView=new WebView(this);
    WebSettings s=webView.getSettings();
    s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);
    webView.addJavascriptInterface(new NativeBridge(),"JKBatNative");
    webView.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return handleUrl(r.getUrl().toString());}
      @Override @SuppressWarnings("deprecation") public boolean shouldOverrideUrlLoading(WebView v,String u){return handleUrl(u);}
      @Override public void onPageFinished(WebView v,String u){pageReady=true;injectInsets();flush();}
    });
    webView.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;
        try{
          Intent i=p!=null?p.createIntent():new Intent(Intent.ACTION_GET_CONTENT);
          i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
          startActivityForResult(i,REQ_FILE);return true;
        }catch(Exception e){fileCallback=null;return false;}
      }
    });
    setContentView(webView);installInsets();consume(getIntent());
    webView.loadUrl("file:///android_asset/index.html");requestNotif();
    FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t->{if(t.isSuccessful()&&t.getResult()!=null)onFcmTokenAvailable(t.getResult());});
  }

  private void installInsets(){
    if(Build.VERSION.SDK_INT>=21){
      webView.setOnApplyWindowInsetsListener((v,insets)->{
        int bottom;
        if(Build.VERSION.SDK_INT>=30) bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
        else bottom=insets.getSystemWindowInsetBottom();
        float density=getResources().getDisplayMetrics().density;
        navInsetCssPx=Math.max(0,Math.round(bottom/(density<=0?1:density)));
        injectInsets();return insets;
      });
      webView.post(()->webView.requestApplyInsets());
    }
  }
  private void injectInsets(){if(!pageReady||webView==null)return;eval("document.documentElement.style.setProperty('--android-nav-inset','"+navInsetCssPx+"px');window.dispatchEvent(new Event('jkbat-system-insets'));window.dispatchEvent(new Event('resize'));");}

  private boolean handleUrl(String u){
    if(u==null)return false;
    try{
      Uri uri=Uri.parse(u);
      if(u.startsWith("jkbat-open://external")){String target=uri.getQueryParameter("url");if(target!=null)openExternal(target);return true;}
      if(u.startsWith("jkbat-pdf://external")){String target=uri.getQueryParameter("url");if(target!=null)openPdf(target);return true;}
      if(u.startsWith("tel:")||u.startsWith("sms:")||u.startsWith("mailto:")||u.startsWith("geo:")){startActivity(new Intent(Intent.ACTION_VIEW,uri));return true;}
    }catch(Exception ignored){}
    return false;
  }
  private void openExternal(String target){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}
  private void openPdf(String target){
    new Thread(()->{
      try{
        File dir=new File(getCacheDir(),"pdf");if(!dir.exists())dir.mkdirs();
        File out=new File(dir,"JKBat-document-"+System.currentTimeMillis()+".pdf");
        HttpURLConnection c=(HttpURLConnection)new URL(target).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setInstanceFollowRedirects(true);
        try(InputStream in=c.getInputStream();OutputStream os=new FileOutputStream(out)){byte[] buf=new byte[32768];int n;while((n=in.read(buf))>0)os.write(buf,0,n);}finally{c.disconnect();}
        Uri content=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",out);
        runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(content,"application/pdf");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){openExternal(target);}});
      }catch(Exception e){runOnUiThread(()->openExternal(target));}
    }).start();
  }

  @Override protected void onActivityResult(int req,int result,Intent data){
    super.onActivityResult(req,result,data);if(req!=REQ_FILE||fileCallback==null)return;
    Uri[] out=null;
    if(result==RESULT_OK&&data!=null){out=WebChromeClient.FileChooserParams.parseResult(result,data);if(out!=null&&out.length>0)selectedUri=out[0];}
    fileCallback.onReceiveValue(out);fileCallback=null;
  }

  @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);consume(i);flush();}
  @Override protected void onResume(){super.onResume();if(pageReady)eval("window.jkbatAppResumed&&window.jkbatAppResumed();");}
  private void consume(Intent i){if(i==null)return;String s=i.getStringExtra("screen");if(s!=null&&!s.isEmpty())pendingScreen=s;}
  public void onFcmTokenAvailable(String t){getSharedPreferences("jkbat_client_push",MODE_PRIVATE).edit().putString("fcm_token",t).apply();pendingFcmToken=t;flush();}
  private void flush(){
    if(!pageReady||webView==null)return;
    if(pendingFcmToken==null||pendingFcmToken.isEmpty())pendingFcmToken=getSharedPreferences("jkbat_client_push",MODE_PRIVATE).getString("fcm_token","");
    if(pendingFcmToken!=null&&!pendingFcmToken.isEmpty())eval("window.jkbatReceiveFcmToken && window.jkbatReceiveFcmToken("+JSONObject.quote(pendingFcmToken)+");");
    if(pendingScreen!=null){eval("window.jkbatOpenScreenFromNotification && window.jkbatOpenScreenFromNotification("+JSONObject.quote(pendingScreen)+");");pendingScreen=null;}
  }
  private void eval(String js){runOnUiThread(()->webView.evaluateJavascript(js,null));}
  private void requestNotif(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);}
  @Override protected void onDestroy(){if(instance==this)instance=null;super.onDestroy();}

  public class NativeBridge {
    @JavascriptInterface public boolean hasSelectedFile(){return selectedUri!=null;}
    @JavascriptInterface public long selectedFileSize(){return getUriSize(selectedUri);}
    @JavascriptInterface public void uploadSelectedMedia(String uploadUrl,String mime,String bearer,String apiKey,String requestId){
      final Uri uri=selectedUri;
      if(uri==null){nativeDone(requestId,0,"Aucun fichier sélectionné");return;}
      new Thread(()->{
        HttpURLConnection c=null;
        try{
          long total=getUriSize(uri);long sent=0;
          c=(HttpURLConnection)new URL(uploadUrl).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setChunkedStreamingMode(1024*1024);
          c.setRequestProperty("Content-Type",mime==null||mime.isEmpty()?"application/octet-stream":mime);
          c.setRequestProperty("Authorization","Bearer "+bearer);c.setRequestProperty("apikey",apiKey);c.setRequestProperty("x-upsert","false");
          try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=c.getOutputStream()){
            if(in==null)throw new IOException("Fichier inaccessible");byte[] buf=new byte[256*1024];int n;long last=0;
            while((n=in.read(buf))>0){out.write(buf,0,n);sent+=n;long now=System.currentTimeMillis();if(now-last>250){last=now;int pct=total>0?(int)Math.min(99,(sent*100/total)):1;nativeProgress(requestId,pct);}}
          }
          int status=c.getResponseCode();InputStream resp=status>=200&&status<400?c.getInputStream():c.getErrorStream();String text=readAll(resp);nativeProgress(requestId,100);nativeDone(requestId,status,text);
        }catch(Exception e){nativeDone(requestId,0,e.getMessage()==null?"Connexion interrompue":e.getMessage());}finally{if(c!=null)c.disconnect();}
      }).start();
    }
  }
  private long getUriSize(Uri uri){if(uri==null)return 0;try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.SIZE);if(i>=0&&!c.isNull(i))return c.getLong(i);}}catch(Exception ignored){}return 0;}
  private String readAll(InputStream in)throws IOException{if(in==null)return "";try(InputStream x=in;ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=x.read(buf))>0)b.write(buf,0,n);return b.toString(StandardCharsets.UTF_8.name());}}
  private void nativeProgress(String id,int p){eval("window.jkbatNativeUploadProgress && window.jkbatNativeUploadProgress("+JSONObject.quote(id)+","+p+");");}
  private void nativeDone(String id,int status,String text){eval("window.jkbatNativeUploadDone && window.jkbatNativeUploadDone("+JSONObject.quote(id)+","+status+","+JSONObject.quote(text==null?"":text)+");");}
}
