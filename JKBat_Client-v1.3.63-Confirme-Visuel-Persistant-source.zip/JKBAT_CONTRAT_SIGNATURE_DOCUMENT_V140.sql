-- ============================================================
-- JKBat Client v1.3.20 — Signature des contrats + classement Documents
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
-- Prérequis : JKBAT_CONTRATS_ENTRETIENS_V133 + correctif RLS V138
-- ============================================================

alter table public.jkbat_maintenance_contracts
  add column if not exists client_signature_data text,
  add column if not exists client_signer_name text,
  add column if not exists client_signed_at timestamptz,
  add column if not exists client_signed_snapshot jsonb,
  add column if not exists client_contract_document_id uuid;

create index if not exists jkbat_maintenance_contracts_signed_idx
  on public.jkbat_maintenance_contracts(client_id, client_signed_at desc);

create or replace function public.jkbat_client_sign_maintenance_contract(
  p_contract_id uuid,
  p_signature_data text,
  p_signer_name text default ''
) returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_contract public.jkbat_maintenance_contracts%rowtype;
  v_signature text := trim(coalesce(p_signature_data,''));
  v_name text := trim(coalesce(p_signer_name,''));
  v_doc_id uuid;
  v_now timestamptz := now();
  v_snapshot jsonb;
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;

  select *
    into v_contract
    from public.jkbat_maintenance_contracts
   where id=p_contract_id
     and client_id=auth.uid();

  if not found then
    raise exception 'contract not found';
  end if;

  -- Un contrat déjà signé reste figé. On renvoie simplement son document.
  if v_contract.client_signed_at is not null then
    if v_contract.client_contract_document_id is not null then
      return v_contract.client_contract_document_id;
    end if;
  end if;

  if length(v_signature) < 100
     or position('data:image/' in lower(v_signature)) <> 1 then
    raise exception 'signature required';
  end if;

  if length(v_signature) > 700000 then
    raise exception 'signature too large';
  end if;

  if v_name = '' then
    select trim(coalesce(full_name,''))
      into v_name
      from public.jkbat_client_profiles
     where id=auth.uid();
  end if;

  if v_name = '' then
    v_name := 'Client';
  end if;

  -- Copie figée des données du contrat au moment exact de la signature.
  -- Les champs de signature sont retirés pour ne pas créer de récursion inutile.
  v_snapshot :=
    to_jsonb(v_contract)
    - 'client_signature_data'
    - 'client_signer_name'
    - 'client_signed_at'
    - 'client_signed_snapshot'
    - 'client_contract_document_id';

  -- Réutilise un document Contrat déjà lié s'il existe, sinon le crée.
  select d.id
    into v_doc_id
    from public.jkbat_client_documents d
   where d.client_id=auth.uid()
     and lower(coalesce(d.kind,'')) like '%contrat%'
     and d.file_url='contract:'||p_contract_id::text
   order by d.created_at asc
   limit 1;

  if v_doc_id is null then
    insert into public.jkbat_client_documents(
      client_id, kind, title, status, amount, file_url, created_at
    ) values (
      auth.uid(),
      'Contrat',
      coalesce(nullif(trim(v_contract.title),''),'Contrat JKBat'),
      'SIGNÉ CLIENT',
      nullif(v_contract.price_estimate,0),
      'contract:'||p_contract_id::text,
      v_now
    )
    returning id into v_doc_id;
  else
    update public.jkbat_client_documents
       set kind='Contrat',
           title=coalesce(nullif(trim(v_contract.title),''),'Contrat JKBat'),
           status='SIGNÉ CLIENT',
           amount=nullif(v_contract.price_estimate,0),
           file_url='contract:'||p_contract_id::text
     where id=v_doc_id;
  end if;

  update public.jkbat_maintenance_contracts
     set client_signature_data=v_signature,
         client_signer_name=v_name,
         client_signed_at=v_now,
         client_signed_snapshot=v_snapshot,
         client_contract_document_id=v_doc_id,
         updated_at=now()
   where id=p_contract_id
     and client_id=auth.uid();

  return v_doc_id;
end;
$$;

revoke all on function public.jkbat_client_sign_maintenance_contract(uuid,text,text) from public;
grant execute on function public.jkbat_client_sign_maintenance_contract(uuid,text,text) to authenticated;

notify pgrst, 'reload schema';
