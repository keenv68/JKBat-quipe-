JKBat Client v1.3.11 — Contrats & entretiens
- Nouvelle page Mes contrats & entretiens.
- Prochaine échéance et rendez-vous récurrent visibles depuis l'accueil.
- Historique des passages terminés.
- Demande de report d'un entretien programmé vers JKBat Pro.
- SQL partagé : JKBAT_CONTRATS_ENTRETIENS_V133.sql
