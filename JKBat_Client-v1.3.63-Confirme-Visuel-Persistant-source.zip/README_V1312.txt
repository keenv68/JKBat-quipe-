JKBat Client v1.3.12 — Suivi intervention en direct
- Timeline Planifié / Confirmé / En route / Sur place / Terminé.
- Technicien affecté + heures de départ/arrivée/fin.
- Bannière d'accueil lorsque le technicien est en route ou sur place.
- Actualisation automatique toutes les 8 secondes.
- SQL requis : JKBAT_SUIVI_INTERVENTIONS_V134.sql
