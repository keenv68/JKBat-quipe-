JKBat Client v1.3.13 — trajet technicien en direct
- Carte en direct lorsque le technicien est EN ROUTE.
- Position rafraîchie automatiquement environ toutes les 12 secondes.
- Heure de dernière position et précision GPS affichées.
- Signal trop ancien (> 2 min) masqué automatiquement.
- Bouton « Voir le trajet jusqu'à chez vous » ouvre l'itinéraire dans l'application de cartographie.
- La position disparaît automatiquement dès l'arrivée du technicien.
