JKBat Client v1.3.14 — correctif réel du suivi GPS

- Le suivi Planifié → Confirmé → En route → Sur place → Terminé est maintenant intégré directement au moteur principal de l'application.
- Corrige le bug des v1.3.12/1.3.13 où le code de suivi ajouté hors du moteur ne remplaçait pas les fonctions internes.
- Carte GPS affichée pendant EN ROUTE dès qu'une position est reçue.
- Actualisation automatique via le polling principal (8 s).
