JKBat Client v1.3.15 — carte GPS persistante

Correctifs
- La carte ne disparaît plus lorsque le signal GPS du technicien devient temporairement ancien.
- La dernière position connue reste affichée avec un avertissement « GPS PAUSE » et l'ancienneté de la dernière position.
- Tant qu'aucune position n'a encore été reçue, l'écran conserve « Connexion GPS en cours… ».
- Le rafraîchissement automatique toutes les 8 secondes reste inchangé.

Version technicien conseillée
- JKBat Équipe v1.0.37 GPS robuste.
