JKBat’Services Client v1.3.16 — GPS Design harmonisé

Base: v1.3.15 GPS Robuste.
Aucune modification du fonctionnement du suivi GPS.

Évolutions visuelles:
- nouvelle carte GPS plus compacte et plus moderne;
- entête “Suivi du technicien” + badge EN DIRECT / GPS PAUSE;
- carte OpenStreetMap mieux intégrée;
- dernière position et précision regroupées;
- bouton “Itinéraire jusqu’à chez vous” pleine largeur;
- message de confidentialité plus discret;
- état d’attente GPS modernisé;
- frise d’avancement du rendez-vous harmonisée.
