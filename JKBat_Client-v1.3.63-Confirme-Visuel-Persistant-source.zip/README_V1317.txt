JKBat'Services v1.3.17 — Contrats types & couleurs

- Cartes de contrat avec code couleur, icône et formule.
- Vue détaillée : prestations, fréquence, prochaine échéance, tarif et consignes.
- GPS esthétique de la v1.3.16 conservé.
- Exécuter JKBAT_CONTRATS_TYPES_COULEURS_V139.sql une fois.
