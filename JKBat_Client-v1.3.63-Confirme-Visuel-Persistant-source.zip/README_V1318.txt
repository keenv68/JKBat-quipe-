JKBat Client v1.3.18 — Contrats client

Base : v1.3.17 Contrats & couleurs (conservée).
- applicationId conservé : com.jkbat.services.client
- namespace conservé : com.jkbat.services.client.v11
- versionCode : 148
- versionName : 1.3.18
- GPS / suivi technicien de v1.3.17 conservés
- couleurs et modèles de contrats de v1.3.17 conservés
- accès direct Contrats ajouté dans la navigation basse
- écran Mes contrats accessible depuis l’accueil et la barre du bas

Aucun changement SQL requis pour cette mise à jour UI.
