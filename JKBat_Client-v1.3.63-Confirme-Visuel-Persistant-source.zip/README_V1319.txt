JKBat Client v1.3.19 — Contrats PDF

- Base : v1.3.18, même package Android com.jkbat.services.client.
- Dans Mes contrats, Voir le contrat ouvre maintenant un aperçu PDF A4 2 pages.
- Bouton PDF / Imprimer : ouvre le dialogue Android pour imprimer ou enregistrer en PDF.
- Chaque contrat actif apparaît aussi automatiquement dans Mes documents > Contrats.
- Le même contrat PDF s'ouvre depuis Mes contrats ou Mes documents.
- Aucun SQL supplémentaire requis.
