JKBat Client v1.3.20 — Contrat signé + classement Documents

- Signature client directement à la fin de l'aperçu du contrat PDF.
- Le PDF signé affiche la signature, le nom et la date du client.
- Après signature, le contrat est ajouté automatiquement à Mes documents > Contrats.
- Le document Contrat ouvre toujours la version figée au moment de la signature.
- SQL requis : JKBAT_CONTRAT_SIGNATURE_DOCUMENT_V140.sql
