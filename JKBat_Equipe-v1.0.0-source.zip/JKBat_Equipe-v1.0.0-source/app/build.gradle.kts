plugins {
    id("com.android.application")
}

android {
    namespace = "com.jkbat.equipe"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jkbat.equipe"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        create("jkbatRelease") {
            storeFile = rootProject.file(System.getenv("JKBAT_KEYSTORE_FILE") ?: "jkbat-services-release.jks")
            storePassword = System.getenv("JKBAT_KEYSTORE_PASSWORD") ?: ""
            keyAlias = "jkbat-services"
            keyPassword = System.getenv("JKBAT_KEYSTORE_PASSWORD") ?: ""
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("jkbatRelease")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
