JKBat Équipe v1.0.15

- Messagerie JKBat Pro conservée dans une fenêtre séparée.
- Suppression de l’appel HTTP direct à l’Edge Function depuis Android.
- Envoi du message via RPC Supabase jkbat_staff_send_admin_message.
- La notification JKBat Pro est déclenchée par le webhook existant sur jkbat_staff_reports.
- Corrige les erreurs « Failed to fetch » de la v1.0.14.
