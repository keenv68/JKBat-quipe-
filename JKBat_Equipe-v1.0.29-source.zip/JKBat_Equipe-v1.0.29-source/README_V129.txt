JKBat Équipe v1.0.29 — position définitive du bouton Terminer

Correction :
- aucun bouton « Terminer la mission » n’est rendu dans les actions en haut de la fiche ;
- sur une mission « Sur place », la zone du haut conserve uniquement « Signaler impossible » ;
- le bouton « ✓ Terminer la mission » reste uniquement tout en bas, immédiatement sous le bloc « Fiche PDF client » (signature + envoi PDF) ;
- il ne devient actif que si le rapport est validé, sans modification en attente, signé sur la révision actuelle et envoyé au client ;
- après terminaison réussie, la fenêtre de mission se ferme automatiquement.

Aucun nouveau SQL Supabase n’est nécessaire.
