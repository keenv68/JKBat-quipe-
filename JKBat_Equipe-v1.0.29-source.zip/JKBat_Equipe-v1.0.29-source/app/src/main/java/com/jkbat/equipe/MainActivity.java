package com.jkbat.equipe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private static final int REQ_FILE=5107, REQ_NOTIF=4207;
  private static MainActivity instance;
  private WebView webView; private ValueCallback<Uri[]> fileCallback; private boolean pageReady=false;
  private String pendingFcmToken, pendingAssignmentId; private boolean pendingOpenMessages=false;
  public static MainActivity getInstance(){return instance;}
  @Override protected void onCreate(Bundle b){super.onCreate(b);instance=this;if(Build.VERSION.SDK_INT>=21){getWindow().setNavigationBarColor(Color.rgb(248,245,239));getWindow().setStatusBarColor(Color.rgb(248,245,239));}if(Build.VERSION.SDK_INT>=26)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);webView=new WebView(this);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);webView.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return handle(r.getUrl().toString());}@Override @SuppressWarnings("deprecation") public boolean shouldOverrideUrlLoading(WebView v,String u){return handle(u);}@Override public void onPageFinished(WebView v,String u){pageReady=true;injectInsets();flush();}});webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;try{Intent i=p!=null?p.createIntent():new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_FILE);return true;}catch(Exception e){fileCallback=null;return false;}}});setContentView(webView);installInsets();consume(getIntent());webView.loadUrl("file:///android_asset/index.html");requestNotif();FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t->{if(t.isSuccessful()&&t.getResult()!=null)onFcmTokenAvailable(t.getResult());});}
  private boolean handle(String u){if(u==null)return false;try{if(u.startsWith("tel:")||u.startsWith("sms:")||u.startsWith("mailto:")||u.startsWith("geo:")){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));return true;}}catch(Exception ignored){}return false;}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=REQ_FILE||fileCallback==null)return;Uri[] out=null;if(result==RESULT_OK&&data!=null)out=WebChromeClient.FileChooserParams.parseResult(result,data);fileCallback.onReceiveValue(out);fileCallback=null;}
  @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);consume(i);flush();}
  private void consume(Intent i){if(i==null)return;String id=i.getStringExtra("assignment_id");if(id!=null&&!id.isEmpty())pendingAssignmentId=id;String open=i.getStringExtra("open_staff_messages");if("1".equals(open))pendingOpenMessages=true;}
  public void onFcmTokenAvailable(String t){getSharedPreferences("jkbat_equipe_push",MODE_PRIVATE).edit().putString("fcm_token",t).apply();pendingFcmToken=t;flush();}
  private void flush(){if(!pageReady||webView==null)return;if(pendingFcmToken==null||pendingFcmToken.isEmpty())pendingFcmToken=getSharedPreferences("jkbat_equipe_push",MODE_PRIVATE).getString("fcm_token","");if(pendingFcmToken!=null&&!pendingFcmToken.isEmpty())eval("window.jkbatReceiveFcmToken&&window.jkbatReceiveFcmToken("+JSONObject.quote(pendingFcmToken)+");");if(pendingOpenMessages){eval("window.jkbatOpenMessagesFromNotification123&&window.jkbatOpenMessagesFromNotification123();");pendingOpenMessages=false;pendingAssignmentId=null;}else if(pendingAssignmentId!=null){eval("window.jkbatOpenAssignmentFromNotification&&window.jkbatOpenAssignmentFromNotification("+JSONObject.quote(pendingAssignmentId)+");");pendingAssignmentId=null;}}
  public void onStaffMessagePush(String assignmentId){if(!pageReady||webView==null)return;eval("window.jkbatOnStaffMessagePush123&&window.jkbatOnStaffMessagePush123();");}

  private int navInsetCssPx=0;
  private void installInsets(){
    if(Build.VERSION.SDK_INT>=21){
      webView.setOnApplyWindowInsetsListener((v,insets)->{
        int bottom;
        if(Build.VERSION.SDK_INT>=30) bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
        else bottom=insets.getSystemWindowInsetBottom();
        float density=getResources().getDisplayMetrics().density;
        navInsetCssPx=0;
        injectInsets();
        return insets;
      });
      webView.post(()->webView.requestApplyInsets());
    }
  }
  private void injectInsets(){if(!pageReady||webView==null)return;eval("document.documentElement.style.setProperty('--android-nav-inset','"+navInsetCssPx+"px');window.dispatchEvent(new Event('jkbat-system-insets'));window.dispatchEvent(new Event('resize'));");}
  private void eval(String js){runOnUiThread(()->webView.evaluateJavascript(js,null));}
  private void requestNotif(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);}
  @Override protected void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
}
