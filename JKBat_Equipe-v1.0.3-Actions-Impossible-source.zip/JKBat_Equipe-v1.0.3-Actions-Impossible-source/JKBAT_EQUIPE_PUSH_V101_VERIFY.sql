-- Vérification JKBat Équipe v1.0.1 Push
-- Ne modifie rien. Il vérifie que les RPC de tokens FCM existent déjà.
select p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname='public'
  and p.proname in ('jkbat_register_push_token','jkbat_unregister_push_token')
order by p.proname;

select count(*) as push_tokens_enregistres
from public.jkbat_push_tokens;
