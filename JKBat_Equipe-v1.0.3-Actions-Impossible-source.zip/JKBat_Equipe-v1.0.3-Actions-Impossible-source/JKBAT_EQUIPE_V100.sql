-- ============================================================
-- JKBat Équipe v1.0.0
-- Base Supabase pour les salariés / techniciens
-- À exécuter UNE FOIS dans Supabase > SQL Editor
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.jkbat_staff_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  email text not null default '',
  role text not null default 'TECHNICIEN',
  active boolean not null default false,
  technician_ref text,
  color text not null default '#c79243',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists jkbat_staff_profiles_email_uidx
  on public.jkbat_staff_profiles (lower(email))
  where nullif(trim(email),'') is not null;

create table if not exists public.jkbat_staff_assignments (
  id uuid primary key default gen_random_uuid(),
  staff_user_id uuid not null references auth.users(id) on delete cascade,
  source_type text not null default 'INTERVENTION',
  source_id text not null,
  title text not null default '',
  client_name text not null default '',
  client_phone text not null default '',
  address text not null default '',
  trade text not null default '',
  scheduled_date date,
  scheduled_time time,
  notes text not null default '',
  priority text not null default 'NORMALE',
  status text not null default 'À FAIRE',
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(source_type, source_id)
);

create index if not exists jkbat_staff_assignments_staff_date_idx
  on public.jkbat_staff_assignments(staff_user_id, scheduled_date, scheduled_time);

create table if not exists public.jkbat_staff_reports (
  assignment_id uuid primary key references public.jkbat_staff_assignments(id) on delete cascade,
  staff_user_id uuid not null references auth.users(id) on delete cascade,
  report text not null default '',
  issue text not null default '',
  materials text not null default '',
  updated_at timestamptz not null default now()
);

create table if not exists public.jkbat_staff_media (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.jkbat_staff_assignments(id) on delete cascade,
  staff_user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('AVANT','APRES','AUTRE')),
  storage_path text not null,
  media_type text not null default 'image',
  file_name text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists jkbat_staff_media_assignment_idx
  on public.jkbat_staff_media(assignment_id, created_at);

-- ------------------------------------------------------------
-- Helpers
-- ------------------------------------------------------------
create or replace function public.jkbat_staff_is_active(p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.jkbat_staff_profiles p
    where p.id = p_user_id and p.active = true
  );
$$;

create or replace function public.jkbat_staff_register_profile(
  p_full_name text default '',
  p_phone text default ''
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_email text := coalesce(auth.jwt() ->> 'email','');
begin
  if v_uid is null then raise exception 'authentication required'; end if;

  insert into public.jkbat_staff_profiles(id, full_name, phone, email)
  values(
    v_uid,
    coalesce(nullif(trim(p_full_name),''), coalesce(auth.jwt() -> 'user_metadata' ->> 'full_name','')),
    coalesce(trim(p_phone),''),
    v_email
  )
  on conflict(id) do update set
    full_name = case when nullif(trim(excluded.full_name),'') is not null then excluded.full_name else public.jkbat_staff_profiles.full_name end,
    phone = case when nullif(trim(excluded.phone),'') is not null then excluded.phone else public.jkbat_staff_profiles.phone end,
    email = case when nullif(trim(excluded.email),'') is not null then excluded.email else public.jkbat_staff_profiles.email end,
    updated_at = now();
end;
$$;

create or replace function public.jkbat_staff_set_status(
  p_assignment_id uuid,
  p_status text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status text := upper(trim(coalesce(p_status,'')));
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if v_status not in ('À FAIRE','EN COURS','TERMINÉE','IMPOSSIBLE') then
    raise exception 'invalid status';
  end if;

  update public.jkbat_staff_assignments
     set status = v_status,
         started_at = case when v_status='EN COURS' then coalesce(started_at,now()) else started_at end,
         completed_at = case when v_status='TERMINÉE' then coalesce(completed_at,now()) when v_status<>'TERMINÉE' then null else completed_at end,
         updated_at = now()
   where id = p_assignment_id
     and staff_user_id = auth.uid();

  if not found then raise exception 'assignment not found'; end if;
end;
$$;

create or replace function public.jkbat_staff_save_report(
  p_assignment_id uuid,
  p_report text default '',
  p_issue text default '',
  p_materials text default ''
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  if not exists(
    select 1 from public.jkbat_staff_assignments a
    where a.id=p_assignment_id and a.staff_user_id=auth.uid()
  ) then raise exception 'assignment not found'; end if;

  insert into public.jkbat_staff_reports(assignment_id,staff_user_id,report,issue,materials,updated_at)
  values(p_assignment_id,auth.uid(),coalesce(p_report,''),coalesce(p_issue,''),coalesce(p_materials,''),now())
  on conflict(assignment_id) do update set
    report=excluded.report,
    issue=excluded.issue,
    materials=excluded.materials,
    updated_at=now();
end;
$$;

revoke all on function public.jkbat_staff_register_profile(text,text) from public;
revoke all on function public.jkbat_staff_set_status(uuid,text) from public;
revoke all on function public.jkbat_staff_save_report(uuid,text,text,text) from public;
grant execute on function public.jkbat_staff_register_profile(text,text) to authenticated;
grant execute on function public.jkbat_staff_set_status(uuid,text) to authenticated;
grant execute on function public.jkbat_staff_save_report(uuid,text,text,text) to authenticated;

-- ------------------------------------------------------------
-- RLS
-- ------------------------------------------------------------
alter table public.jkbat_staff_profiles enable row level security;
alter table public.jkbat_staff_assignments enable row level security;
alter table public.jkbat_staff_reports enable row level security;
alter table public.jkbat_staff_media enable row level security;

drop policy if exists "staff profile own read" on public.jkbat_staff_profiles;
drop policy if exists "staff profile admin read" on public.jkbat_staff_profiles;
drop policy if exists "staff profile admin update" on public.jkbat_staff_profiles;
create policy "staff profile own read" on public.jkbat_staff_profiles
for select using (id=auth.uid());
create policy "staff profile admin read" on public.jkbat_staff_profiles
for select using (public.jkbat_is_admin());
create policy "staff profile admin update" on public.jkbat_staff_profiles
for update using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());

drop policy if exists "staff assignment own read" on public.jkbat_staff_assignments;
drop policy if exists "staff assignment admin all" on public.jkbat_staff_assignments;
create policy "staff assignment own read" on public.jkbat_staff_assignments
for select using (staff_user_id=auth.uid() and public.jkbat_staff_is_active(auth.uid()));
create policy "staff assignment admin all" on public.jkbat_staff_assignments
for all using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());

drop policy if exists "staff report own read" on public.jkbat_staff_reports;
drop policy if exists "staff report admin read" on public.jkbat_staff_reports;
create policy "staff report own read" on public.jkbat_staff_reports
for select using (staff_user_id=auth.uid() and public.jkbat_staff_is_active(auth.uid()));
create policy "staff report admin read" on public.jkbat_staff_reports
for select using (public.jkbat_is_admin());

drop policy if exists "staff media own read" on public.jkbat_staff_media;
drop policy if exists "staff media own insert" on public.jkbat_staff_media;
drop policy if exists "staff media own delete" on public.jkbat_staff_media;
drop policy if exists "staff media admin all" on public.jkbat_staff_media;
create policy "staff media own read" on public.jkbat_staff_media
for select using (staff_user_id=auth.uid() and public.jkbat_staff_is_active(auth.uid()));
create policy "staff media own insert" on public.jkbat_staff_media
for insert with check (
  staff_user_id=auth.uid()
  and public.jkbat_staff_is_active(auth.uid())
  and exists(select 1 from public.jkbat_staff_assignments a where a.id=assignment_id and a.staff_user_id=auth.uid())
);
create policy "staff media own delete" on public.jkbat_staff_media
for delete using (staff_user_id=auth.uid() and public.jkbat_staff_is_active(auth.uid()));
create policy "staff media admin all" on public.jkbat_staff_media
for all using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());

-- ------------------------------------------------------------
-- Stockage privé photos salariés
-- ------------------------------------------------------------
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('jkbat-staff-media','jkbat-staff-media',false,10485760,array['image/jpeg','image/png','image/webp','image/heic','image/heif'])
on conflict(id) do update set
  public=false,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "staff storage own select" on storage.objects;
drop policy if exists "staff storage own insert" on storage.objects;
drop policy if exists "staff storage own delete" on storage.objects;
drop policy if exists "staff storage admin all" on storage.objects;
create policy "staff storage own select" on storage.objects
for select using (
  bucket_id='jkbat-staff-media'
  and (storage.foldername(name))[1]=auth.uid()::text
  and public.jkbat_staff_is_active(auth.uid())
);
create policy "staff storage own insert" on storage.objects
for insert with check (
  bucket_id='jkbat-staff-media'
  and (storage.foldername(name))[1]=auth.uid()::text
  and public.jkbat_staff_is_active(auth.uid())
);
create policy "staff storage own delete" on storage.objects
for delete using (
  bucket_id='jkbat-staff-media'
  and (storage.foldername(name))[1]=auth.uid()::text
  and public.jkbat_staff_is_active(auth.uid())
);
create policy "staff storage admin all" on storage.objects
for all using (bucket_id='jkbat-staff-media' and public.jkbat_is_admin())
with check (bucket_id='jkbat-staff-media' and public.jkbat_is_admin());

-- Vérification
select 'jkbat_staff_profiles' as table_name, count(*) as rows from public.jkbat_staff_profiles
union all select 'jkbat_staff_assignments', count(*) from public.jkbat_staff_assignments
union all select 'jkbat_staff_reports', count(*) from public.jkbat_staff_reports
union all select 'jkbat_staff_media', count(*) from public.jkbat_staff_media;
