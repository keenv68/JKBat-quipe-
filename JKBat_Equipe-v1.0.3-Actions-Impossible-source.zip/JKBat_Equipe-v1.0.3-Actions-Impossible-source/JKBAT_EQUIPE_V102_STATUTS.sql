-- JKBat Équipe v1.0.2 — statuts terrain
-- À exécuter UNE FOIS dans Supabase > SQL Editor avant d'utiliser En route / Sur place.

create or replace function public.jkbat_staff_set_status(
  p_assignment_id uuid,
  p_status text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status text := upper(trim(coalesce(p_status,'')));
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  if v_status not in ('À FAIRE','EN ROUTE','SUR PLACE','EN COURS','TERMINÉE','IMPOSSIBLE') then
    raise exception 'invalid status';
  end if;

  update public.jkbat_staff_assignments
     set status = v_status,
         started_at = case
           when v_status in ('EN ROUTE','SUR PLACE','EN COURS') then coalesce(started_at,now())
           else started_at
         end,
         completed_at = case
           when v_status='TERMINÉE' then coalesce(completed_at,now())
           when v_status<>'TERMINÉE' then null
           else completed_at
         end,
         updated_at = now()
   where id = p_assignment_id
     and staff_user_id = auth.uid();

  if not found then raise exception 'assignment not found'; end if;
end;
$$;

revoke all on function public.jkbat_staff_set_status(uuid,text) from public;
grant execute on function public.jkbat_staff_set_status(uuid,text) to authenticated;
