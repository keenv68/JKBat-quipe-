-- JKBat Équipe v1.0.3 — raison obligatoire pour une mission impossible
-- À exécuter UNE FOIS dans Supabase > SQL Editor.

alter table public.jkbat_staff_reports
  add column if not exists impossible_reason text not null default '',
  add column if not exists impossible_at timestamptz;

create or replace function public.jkbat_staff_mark_impossible(
  p_assignment_id uuid,
  p_reason text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_reason text := trim(coalesce(p_reason,''));
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if length(v_reason) < 3 then raise exception 'reason required'; end if;

  update public.jkbat_staff_assignments
     set status='IMPOSSIBLE',
         completed_at=null,
         updated_at=now()
   where id=p_assignment_id
     and staff_user_id=auth.uid();

  if not found then raise exception 'assignment not found'; end if;

  insert into public.jkbat_staff_reports(
    assignment_id, staff_user_id, report, issue, materials,
    impossible_reason, impossible_at, updated_at
  ) values(
    p_assignment_id, auth.uid(), '', '', '',
    v_reason, now(), now()
  )
  on conflict(assignment_id) do update set
    impossible_reason=excluded.impossible_reason,
    impossible_at=excluded.impossible_at,
    updated_at=now();
end;
$$;

revoke all on function public.jkbat_staff_mark_impossible(uuid,text) from public;
grant execute on function public.jkbat_staff_mark_impossible(uuid,text) to authenticated;
