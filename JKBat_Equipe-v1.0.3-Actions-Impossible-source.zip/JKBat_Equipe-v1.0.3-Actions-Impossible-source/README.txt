JKBat Équipe v1.0.1

Application Android salarié / technicien JKBat.
- Authentification Supabase
- Compte salarié à activer par JKBat Pro
- Planning personnel
- Démarrer / terminer une mission
- Compte rendu, anomalies, matériel
- Photos avant / après

Exécuter JKBAT_EQUIPE_V100.sql dans Supabase avant le premier test.
Le push Firebase n'est pas encore activé dans cette première base car l'application possède un nouveau package Android com.jkbat.equipe.
