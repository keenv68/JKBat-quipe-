JKBat Équipe v1.0.1 — Notifications + finition compte rendu

Nouveautés :
- Firebase Cloud Messaging activé pour com.jkbat.equipe.
- Demande de l'autorisation Android des notifications (Android 13+).
- Enregistrement sécurisé du token FCM via jkbat_register_push_token.
- Une notification peut ouvrir directement la mission concernée.
- Le bouton « Enregistrer le compte rendu » est maintenant placé SOUS les photos AVANT/APRÈS.
- Le compte rendu, l'anomalie, le matériel et les photos restent synchronisés avec JKBat Pro.

Backend notifications :
1. Déployer l'Edge Function fournie : JKBAT_EQUIPE_PUSH_V101_EDGE_FUNCTION.txt
2. Désactiver « Verify JWT with legacy secret » pour cette fonction (webhook protégé par x-jkbat-secret).
3. Créer un Database Webhook sur public.jkbat_staff_assignments pour INSERT + UPDATE.
4. Méthode POST vers l'URL de la fonction.
5. Header : x-jkbat-secret = la même valeur que JKBAT_PUSH_WEBHOOK_SECRET.

Le projet Firebase utilisé est jkbat-services-push et le package Android est com.jkbat.equipe.
