JKBat Équipe v1.0.2 — Statuts terrain + Historique complet

Nouveautés
- Parcours de mission : À FAIRE → EN ROUTE → SUR PLACE → TERMINÉE.
- Compatibilité avec l'ancien statut EN COURS (affiché comme SUR PLACE).
- Frise de progression dans les cartes et le détail d'une mission.
- Onglet Historique dans Interventions.
- Historique complet : date de fin, compte rendu, anomalie, matériel et nombre de photos.
- Une mission terminée reste ouvrable avec son compte rendu et ses photos.
- Notifications : l'Edge Function v1.0.2 cible uniquement les tokens android-equipe pour éviter les doublons.

Avant test
1. Exécuter JKBAT_EQUIPE_V102_STATUTS.sql dans Supabase > SQL Editor.
2. Dans Edge Functions > jkbat-push-equipe-v101 > Code, remplacer le code par JKBAT_EQUIPE_PUSH_V102_EDGE_FUNCTION.txt puis Deploy.
   Le webhook existant ne change pas.
3. Installer/build JKBat Équipe v1.0.2.
