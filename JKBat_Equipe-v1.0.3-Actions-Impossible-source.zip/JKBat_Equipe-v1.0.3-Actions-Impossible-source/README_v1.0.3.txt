JKBat Équipe v1.0.3 — Actions client + raison d’impossibilité

Nouveautés :
- Appeler le client depuis une mission
- Envoyer un SMS au client
- Ouvrir l’itinéraire GPS
- Signaler une mission impossible avec raison obligatoire
- Raisons rapides : client absent, accès impossible, adresse incorrecte, matériel manquant, sécurité, autre
- Raison et horodatage conservés dans jkbat_staff_reports
- Raison visible dans la mission et l’historique

Avant utilisation : exécuter JKBAT_EQUIPE_V103_IMPOSSIBLE.sql dans Supabase SQL Editor.
