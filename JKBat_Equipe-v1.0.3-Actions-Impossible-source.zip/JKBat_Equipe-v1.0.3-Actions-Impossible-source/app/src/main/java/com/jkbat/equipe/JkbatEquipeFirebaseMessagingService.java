package com.jkbat.equipe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class JkbatEquipeFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "jkbat_equipe_updates";

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        getSharedPreferences("jkbat_equipe_push", MODE_PRIVATE)
                .edit().putString("fcm_token", token).apply();
        MainActivity activity = MainActivity.getInstance();
        if (activity != null) activity.onFcmTokenAvailable(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Map<String, String> data = remoteMessage.getData();
        String title = data.get("title");
        String body = data.get("body");
        String assignmentId = data.get("assignment_id");

        if ((title == null || title.isEmpty()) && remoteMessage.getNotification() != null) {
            title = remoteMessage.getNotification().getTitle();
        }
        if ((body == null || body.isEmpty()) && remoteMessage.getNotification() != null) {
            body = remoteMessage.getNotification().getBody();
        }
        if (title == null || title.isEmpty()) title = "JKBat Équipe";
        if (body == null || body.isEmpty()) body = "Ton planning JKBat a été mis à jour.";

        createChannel();

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (assignmentId != null && !assignmentId.isEmpty()) {
            intent.putExtra("open_assignment", assignmentId);
        }

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        int requestCode = (int) (System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, requestCode, intent, flags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setDefaults(Notification.DEFAULT_ALL);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(requestCode, builder.build());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Planning et missions JKBat",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Nouvelles missions et changements de planning JKBat Équipe");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }
}
