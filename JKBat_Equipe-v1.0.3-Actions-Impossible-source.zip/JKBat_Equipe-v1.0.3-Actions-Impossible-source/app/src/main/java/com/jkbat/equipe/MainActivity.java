package com.jkbat.equipe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 4107;
    private static MainActivity instance;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private boolean pageReady = false;
    private int bottomSystemInset = 0;
    private String pendingFcmToken;
    private String pendingAssignmentId;

    public static MainActivity getInstance() { return instance; }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            webView.setOnApplyWindowInsetsListener((v, insets) -> {
                int bottom;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    bottom = insets.getInsets(android.view.WindowInsets.Type.navigationBars()).bottom;
                } else bottom = insets.getSystemWindowInsetBottom();
                bottomSystemInset = Math.max(0, bottom);
                pushInsets();
                return insets;
            });
            webView.requestApplyInsets();
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent i = params != null ? params.createIntent() : new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(i, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback.onReceiveValue(null); fileCallback = null; return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return handle(request.getUrl().toString()); }
            @Override @SuppressWarnings("deprecation") public boolean shouldOverrideUrlLoading(WebView view, String url) { return handle(url); }
            @Override public void onPageFinished(WebView view, String url) { pageReady = true; pushInsets(); flushPendingEvents(); }
        });
        setContentView(webView);
        consumeIntent(getIntent());
        webView.loadUrl("file:///android_asset/index.html");
        requestNotificationPermissionIfNeeded();
        refreshFcmToken();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        consumeIntent(intent);
        flushPendingEvents();
    }

    @Override protected void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private boolean handle(String url) {
        if (url == null) return false;
        if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("sms:") || url.startsWith("geo:")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
            return true;
        }
        if (url.startsWith("jkbat-open://external")) {
            try {
                Uri w=Uri.parse(url); String target=w.getQueryParameter("url");
                if (target != null && (target.startsWith("https://") || target.startsWith("http://"))) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(target)));
            } catch (Exception ignored) {}
            return true;
        }
        return false;
    }

    private void consumeIntent(Intent intent) {
        if (intent == null) return;
        String assignmentId = intent.getStringExtra("open_assignment");
        if (assignmentId != null && !assignmentId.isEmpty()) pendingAssignmentId = assignmentId;
    }

    private void refreshFcmToken() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) return;
            String token = task.getResult();
            if (token == null || token.isEmpty()) return;
            onFcmTokenAvailable(token);
        });
    }

    public void onFcmTokenAvailable(String token) {
        getSharedPreferences("jkbat_equipe_push", MODE_PRIVATE)
                .edit().putString("fcm_token", token).apply();
        pendingFcmToken = token;
        flushPendingEvents();
    }

    private void flushPendingEvents() {
        if (!pageReady || webView == null) return;
        if (pendingFcmToken == null || pendingFcmToken.isEmpty()) {
            pendingFcmToken = getSharedPreferences("jkbat_equipe_push", MODE_PRIVATE)
                    .getString("fcm_token", "");
        }
        if (pendingFcmToken != null && !pendingFcmToken.isEmpty()) {
            eval("window.jkbatReceiveFcmToken && window.jkbatReceiveFcmToken(" + JSONObject.quote(pendingFcmToken) + ");");
        }
        if (pendingAssignmentId != null && !pendingAssignmentId.isEmpty()) {
            eval("window.jkbatOpenAssignmentFromNotification && window.jkbatOpenAssignmentFromNotification(" + JSONObject.quote(pendingAssignmentId) + ");");
            pendingAssignmentId = null;
        }
    }

    private void pushInsets() {
        if (!pageReady || webView == null) return;
        float density=Math.max(1f,getResources().getDisplayMetrics().density);
        int cssBottom=Math.max(0,Math.min(80,Math.round(bottomSystemInset/density)));
        eval("document.documentElement.style.setProperty('--android-nav-inset','"+cssBottom+"px');window.dispatchEvent(new Event('resize'));");
    }

    private void eval(String js) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4201);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode,data);
        fileCallback.onReceiveValue(result); fileCallback = null;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
