package com.jkbat.equipe;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LiveLocationService extends Service implements LocationListener {
  public static final String ACTION_START = "com.jkbat.equipe.START_LIVE_LOCATION";
  public static final String ACTION_STOP = "com.jkbat.equipe.STOP_LIVE_LOCATION";
  private static final String CHANNEL_ID = "jkbat_live_location";
  private static final int NOTIFICATION_ID = 13601;
  private static final String PREFS = "jkbat_live_location";

  private LocationManager locationManager;
  private final ExecutorService network = Executors.newSingleThreadExecutor();
  private String assignmentId = "", supabaseUrl = "", anonKey = "", trackingToken = "";
  private long lastSendAt = 0L;

  @Override public void onCreate() {
    super.onCreate();
    locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
    createChannel();
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    String action = intent == null ? "" : intent.getAction();
    if (ACTION_STOP.equals(action)) {
      restoreCredentials();
      if (intent != null) {
        String incomingId = safe(intent.getStringExtra("assignment_id"));
        String incomingToken = safe(intent.getStringExtra("tracking_token"));
        if (!incomingId.isEmpty()) assignmentId = incomingId;
        if (!incomingToken.isEmpty()) trackingToken = incomingToken;
      }
      stopTracking(true);
      return START_NOT_STICKY;
    }

    if (intent != null) {
      assignmentId = safe(intent.getStringExtra("assignment_id"));
      supabaseUrl = safe(intent.getStringExtra("supabase_url"));
      anonKey = safe(intent.getStringExtra("anon_key"));
      trackingToken = safe(intent.getStringExtra("tracking_token"));
      saveCredentials();
    } else {
      restoreCredentials();
    }

    if (assignmentId.isEmpty() || supabaseUrl.isEmpty() || anonKey.isEmpty() || trackingToken.isEmpty()) {
      stopSelf();
      return START_NOT_STICKY;
    }

    startForeground(NOTIFICATION_ID, buildNotification());
    startLocationUpdates();
    return START_STICKY;
  }

  private void startLocationUpdates() {
    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
      stopTracking(false);
      return;
    }
    try {
      if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000L, 5f, this);
    } catch (Exception ignored) {}
    try {
      if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 12000L, 10f, this);
    } catch (Exception ignored) {}

    try {
      Location best = null;
      Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
      Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
      if (gps != null) best = gps;
      if (net != null && (best == null || net.getTime() > best.getTime())) best = net;
      if (best != null && System.currentTimeMillis() - best.getTime() < 120000L) sendLocation(best);
    } catch (Exception ignored) {}
  }

  @Override public void onLocationChanged(Location location) {
    if (location == null) return;
    if (location.hasAccuracy() && location.getAccuracy() > 300f) return;
    long now = System.currentTimeMillis();
    if (now - lastSendAt < 9000L) return;
    lastSendAt = now;
    sendLocation(location);
  }
  @Override public void onProviderEnabled(String provider) {}
  @Override public void onProviderDisabled(String provider) {}
  @Override @SuppressWarnings("deprecation") public void onStatusChanged(String provider, int status, Bundle extras) {}

  private void sendLocation(Location l) {
    final double lat = l.getLatitude(), lng = l.getLongitude();
    final double accuracy = l.hasAccuracy() ? l.getAccuracy() : 0d;
    final double speed = l.hasSpeed() ? l.getSpeed() : 0d;
    final double bearing = l.hasBearing() ? l.getBearing() : 0d;
    network.execute(() -> {
      try {
        JSONObject body = new JSONObject();
        body.put("p_assignment_id", assignmentId);
        body.put("p_tracking_token", trackingToken);
        body.put("p_lat", lat);
        body.put("p_lng", lng);
        body.put("p_accuracy", accuracy);
        body.put("p_speed", speed);
        body.put("p_heading", bearing);
        postAnonRpc(supabaseUrl + "/rest/v1/rpc/jkbat_live_update_location", anonKey, body.toString());
      } catch (Exception ignored) {}
    });
  }

  private void sendStop() {
    if (assignmentId.isEmpty() || supabaseUrl.isEmpty() || anonKey.isEmpty() || trackingToken.isEmpty()) return;
    network.execute(() -> {
      try {
        JSONObject body = new JSONObject();
        body.put("p_assignment_id", assignmentId);
        body.put("p_tracking_token", trackingToken);
        postAnonRpc(supabaseUrl + "/rest/v1/rpc/jkbat_live_stop_location", anonKey, body.toString());
      } catch (Exception ignored) {}
    });
  }

  private static void postAnonRpc(String target, String key, String body) throws Exception {
    HttpURLConnection c = (HttpURLConnection)new URL(target).openConnection();
    c.setConnectTimeout(10000);
    c.setReadTimeout(10000);
    c.setRequestMethod("POST");
    c.setDoOutput(true);
    c.setRequestProperty("apikey", key);
    c.setRequestProperty("Authorization", "Bearer " + key);
    c.setRequestProperty("Content-Type", "application/json");
    byte[] data = body.getBytes(StandardCharsets.UTF_8);
    c.setFixedLengthStreamingMode(data.length);
    try (OutputStream os = c.getOutputStream()) { os.write(data); }
    int code = c.getResponseCode();
    if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
    c.disconnect();
  }

  private void stopTracking(boolean tellServer) {
    try { if (locationManager != null) locationManager.removeUpdates(this); } catch (Exception ignored) {}
    if (tellServer) sendStop();
    getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply();
    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
    stopSelf();
  }

  private void saveCredentials() {
    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
      .putString("assignment_id", assignmentId)
      .putString("supabase_url", supabaseUrl)
      .putString("anon_key", anonKey)
      .putString("tracking_token", trackingToken)
      .apply();
  }

  private void restoreCredentials() {
    SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
    assignmentId = p.getString("assignment_id", "");
    supabaseUrl = p.getString("supabase_url", "");
    anonKey = p.getString("anon_key", "");
    trackingToken = p.getString("tracking_token", "");
  }

  private Notification buildNotification() {
    Intent open = new Intent(this, MainActivity.class);
    PendingIntent pi = PendingIntent.getActivity(this, 136, open,
      Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
    b.setContentTitle("JKBat Équipe · trajet en direct")
      .setContentText("GPS client actif · partage sécurisé jusqu’à l’arrivée")
      .setSmallIcon(com.jkbat.equipe.R.drawable.ic_notification)
      .setOngoing(true)
      .setContentIntent(pi)
      .setCategory(Notification.CATEGORY_SERVICE);
    return b.build();
  }

  private void createChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
      NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Trajet technicien en direct", NotificationManager.IMPORTANCE_LOW);
      ch.setDescription("Partage GPS actif uniquement quand le technicien est en route");
      nm.createNotificationChannel(ch);
    }
  }

  private static String safe(String s) { return s == null ? "" : s.trim(); }

  @Override public void onDestroy() {
    try { if (locationManager != null) locationManager.removeUpdates(this); } catch (Exception ignored) {}
    network.shutdown();
    super.onDestroy();
  }
  @Override public IBinder onBind(Intent intent) { return null; }
}
