plugins { id("com.android.application") }

android {
    namespace = "com.jkbat.equipe"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jkbat.equipe"
        minSdk = 23
        targetSdk = 35
        versionCode = 42
        versionName = "1.0.42"
    }
    signingConfigs {
        create("jkbatRelease") {
            val ks = System.getenv("JKBAT_KEYSTORE_FILE") ?: "jkbat-services-release.jks"
            storeFile = rootProject.file(ks)
            storePassword = System.getenv("JKBAT_KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("JKBAT_KEY_ALIAS") ?: "jkbat-services"
            keyPassword = System.getenv("JKBAT_KEYSTORE_PASSWORD") ?: ""
        }
    }
    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
        getByName("release") { signingConfig = signingConfigs.getByName("jkbatRelease"); isMinifyEnabled = false }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.18.0"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
