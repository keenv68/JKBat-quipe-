-- ============================================================
-- JKBat Contrats & entretiens récurrents
-- Pro 6.16.81 / PC 6.17.34 / Client 1.3.11 / Équipe 1.0.33
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.jkbat_maintenance_contracts (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null,
  client_name text not null default '',
  client_phone text not null default '',
  address text not null default '',
  title text not null default 'Entretien',
  trade text not null default '',
  interval_months integer not null default 12 check (interval_months between 1 and 120),
  price_estimate numeric not null default 0,
  next_due_date date not null,
  notes text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.jkbat_maintenance_visits (
  id uuid primary key default gen_random_uuid(),
  contract_id uuid not null references public.jkbat_maintenance_contracts(id) on delete cascade,
  due_date date not null,
  scheduled_at timestamptz,
  completed_at timestamptz,
  status text not null default 'A_PLANIFIER',
  client_appointment_id uuid,
  staff_assignment_id uuid,
  staff_user_id uuid,
  technician_name text not null default '',
  client_request_note text not null default '',
  client_request_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(contract_id,due_date)
);

create index if not exists jkbat_maintenance_contracts_client_idx
  on public.jkbat_maintenance_contracts(client_id,active,next_due_date);
create index if not exists jkbat_maintenance_visits_contract_idx
  on public.jkbat_maintenance_visits(contract_id,due_date desc);
create index if not exists jkbat_maintenance_visits_status_idx
  on public.jkbat_maintenance_visits(status,due_date);

-- Liaison explicite avec JKBat Équipe. Les colonnes sont sans FK volontairement
-- pour rester compatibles avec les installations ayant évolué au fil des versions.
alter table public.jkbat_staff_assignments
  add column if not exists maintenance_contract_id uuid,
  add column if not exists maintenance_visit_id uuid,
  add column if not exists maintenance_label text not null default '';

create index if not exists jkbat_staff_assignments_maintenance_visit_idx
  on public.jkbat_staff_assignments(maintenance_visit_id);

alter table public.jkbat_maintenance_contracts enable row level security;
alter table public.jkbat_maintenance_visits enable row level security;

-- ------------------------------------------------------------
-- RLS Contrats
-- ------------------------------------------------------------
drop policy if exists "maintenance contracts admin all" on public.jkbat_maintenance_contracts;
drop policy if exists "maintenance contracts client read" on public.jkbat_maintenance_contracts;
drop policy if exists "maintenance contracts staff read" on public.jkbat_maintenance_contracts;

create policy "maintenance contracts admin all" on public.jkbat_maintenance_contracts
for all using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());

create policy "maintenance contracts client read" on public.jkbat_maintenance_contracts
for select using (client_id=auth.uid());

create policy "maintenance contracts staff read" on public.jkbat_maintenance_contracts
for select using (
  public.jkbat_staff_is_active(auth.uid())
  and exists(
    select 1
      from public.jkbat_maintenance_visits v
      join public.jkbat_staff_assignments a on a.id=v.staff_assignment_id
     where v.contract_id=jkbat_maintenance_contracts.id
       and a.staff_user_id=auth.uid()
  )
);

-- ------------------------------------------------------------
-- RLS Passages d'entretien
-- ------------------------------------------------------------
drop policy if exists "maintenance visits admin all" on public.jkbat_maintenance_visits;
drop policy if exists "maintenance visits client read" on public.jkbat_maintenance_visits;
drop policy if exists "maintenance visits staff read" on public.jkbat_maintenance_visits;

create policy "maintenance visits admin all" on public.jkbat_maintenance_visits
for all using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());

create policy "maintenance visits client read" on public.jkbat_maintenance_visits
for select using (
  exists(
    select 1 from public.jkbat_maintenance_contracts c
    where c.id=contract_id and c.client_id=auth.uid()
  )
);

create policy "maintenance visits staff read" on public.jkbat_maintenance_visits
for select using (
  public.jkbat_staff_is_active(auth.uid())
  and exists(
    select 1 from public.jkbat_staff_assignments a
    where a.id=staff_assignment_id and a.staff_user_id=auth.uid()
  )
);

-- ------------------------------------------------------------
-- Enregistrement / modification d'un contrat
-- + création automatique de la prochaine échéance
-- ------------------------------------------------------------
create or replace function public.jkbat_admin_save_maintenance_contract(
  p_client_id uuid,
  p_title text,
  p_trade text,
  p_interval_months integer,
  p_next_due_date date,
  p_price_estimate numeric default 0,
  p_address text default '',
  p_notes text default '',
  p_contract_id uuid default null
) returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid;
  v_name text := '';
  v_phone text := '';
  v_profile_address text := '';
  v_open_visit uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_client_id is null then raise exception 'client required'; end if;
  if nullif(trim(coalesce(p_title,'')),'') is null then raise exception 'title required'; end if;
  if p_next_due_date is null then raise exception 'next due date required'; end if;
  if coalesce(p_interval_months,0) < 1 then raise exception 'invalid interval'; end if;

  select coalesce(full_name,''),coalesce(phone,''),coalesce(address,'')
    into v_name,v_phone,v_profile_address
    from public.jkbat_client_profiles
   where id=p_client_id;
  if not found then raise exception 'client profile not found'; end if;

  if p_contract_id is null then
    insert into public.jkbat_maintenance_contracts(
      client_id,client_name,client_phone,address,title,trade,interval_months,
      price_estimate,next_due_date,notes,active,updated_at
    ) values(
      p_client_id,v_name,v_phone,coalesce(nullif(trim(p_address),''),v_profile_address),
      trim(p_title),coalesce(trim(p_trade),''),p_interval_months,
      greatest(coalesce(p_price_estimate,0),0),p_next_due_date,coalesce(p_notes,''),true,now()
    ) returning id into v_id;
  else
    update public.jkbat_maintenance_contracts
       set client_id=p_client_id,
           client_name=v_name,
           client_phone=v_phone,
           address=coalesce(nullif(trim(p_address),''),v_profile_address),
           title=trim(p_title),
           trade=coalesce(trim(p_trade),''),
           interval_months=p_interval_months,
           price_estimate=greatest(coalesce(p_price_estimate,0),0),
           next_due_date=p_next_due_date,
           notes=coalesce(p_notes,''),
           updated_at=now()
     where id=p_contract_id
     returning id into v_id;
    if not found then raise exception 'contract not found'; end if;
  end if;

  -- Si le prochain passage n'est pas encore réellement programmé, on déplace
  -- l'échéance existante au lieu de créer des doublons.
  select id into v_open_visit
    from public.jkbat_maintenance_visits
   where contract_id=v_id
     and status in ('A_PLANIFIER','REPORT_DEMANDE')
     and scheduled_at is null
   order by due_date asc
   limit 1;

  if v_open_visit is not null then
    update public.jkbat_maintenance_visits
       set due_date=p_next_due_date,updated_at=now()
     where id=v_open_visit;
  else
    insert into public.jkbat_maintenance_visits(contract_id,due_date,status)
    values(v_id,p_next_due_date,'A_PLANIFIER')
    on conflict(contract_id,due_date) do nothing;
  end if;

  return v_id;
end;
$$;

-- ------------------------------------------------------------
-- Programmation d'un passage : JKBat Client + JKBat Équipe
-- ------------------------------------------------------------
create or replace function public.jkbat_admin_schedule_maintenance_visit(
  p_visit_id uuid,
  p_start_at timestamptz,
  p_staff_user_id uuid default null,
  p_technician_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_visit public.jkbat_maintenance_visits%rowtype;
  v_contract public.jkbat_maintenance_contracts%rowtype;
  v_appt uuid;
  v_assign uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_start_at is null then raise exception 'date required'; end if;

  select * into v_visit from public.jkbat_maintenance_visits where id=p_visit_id for update;
  if not found then raise exception 'visit not found'; end if;
  select * into v_contract from public.jkbat_maintenance_contracts where id=v_visit.contract_id;
  if not found then raise exception 'contract not found'; end if;
  if not v_contract.active then raise exception 'contract inactive'; end if;

  v_appt:=v_visit.client_appointment_id;
  if v_appt is null then
    insert into public.jkbat_client_appointments(client_id,title,address,start_at,status)
    values(v_contract.client_id,'Entretien · '||v_contract.title,v_contract.address,p_start_at,'PLANIFIÉ')
    returning id into v_appt;
  else
    update public.jkbat_client_appointments
       set title='Entretien · '||v_contract.title,
           address=v_contract.address,
           start_at=p_start_at,
           status='PLANIFIÉ'
     where id=v_appt;
  end if;

  v_assign:=v_visit.staff_assignment_id;
  if p_staff_user_id is not null then
    insert into public.jkbat_staff_assignments(
      staff_user_id,source_type,source_id,title,client_name,client_phone,address,trade,
      scheduled_date,scheduled_time,notes,priority,status,client_profile_id,
      maintenance_contract_id,maintenance_visit_id,maintenance_label,updated_at
    ) values(
      p_staff_user_id,'CONTRAT',v_visit.id::text,'Entretien · '||v_contract.title,
      v_contract.client_name,v_contract.client_phone,v_contract.address,v_contract.trade,
      (p_start_at at time zone 'Europe/Paris')::date,
      (p_start_at at time zone 'Europe/Paris')::time,
      trim(both from concat_ws(E'\n',v_contract.notes,'Contrat récurrent · tous les '||v_contract.interval_months||' mois')),
      'NORMALE','À FAIRE',v_contract.client_id,
      v_contract.id,v_visit.id,v_contract.title,now()
    )
    on conflict(source_type,source_id) do update set
      staff_user_id=excluded.staff_user_id,
      title=excluded.title,
      client_name=excluded.client_name,
      client_phone=excluded.client_phone,
      address=excluded.address,
      trade=excluded.trade,
      scheduled_date=excluded.scheduled_date,
      scheduled_time=excluded.scheduled_time,
      notes=excluded.notes,
      client_profile_id=excluded.client_profile_id,
      maintenance_contract_id=excluded.maintenance_contract_id,
      maintenance_visit_id=excluded.maintenance_visit_id,
      maintenance_label=excluded.maintenance_label,
      status=case when upper(coalesce(public.jkbat_staff_assignments.status,'')) like 'TERMIN%' then public.jkbat_staff_assignments.status else 'À FAIRE' end,
      updated_at=now()
    returning id into v_assign;
  elsif v_assign is not null then
    -- Désaffectation possible avant terminaison.
    delete from public.jkbat_staff_assignments
     where id=v_assign and upper(coalesce(status,'')) not like 'TERMIN%';
    if found then v_assign:=null; end if;
  end if;

  update public.jkbat_maintenance_visits
     set scheduled_at=p_start_at,
         due_date=(p_start_at at time zone 'Europe/Paris')::date,
         status='PLANIFIE',
         client_appointment_id=v_appt,
         staff_assignment_id=v_assign,
         staff_user_id=p_staff_user_id,
         technician_name=coalesce(p_technician_name,''),
         client_request_note='',client_request_at=null,
         updated_at=now()
   where id=p_visit_id;

  update public.jkbat_maintenance_contracts
     set next_due_date=(p_start_at at time zone 'Europe/Paris')::date,updated_at=now()
   where id=v_contract.id;
end;
$$;

-- ------------------------------------------------------------
-- Report d'une échéance. Si le passage était programmé, son heure est conservée.
-- ------------------------------------------------------------
create or replace function public.jkbat_admin_postpone_maintenance_visit(
  p_visit_id uuid,
  p_new_date date
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.jkbat_maintenance_visits%rowtype;
  v_contract_id uuid;
  v_new_start timestamptz;
  v_time time;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_new_date is null then raise exception 'date required'; end if;

  select * into v from public.jkbat_maintenance_visits where id=p_visit_id for update;
  if not found then raise exception 'visit not found'; end if;
  v_contract_id:=v.contract_id;

  if v.scheduled_at is not null then
    v_time:=(v.scheduled_at at time zone 'Europe/Paris')::time;
    v_new_start:=(p_new_date::timestamp + v_time) at time zone 'Europe/Paris';
    if v.client_appointment_id is not null then
      update public.jkbat_client_appointments set start_at=v_new_start,status='PLANIFIÉ' where id=v.client_appointment_id;
    end if;
    if v.staff_assignment_id is not null then
      update public.jkbat_staff_assignments
         set scheduled_date=p_new_date,scheduled_time=v_time,status='À FAIRE',completed_at=null,updated_at=now()
       where id=v.staff_assignment_id and upper(coalesce(status,'')) not like 'TERMIN%';
    end if;
    update public.jkbat_maintenance_visits
       set due_date=p_new_date,scheduled_at=v_new_start,status='PLANIFIE',client_request_note='',client_request_at=null,updated_at=now()
     where id=p_visit_id;
  else
    update public.jkbat_maintenance_visits
       set due_date=p_new_date,status='A_PLANIFIER',client_request_note='',client_request_at=null,updated_at=now()
     where id=p_visit_id;
  end if;

  update public.jkbat_maintenance_contracts set next_due_date=p_new_date,updated_at=now() where id=v_contract_id;
end;
$$;

-- ------------------------------------------------------------
-- Moteur commun de terminaison : clôture + prochaine échéance automatique
-- ------------------------------------------------------------
create or replace function public.jkbat_complete_maintenance_visit_internal(p_visit_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.jkbat_maintenance_visits%rowtype;
  c public.jkbat_maintenance_contracts%rowtype;
  v_base date;
  v_next date;
begin
  select * into v from public.jkbat_maintenance_visits where id=p_visit_id for update;
  if not found then return; end if;
  if upper(coalesce(v.status,''))='TERMINE' then return; end if;
  select * into c from public.jkbat_maintenance_contracts where id=v.contract_id for update;
  if not found then return; end if;

  update public.jkbat_maintenance_visits
     set status='TERMINE',completed_at=coalesce(completed_at,now()),updated_at=now()
   where id=v.id;

  if v.client_appointment_id is not null then
    update public.jkbat_client_appointments set status='TERMINÉ' where id=v.client_appointment_id;
  end if;

  if v.staff_assignment_id is not null then
    update public.jkbat_staff_assignments
       set status='TERMINÉE',completed_at=coalesce(completed_at,now()),updated_at=now()
     where id=v.staff_assignment_id
       and upper(coalesce(status,'')) not like 'TERMIN%';
  end if;

  v_base:=coalesce((v.scheduled_at at time zone 'Europe/Paris')::date,v.due_date,current_date);
  v_next:=(v_base + make_interval(months=>greatest(c.interval_months,1)))::date;

  update public.jkbat_maintenance_contracts
     set next_due_date=v_next,updated_at=now()
   where id=c.id;

  if c.active then
    insert into public.jkbat_maintenance_visits(contract_id,due_date,status)
    values(c.id,v_next,'A_PLANIFIER')
    on conflict(contract_id,due_date) do nothing;
  end if;
end;
$$;

create or replace function public.jkbat_admin_complete_maintenance_visit(p_visit_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  perform public.jkbat_complete_maintenance_visit_internal(p_visit_id);
end;
$$;

create or replace function public.jkbat_admin_set_maintenance_contract_active(
  p_contract_id uuid,
  p_active boolean
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare c public.jkbat_maintenance_contracts%rowtype;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;

  update public.jkbat_maintenance_contracts
     set active=coalesce(p_active,false),updated_at=now()
   where id=p_contract_id returning * into c;
  if not found then raise exception 'contract not found'; end if;

  if not coalesce(p_active,false) then
    update public.jkbat_maintenance_visits
       set status='ANNULE',updated_at=now()
     where contract_id=p_contract_id and status in ('A_PLANIFIER','REPORT_DEMANDE') and scheduled_at is null;
  else
    insert into public.jkbat_maintenance_visits(contract_id,due_date,status)
    values(c.id,c.next_due_date,'A_PLANIFIER')
    on conflict(contract_id,due_date) do nothing;
  end if;
end;
$$;

-- ------------------------------------------------------------
-- Demande de report côté JKBat Client
-- ------------------------------------------------------------
create or replace function public.jkbat_client_request_maintenance_reschedule(
  p_visit_id uuid,
  p_note text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  update public.jkbat_maintenance_visits v
     set status='REPORT_DEMANDE',client_request_note=coalesce(p_note,''),client_request_at=now(),updated_at=now()
   where v.id=p_visit_id
     and upper(coalesce(v.status,'')) not in ('TERMINE','ANNULE')
     and exists(
       select 1 from public.jkbat_maintenance_contracts c
       where c.id=v.contract_id and c.client_id=auth.uid()
     );
  if not found then raise exception 'visit not found'; end if;
end;
$$;

-- ------------------------------------------------------------
-- Quand JKBat Équipe termine une mission issue d'un contrat,
-- le contrat avance automatiquement à la prochaine échéance.
-- ------------------------------------------------------------
create or replace function public.jkbat_maintenance_after_staff_completion()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if upper(trim(coalesce(new.status,''))) like 'TERMIN%'
     and upper(trim(coalesce(old.status,''))) not like 'TERMIN%'
     and (upper(coalesce(new.source_type,''))='CONTRAT' or new.maintenance_visit_id is not null) then
    perform public.jkbat_complete_maintenance_visit_internal(
      coalesce(new.maintenance_visit_id,
               case when new.source_id ~* '^[0-9a-f-]{36}$' then new.source_id::uuid else null end)
    );
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_maintenance_after_staff_completion_trg on public.jkbat_staff_assignments;
create trigger jkbat_maintenance_after_staff_completion_trg
after update of status on public.jkbat_staff_assignments
for each row execute function public.jkbat_maintenance_after_staff_completion();

-- ------------------------------------------------------------
-- Droits fonctions
-- ------------------------------------------------------------
revoke all on function public.jkbat_admin_save_maintenance_contract(uuid,text,text,integer,date,numeric,text,text,uuid) from public;
revoke all on function public.jkbat_admin_schedule_maintenance_visit(uuid,timestamptz,uuid,text) from public;
revoke all on function public.jkbat_admin_postpone_maintenance_visit(uuid,date) from public;
revoke all on function public.jkbat_admin_complete_maintenance_visit(uuid) from public;
revoke all on function public.jkbat_admin_set_maintenance_contract_active(uuid,boolean) from public;
revoke all on function public.jkbat_client_request_maintenance_reschedule(uuid,text) from public;
revoke all on function public.jkbat_complete_maintenance_visit_internal(uuid) from public;

grant execute on function public.jkbat_admin_save_maintenance_contract(uuid,text,text,integer,date,numeric,text,text,uuid) to authenticated;
grant execute on function public.jkbat_admin_schedule_maintenance_visit(uuid,timestamptz,uuid,text) to authenticated;
grant execute on function public.jkbat_admin_postpone_maintenance_visit(uuid,date) to authenticated;
grant execute on function public.jkbat_admin_complete_maintenance_visit(uuid) to authenticated;
grant execute on function public.jkbat_admin_set_maintenance_contract_active(uuid,boolean) to authenticated;
grant execute on function public.jkbat_client_request_maintenance_reschedule(uuid,text) to authenticated;

-- La fonction interne n'est volontairement pas accordée aux rôles applicatifs.
