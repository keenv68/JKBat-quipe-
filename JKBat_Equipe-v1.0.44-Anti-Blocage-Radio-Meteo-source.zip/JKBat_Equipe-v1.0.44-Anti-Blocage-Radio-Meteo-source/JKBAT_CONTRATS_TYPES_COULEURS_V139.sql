-- ============================================================
-- JKBat — Contrats typés + code couleur v1.3.9
-- Pro 6.16.87 / Équipe 1.0.39 / Client 1.3.17
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Ajoute une identité visuelle cohérente aux contrats :
-- Climatisation, Plomberie, Canalisations, Multiservices,
-- Maintenance Premium et Personnalisé.
-- ============================================================

alter table public.jkbat_maintenance_contracts
  add column if not exists contract_type text not null default 'PERSONNALISE',
  add column if not exists formula text not null default '',
  add column if not exists color_hex text not null default '#C79243',
  add column if not exists icon text not null default '↻',
  add column if not exists services jsonb not null default '[]'::jsonb;

alter table public.jkbat_staff_assignments
  add column if not exists maintenance_type text not null default '',
  add column if not exists maintenance_formula text not null default '',
  add column if not exists maintenance_color text not null default '',
  add column if not exists maintenance_icon text not null default '';

-- ------------------------------------------------------------
-- Mise à niveau des contrats existants selon leur titre / métier.
-- Les valeurs déjà personnalisées restent prioritaires.
-- ------------------------------------------------------------
update public.jkbat_maintenance_contracts
set contract_type = case
      when lower(coalesce(title,'') || ' ' || coalesce(trade,'')) ~ '(clim|climatisation|pompe.?à.?chaleur|pac)' then 'CLIMATISATION'
      when lower(coalesce(title,'') || ' ' || coalesce(trade,'')) ~ '(plomb|sanitaire|robinet|wc)' then 'PLOMBERIE'
      when lower(coalesce(title,'') || ' ' || coalesce(trade,'')) ~ '(canal|évacuation|debouch|débouch|curage)' then 'CANALISATIONS'
      when lower(coalesce(title,'') || ' ' || coalesce(trade,'')) ~ '(premium)' then 'PREMIUM'
      when lower(coalesce(title,'') || ' ' || coalesce(trade,'')) ~ '(multi|petits travaux|maintenance)' then 'MULTISERVICES'
      else contract_type
    end
where coalesce(contract_type,'') in ('','PERSONNALISE');

update public.jkbat_maintenance_contracts
set formula = case contract_type
      when 'CLIMATISATION' then coalesce(nullif(formula,''),'Essentielle')
      when 'PLOMBERIE' then coalesce(nullif(formula,''),'Sérénité')
      when 'CANALISATIONS' then coalesce(nullif(formula,''),'Prévention')
      when 'MULTISERVICES' then coalesce(nullif(formula,''),'Confort')
      when 'PREMIUM' then coalesce(nullif(formula,''),'Premium')
      else formula
    end,
    color_hex = case contract_type
      when 'CLIMATISATION' then '#4C8FAE'
      when 'PLOMBERIE' then '#315F7B'
      when 'CANALISATIONS' then '#2F846F'
      when 'MULTISERVICES' then '#C39238'
      when 'PREMIUM' then '#2C2C2C'
      else coalesce(nullif(color_hex,''),'#C79243')
    end,
    icon = case contract_type
      when 'CLIMATISATION' then '❄'
      when 'PLOMBERIE' then '💧'
      when 'CANALISATIONS' then '◉'
      when 'MULTISERVICES' then '🛠'
      when 'PREMIUM' then '★'
      else coalesce(nullif(icon,''),'↻')
    end,
    services = case
      when services <> '[]'::jsonb then services
      when contract_type='CLIMATISATION' then '["Nettoyage & hygiène","Contrôle de fonctionnement","Évacuation des condensats","Unité extérieure","Raccordements","Compte rendu numérique"]'::jsonb
      when contract_type='PLOMBERIE' then '["Contrôle des fuites","Robinetterie","Chasses d’eau","Évacuations","Joints & étanchéité","Compte rendu numérique"]'::jsonb
      when contract_type='CANALISATIONS' then '["Contrôle d’écoulement","Inspection caméra ciblée","Repérage des anomalies","Entretien préventif","Historique des constats","Compte rendu numérique"]'::jsonb
      when contract_type='MULTISERVICES' then '["Contrôle général","Petits dépannages","Sanitaires","Fixations","Préconisations","Suivi numérique"]'::jsonb
      when contract_type='PREMIUM' then '["Visites trimestrielles","Priorité dépannage","Multi-équipements","Suivi renforcé","Rappels automatiques","Dossier client complet"]'::jsonb
      else services
    end;

-- ------------------------------------------------------------
-- Les missions JKBat Équipe héritent automatiquement du visuel
-- du contrat, sans modifier le RPC de programmation existant.
-- ------------------------------------------------------------
create or replace function public.jkbat_fill_staff_contract_visual()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  c public.jkbat_maintenance_contracts%rowtype;
begin
  if new.maintenance_contract_id is null then
    new.maintenance_type := '';
    new.maintenance_formula := '';
    new.maintenance_color := '';
    new.maintenance_icon := '';
    return new;
  end if;

  select * into c
    from public.jkbat_maintenance_contracts
   where id=new.maintenance_contract_id;

  if found then
    new.maintenance_type := coalesce(c.contract_type,'PERSONNALISE');
    new.maintenance_formula := coalesce(c.formula,'');
    new.maintenance_color := coalesce(c.color_hex,'#C79243');
    new.maintenance_icon := coalesce(c.icon,'↻');
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_fill_staff_contract_visual_trg on public.jkbat_staff_assignments;
create trigger jkbat_fill_staff_contract_visual_trg
before insert or update of maintenance_contract_id on public.jkbat_staff_assignments
for each row execute function public.jkbat_fill_staff_contract_visual();

-- Synchronisation immédiate des missions déjà programmées.
update public.jkbat_staff_assignments a
set maintenance_type = coalesce(c.contract_type,'PERSONNALISE'),
    maintenance_formula = coalesce(c.formula,''),
    maintenance_color = coalesce(c.color_hex,'#C79243'),
    maintenance_icon = coalesce(c.icon,'↻')
from public.jkbat_maintenance_contracts c
where a.maintenance_contract_id=c.id;

-- Si la famille ou la couleur d'un contrat change, les missions liées
-- sont mises à jour automatiquement.
create or replace function public.jkbat_propagate_contract_visual()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.jkbat_staff_assignments
     set maintenance_type=coalesce(new.contract_type,'PERSONNALISE'),
         maintenance_formula=coalesce(new.formula,''),
         maintenance_color=coalesce(new.color_hex,'#C79243'),
         maintenance_icon=coalesce(new.icon,'↻'),
         updated_at=now()
   where maintenance_contract_id=new.id;
  return new;
end;
$$;

drop trigger if exists jkbat_propagate_contract_visual_trg on public.jkbat_maintenance_contracts;
create trigger jkbat_propagate_contract_visual_trg
after update of contract_type,formula,color_hex,icon on public.jkbat_maintenance_contracts
for each row execute function public.jkbat_propagate_contract_visual();

-- Contrôle léger du format de couleur lors des écritures directes.
create or replace function public.jkbat_normalize_contract_visual()
returns trigger
language plpgsql
set search_path=public
as $$
begin
  new.contract_type := upper(trim(coalesce(new.contract_type,'PERSONNALISE')));
  new.formula := trim(coalesce(new.formula,''));
  new.icon := coalesce(nullif(trim(new.icon),''),'↻');
  if coalesce(new.color_hex,'') !~ '^#[0-9A-Fa-f]{6}$' then
    new.color_hex := '#C79243';
  end if;
  if new.services is null or jsonb_typeof(new.services) <> 'array' then
    new.services := '[]'::jsonb;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_normalize_contract_visual_trg on public.jkbat_maintenance_contracts;
create trigger jkbat_normalize_contract_visual_trg
before insert or update of contract_type,formula,color_hex,icon,services on public.jkbat_maintenance_contracts
for each row execute function public.jkbat_normalize_contract_visual();

notify pgrst, 'reload schema';
