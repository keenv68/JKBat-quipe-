-- JKBat Pro / Équipe — reprogrammation d’une mission IMPOSSIBLE
-- À exécuter UNE FOIS dans Supabase > SQL Editor.

create or replace function public.jkbat_admin_reprogram_staff_assignment(
  p_assignment_id uuid,
  p_scheduled_date date,
  p_scheduled_time time default null
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_scheduled_date is null then raise exception 'scheduled date required'; end if;

  update public.jkbat_staff_assignments
     set scheduled_date=p_scheduled_date,
         scheduled_time=p_scheduled_time,
         status='À FAIRE',
         started_at=null,
         completed_at=null,
         archived_at=null,
         updated_at=now()
   where id=p_assignment_id;

  if not found then raise exception 'assignment not found'; end if;

  -- Nouveau passage : on repart avec un compte rendu vierge.
  update public.jkbat_staff_reports
     set report='', issue='', materials='',
         impossible_reason='', impossible_at=null,
         report_status='BROUILLON', revision=0,
         validated_at=null, submitted_at=null, updated_at=now()
   where assignment_id=p_assignment_id;
end;
$$;

revoke all on function public.jkbat_admin_reprogram_staff_assignment(uuid,date,time) from public;
grant execute on function public.jkbat_admin_reprogram_staff_assignment(uuid,date,time) to authenticated;
