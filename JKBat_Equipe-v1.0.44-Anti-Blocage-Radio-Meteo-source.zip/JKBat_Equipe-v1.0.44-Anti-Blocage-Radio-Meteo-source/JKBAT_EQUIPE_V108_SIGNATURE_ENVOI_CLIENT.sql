-- JKBat Équipe / Pro — signature client obligatoire + envoi de la fiche PDF
-- Version fonctionnelle : Équipe v1.0.8 / Pro mobile v6.16.42 / PC v6.17.16
-- À exécuter UNE FOIS dans Supabase > SQL Editor.

-- 1) Liaison mission -> compte JKBat'Services et suivi de la fiche signée.
alter table public.jkbat_staff_assignments
  add column if not exists client_profile_id uuid references public.jkbat_client_profiles(id) on delete set null;

alter table public.jkbat_staff_reports
  add column if not exists client_signature text,
  add column if not exists signer_name text,
  add column if not exists signed_at timestamptz,
  add column if not exists client_sent_at timestamptz,
  add column if not exists client_document_id uuid,
  add column if not exists client_document_path text;

create index if not exists jkbat_staff_assignments_client_profile_idx
  on public.jkbat_staff_assignments(client_profile_id);
create index if not exists jkbat_staff_reports_client_sent_idx
  on public.jkbat_staff_reports(client_sent_at);

-- 2) Résolution sécurisée du compte client lié à une mission du salarié.
create or replace function public.jkbat_staff_client_for_assignment(
  p_assignment_id uuid
) returns table(id uuid, full_name text, email text, phone text)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_assignment public.jkbat_staff_assignments%rowtype;
  v_client public.jkbat_client_profiles%rowtype;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select * into v_assignment
  from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;

  if v_assignment.client_profile_id is not null then
    select * into v_client from public.jkbat_client_profiles p where p.id=v_assignment.client_profile_id;
  end if;

  if v_client.id is null and nullif(regexp_replace(coalesce(v_assignment.client_phone,''),'\D','','g'),'') is not null then
    select * into v_client
    from public.jkbat_client_profiles p
    where regexp_replace(coalesce(p.phone,''),'\D','','g') = regexp_replace(coalesce(v_assignment.client_phone,''),'\D','','g')
    order by case when lower(trim(coalesce(p.full_name,'')))=lower(trim(coalesce(v_assignment.client_name,''))) then 0 else 1 end,
             p.id
    limit 1;
  end if;

  if v_client.id is null and nullif(trim(coalesce(v_assignment.client_name,'')),'') is not null then
    select * into v_client
    from public.jkbat_client_profiles p
    where lower(trim(coalesce(p.full_name,'')))=lower(trim(v_assignment.client_name))
    order by p.id
    limit 1;
  end if;

  if v_client.id is null then raise exception 'client account not linked'; end if;

  if v_assignment.client_profile_id is distinct from v_client.id then
    update public.jkbat_staff_assignments
       set client_profile_id=v_client.id, updated_at=now()
     where id=p_assignment_id;
  end if;

  return query select v_client.id,v_client.full_name,v_client.email,v_client.phone;
end;
$$;

-- 3) Signature : impossible de signer un brouillon non validé.
create or replace function public.jkbat_staff_save_client_signature(
  p_assignment_id uuid,
  p_signature text,
  p_signer_name text
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_report public.jkbat_staff_reports%rowtype;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if not exists(select 1 from public.jkbat_staff_assignments a where a.id=p_assignment_id and a.staff_user_id=auth.uid()) then
    raise exception 'assignment not found';
  end if;

  select * into v_report from public.jkbat_staff_reports r
   where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
  if not found or coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then
    raise exception 'report must be validated before signature';
  end if;
  if trim(coalesce(v_report.report,''))='' then raise exception 'report required'; end if;
  if p_signature is null or p_signature not like 'data:image/%' or length(p_signature)<300 then
    raise exception 'valid signature required';
  end if;
  if length(p_signature)>500000 then raise exception 'signature too large'; end if;
  if nullif(trim(coalesce(p_signer_name,'')),'') is null then raise exception 'signer name required'; end if;

  update public.jkbat_staff_reports
     set client_signature=p_signature,
         signer_name=trim(p_signer_name),
         signed_at=now(),
         client_sent_at=null,
         updated_at=now()
   where assignment_id=p_assignment_id and staff_user_id=auth.uid();
end;
$$;

-- 4) Publication dans Mes documents du client.
-- Le salarié ne choisit pas librement un autre client : la fonction résout le compte lié à SA mission.
create or replace function public.jkbat_staff_publish_intervention_document(
  p_assignment_id uuid,
  p_title text,
  p_storage_path text
) returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_assignment public.jkbat_staff_assignments%rowtype;
  v_report public.jkbat_staff_reports%rowtype;
  v_client_id uuid;
  v_doc_id uuid;
  v_title text := coalesce(nullif(trim(p_title),''),'Fiche d’intervention');
  v_expected_prefix text;
  v_conv_id uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select * into v_assignment
  from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;

  select * into v_report
  from public.jkbat_staff_reports r
  where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
  if not found then raise exception 'report not found'; end if;
  if coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then raise exception 'report not validated'; end if;
  if v_report.client_signature is null or v_report.signed_at is null then raise exception 'client signature required'; end if;

  v_expected_prefix := 'staff/'||auth.uid()::text||'/'||p_assignment_id::text||'/';
  if p_storage_path is null or position(v_expected_prefix in p_storage_path)<>1 or p_storage_path not like '%.pdf' then
    raise exception 'invalid document path';
  end if;

  select x.id into v_client_id
  from public.jkbat_staff_client_for_assignment(p_assignment_id) x
  limit 1;
  if v_client_id is null then raise exception 'client account not linked'; end if;

  if v_report.client_document_id is not null
     and exists(select 1 from public.jkbat_client_documents d where d.id=v_report.client_document_id and d.client_id=v_client_id) then
    update public.jkbat_client_documents
       set kind='Rapport', title=v_title, status='Disponible', amount=null,
           file_url='storage:'||p_storage_path
     where id=v_report.client_document_id
     returning id into v_doc_id;
  else
    insert into public.jkbat_client_documents(client_id,kind,title,status,amount,file_url)
    values(v_client_id,'Rapport',v_title,'Disponible',null,'storage:'||p_storage_path)
    returning id into v_doc_id;
  end if;

  update public.jkbat_staff_reports
     set client_document_id=v_doc_id,
         client_document_path=p_storage_path,
         client_sent_at=now(),
         updated_at=now()
   where assignment_id=p_assignment_id and staff_user_id=auth.uid();

  -- Message client : déclenche aussi le circuit de notification JKBat'Services déjà en place.
  begin
    select c.id into v_conv_id
      from public.jkbat_conversations c
     where c.client_id=v_client_id
     order by c.created_at asc
     limit 1;
    if v_conv_id is not null then
      insert into public.jkbat_messages(conversation_id,sender_id,sender_role,body)
      values(v_conv_id,auth.uid(),'business','Nouvelle fiche d’intervention signée disponible : '||v_title);
    end if;
  exception when others then
    null;
  end;

  return v_doc_id;
end;
$$;

-- 5) Un compte rendu modifié invalide la signature pour empêcher l'envoi d'un PDF signé sur une ancienne version.
create or replace function public.jkbat_staff_save_report(
  p_assignment_id uuid,
  p_report text default '',
  p_issue text default '',
  p_materials text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_assignment_status text;
  v_old public.jkbat_staff_reports%rowtype;
  v_exists boolean := false;
  v_changed boolean := false;
  v_new_status text := 'BROUILLON';
  v_revision integer := 0;
  v_validated_at timestamptz := null;
  v_report text := coalesce(p_report,'');
  v_issue text := coalesce(p_issue,'');
  v_materials text := coalesce(p_materials,'');
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,''))) into v_assignment_status
  from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;

  select * into v_old from public.jkbat_staff_reports r where r.assignment_id=p_assignment_id;
  v_exists := found;
  if v_exists then
    v_changed := v_old.report is distinct from v_report
      or v_old.issue is distinct from v_issue
      or v_old.materials is distinct from v_materials;
    v_revision := greatest(coalesce(v_old.revision,0),0);
    v_validated_at := v_old.validated_at;
  else
    v_changed := true;
  end if;

  if v_assignment_status='TERMINÉE' and v_exists
     and coalesce(v_old.report_status,'BROUILLON') in ('VALIDÉ','MISE À JOUR')
     and trim(v_report)='' then raise exception 'report required'; end if;

  if trim(v_report)<>'' and v_assignment_status in ('SUR PLACE','EN COURS','TERMINÉE') then
    if v_assignment_status='TERMINÉE' and v_exists
       and coalesce(v_old.report_status,'BROUILLON') in ('VALIDÉ','MISE À JOUR') and v_changed then
      v_new_status:='MISE À JOUR'; v_revision:=greatest(v_revision,1)+1; v_validated_at:=coalesce(v_validated_at,now());
    else
      v_new_status:=case when v_exists and v_old.report_status='MISE À JOUR' then 'MISE À JOUR' else 'VALIDÉ' end;
      v_revision:=greatest(v_revision,1); v_validated_at:=coalesce(v_validated_at,now());
    end if;
  elsif v_exists then
    v_new_status:=coalesce(v_old.report_status,'BROUILLON');
  end if;

  insert into public.jkbat_staff_reports(
    assignment_id,staff_user_id,report,issue,materials,
    report_status,revision,validated_at,submitted_at,updated_at,
    client_signature,signer_name,signed_at,client_sent_at,client_document_id,client_document_path
  ) values(
    p_assignment_id,auth.uid(),v_report,v_issue,v_materials,
    v_new_status,v_revision,v_validated_at,
    case when v_new_status in ('VALIDÉ','MISE À JOUR') then now() else null end,now(),
    null,null,null,null,null,null
  )
  on conflict(assignment_id) do update set
    staff_user_id=excluded.staff_user_id,
    report=excluded.report,
    issue=excluded.issue,
    materials=excluded.materials,
    report_status=excluded.report_status,
    revision=excluded.revision,
    validated_at=excluded.validated_at,
    submitted_at=case when excluded.report_status in ('VALIDÉ','MISE À JOUR') then now() else public.jkbat_staff_reports.submitted_at end,
    client_signature=case when v_changed then null else public.jkbat_staff_reports.client_signature end,
    signer_name=case when v_changed then null else public.jkbat_staff_reports.signer_name end,
    signed_at=case when v_changed then null else public.jkbat_staff_reports.signed_at end,
    client_sent_at=case when v_changed then null else public.jkbat_staff_reports.client_sent_at end,
    -- document_id/path restent mémorisés pour remplacer le même document au prochain envoi.
    updated_at=now();
end;
$$;

-- 6) La reprogrammation d'une mission IMPOSSIBLE repart avec une fiche vierge et non signée.
create or replace function public.jkbat_admin_reprogram_staff_assignment(
  p_assignment_id uuid,
  p_scheduled_date date,
  p_scheduled_time time default null
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_scheduled_date is null then raise exception 'scheduled date required'; end if;

  update public.jkbat_staff_assignments
     set scheduled_date=p_scheduled_date, scheduled_time=p_scheduled_time,
         status='À FAIRE', started_at=null, completed_at=null, archived_at=null, updated_at=now()
   where id=p_assignment_id;
  if not found then raise exception 'assignment not found'; end if;

  update public.jkbat_staff_reports
     set report='',issue='',materials='',impossible_reason='',impossible_at=null,
         report_status='BROUILLON',revision=0,validated_at=null,submitted_at=null,
         client_signature=null,signer_name=null,signed_at=null,client_sent_at=null,
         client_document_id=null,client_document_path=null,updated_at=now()
   where assignment_id=p_assignment_id;
end;
$$;

-- 7) Stockage PDF : le salarié ne peut écrire que dans staff/<son uid>/<sa mission>/...
-- Le client peut lire uniquement un objet réellement référencé par l'un de SES documents.
drop policy if exists "staff client docs own select" on storage.objects;
drop policy if exists "staff client docs own insert" on storage.objects;
drop policy if exists "staff client docs own delete" on storage.objects;
drop policy if exists "client docs referenced staff path select" on storage.objects;

create policy "staff client docs own select" on storage.objects
for select to authenticated
using (
  bucket_id='jkbat-client-documents'
  and (storage.foldername(name))[1]='staff'
  and (storage.foldername(name))[2]=auth.uid()::text
  and public.jkbat_staff_is_active(auth.uid())
  and exists(
    select 1 from public.jkbat_staff_assignments a
    where a.id::text=(storage.foldername(name))[3] and a.staff_user_id=auth.uid()
  )
);

create policy "staff client docs own insert" on storage.objects
for insert to authenticated
with check (
  bucket_id='jkbat-client-documents'
  and (storage.foldername(name))[1]='staff'
  and (storage.foldername(name))[2]=auth.uid()::text
  and public.jkbat_staff_is_active(auth.uid())
  and exists(
    select 1 from public.jkbat_staff_assignments a
    where a.id::text=(storage.foldername(name))[3] and a.staff_user_id=auth.uid()
  )
);

create policy "staff client docs own delete" on storage.objects
for delete to authenticated
using (
  bucket_id='jkbat-client-documents'
  and (storage.foldername(name))[1]='staff'
  and (storage.foldername(name))[2]=auth.uid()::text
  and public.jkbat_staff_is_active(auth.uid())
  and exists(
    select 1 from public.jkbat_staff_assignments a
    where a.id::text=(storage.foldername(name))[3] and a.staff_user_id=auth.uid()
  )
);

create policy "client docs referenced staff path select" on storage.objects
for select to authenticated
using (
  bucket_id='jkbat-client-documents'
  and exists(
    select 1 from public.jkbat_client_documents d
    where d.client_id=auth.uid()
      and regexp_replace(coalesce(d.file_url,''),'^storage:','')=name
  )
);

-- 8) Droits RPC.
revoke all on function public.jkbat_staff_client_for_assignment(uuid) from public;
revoke all on function public.jkbat_staff_save_client_signature(uuid,text,text) from public;
revoke all on function public.jkbat_staff_publish_intervention_document(uuid,text,text) from public;
revoke all on function public.jkbat_staff_save_report(uuid,text,text,text) from public;
revoke all on function public.jkbat_admin_reprogram_staff_assignment(uuid,date,time) from public;

grant execute on function public.jkbat_staff_client_for_assignment(uuid) to authenticated;
grant execute on function public.jkbat_staff_save_client_signature(uuid,text,text) to authenticated;
grant execute on function public.jkbat_staff_publish_intervention_document(uuid,text,text) to authenticated;
grant execute on function public.jkbat_staff_save_report(uuid,text,text,text) to authenticated;
grant execute on function public.jkbat_admin_reprogram_staff_assignment(uuid,date,time) to authenticated;
