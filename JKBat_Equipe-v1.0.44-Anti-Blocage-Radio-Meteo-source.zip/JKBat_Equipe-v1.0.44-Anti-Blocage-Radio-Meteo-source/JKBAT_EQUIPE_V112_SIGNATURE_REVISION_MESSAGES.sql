-- JKBat Équipe v1.0.12 — signature par révision + messages vers JKBat Pro
-- À exécuter dans Supabase > SQL Editor puis Run.

alter table public.jkbat_staff_reports
  add column if not exists signature_revision integer,
  add column if not exists staff_messages jsonb not null default '[]'::jsonb;

update public.jkbat_staff_reports
set staff_messages='[]'::jsonb
where staff_messages is null or jsonb_typeof(staff_messages)<>'array';

-- Une mission ne peut être terminée qu'avec la signature de la VERSION ACTUELLE.
create or replace function public.jkbat_staff_set_status(
  p_assignment_id uuid,
  p_status text
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text := upper(trim(coalesce(p_status,'')));
  v_report public.jkbat_staff_reports%rowtype;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if v_status not in ('À FAIRE','EN ROUTE','SUR PLACE','EN COURS','TERMINÉE','IMPOSSIBLE') then raise exception 'invalid status'; end if;

  if v_status='TERMINÉE' then
    select r.* into v_report from public.jkbat_staff_reports r
    where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
    if not found then raise exception 'report required before completion'; end if;
    if coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then raise exception 'report must be validated before completion'; end if;
    if nullif(trim(coalesce(v_report.report,'')),'') is null then raise exception 'report required before completion'; end if;
    if v_report.client_signature is null or v_report.signed_at is null then raise exception 'client signature required before completion'; end if;
    if coalesce(v_report.signature_revision,-1) <> coalesce(v_report.revision,0) then raise exception 'client signature outdated: new signature required'; end if;
  end if;

  update public.jkbat_staff_assignments a
     set status=v_status,
         started_at=case when v_status in ('EN ROUTE','SUR PLACE','EN COURS') then coalesce(a.started_at,now()) else a.started_at end,
         completed_at=case when v_status='TERMINÉE' then coalesce(a.completed_at,now()) when v_status<>'TERMINÉE' then null else a.completed_at end,
         updated_at=now()
   where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;
end;
$$;

-- Toute modification métier incrémente la révision et invalide la signature précédente.
create or replace function public.jkbat_staff_save_report(
  p_assignment_id uuid,
  p_report text default '',
  p_issue text default '',
  p_materials text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_assignment_status text;
  v_old public.jkbat_staff_reports%rowtype;
  v_exists boolean := false;
  v_changed boolean := false;
  v_new_status text := 'BROUILLON';
  v_revision integer := 0;
  v_validated_at timestamptz := null;
  v_report text := coalesce(p_report,'');
  v_issue text := coalesce(p_issue,'');
  v_materials text := coalesce(p_materials,'');
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,''))) into v_assignment_status
  from public.jkbat_staff_assignments a where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;

  select r.* into v_old from public.jkbat_staff_reports r where r.assignment_id=p_assignment_id;
  v_exists:=found;
  if v_exists then
    v_changed := v_old.report is distinct from v_report or v_old.issue is distinct from v_issue or v_old.materials is distinct from v_materials;
    v_revision := greatest(coalesce(v_old.revision,0),0);
    v_validated_at := v_old.validated_at;
  else v_changed:=true; end if;

  if v_assignment_status='TERMINÉE' and trim(v_report)='' then raise exception 'report required'; end if;

  if trim(v_report)<>'' and v_assignment_status in ('SUR PLACE','EN COURS','TERMINÉE') then
    if v_exists and coalesce(v_old.report_status,'BROUILLON') in ('VALIDÉ','MISE À JOUR') and v_changed then
      v_new_status:='MISE À JOUR'; v_revision:=greatest(v_revision,1)+1; v_validated_at:=coalesce(v_validated_at,now());
    elsif v_exists and coalesce(v_old.report_status,'BROUILLON')='MISE À JOUR' then
      v_new_status:='MISE À JOUR'; v_revision:=greatest(v_revision,1); v_validated_at:=coalesce(v_validated_at,now());
    else
      v_new_status:='VALIDÉ'; v_revision:=greatest(v_revision,1); v_validated_at:=coalesce(v_validated_at,now());
    end if;
  elsif v_exists then v_new_status:=coalesce(v_old.report_status,'BROUILLON'); end if;

  insert into public.jkbat_staff_reports(
    assignment_id,staff_user_id,report,issue,materials,report_status,revision,validated_at,submitted_at,updated_at,
    client_signature,signer_name,signed_at,signature_revision,client_sent_at,client_document_id,client_document_path,staff_messages
  ) values(
    p_assignment_id,auth.uid(),v_report,v_issue,v_materials,v_new_status,v_revision,v_validated_at,
    case when v_new_status in ('VALIDÉ','MISE À JOUR') then now() else null end,now(),
    null,null,null,null,null,null,null,'[]'::jsonb
  )
  on conflict(assignment_id) do update set
    staff_user_id=excluded.staff_user_id,report=excluded.report,issue=excluded.issue,materials=excluded.materials,
    report_status=excluded.report_status,revision=excluded.revision,validated_at=excluded.validated_at,
    submitted_at=case when excluded.report_status in ('VALIDÉ','MISE À JOUR') then now() else public.jkbat_staff_reports.submitted_at end,
    client_signature=case when v_changed then null else public.jkbat_staff_reports.client_signature end,
    signer_name=case when v_changed then null else public.jkbat_staff_reports.signer_name end,
    signed_at=case when v_changed then null else public.jkbat_staff_reports.signed_at end,
    signature_revision=case when v_changed then null else public.jkbat_staff_reports.signature_revision end,
    client_sent_at=case when v_changed then null else public.jkbat_staff_reports.client_sent_at end,
    client_document_id=public.jkbat_staff_reports.client_document_id,
    client_document_path=public.jkbat_staff_reports.client_document_path,
    staff_messages=coalesce(public.jkbat_staff_reports.staff_messages,'[]'::jsonb),updated_at=now();
end;
$$;

create or replace function public.jkbat_staff_touch_report(p_assignment_id uuid) returns void
language plpgsql security definer set search_path=public as $$
declare v_assignment_status text;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  select upper(trim(coalesce(a.status,''))) into v_assignment_status from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;
  if v_assignment_status not in ('SUR PLACE','EN COURS','TERMINÉE') then return; end if;
  update public.jkbat_staff_reports r set report_status='MISE À JOUR',revision=greatest(coalesce(r.revision,0),1)+1,
    submitted_at=now(),client_signature=null,signer_name=null,signed_at=null,signature_revision=null,client_sent_at=null,updated_at=now()
  where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid() and r.report_status in ('VALIDÉ','MISE À JOUR');
end;
$$;

-- La signature est enregistrée avec le numéro de révision signé.
create or replace function public.jkbat_staff_save_client_signature(
  p_assignment_id uuid,p_signature text,p_signer_name text
) returns void
language plpgsql security definer set search_path=public as $$
declare v_report public.jkbat_staff_reports%rowtype;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if not exists(select 1 from public.jkbat_staff_assignments a where a.id=p_assignment_id and a.staff_user_id=auth.uid()) then raise exception 'assignment not found'; end if;
  select r.* into v_report from public.jkbat_staff_reports r where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
  if not found or coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then raise exception 'report must be validated before signature'; end if;
  if trim(coalesce(v_report.report,''))='' then raise exception 'report required'; end if;
  if p_signature is null or p_signature not like 'data:image/%' or length(p_signature)<300 then raise exception 'valid signature required'; end if;
  if length(p_signature)>500000 then raise exception 'signature too large'; end if;
  if nullif(trim(coalesce(p_signer_name,'')),'') is null then raise exception 'signer name required'; end if;
  update public.jkbat_staff_reports set client_signature=p_signature,signer_name=trim(p_signer_name),signed_at=now(),
    signature_revision=coalesce(v_report.revision,0),client_sent_at=null,updated_at=now()
  where assignment_id=p_assignment_id and staff_user_id=auth.uid();
end;
$$;

-- Message du salarié vers JKBat Pro : conservé dans l'historique de la mission.
create or replace function public.jkbat_staff_send_admin_message(
  p_assignment_id uuid,p_body text
) returns void
language plpgsql security definer set search_path=public as $$
declare v_body text:=trim(coalesce(p_body,'')); v_staff_name text; v_msg jsonb;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if not exists(select 1 from public.jkbat_staff_assignments a where a.id=p_assignment_id and a.staff_user_id=auth.uid()) then raise exception 'assignment not found'; end if;
  if v_body='' then raise exception 'message required'; end if;
  if length(v_body)>1000 then raise exception 'message too long'; end if;
  select coalesce(nullif(trim(p.full_name),''),nullif(trim(p.email),''),'Salarié JKBat') into v_staff_name
  from public.jkbat_staff_profiles p where p.id=auth.uid();
  v_msg:=jsonb_build_object('body',v_body,'sent_at',now(),'sender_name',coalesce(v_staff_name,'Salarié JKBat'));
  insert into public.jkbat_staff_reports(assignment_id,staff_user_id,staff_messages,updated_at)
  values(p_assignment_id,auth.uid(),jsonb_build_array(v_msg),now())
  on conflict(assignment_id) do update set
    staff_messages=coalesce(public.jkbat_staff_reports.staff_messages,'[]'::jsonb)||jsonb_build_array(v_msg),updated_at=now();
end;
$$;

-- Publication : refuse une signature correspondant à une ancienne révision.
create or replace function public.jkbat_staff_publish_intervention_document(
  p_assignment_id uuid,p_title text,p_storage_path text
) returns uuid
language plpgsql security definer set search_path=public as $$
declare
  v_assignment public.jkbat_staff_assignments%rowtype; v_report public.jkbat_staff_reports%rowtype;
  v_client_id uuid; v_doc_id uuid; v_title text:=coalesce(nullif(trim(p_title),''),'Fiche d’intervention');
  v_expected_prefix text; v_conv_id uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  select a.* into v_assignment from public.jkbat_staff_assignments a where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;
  select r.* into v_report from public.jkbat_staff_reports r where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
  if not found then raise exception 'report not found'; end if;
  if coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then raise exception 'report not validated'; end if;
  if v_report.client_signature is null or v_report.signed_at is null then raise exception 'client signature required'; end if;
  if coalesce(v_report.signature_revision,-1)<>coalesce(v_report.revision,0) then raise exception 'client signature outdated: new signature required'; end if;
  v_expected_prefix:='staff/'||auth.uid()::text||'/'||p_assignment_id::text||'/';
  if p_storage_path is null or position(v_expected_prefix in p_storage_path)<>1 or p_storage_path not like '%.pdf' then raise exception 'invalid document path'; end if;
  select x.id into v_client_id from public.jkbat_staff_client_for_assignment(p_assignment_id) x limit 1;
  if v_client_id is null then raise exception 'client account not linked'; end if;
  if v_report.client_document_id is not null and exists(select 1 from public.jkbat_client_documents d where d.id=v_report.client_document_id and d.client_id=v_client_id) then
    update public.jkbat_client_documents d set kind='Fiche d’intervention',title=v_title,status='Disponible',amount=null,file_url='storage:'||p_storage_path
    where d.id=v_report.client_document_id returning d.id into v_doc_id;
  else
    insert into public.jkbat_client_documents(client_id,kind,title,status,amount,file_url)
    values(v_client_id,'Fiche d’intervention',v_title,'Disponible',null,'storage:'||p_storage_path) returning id into v_doc_id;
  end if;
  update public.jkbat_staff_reports r set client_document_id=v_doc_id,client_document_path=p_storage_path,client_sent_at=now(),updated_at=now()
  where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
  begin
    select c.id into v_conv_id from public.jkbat_conversations c where c.client_id=v_client_id order by c.created_at asc limit 1;
    if v_conv_id is not null then insert into public.jkbat_messages(conversation_id,sender_id,sender_role,body)
      values(v_conv_id,auth.uid(),'business','Nouvelle fiche d’intervention signée disponible : '||v_title); end if;
  exception when others then null; end;
  return v_doc_id;
end;
$$;

revoke all on function public.jkbat_staff_set_status(uuid,text) from public;
revoke all on function public.jkbat_staff_save_report(uuid,text,text,text) from public;
revoke all on function public.jkbat_staff_touch_report(uuid) from public;
revoke all on function public.jkbat_staff_save_client_signature(uuid,text,text) from public;
revoke all on function public.jkbat_staff_send_admin_message(uuid,text) from public;
revoke all on function public.jkbat_staff_publish_intervention_document(uuid,text,text) from public;
grant execute on function public.jkbat_staff_set_status(uuid,text) to authenticated;
grant execute on function public.jkbat_staff_save_report(uuid,text,text,text) to authenticated;
grant execute on function public.jkbat_staff_touch_report(uuid) to authenticated;
grant execute on function public.jkbat_staff_save_client_signature(uuid,text,text) to authenticated;
grant execute on function public.jkbat_staff_send_admin_message(uuid,text) to authenticated;
grant execute on function public.jkbat_staff_publish_intervention_document(uuid,text,text) to authenticated;
NOTIFY pgrst, 'reload schema';
