-- JKBat Équipe v1.0.20 / JKBat Pro v6.16.50
-- Suppression des messages Équipe depuis JKBat Pro.
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run.
-- La suppression "pour tous" est un soft-delete + événement technique invisible,
-- ce qui évite de déclencher une fausse notification avec l'Edge Function v1.0.19.

alter table public.jkbat_staff_reports
  add column if not exists staff_messages jsonb not null default '[]'::jsonb;

-- Les nouveaux messages reçoivent désormais un identifiant stable.
create or replace function public.jkbat_staff_send_admin_message(p_assignment_id uuid,p_body text)
returns void language plpgsql security definer set search_path=public as $$
declare v_body text:=trim(coalesce(p_body,''));v_staff_name text;v_msg jsonb;v_now timestamptz:=now();
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;
 if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
 if not exists(select 1 from public.jkbat_staff_assignments a where a.id=p_assignment_id and a.staff_user_id=auth.uid()) then raise exception 'assignment not found'; end if;
 if v_body='' then raise exception 'message required'; end if;if length(v_body)>1000 then raise exception 'message too long'; end if;
 select coalesce(nullif(trim(p.full_name),''),nullif(trim(p.email),''),'Salarié JKBat') into v_staff_name from public.jkbat_staff_profiles p where p.id=auth.uid();
 v_msg:=jsonb_build_object('id',gen_random_uuid()::text,'body',v_body,'sent_at',v_now,'sender_name',coalesce(v_staff_name,'Salarié JKBat'),'sender_role','staff','sender_user_id',auth.uid());
 insert into public.jkbat_staff_reports(assignment_id,staff_user_id,staff_messages,last_team_message,last_team_message_at,last_team_message_sender,last_team_message_role,last_staff_message,last_staff_message_at,last_staff_message_sender,updated_at)
 values(p_assignment_id,auth.uid(),jsonb_build_array(v_msg),v_body,v_now,coalesce(v_staff_name,'Salarié JKBat'),'staff',v_body,v_now,coalesce(v_staff_name,'Salarié JKBat'),v_now)
 on conflict(assignment_id) do update set staff_user_id=excluded.staff_user_id,staff_messages=coalesce(public.jkbat_staff_reports.staff_messages,'[]'::jsonb)||jsonb_build_array(v_msg),last_team_message=v_body,last_team_message_at=v_now,last_team_message_sender=coalesce(v_staff_name,'Salarié JKBat'),last_team_message_role='staff',last_staff_message=v_body,last_staff_message_at=v_now,last_staff_message_sender=coalesce(v_staff_name,'Salarié JKBat'),updated_at=v_now;
end $$;

create or replace function public.jkbat_admin_send_staff_message(p_assignment_id uuid,p_body text)
returns void language plpgsql security definer set search_path=public as $$
declare v_body text:=trim(coalesce(p_body,''));v_staff_user_id uuid;v_sender text:='JKBat Pro';v_msg jsonb;v_now timestamptz:=now();
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
 if v_body='' then raise exception 'message required'; end if;if length(v_body)>1000 then raise exception 'message too long'; end if;
 select a.staff_user_id into v_staff_user_id from public.jkbat_staff_assignments a where a.id=p_assignment_id;if v_staff_user_id is null then raise exception 'assignment not found'; end if;
 v_msg:=jsonb_build_object('id',gen_random_uuid()::text,'body',v_body,'sent_at',v_now,'sender_name',v_sender,'sender_role','admin','sender_user_id',auth.uid());
 insert into public.jkbat_staff_reports(assignment_id,staff_user_id,staff_messages,last_team_message,last_team_message_at,last_team_message_sender,last_team_message_role,updated_at)
 values(p_assignment_id,v_staff_user_id,jsonb_build_array(v_msg),v_body,v_now,v_sender,'admin',v_now)
 on conflict(assignment_id) do update set staff_user_id=excluded.staff_user_id,staff_messages=coalesce(public.jkbat_staff_reports.staff_messages,'[]'::jsonb)||jsonb_build_array(v_msg),last_team_message=v_body,last_team_message_at=v_now,last_team_message_sender=v_sender,last_team_message_role='admin',updated_at=v_now;
end $$;

create or replace function public.jkbat_admin_delete_staff_message(
 p_assignment_id uuid,p_message_id text default null,p_sent_at text default null,p_sender_role text default null,p_body text default null
) returns void language plpgsql security definer set search_path=public as $$
declare v_msgs jsonb;v_new jsonb:='[]'::jsonb;v_elem jsonb;v_found boolean:=false;v_now timestamptz:=now();v_tomb jsonb;
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
 select coalesce(staff_messages,'[]'::jsonb) into v_msgs from public.jkbat_staff_reports where assignment_id=p_assignment_id for update;
 if v_msgs is null then raise exception 'conversation not found'; end if;
 for v_elem in select value from jsonb_array_elements(v_msgs) loop
   if not v_found and coalesce((v_elem->>'deleted_for_all')::boolean,false)=false and lower(coalesce(v_elem->>'sender_role',''))<>'system' and (
     (coalesce(p_message_id,'')<>'' and coalesce(v_elem->>'id','')=p_message_id) or
     (coalesce(p_message_id,'')='' and coalesce(v_elem->>'sent_at','')=coalesce(p_sent_at,'') and lower(coalesce(v_elem->>'sender_role',''))=lower(coalesce(p_sender_role,'')) and coalesce(v_elem->>'body','')=coalesce(p_body,''))
   ) then
     v_elem:=v_elem||jsonb_build_object('deleted_for_all',true,'deleted_at',v_now,'deleted_by','admin');v_found:=true;
   end if;
   v_new:=v_new||jsonb_build_array(v_elem);
 end loop;
 if not v_found then raise exception 'message not found'; end if;
 v_tomb:=jsonb_build_object('id',gen_random_uuid()::text,'body','','sent_at',v_now,'sender_name','JKBat Pro','sender_role','system','event','delete');
 update public.jkbat_staff_reports set staff_messages=v_new||jsonb_build_array(v_tomb),updated_at=v_now where assignment_id=p_assignment_id;
end $$;

create or replace function public.jkbat_admin_clear_staff_messages(p_assignment_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_msgs jsonb;v_new jsonb:='[]'::jsonb;v_elem jsonb;v_now timestamptz:=now();v_tomb jsonb;
begin
 if auth.uid() is null then raise exception 'authentication required'; end if;if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
 select coalesce(staff_messages,'[]'::jsonb) into v_msgs from public.jkbat_staff_reports where assignment_id=p_assignment_id for update;
 if v_msgs is null then raise exception 'conversation not found'; end if;
 for v_elem in select value from jsonb_array_elements(v_msgs) loop
   if lower(coalesce(v_elem->>'sender_role',''))<>'system' and coalesce((v_elem->>'deleted_for_all')::boolean,false)=false then v_elem:=v_elem||jsonb_build_object('deleted_for_all',true,'deleted_at',v_now,'deleted_by','admin'); end if;
   v_new:=v_new||jsonb_build_array(v_elem);
 end loop;
 v_tomb:=jsonb_build_object('id',gen_random_uuid()::text,'body','','sent_at',v_now,'sender_name','JKBat Pro','sender_role','system','event','delete_all');
 update public.jkbat_staff_reports set staff_messages=v_new||jsonb_build_array(v_tomb),updated_at=v_now where assignment_id=p_assignment_id;
end $$;

revoke all on function public.jkbat_staff_send_admin_message(uuid,text) from public;
revoke all on function public.jkbat_admin_send_staff_message(uuid,text) from public;
revoke all on function public.jkbat_admin_delete_staff_message(uuid,text,text,text,text) from public;
revoke all on function public.jkbat_admin_clear_staff_messages(uuid) from public;
grant execute on function public.jkbat_staff_send_admin_message(uuid,text) to authenticated;
grant execute on function public.jkbat_admin_send_staff_message(uuid,text) to authenticated;
grant execute on function public.jkbat_admin_delete_staff_message(uuid,text,text,text,text) to authenticated;
grant execute on function public.jkbat_admin_clear_staff_messages(uuid) to authenticated;
NOTIFY pgrst, 'reload schema';
