-- JKBat Équipe v1.0.26 / JKBat Pro v6.16.67
-- Messagerie générale salarié <-> JKBat Pro, utilisable sans mission ouverte.
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run.

create or replace function public.jkbat_staff_get_or_create_general_chat_assignment()
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid := auth.uid();
  v_id uuid;
  v_source_id text;
begin
  if v_uid is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(v_uid) then raise exception 'staff account inactive'; end if;
  v_source_id := 'GENERAL_CHAT:' || v_uid::text;
  insert into public.jkbat_staff_assignments(
    staff_user_id,source_type,source_id,title,client_name,client_phone,address,trade,
    scheduled_date,scheduled_time,notes,priority,status,updated_at
  ) values(
    v_uid,'CHAT',v_source_id,'Conversation générale JKBat','','','','',
    null,null,'Messagerie directe JKBat Équipe ↔ JKBat Pro','NORMALE','TERMINÉE',now()
  )
  on conflict(source_type,source_id) do update set
    staff_user_id=excluded.staff_user_id,
    title='Conversation générale JKBat',
    updated_at=now()
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.jkbat_staff_get_or_create_general_chat_assignment() from public;
grant execute on function public.jkbat_staff_get_or_create_general_chat_assignment() to authenticated;
NOTIFY pgrst, 'reload schema';
