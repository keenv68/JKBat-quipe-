-- JKBat GPS — correctif V1.3.8
-- Corrige le démarrage du suivi GPS lorsque pgcrypto est installé dans le schéma "extensions".
-- À exécuter dans Supabase > SQL Editor > Run.

alter function public.jkbat_staff_begin_live_tracking(uuid)
  set search_path = public, extensions;

alter function public.jkbat_live_update_location(
  uuid,
  text,
  double precision,
  double precision,
  numeric,
  numeric,
  numeric
)
  set search_path = public, extensions;

alter function public.jkbat_live_stop_location(uuid, text)
  set search_path = public, extensions;

NOTIFY pgrst, 'reload schema';
