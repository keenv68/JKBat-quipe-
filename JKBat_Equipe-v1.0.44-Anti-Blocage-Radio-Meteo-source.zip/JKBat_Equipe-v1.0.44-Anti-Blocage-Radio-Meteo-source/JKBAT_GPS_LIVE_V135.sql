-- ============================================================
-- JKBat — GPS technicien en direct v1.3.5
-- Pro 6.16.86 / PC 6.17.39 / Équipe 1.0.35 / Client 1.3.13
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Confidentialité : seule la position courante est conservée pendant
-- le statut EN ROUTE. Elle est effacée automatiquement à l'arrivée,
-- à la fin ou en cas d'impossibilité.
-- ============================================================

alter table public.jkbat_client_appointments
  add column if not exists live_location_active boolean not null default false,
  add column if not exists technician_lat double precision,
  add column if not exists technician_lng double precision,
  add column if not exists technician_accuracy_m numeric,
  add column if not exists technician_speed_mps numeric,
  add column if not exists technician_heading numeric,
  add column if not exists technician_location_at timestamptz;

create index if not exists jkbat_client_appointments_live_location_idx
  on public.jkbat_client_appointments(live_location_active,technician_location_at desc);

create or replace function public.jkbat_staff_update_live_location(
  p_assignment_id uuid,
  p_lat double precision,
  p_lng double precision,
  p_accuracy numeric default null,
  p_speed numeric default null,
  p_heading numeric default null
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,''))) into v_status
    from public.jkbat_staff_assignments a
   where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;
  if v_status <> 'EN ROUTE' then raise exception 'live location allowed only while EN ROUTE'; end if;
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then
    raise exception 'invalid coordinates';
  end if;

  update public.jkbat_client_appointments a
     set live_location_active=true,
         technician_lat=p_lat,
         technician_lng=p_lng,
         technician_accuracy_m=case when p_accuracy is null then null else greatest(p_accuracy,0) end,
         technician_speed_mps=case when p_speed is null then null else greatest(p_speed,0) end,
         technician_heading=case when p_heading is null then null else mod(p_heading::numeric+360,360) end,
         technician_location_at=now(),
         tracking_status='EN ROUTE',
         tracking_updated_at=now()
   where a.staff_assignment_id=p_assignment_id;
end;
$$;

create or replace function public.jkbat_staff_stop_live_location(
  p_assignment_id uuid
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not exists(
    select 1 from public.jkbat_staff_assignments a
     where a.id=p_assignment_id and a.staff_user_id=auth.uid()
  ) then raise exception 'assignment not found'; end if;

  update public.jkbat_client_appointments
     set live_location_active=false,
         technician_lat=null,
         technician_lng=null,
         technician_accuracy_m=null,
         technician_speed_mps=null,
         technician_heading=null,
         technician_location_at=null
   where staff_assignment_id=p_assignment_id;
end;
$$;

-- Coupe et efface automatiquement la position dès que le technicien
-- n'est plus EN ROUTE. Ainsi aucune géolocalisation précise n'est
-- conservée après son arrivée chez le client.
create or replace function public.jkbat_clear_live_location_after_status()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if upper(trim(coalesce(new.status,''))) <> 'EN ROUTE' then
    update public.jkbat_client_appointments
       set live_location_active=false,
           technician_lat=null,
           technician_lng=null,
           technician_accuracy_m=null,
           technician_speed_mps=null,
           technician_heading=null,
           technician_location_at=null
     where staff_assignment_id=new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_staff_live_location_cleanup_trg on public.jkbat_staff_assignments;
create trigger jkbat_staff_live_location_cleanup_trg
after insert or update of status on public.jkbat_staff_assignments
for each row execute function public.jkbat_clear_live_location_after_status();

revoke all on function public.jkbat_staff_update_live_location(uuid,double precision,double precision,numeric,numeric,numeric) from public;
revoke all on function public.jkbat_staff_stop_live_location(uuid) from public;
grant execute on function public.jkbat_staff_update_live_location(uuid,double precision,double precision,numeric,numeric,numeric) to authenticated;
grant execute on function public.jkbat_staff_stop_live_location(uuid) to authenticated;

NOTIFY pgrst, 'reload schema';
