-- ============================================================
-- JKBat — GPS Live session stable v1.3.7
-- Équipe 1.0.36 / compatible Client 1.3.14 et Pro 6.16.86+
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Objectif : empêcher la coupure du GPS lorsque le JWT de connexion
-- du salarié expire pendant un trajet. Le serveur remet un jeton GPS
-- temporaire, aléatoire et limité à UNE mission EN ROUTE.
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.jkbat_live_tracking_tokens (
  assignment_id uuid primary key references public.jkbat_staff_assignments(id) on delete cascade,
  staff_user_id uuid not null references auth.users(id) on delete cascade,
  token_hash text not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.jkbat_live_tracking_tokens enable row level security;

-- Aucun accès direct à la table depuis les applications.
-- Tout passe par les fonctions SECURITY DEFINER ci-dessous.
revoke all on table public.jkbat_live_tracking_tokens from anon, authenticated;

create or replace function public.jkbat_staff_begin_live_tracking(
  p_assignment_id uuid
) returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid := auth.uid();
  v_status text;
  v_token text;
begin
  if v_uid is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(v_uid) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,''))) into v_status
    from public.jkbat_staff_assignments a
   where a.id=p_assignment_id
     and a.staff_user_id=v_uid;
  if not found then raise exception 'assignment not found'; end if;
  if v_status <> 'EN ROUTE' then raise exception 'live location allowed only while EN ROUTE'; end if;

  v_token := encode(gen_random_bytes(32),'hex');

  insert into public.jkbat_live_tracking_tokens(
    assignment_id,staff_user_id,token_hash,expires_at,created_at,updated_at
  ) values(
    p_assignment_id,v_uid,encode(digest(v_token,'sha256'),'hex'),now()+interval '12 hours',now(),now()
  )
  on conflict(assignment_id) do update set
    staff_user_id=excluded.staff_user_id,
    token_hash=excluded.token_hash,
    expires_at=excluded.expires_at,
    updated_at=now();

  return v_token;
end;
$$;

create or replace function public.jkbat_live_update_location(
  p_assignment_id uuid,
  p_tracking_token text,
  p_lat double precision,
  p_lng double precision,
  p_accuracy numeric default null,
  p_speed numeric default null,
  p_heading numeric default null
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_staff uuid;
  v_status text;
begin
  if p_tracking_token is null or length(trim(p_tracking_token)) < 32 then
    raise exception 'invalid tracking token';
  end if;

  select t.staff_user_id into v_staff
    from public.jkbat_live_tracking_tokens t
   where t.assignment_id=p_assignment_id
     and t.token_hash=encode(digest(trim(p_tracking_token),'sha256'),'hex')
     and t.expires_at>now();
  if not found then raise exception 'tracking token expired or invalid'; end if;

  select upper(trim(coalesce(a.status,''))) into v_status
    from public.jkbat_staff_assignments a
   where a.id=p_assignment_id
     and a.staff_user_id=v_staff;
  if not found then raise exception 'assignment not found'; end if;
  if v_status <> 'EN ROUTE' then raise exception 'live location allowed only while EN ROUTE'; end if;

  if p_lat is null or p_lng is null
     or p_lat not between -90 and 90
     or p_lng not between -180 and 180 then
    raise exception 'invalid coordinates';
  end if;

  update public.jkbat_client_appointments a
     set live_location_active=true,
         technician_lat=p_lat,
         technician_lng=p_lng,
         technician_accuracy_m=case when p_accuracy is null then null else greatest(p_accuracy,0) end,
         technician_speed_mps=case when p_speed is null then null else greatest(p_speed,0) end,
         technician_heading=case when p_heading is null then null else mod(p_heading::numeric+360,360) end,
         technician_location_at=now(),
         tracking_status='EN ROUTE',
         tracking_updated_at=now()
   where a.staff_assignment_id=p_assignment_id;

  update public.jkbat_live_tracking_tokens
     set updated_at=now()
   where assignment_id=p_assignment_id;
end;
$$;

create or replace function public.jkbat_live_stop_location(
  p_assignment_id uuid,
  p_tracking_token text
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not exists(
    select 1
      from public.jkbat_live_tracking_tokens t
     where t.assignment_id=p_assignment_id
       and t.token_hash=encode(digest(trim(coalesce(p_tracking_token,'')),'sha256'),'hex')
  ) then
    -- Si le jeton a déjà été supprimé par le changement de statut,
    -- on rend l'appel idempotent et on nettoie quand même le rendez-vous.
    update public.jkbat_client_appointments
       set live_location_active=false,
           technician_lat=null,
           technician_lng=null,
           technician_accuracy_m=null,
           technician_speed_mps=null,
           technician_heading=null,
           technician_location_at=null
     where staff_assignment_id=p_assignment_id;
    return;
  end if;

  delete from public.jkbat_live_tracking_tokens
   where assignment_id=p_assignment_id;

  update public.jkbat_client_appointments
     set live_location_active=false,
         technician_lat=null,
         technician_lng=null,
         technician_accuracy_m=null,
         technician_speed_mps=null,
         technician_heading=null,
         technician_location_at=null
   where staff_assignment_id=p_assignment_id;
end;
$$;

-- Nettoyage immédiat du jeton sécurisé si la mission quitte EN ROUTE.
create or replace function public.jkbat_clear_live_tracking_token_after_status()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if upper(trim(coalesce(new.status,''))) <> 'EN ROUTE' then
    delete from public.jkbat_live_tracking_tokens where assignment_id=new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_live_tracking_token_cleanup_trg on public.jkbat_staff_assignments;
create trigger jkbat_live_tracking_token_cleanup_trg
after insert or update of status on public.jkbat_staff_assignments
for each row execute function public.jkbat_clear_live_tracking_token_after_status();

revoke all on function public.jkbat_staff_begin_live_tracking(uuid) from public;
revoke all on function public.jkbat_live_update_location(uuid,text,double precision,double precision,numeric,numeric,numeric) from public;
revoke all on function public.jkbat_live_stop_location(uuid,text) from public;

grant execute on function public.jkbat_staff_begin_live_tracking(uuid) to authenticated;
grant execute on function public.jkbat_live_update_location(uuid,text,double precision,double precision,numeric,numeric,numeric) to anon, authenticated;
grant execute on function public.jkbat_live_stop_location(uuid,text) to anon, authenticated;

NOTIFY pgrst, 'reload schema';
