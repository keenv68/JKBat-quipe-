-- ============================================================
-- JKBat Stock & Matériel connecté — Pro 6.16.80 / Équipe 1.0.32
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
-- ============================================================

create extension if not exists pgcrypto;

create table if not exists public.jkbat_stock_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default '',
  unit text not null default 'u',
  qty numeric not null default 0,
  min_qty numeric not null default 0,
  purchase_price numeric not null default 0,
  sale_price numeric not null default 0,
  supplier text not null default '',
  note text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.jkbat_stock_usage (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.jkbat_staff_assignments(id) on delete cascade,
  item_id uuid not null references public.jkbat_stock_items(id) on delete restrict,
  staff_user_id uuid not null references auth.users(id) on delete cascade,
  qty_used numeric not null default 0 check (qty_used >= 0),
  qty_to_order numeric not null default 0 check (qty_to_order >= 0),
  note text not null default '',
  applied_at timestamptz,
  ordered_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(assignment_id,item_id)
);

create table if not exists public.jkbat_stock_movements (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.jkbat_stock_items(id) on delete restrict,
  assignment_id uuid references public.jkbat_staff_assignments(id) on delete set null,
  staff_user_id uuid references auth.users(id) on delete set null,
  delta numeric not null,
  reason text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists jkbat_stock_usage_assignment_idx on public.jkbat_stock_usage(assignment_id,created_at);
create index if not exists jkbat_stock_usage_order_idx on public.jkbat_stock_usage(ordered_at,qty_to_order);
create index if not exists jkbat_stock_movements_item_idx on public.jkbat_stock_movements(item_id,created_at desc);

alter table public.jkbat_stock_items enable row level security;
alter table public.jkbat_stock_usage enable row level security;
alter table public.jkbat_stock_movements enable row level security;

drop policy if exists "stock items admin all" on public.jkbat_stock_items;
drop policy if exists "stock items staff read" on public.jkbat_stock_items;
create policy "stock items admin all" on public.jkbat_stock_items
for all using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());
create policy "stock items staff read" on public.jkbat_stock_items
for select using (active=true and public.jkbat_staff_is_active(auth.uid()));

drop policy if exists "stock usage admin all" on public.jkbat_stock_usage;
drop policy if exists "stock usage staff read" on public.jkbat_stock_usage;
create policy "stock usage admin all" on public.jkbat_stock_usage
for all using (public.jkbat_is_admin()) with check (public.jkbat_is_admin());
create policy "stock usage staff read" on public.jkbat_stock_usage
for select using (
  public.jkbat_staff_is_active(auth.uid())
  and staff_user_id=auth.uid()
  and exists(select 1 from public.jkbat_staff_assignments a where a.id=assignment_id and a.staff_user_id=auth.uid())
);

drop policy if exists "stock movements admin read" on public.jkbat_stock_movements;
create policy "stock movements admin read" on public.jkbat_stock_movements
for select using (public.jkbat_is_admin());

create or replace function public.jkbat_staff_set_stock_usage(
  p_assignment_id uuid,
  p_item_id uuid,
  p_qty_used numeric default 0,
  p_qty_to_order numeric default 0,
  p_note text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text;
  v_used numeric := greatest(coalesce(p_qty_used,0),0);
  v_order numeric := greatest(coalesce(p_qty_to_order,0),0);
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,''))) into v_status
  from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;
  if v_status in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE') then raise exception 'stock usage locked after completion'; end if;
  if not exists(select 1 from public.jkbat_stock_items i where i.id=p_item_id and i.active=true) then raise exception 'stock item not found'; end if;

  if v_used=0 and v_order=0 and trim(coalesce(p_note,''))='' then
    delete from public.jkbat_stock_usage
    where assignment_id=p_assignment_id and item_id=p_item_id and staff_user_id=auth.uid() and applied_at is null;
    return;
  end if;

  insert into public.jkbat_stock_usage(assignment_id,item_id,staff_user_id,qty_used,qty_to_order,note,updated_at)
  values(p_assignment_id,p_item_id,auth.uid(),v_used,v_order,coalesce(p_note,''),now())
  on conflict(assignment_id,item_id) do update set
    qty_used=excluded.qty_used,
    qty_to_order=excluded.qty_to_order,
    note=excluded.note,
    staff_user_id=excluded.staff_user_id,
    updated_at=now()
  where public.jkbat_stock_usage.applied_at is null;
end;
$$;

create or replace function public.jkbat_admin_adjust_stock(
  p_item_id uuid,
  p_delta numeric,
  p_reason text default 'Ajustement manuel'
) returns numeric
language plpgsql
security definer
set search_path=public
as $$
declare v_qty numeric;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  update public.jkbat_stock_items set qty=qty+coalesce(p_delta,0),updated_at=now() where id=p_item_id returning qty into v_qty;
  if not found then raise exception 'stock item not found'; end if;
  if coalesce(p_delta,0)<>0 then
    insert into public.jkbat_stock_movements(item_id,delta,reason) values(p_item_id,p_delta,coalesce(nullif(trim(p_reason),''),'Ajustement manuel'));
  end if;
  return v_qty;
end;
$$;

create or replace function public.jkbat_admin_set_stock_ordered(
  p_usage_id uuid,
  p_ordered boolean default true
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  update public.jkbat_stock_usage set ordered_at=case when coalesce(p_ordered,true) then now() else null end,updated_at=now() where id=p_usage_id;
  if not found then raise exception 'order request not found'; end if;
end;
$$;

create or replace function public.jkbat_apply_stock_on_assignment_completion()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare u record;
begin
  if upper(trim(coalesce(new.status,''))) in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE')
     and upper(trim(coalesce(old.status,''))) not in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE') then
    for u in
      select su.* from public.jkbat_stock_usage su
      where su.assignment_id=new.id and su.applied_at is null
      for update
    loop
      if coalesce(u.qty_used,0)>0 then
        update public.jkbat_stock_items set qty=qty-u.qty_used,updated_at=now() where id=u.item_id;
        insert into public.jkbat_stock_movements(item_id,assignment_id,staff_user_id,delta,reason)
        values(u.item_id,new.id,u.staff_user_id,-u.qty_used,'Utilisé sur intervention terminée');
      end if;
      update public.jkbat_stock_usage set applied_at=now(),updated_at=now() where id=u.id;
    end loop;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_apply_stock_on_completion_trg on public.jkbat_staff_assignments;
create trigger jkbat_apply_stock_on_completion_trg
after update of status on public.jkbat_staff_assignments
for each row execute function public.jkbat_apply_stock_on_assignment_completion();

revoke all on function public.jkbat_staff_set_stock_usage(uuid,uuid,numeric,numeric,text) from public;
revoke all on function public.jkbat_admin_adjust_stock(uuid,numeric,text) from public;
revoke all on function public.jkbat_admin_set_stock_ordered(uuid,boolean) from public;
grant execute on function public.jkbat_staff_set_stock_usage(uuid,uuid,numeric,numeric,text) to authenticated;
grant execute on function public.jkbat_admin_adjust_stock(uuid,numeric,text) to authenticated;
grant execute on function public.jkbat_admin_set_stock_ordered(uuid,boolean) to authenticated;
