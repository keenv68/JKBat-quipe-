-- ============================================================
-- JKBat — Suivi intervention en direct v1.3.4
-- Pro 6.16.85 / PC 6.17.38 / Équipe 1.0.34 / Client 1.3.12
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
-- ============================================================

alter table public.jkbat_client_appointments
  add column if not exists staff_assignment_id uuid references public.jkbat_staff_assignments(id) on delete set null,
  add column if not exists source_type text not null default '',
  add column if not exists source_id text not null default '',
  add column if not exists technician_name text not null default '',
  add column if not exists tracking_status text not null default 'PLANIFIÉ',
  add column if not exists tracking_updated_at timestamptz,
  add column if not exists en_route_at timestamptz,
  add column if not exists on_site_at timestamptz,
  add column if not exists intervention_completed_at timestamptz;

create index if not exists jkbat_client_appointments_staff_assignment_idx
  on public.jkbat_client_appointments(staff_assignment_id);
create index if not exists jkbat_client_appointments_source_idx
  on public.jkbat_client_appointments(source_type,source_id);

create or replace function public.jkbat_tracking_label_from_staff(p_status text)
returns text
language sql
immutable
as $$
  select case
    when upper(trim(coalesce(p_status,''))) in ('EN ROUTE') then 'EN ROUTE'
    when upper(trim(coalesce(p_status,''))) in ('SUR PLACE','EN COURS') then 'SUR PLACE'
    when upper(trim(coalesce(p_status,''))) in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE') then 'TERMINÉE'
    when upper(trim(coalesce(p_status,'')))='IMPOSSIBLE' then 'IMPOSSIBLE'
    else 'PLANIFIÉ'
  end;
$$;

create or replace function public.jkbat_sync_staff_tracking_to_client()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tracking text;
  v_staff_name text := '';
  v_appt record;
  v_conv uuid;
  v_body text;
  v_old_tracking text := '';
begin
  v_tracking := public.jkbat_tracking_label_from_staff(new.status);
  select coalesce(p.full_name,p.email,'') into v_staff_name
    from public.jkbat_staff_profiles p where p.id=new.staff_user_id;

  update public.jkbat_client_appointments a
     set staff_assignment_id=new.id,
         technician_name=coalesce(nullif(v_staff_name,''),a.technician_name),
         tracking_status=v_tracking,
         tracking_updated_at=now(),
         en_route_at=case when v_tracking='EN ROUTE' then coalesce(a.en_route_at,now()) else a.en_route_at end,
         on_site_at=case when v_tracking='SUR PLACE' then coalesce(a.on_site_at,now()) else a.on_site_at end,
         intervention_completed_at=case when v_tracking='TERMINÉE' then coalesce(a.intervention_completed_at,now()) else a.intervention_completed_at end
   where a.staff_assignment_id=new.id
      or (
        nullif(trim(coalesce(a.source_type,'')),'') is not null
        and upper(trim(a.source_type))=upper(trim(coalesce(new.source_type,'')))
        and a.source_id=coalesce(new.source_id,'')
      );

  if tg_op='UPDATE' then
    v_old_tracking:=public.jkbat_tracking_label_from_staff(old.status);
  end if;

  -- Message automatique côté client : le webhook push existant sur jkbat_messages
  -- transforme ce message en notification Android sans nouvelle Edge Function.
  if v_tracking is distinct from v_old_tracking
     and v_tracking in ('EN ROUTE','SUR PLACE','TERMINÉE','IMPOSSIBLE') then
    for v_appt in
      select a.id,a.client_id,a.title,a.start_at,a.technician_name
      from public.jkbat_client_appointments a
      where a.staff_assignment_id=new.id
    loop
      begin
        select c.id into v_conv
          from public.jkbat_conversations c
         where c.client_id=v_appt.client_id
         order by c.created_at asc
         limit 1;
        if v_conv is not null then
          v_body:=case v_tracking
            when 'EN ROUTE' then '🚗 Votre technicien '||coalesce(nullif(v_appt.technician_name,''),'JKBat')||' est en route pour votre rendez-vous « '||coalesce(v_appt.title,'Intervention')||' ».'
            when 'SUR PLACE' then '📍 Votre technicien est arrivé sur place. L’intervention « '||coalesce(v_appt.title,'Intervention')||' » peut commencer.'
            when 'TERMINÉE' then '✅ Votre intervention « '||coalesce(v_appt.title,'Intervention')||' » est terminée. Les documents seront disponibles dans votre espace JKBat.'
            else '⚠️ Votre intervention « '||coalesce(v_appt.title,'Intervention')||' » nécessite une mise à jour. JKBat vous recontactera si nécessaire.'
          end;
          insert into public.jkbat_messages(conversation_id,sender_id,sender_role,body)
          values(v_conv,new.staff_user_id,'business',v_body);
        end if;
      exception when others then
        null;
      end;
    end loop;
  end if;

  return new;
end;
$$;

drop trigger if exists jkbat_staff_tracking_client_trg on public.jkbat_staff_assignments;
create trigger jkbat_staff_tracking_client_trg
after insert or update of status,staff_user_id,source_type,source_id on public.jkbat_staff_assignments
for each row execute function public.jkbat_sync_staff_tracking_to_client();

-- Les contrats récurrents disposent déjà d'un rendez-vous Client et d'une mission Équipe.
-- Ce trigger relie explicitement les deux dès qu'un passage est programmé.
create or replace function public.jkbat_link_maintenance_visit_tracking()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text := 'PLANIFIÉ';
  v_name text := coalesce(new.technician_name,'');
begin
  if new.client_appointment_id is null then return new; end if;

  if new.staff_assignment_id is not null then
    select public.jkbat_tracking_label_from_staff(a.status),
           coalesce(nullif(v_name,''),p.full_name,p.email,'')
      into v_status,v_name
      from public.jkbat_staff_assignments a
      left join public.jkbat_staff_profiles p on p.id=a.staff_user_id
     where a.id=new.staff_assignment_id;
  end if;

  update public.jkbat_client_appointments
     set staff_assignment_id=new.staff_assignment_id,
         source_type='CONTRAT',
         source_id=new.id::text,
         technician_name=coalesce(v_name,''),
         tracking_status=coalesce(v_status,'PLANIFIÉ'),
         tracking_updated_at=now()
   where id=new.client_appointment_id;
  return new;
end;
$$;

drop trigger if exists jkbat_maintenance_visit_tracking_trg on public.jkbat_maintenance_visits;
create trigger jkbat_maintenance_visit_tracking_trg
after insert or update of staff_assignment_id,staff_user_id,technician_name,client_appointment_id,status
on public.jkbat_maintenance_visits
for each row execute function public.jkbat_link_maintenance_visit_tracking();

-- Recalage des rendez-vous déjà liés avant l'installation de ce patch.
update public.jkbat_client_appointments a
   set staff_assignment_id=v.staff_assignment_id,
       source_type='CONTRAT',
       source_id=v.id::text,
       technician_name=coalesce(v.technician_name,''),
       tracking_status=coalesce(public.jkbat_tracking_label_from_staff(s.status),'PLANIFIÉ'),
       tracking_updated_at=now(),
       en_route_at=case when public.jkbat_tracking_label_from_staff(s.status)='EN ROUTE' then coalesce(a.en_route_at,s.started_at,now()) else a.en_route_at end,
       on_site_at=case when public.jkbat_tracking_label_from_staff(s.status)='SUR PLACE' then coalesce(a.on_site_at,s.started_at,now()) else a.on_site_at end,
       intervention_completed_at=case when public.jkbat_tracking_label_from_staff(s.status)='TERMINÉE' then coalesce(a.intervention_completed_at,s.completed_at,now()) else a.intervention_completed_at end
  from public.jkbat_maintenance_visits v
  left join public.jkbat_staff_assignments s on s.id=v.staff_assignment_id
 where a.id=v.client_appointment_id;

NOTIFY pgrst, 'reload schema';
