-- JKBat v1.0.21 / Pro 6.16.62 / Client 1.3.9
-- Harmonisation fiche Équipe -> Pro + retrait d'un document côté client sans supprimer la copie interne.

alter table public.jkbat_staff_reports
  add column if not exists result text,
  add column if not exists recommendation text,
  add column if not exists client_observations text;

alter table public.jkbat_client_documents
  add column if not exists client_visible boolean not null default true,
  add column if not exists removed_from_client_at timestamptz,
  add column if not exists removed_from_client_by uuid;

create index if not exists jkbat_client_documents_visible_idx
  on public.jkbat_client_documents(client_id,client_visible,created_at desc);

create or replace function public.jkbat_staff_save_report_v121(
  p_assignment_id uuid,
  p_report text default '',
  p_issue text default '',
  p_materials text default '',
  p_result text default '',
  p_recommendation text default '',
  p_client_observations text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_assignment_status text;
  v_old public.jkbat_staff_reports%rowtype;
  v_exists boolean := false;
  v_changed boolean := false;
  v_new_status text := 'BROUILLON';
  v_revision integer := 0;
  v_validated_at timestamptz := null;
  v_report text := coalesce(p_report,'');
  v_issue text := coalesce(p_issue,'');
  v_materials text := coalesce(p_materials,'');
  v_result text := coalesce(p_result,'');
  v_recommendation text := coalesce(p_recommendation,'');
  v_client_observations text := coalesce(p_client_observations,'');
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,''))) into v_assignment_status
  from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;

  select r.* into v_old
  from public.jkbat_staff_reports r
  where r.assignment_id=p_assignment_id;
  v_exists:=found;

  if v_exists then
    v_changed :=
      v_old.report is distinct from v_report or
      v_old.issue is distinct from v_issue or
      v_old.materials is distinct from v_materials or
      v_old.result is distinct from v_result or
      v_old.recommendation is distinct from v_recommendation or
      v_old.client_observations is distinct from v_client_observations;
    v_revision := greatest(coalesce(v_old.revision,0),0);
    v_validated_at := v_old.validated_at;
  else
    v_changed:=true;
  end if;

  if v_assignment_status='TERMINÉE' and trim(v_report)='' then
    raise exception 'report required';
  end if;

  if trim(v_report)<>'' and v_assignment_status in ('SUR PLACE','EN COURS','TERMINÉE') then
    if v_exists and coalesce(v_old.report_status,'BROUILLON') in ('VALIDÉ','MISE À JOUR') and v_changed then
      v_new_status:='MISE À JOUR';
      v_revision:=greatest(v_revision,1)+1;
      v_validated_at:=coalesce(v_validated_at,now());
    elsif v_exists and coalesce(v_old.report_status,'BROUILLON')='MISE À JOUR' then
      v_new_status:='MISE À JOUR';
      v_revision:=greatest(v_revision,1);
      v_validated_at:=coalesce(v_validated_at,now());
    else
      v_new_status:='VALIDÉ';
      v_revision:=greatest(v_revision,1);
      v_validated_at:=coalesce(v_validated_at,now());
    end if;
  elsif v_exists then
    v_new_status:=coalesce(v_old.report_status,'BROUILLON');
  end if;

  insert into public.jkbat_staff_reports(
    assignment_id,staff_user_id,report,issue,materials,result,recommendation,client_observations,
    report_status,revision,validated_at,submitted_at,updated_at,
    client_signature,signer_name,signed_at,signature_revision,client_sent_at,
    client_document_id,client_document_path,staff_messages
  ) values(
    p_assignment_id,auth.uid(),v_report,v_issue,v_materials,v_result,v_recommendation,v_client_observations,
    v_new_status,v_revision,v_validated_at,
    case when v_new_status in ('VALIDÉ','MISE À JOUR') then now() else null end,now(),
    null,null,null,null,null,null,null,'[]'::jsonb
  )
  on conflict(assignment_id) do update set
    staff_user_id=excluded.staff_user_id,
    report=excluded.report,
    issue=excluded.issue,
    materials=excluded.materials,
    result=excluded.result,
    recommendation=excluded.recommendation,
    client_observations=excluded.client_observations,
    report_status=excluded.report_status,
    revision=excluded.revision,
    validated_at=excluded.validated_at,
    submitted_at=case when excluded.report_status in ('VALIDÉ','MISE À JOUR') then now() else public.jkbat_staff_reports.submitted_at end,
    client_signature=case when v_changed then null else public.jkbat_staff_reports.client_signature end,
    signer_name=case when v_changed then null else public.jkbat_staff_reports.signer_name end,
    signed_at=case when v_changed then null else public.jkbat_staff_reports.signed_at end,
    signature_revision=case when v_changed then null else public.jkbat_staff_reports.signature_revision end,
    client_sent_at=case when v_changed then null else public.jkbat_staff_reports.client_sent_at end,
    client_document_id=public.jkbat_staff_reports.client_document_id,
    client_document_path=public.jkbat_staff_reports.client_document_path,
    staff_messages=coalesce(public.jkbat_staff_reports.staff_messages,'[]'::jsonb),
    updated_at=now();
end;
$$;

create or replace function public.jkbat_admin_set_client_document_visibility(
  p_document_id uuid,
  p_visible boolean
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;

  update public.jkbat_client_documents
     set client_visible=coalesce(p_visible,false),
         removed_from_client_at=case when coalesce(p_visible,false) then null else now() end,
         removed_from_client_by=case when coalesce(p_visible,false) then null else auth.uid() end
   where id=p_document_id;

  if not found then raise exception 'document not found'; end if;
end;
$$;

-- Republier depuis JKBat Équipe rend automatiquement le PDF de nouveau visible côté client.
create or replace function public.jkbat_staff_publish_intervention_document(
  p_assignment_id uuid,p_title text,p_storage_path text
) returns uuid
language plpgsql security definer set search_path=public as $$
declare
  v_assignment public.jkbat_staff_assignments%rowtype;
  v_report public.jkbat_staff_reports%rowtype;
  v_client_id uuid;
  v_doc_id uuid;
  v_title text:=coalesce(nullif(trim(p_title),''),'Fiche d’intervention');
  v_expected_prefix text;
  v_conv_id uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select a.* into v_assignment from public.jkbat_staff_assignments a
  where a.id=p_assignment_id and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;

  select r.* into v_report from public.jkbat_staff_reports r
  where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
  if not found then raise exception 'report not found'; end if;

  if coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then raise exception 'report not validated'; end if;
  if v_report.client_signature is null or v_report.signed_at is null then raise exception 'client signature required'; end if;
  if coalesce(v_report.signature_revision,-1)<>coalesce(v_report.revision,0) then raise exception 'client signature outdated: new signature required'; end if;

  v_expected_prefix:='staff/'||auth.uid()::text||'/'||p_assignment_id::text||'/';
  if p_storage_path is null or position(v_expected_prefix in p_storage_path)<>1 or p_storage_path not like '%.pdf' then raise exception 'invalid document path'; end if;

  select x.id into v_client_id from public.jkbat_staff_client_for_assignment(p_assignment_id) x limit 1;
  if v_client_id is null then raise exception 'client account not linked'; end if;

  if v_report.client_document_id is not null
     and exists(select 1 from public.jkbat_client_documents d where d.id=v_report.client_document_id and d.client_id=v_client_id) then
    update public.jkbat_client_documents d
       set kind='Fiche d’intervention',title=v_title,status='Disponible',amount=null,
           file_url='storage:'||p_storage_path,client_visible=true,
           removed_from_client_at=null,removed_from_client_by=null
     where d.id=v_report.client_document_id
     returning d.id into v_doc_id;
  else
    insert into public.jkbat_client_documents(client_id,kind,title,status,amount,file_url,client_visible)
    values(v_client_id,'Fiche d’intervention',v_title,'Disponible',null,'storage:'||p_storage_path,true)
    returning id into v_doc_id;
  end if;

  update public.jkbat_staff_reports r
     set client_document_id=v_doc_id,client_document_path=p_storage_path,client_sent_at=now(),updated_at=now()
   where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();

  begin
    select c.id into v_conv_id from public.jkbat_conversations c
    where c.client_id=v_client_id order by c.created_at asc limit 1;
    if v_conv_id is not null then
      insert into public.jkbat_messages(conversation_id,sender_id,sender_role,body)
      values(v_conv_id,auth.uid(),'business','Nouvelle fiche d’intervention signée disponible : '||v_title);
    end if;
  exception when others then null;
  end;

  return v_doc_id;
end;
$$;

revoke all on function public.jkbat_staff_save_report_v121(uuid,text,text,text,text,text,text) from public;
revoke all on function public.jkbat_admin_set_client_document_visibility(uuid,boolean) from public;
revoke all on function public.jkbat_staff_publish_intervention_document(uuid,text,text) from public;

grant execute on function public.jkbat_staff_save_report_v121(uuid,text,text,text,text,text,text) to authenticated;
grant execute on function public.jkbat_admin_set_client_document_visibility(uuid,boolean) to authenticated;
grant execute on function public.jkbat_staff_publish_intervention_document(uuid,text,text) to authenticated;
