JKBat Équipe v1.0.8 — Signature obligatoire + envoi fiche client

Base reconstruite depuis l'APK RELEASE v1.0.6, avec les évolutions SQL v1.0.7 de reprogrammation conservées.

Nouveautés v1.0.8 :
- signature du client obligatoire avant envoi de la fiche PDF ;
- bouton d'envoi bloqué tant que la signature n'est pas enregistrée ;
- PDF de fiche d'intervention avec thème métier ;
- envoi sécurisé dans JKBat'Services > Mes documents ;
- remontée client_sent_at / signed_at dans le suivi JKBat Pro ;
- notification JKBat Pro via la Edge Function staff-report v1.0.8.

Ordre d'installation recommandé :
1. Exécuter JKBAT_EQUIPE_V108_SIGNATURE_ENVOI_CLIENT.sql dans Supabase SQL Editor.
2. Remplacer/déployer la Edge Function staff report avec JKBAT_STAFF_REPORT_PUSH_V108_EDGE_FUNCTION.txt.
3. Mettre à jour JKBat Pro mobile/PC.
4. Construire et installer JKBat Équipe v1.0.8.
