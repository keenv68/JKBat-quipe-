JKBat Équipe v1.0.9
- correction du Failed to fetch lors de la génération de la fiche PDF
- logo embarqué directement dans le générateur PDF
- messages d'erreur précisant l'étape d'envoi
- toutes les fonctions v1.0.8 conservées
