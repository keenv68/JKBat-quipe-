JKBat Équipe v1.0.10
- Bandeau inférieur harmonisé avec JKBat'Services et prise en compte de la barre de navigation Android.
- Impossible de terminer une mission sans signature client.
- Toute modification d'un rapport déjà validé devient une MISE À JOUR.
- Toute modification texte/photo invalide la signature : le client doit signer à nouveau.
- JKBat Pro est informé des validations, mises à jour, signatures et envois client via la Edge Function v1.0.10.
- Envoi PDF client conservé.
