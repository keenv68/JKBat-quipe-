JKBat Équipe v1.0.11

Correction ciblée du bandeau inférieur :
- barre de navigation visuellement alignée sur JKBat’Services ;
- textes et icônes plus lisibles ;
- onglet actif beige/or plus net ;
- séparation réelle entre le bandeau de l’application et les 3 boutons Android ;
- correctif Android 15 / targetSdk 35 contre l’edge-to-edge forcé.

Toutes les fonctions v1.0.10 sont conservées : signature obligatoire avant terminaison, mise à jour après modification, notifications JKBat Pro et envoi fiche client.
