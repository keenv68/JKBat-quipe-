JKBat Équipe v1.0.12
- signature liée au numéro de révision du rapport
- modification texte : envoi/terminaison immédiatement bloqués avant même l'enregistrement
- après enregistrement d'une modification : ancienne signature invalidée et nouvelle signature obligatoire
- messages du salarié vers JKBat Pro avec historique par mission et notification push
- bandeau Android corrigé de v1.0.11 conservé
