JKBat Équipe v1.0.13

- Messagerie JKBat Pro séparée de la fiche d’intervention : bouton compact dans la mission + fenêtre dédiée.
- Les champs du compte rendu restent visibles sans être coupés par l’historique des messages.
- Envoi de message via la Edge Function existante jkbat-push-staff-report-v104 en mode authentifié.
- Notification JKBat Pro envoyée directement après l’enregistrement du message, sans dépendre du webhook SQL pour les messages.
- Historique des messages conservé dans jkbat_staff_reports.staff_messages.
- Règles signature/révision v1.0.12 conservées.
