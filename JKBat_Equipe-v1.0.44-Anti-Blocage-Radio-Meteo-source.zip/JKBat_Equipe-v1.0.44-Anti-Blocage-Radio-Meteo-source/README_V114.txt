JKBat Équipe v1.0.14
- correction bouton fermer messagerie salarié -> JKBat Pro
- correction envoi Edge Function depuis Android (CORS)
- état d'envoi visible dans la fenêtre
- timeout réseau et erreurs visibles
- fonctionnalités v1.0.13 conservées
