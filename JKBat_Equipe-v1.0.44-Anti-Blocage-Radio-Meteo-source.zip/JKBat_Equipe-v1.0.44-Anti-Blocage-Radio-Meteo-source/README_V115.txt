JKBat Équipe v1.0.15
- suppression de l’appel direct fetch vers l’Edge Function depuis Android
- envoi message via RPC Supabase existante
- notification JKBat Pro déclenchée par le webhook jkbat_staff_reports
- fermeture de la fenêtre messagerie conservée
