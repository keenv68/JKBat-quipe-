JKBat Équipe v1.0.16

Corrections :
- notification message salarié -> JKBat Pro corrigée : la Edge Function surveille désormais le vrai champ staff_messages ;
- aucun nouveau SQL requis ;
- aucun nouveau webhook requis ;
- le message de confirmation vert disparaît automatiquement après quelques secondes ;
- conservation de la signature par révision, de la messagerie séparée et des règles de terminaison.
