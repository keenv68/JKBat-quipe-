JKBat Équipe v1.0.17
- Corrige 'assignment not found' après resynchronisation d'une tâche.
- La messagerie retrouve la mission active via source_type/source_id si l'UUID cloud a changé.
- Aucun nouveau SQL ni webhook requis si le SQL/Edge v1.0.17 est déjà installé.
