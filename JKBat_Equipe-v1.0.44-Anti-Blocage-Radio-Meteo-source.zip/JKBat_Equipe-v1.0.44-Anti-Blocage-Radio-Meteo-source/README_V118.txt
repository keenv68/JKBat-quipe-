JKBat Équipe v1.0.18
- Messagerie bidirectionnelle avec JKBat Pro
- Affichage des réponses JKBat Pro dans la conversation de mission
- Notifications des réponses via le webhook staff reports
