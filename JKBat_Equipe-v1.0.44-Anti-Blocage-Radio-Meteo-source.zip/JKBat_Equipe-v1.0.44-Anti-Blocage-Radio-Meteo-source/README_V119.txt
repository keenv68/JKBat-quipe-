JKBat Équipe v1.0.19
- Nouvelle icône Android Équipe blanche / or / bleu.
- Repère ÉQUIPE et symbole équipe pour la distinguer immédiatement de Pro et Client.
- Aucune modification fonctionnelle de la messagerie bidirectionnelle.
