JKBat Équipe v1.0.20

- Compatible avec la suppression des messages depuis JKBat Pro v6.16.50 / PC v6.17.23.
- Les messages supprimés « pour tous » disparaissent de la conversation salarié.
- Les événements techniques de suppression restent invisibles.
- Conserve l'icône JKBat Équipe bleue de v1.0.19.

À faire : exécuter JKBAT_EQUIPE_V120_SUPPRESSION_MESSAGES.sql dans Supabase.
