JKBat Équipe v1.0.21
- PDF de fiche d’intervention harmonisé avec le modèle JKBat Pro.
- Même découpage : Constat / diagnostic, Travaux réalisés, Résultat / contrôle final, Préconisations, Matériel / pièces, Observations client, signature.
- Métier et code couleur conservés dans le PDF.
- Boutons Appeler / Message / Itinéraire harmonisés.
- Les nouvelles rubriques participent à la révision du rapport et invalident la signature en cas de modification.
- Nécessite le SQL JKBAT_V121_COHERENCE_EQUIPE_DOCUMENTS.sql.
