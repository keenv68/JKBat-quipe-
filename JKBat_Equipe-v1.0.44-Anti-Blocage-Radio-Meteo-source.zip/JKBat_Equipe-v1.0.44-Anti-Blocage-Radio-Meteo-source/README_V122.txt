JKBat Équipe v1.0.22 — Bulle Contacter JKBat

- Ajout d’une bulle flottante « Contacter JKBat » au-dessus de la navigation.
- Si une seule mission est disponible, la conversation JKBat Pro s’ouvre directement.
- Si plusieurs missions sont disponibles, le salarié choisit la mission concernée.
- Réutilise la messagerie bidirectionnelle existante et les notifications push.
- Les suppressions faites depuis JKBat Pro restent synchronisées : un message supprimé pour tous disparaît aussi côté Équipe.
- Aucun nouveau SQL requis.
