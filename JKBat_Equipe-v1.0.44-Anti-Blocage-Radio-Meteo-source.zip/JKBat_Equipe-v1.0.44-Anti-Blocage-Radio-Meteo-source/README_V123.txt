JKBat Équipe v1.0.23

- Bulle Contacter JKBat utilisable sans ouvrir de fiche d’intervention.
- Conversation générale : l’application utilise automatiquement la mission la plus pertinente en arrière-plan, afin de conserver la compatibilité avec la messagerie et la suppression depuis JKBat Pro.
- Badge rouge avec le nombre de messages JKBat Pro non lus.
- Ouverture de la conversation directe lors d’un clic sur une notification de message.
- Actualisation des messages en premier plan + vérification périodique légère.
- Bouton symbole ↻ permanent dans l’en-tête pour actualiser l’application.
- Notifications Android conservées via le flux Firebase/Edge Function existant.
- Aucun nouveau SQL requis.
