JKBat Équipe v1.0.24

- Repositionnement de la bulle « Contacter JKBat ».
- Position fixe en bas à droite, juste au-dessus de la navigation.
- La bulle reste accessible sur Accueil, Planning, Interventions et Compte.
- Fonctionne même sans fiche / mission ouverte.
- Badge de messages non lus et notifications conservés.
- Bouton ↻ d’actualisation conservé.
- Aucun changement SQL requis.
