JKBat Équipe v1.0.25 — Correctif Contacter JKBat

- Corrige la bulle « Contacter JKBat » visible mais inactive en v1.0.24.
- Cause : les helpers de messagerie étaient privés dans une IIFE, tandis que la conversation générale les appelait depuis un autre bloc JavaScript.
- Les helpers nécessaires sont désormais explicitement exposés au module de conversation générale.
- La bulle reste fixe en bas à droite, fonctionne sans fiche ouverte et conserve le badge de non-lus.
- Le bouton Actualiser et les notifications sont conservés.
- Aucun nouveau SQL ni changement d’Edge Function requis.
