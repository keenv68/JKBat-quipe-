JKBat Équipe v1.0.26 — Messagerie générale sans mission

- « Contacter JKBat » permet d’envoyer un message même sans fiche ou mission active.
- Une conversation technique dédiée est créée automatiquement en arrière-plan et reste invisible du planning salarié.
- Badge, notifications et suppression pour tous depuis JKBat Pro restent compatibles.
- Exécuter une seule fois JKBAT_EQUIPE_V126_MESSAGERIE_GENERALE.sql dans Supabase.
