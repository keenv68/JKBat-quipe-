JKBat Équipe v1.0.27 — Terminer la mission en bas

Modification :
- le bouton « Terminer la mission » n’est plus affiché dans les actions en haut de la fiche ;
- il est placé tout en bas, juste sous le bloc signature / envoi de la fiche PDF client ;
- il reste bloqué tant que le compte rendu n’est pas validé, que la signature n’est pas valable, que des modifications ne sont pas enregistrées, ou que la fiche signée n’a pas été envoyée au client ;
- après « Terminer la mission », la fenêtre de la mission se ferme automatiquement ;
- aucune modification Supabase / SQL n’est nécessaire pour cette mise à jour.

Base : JKBat Équipe v1.0.26.
