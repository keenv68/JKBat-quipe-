JKBat Équipe v1.0.28 — Correctif bouton Terminer la mission

Correctif de la v1.0.27 :
- le bouton « ✓ Terminer la mission » est toujours rendu juste sous le bloc « Fiche PDF client » ;
- il reste visible mais désactivé tant que les conditions ne sont pas remplies ;
- il devient actif uniquement si la mission est Sur place, le rapport est validé, aucune modification n'est en attente, la signature est valide et la fiche PDF signée a été envoyée au client ;
- après terminaison réussie, la fenêtre de mission se ferme automatiquement ;
- le bouton Terminer n'apparaît plus dans les actions du haut.

Aucun SQL Supabase supplémentaire n'est nécessaire.
