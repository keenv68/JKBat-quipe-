JKBat Équipe v1.0.30 — Correctif définitif bouton Terminer

- Le bouton « Terminer la mission » est injecté uniquement sous le bloc « Fiche PDF client ».
- Le correctif ne dépend plus des fonctions privées de la messagerie/signature des anciennes versions.
- Un MutationObserver attend réellement l’apparition asynchrone du bloc PDF avant d’ajouter le bouton.
- Le bouton est toujours visible sous le PDF tant que la mission n’est pas terminée.
- Il devient actif uniquement si : mission Sur place + compte rendu validé + aucune modification non enregistrée + signature valide + fiche PDF envoyée.
- Après clic : passage en Terminée puis fermeture automatique de la fenêtre.
- Aucun SQL Supabase supplémentaire.
