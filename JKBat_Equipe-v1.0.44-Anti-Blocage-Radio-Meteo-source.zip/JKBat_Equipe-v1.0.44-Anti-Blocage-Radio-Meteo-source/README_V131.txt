JKBat Équipe v1.0.31 — Correctif scroll mission + bouton Terminer

- Corrige le blocage du défilement dans la fiche mission apparu en v1.0.30.
- Cause : le MutationObserver du bouton Terminer pouvait se relancer en boucle lors des mises à jour du DOM.
- L’observer est désormais temporaire : il attend seulement l’apparition de la fiche PDF, place le bouton, puis se déconnecte.
- Le bouton « ✓ Terminer la mission » reste sous « Fiche PDF client », après signature/envoi.
- La mission se ferme automatiquement après terminaison.
- Aucun nouveau SQL Supabase requis.
