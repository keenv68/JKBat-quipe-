JKBat Équipe v1.0.32 — Stock & matériel
- Sélection des articles du stock JKBat dans chaque mission.
- Quantité utilisée + quantité à commander + note.
- Transmission immédiate à JKBat Pro.
- Stock déduit automatiquement au clic Terminer la mission.
- Données verrouillées après terminaison.
- Requiert JKBAT_STOCK_MATERIEL_V132.sql exécuté une fois dans Supabase.
