JKBat Équipe v1.0.33 — Contrats & entretiens
- Les missions issues d'un contrat sont identifiées comme ENTRETIEN RÉCURRENT.
- Affichage du contrat, fréquence et consignes dans la fiche mission.
- La terminaison d'un passage déclenche automatiquement la prochaine échéance côté JKBat Pro via Supabase.
- SQL partagé : JKBAT_CONTRATS_ENTRETIENS_V133.sql
