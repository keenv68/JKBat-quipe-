JKBat Équipe v1.0.34
- Contrats/récurrences visibles dans le planning salarié.
- Badge Suivi client en direct.
- En route / Sur place / Terminée sont transmis au client via SQL v1.3.4.
