JKBat Équipe v1.0.35 — GPS LIVE
- Le bouton « En route » démarre un service Android de localisation au premier plan.
- Permission localisation demandée au technicien au premier usage.
- Position envoyée environ toutes les 10 à 15 secondes tant que la mission est EN ROUTE.
- Le partage continue écran verrouillé / application en arrière-plan grâce au service de premier plan.
- Le bouton « Je suis sur place », la fin de mission ou un statut impossible arrête le partage.
- Une notification Android permanente signale clairement que la localisation est active.
- La base ne conserve que la position courante; elle est effacée à l'arrivée.
