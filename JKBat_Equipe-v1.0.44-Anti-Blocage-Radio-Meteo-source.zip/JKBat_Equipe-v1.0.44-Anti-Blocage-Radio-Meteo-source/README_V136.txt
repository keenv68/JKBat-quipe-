JKBat Équipe v1.0.36 — GPS session stable

Correctif principal
- Le suivi GPS n'utilise plus directement le jeton de session Supabase du salarié pour chaque position.
- Au passage « En route », l'application demande au serveur un jeton GPS temporaire propre à la mission.
- Ce jeton reste valable jusqu'à 12 heures maximum et ne permet que l'envoi de la position de cette mission.
- Ainsi, l'expiration/renouvellement du jeton de connexion JKBat ne coupe plus le trajet GPS après quelques dizaines de minutes.
- Le jeton GPS et la position précise sont invalidés/effacés quand la mission quitte le statut EN ROUTE.

À exécuter avant test
- JKBAT_GPS_SESSION_STABLE_V137.sql (une fois dans Supabase)

Compatibilité
- JKBat Client v1.3.14 peut rester installé.
- JKBat Pro v6.16.86 / PC v6.17.39 peuvent rester installés.
