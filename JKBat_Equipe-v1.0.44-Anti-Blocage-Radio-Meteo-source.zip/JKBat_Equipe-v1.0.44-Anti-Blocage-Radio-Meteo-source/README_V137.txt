JKBat Équipe v1.0.37 — GPS robuste + diagnostic réel

Correctifs GPS
- Remplace le suivi brut Android LocationManager par Google Fused Location Provider.
- Demande une position actuelle immédiatement au passage « En route », même si le téléphone ne bouge pas.
- Maintient les mises à jour toutes les quelques secondes et relance une recherche de position si aucun fix récent n'arrive.
- Conserve le service de premier plan pendant le trajet.
- Le bloc GPS de la mission n'affiche plus seulement un état théorique : il indique maintenant si une position a réellement été envoyée au serveur, l'heure relative, la précision ou l'erreur réelle.
- Les erreurs HTTP Supabase ne sont plus ignorées silencieusement.

Supabase
- Compatible avec JKBAT_GPS_SESSION_STABLE_V137.sql déjà fourni avec v1.0.36.
- Si ce SQL n'a jamais été exécuté, l'exécuter une fois avant le test.

Compatibilité
- Client conseillé : JKBat Client v1.3.15.
- JKBat Pro v6.16.86 / PC v6.17.39 peuvent rester installés.
