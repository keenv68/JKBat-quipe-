JKBat Équipe v1.0.38 — GPS Design harmonisé

Base: v1.0.37 GPS Robuste.
Aucune modification du moteur GPS validé.

Évolutions visuelles:
- bloc Suivi client modernisé;
- bloc GPS harmonisé avec JKBat’Services;
- état GPS plus lisible (en attente / actif / erreur);
- puce EN DIRECT / EN ATTENTE;
- actions de mission légèrement modernisées;
- conservation du suivi GPS robuste et du correctif Supabase pgcrypto V138.

Le fichier JKBAT_GPS_FIX_PGCRYPTO_V138.sql est inclus dans la source.
