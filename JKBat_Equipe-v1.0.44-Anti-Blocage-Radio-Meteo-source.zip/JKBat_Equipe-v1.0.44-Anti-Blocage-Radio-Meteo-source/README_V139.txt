JKBat Équipe v1.0.39 — Contrats types & couleurs

- Les missions issues d'un contrat reprennent la couleur, l'icône, la famille et la formule.
- Le détail de mission affiche les prestations incluses du contrat.
- GPS et suivi client de la v1.0.38 conservés.
- Exécuter JKBAT_CONTRATS_TYPES_COULEURS_V139.sql une fois.
