JKBat Équipe v1.0.40 — PDF signé vers JKBat Pro

- Dès qu'un client signe la fiche d'intervention sur le téléphone du salarié, l'exemplaire PDF signé est généré et archivé automatiquement dans JKBat Pro.
- Cette remontée vers JKBat Pro est indépendante de l'envoi de la copie au client.
- Le bloc Fiche PDF client affiche « Exemplaire signé reçu dans JKBat Pro » lorsque l'archivage est terminé.
- Si l'archivage échoue (réseau / SQL non installé), un bouton « Renvoyer vers JKBat Pro » permet de relancer sans refaire signer le client.
- Une nouvelle révision du rapport impose toujours une nouvelle signature et produit un nouvel exemplaire signé.

SQL requis : JKBAT_INTERVENTION_SIGNEE_VERS_PRO_V152.txt
