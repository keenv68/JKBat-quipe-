JKBat Équipe v1.0.41
- Correction du bouton Enregistrer la signature client.
- Cause : le wrapper v1.0.40 référençait une variable locale sigAssignment107 inaccessible.
- L'identifiant de mission est désormais exposé de façon sûre via window.sigAssignment107.
- La signature est enregistrée avant l'archivage automatique du PDF signé vers JKBat Pro.
- Aucun nouveau SQL requis.
