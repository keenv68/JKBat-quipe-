JKBat Équipe v1.0.42 — Radio + météo

Base : v1.0.41 Signature Validation Fix.

Ajouts :
- météo actuelle sur l’accueil avec heure, position téléphone ou ville/code postal manuel ;
- cache météo 15 minutes via Open-Meteo ;
- carte Radio JKBat visible sur l’accueil ;
- recherche de stations françaises, favoris, lecture/pause/stop ;
- mini lecteur radio persistant dans l’application ;
- accès Radio JKBat également depuis Mon compte ;
- prise en charge WebView de la géolocalisation et de la lecture média.

Inchangés : planning, interventions, signatures, GPS live, messages, push, PDF et synchronisation JKBat Pro.
