JKBat Équipe v1.0.43 — Correctif connexion + Radio/Météo

- Restauration de session renforcée via refresh token.
- Reconstruction automatique de l’utilisateur Supabase si le cache local est incomplet.
- La météo et la radio ne s’initialisent plus sur l’écran de connexion.
- Le bouton de connexion affiche un état Connexion… et les erreurs sont visibles.
- Toutes les fonctions v1.0.41/v1.0.42 restent conservées.
