JKBat Équipe v1.0.44 — Anti-blocage connexion + Radio/Météo

Correctifs :
- La restauration automatique de session ne peut plus bloquer l'écran indéfiniment.
- Timeout réseau sur l'authentification Supabase.
- Reconnexion automatique limitée ; retour forcé vers un écran de connexion utilisable.
- La connexion manuelle reste disponible même pendant/à la suite d'une tentative de restauration.
- Protection contre les anciennes tentatives de reconnexion qui termineraient après une connexion manuelle.
- Une réponse 401 ne peut plus relancer indéfiniment la boucle de refresh token.
- Radio et météo ne sont initialisées qu'après ouverture réelle de l'espace salarié.
- Conservation des fonctions v1.0.41/v1.0.42 : planning, interventions, signatures, PDF, GPS, messages, synchronisation, radio et météo.
