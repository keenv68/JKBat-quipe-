package com.jkbat.equipe;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LiveLocationService extends Service {
  public static final String ACTION_START = "com.jkbat.equipe.START_LIVE_LOCATION";
  public static final String ACTION_STOP = "com.jkbat.equipe.STOP_LIVE_LOCATION";
  private static final String CHANNEL_ID = "jkbat_live_location";
  private static final int NOTIFICATION_ID = 13701;
  private static final String PREFS = "jkbat_live_location";

  private FusedLocationProviderClient fused;
  private LocationCallback callback;
  private Handler handler;
  private final ExecutorService network = Executors.newSingleThreadExecutor();
  private String assignmentId = "", supabaseUrl = "", anonKey = "", trackingToken = "";
  private long lastSendAt = 0L;
  private long lastFixAt = 0L;
  private boolean updatesStarted = false;

  private final Runnable heartbeat = new Runnable() {
    @Override public void run() {
      if (!assignmentId.isEmpty()) {
        long now = System.currentTimeMillis();
        if (now - lastFixAt > 15000L) requestFreshLocation();
        handler.postDelayed(this, 15000L);
      }
    }
  };

  @Override public void onCreate() {
    super.onCreate();
    fused = LocationServices.getFusedLocationProviderClient(this);
    handler = new Handler(Looper.getMainLooper());
    callback = new LocationCallback() {
      @Override public void onLocationResult(LocationResult result) {
        if (result == null) return;
        Location location = result.getLastLocation();
        if (location != null) handleLocation(location);
      }
    };
    createChannel();
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    String action = intent == null ? "" : intent.getAction();
    if (ACTION_STOP.equals(action)) {
      restoreCredentials();
      if (intent != null) {
        String incomingId = safe(intent.getStringExtra("assignment_id"));
        String incomingToken = safe(intent.getStringExtra("tracking_token"));
        if (!incomingId.isEmpty()) assignmentId = incomingId;
        if (!incomingToken.isEmpty()) trackingToken = incomingToken;
      }
      stopTracking(true);
      return START_NOT_STICKY;
    }

    if (intent != null) {
      assignmentId = safe(intent.getStringExtra("assignment_id"));
      supabaseUrl = safe(intent.getStringExtra("supabase_url"));
      anonKey = safe(intent.getStringExtra("anon_key"));
      trackingToken = safe(intent.getStringExtra("tracking_token"));
      saveCredentials();
    } else {
      restoreCredentials();
    }

    if (assignmentId.isEmpty() || supabaseUrl.isEmpty() || anonKey.isEmpty() || trackingToken.isEmpty()) {
      setError("Paramètres GPS incomplets");
      stopSelf();
      return START_NOT_STICKY;
    }

    startForeground(NOTIFICATION_ID, buildNotification());
    setRunning(true);
    startLocationUpdates();
    return START_STICKY;
  }

  private boolean hasLocationPermission() {
    if (Build.VERSION.SDK_INT < 23) return true;
    return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
      || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
  }

  private void startLocationUpdates() {
    if (!hasLocationPermission()) {
      setError("Autorisation de localisation refusée");
      stopTracking(false);
      return;
    }

    try {
      if (!updatesStarted) {
        LocationRequest request = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 7000L)
          .setMinUpdateIntervalMillis(4000L)
          .setMaxUpdateDelayMillis(10000L)
          .setMinUpdateDistanceMeters(0f)
          .setWaitForAccurateLocation(false)
          .build();
        fused.requestLocationUpdates(request, callback, Looper.getMainLooper())
          .addOnFailureListener(e -> setError("Démarrage GPS impossible : " + safeMessage(e)));
        updatesStarted = true;
      }
      requestFreshLocation();
      handler.removeCallbacks(heartbeat);
      handler.postDelayed(heartbeat, 12000L);
    } catch (SecurityException e) {
      setError("Autorisation GPS manquante");
    } catch (Exception e) {
      setError("Erreur GPS : " + safeMessage(e));
    }
  }

  private void requestFreshLocation() {
    if (!hasLocationPermission()) return;
    try {
      CancellationTokenSource cts = new CancellationTokenSource();
      fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
        .addOnSuccessListener(location -> {
          if (location != null) handleLocation(location);
          else tryRecentLastLocation();
        })
        .addOnFailureListener(e -> {
          setError("Position actuelle indisponible : " + safeMessage(e));
          tryRecentLastLocation();
        });
    } catch (SecurityException e) {
      setError("Autorisation GPS manquante");
    } catch (Exception e) {
      setError("Lecture GPS impossible : " + safeMessage(e));
    }
  }

  private void tryRecentLastLocation() {
    if (!hasLocationPermission()) return;
    try {
      fused.getLastLocation().addOnSuccessListener(location -> {
        if (location == null) return;
        long age = Math.max(0L, System.currentTimeMillis() - location.getTime());
        if (age <= 120000L) handleLocation(location);
      }).addOnFailureListener(e -> setError("Aucune position GPS récente"));
    } catch (SecurityException ignored) {}
  }

  private void handleLocation(Location location) {
    if (location == null) return;
    if (location.hasAccuracy() && location.getAccuracy() > 1000f) {
      setError("Précision GPS insuffisante (" + Math.round(location.getAccuracy()) + " m)");
      return;
    }
    lastFixAt = System.currentTimeMillis();
    long now = System.currentTimeMillis();
    if (now - lastSendAt < 5000L) return;
    lastSendAt = now;
    sendLocation(location);
  }

  private void sendLocation(Location l) {
    final double lat = l.getLatitude(), lng = l.getLongitude();
    final double accuracy = l.hasAccuracy() ? l.getAccuracy() : 0d;
    final double speed = l.hasSpeed() ? l.getSpeed() : 0d;
    final double bearing = l.hasBearing() ? l.getBearing() : 0d;
    network.execute(() -> {
      try {
        JSONObject body = new JSONObject();
        body.put("p_assignment_id", assignmentId);
        body.put("p_tracking_token", trackingToken);
        body.put("p_lat", lat);
        body.put("p_lng", lng);
        body.put("p_accuracy", accuracy);
        body.put("p_speed", speed);
        body.put("p_heading", bearing);
        postAnonRpc(supabaseUrl + "/rest/v1/rpc/jkbat_live_update_location", anonKey, body.toString());
        SharedPreferences.Editor e = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
        e.putBoolean("running", true)
          .putLong("last_success_at", System.currentTimeMillis())
          .putLong("last_fix_at", l.getTime())
          .putString("last_error", "")
          .putLong("last_lat_bits", Double.doubleToRawLongBits(lat))
          .putLong("last_lng_bits", Double.doubleToRawLongBits(lng))
          .putFloat("last_accuracy", (float)accuracy)
          .apply();
      } catch (Exception e) {
        setError("Envoi serveur impossible : " + safeMessage(e));
      }
    });
  }

  private void sendStop() {
    if (assignmentId.isEmpty() || supabaseUrl.isEmpty() || anonKey.isEmpty() || trackingToken.isEmpty()) return;
    network.execute(() -> {
      try {
        JSONObject body = new JSONObject();
        body.put("p_assignment_id", assignmentId);
        body.put("p_tracking_token", trackingToken);
        postAnonRpc(supabaseUrl + "/rest/v1/rpc/jkbat_live_stop_location", anonKey, body.toString());
      } catch (Exception ignored) {}
    });
  }

  private static void postAnonRpc(String target, String key, String body) throws Exception {
    HttpURLConnection c = (HttpURLConnection)new URL(target).openConnection();
    c.setConnectTimeout(10000);
    c.setReadTimeout(10000);
    c.setRequestMethod("POST");
    c.setDoOutput(true);
    c.setRequestProperty("apikey", key);
    c.setRequestProperty("Authorization", "Bearer " + key);
    c.setRequestProperty("Content-Type", "application/json");
    byte[] data = body.getBytes(StandardCharsets.UTF_8);
    c.setFixedLengthStreamingMode(data.length);
    try (OutputStream os = c.getOutputStream()) { os.write(data); }
    int code = c.getResponseCode();
    if (code < 200 || code >= 300) {
      String detail = readStream(c.getErrorStream());
      c.disconnect();
      throw new IllegalStateException("HTTP " + code + (detail.isEmpty() ? "" : " · " + detail));
    }
    c.disconnect();
  }

  private static String readStream(InputStream in) {
    if (in == null) return "";
    try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
      StringBuilder sb = new StringBuilder();
      String line;
      while ((line = br.readLine()) != null && sb.length() < 700) sb.append(line);
      return sb.toString().replace('\n', ' ').trim();
    } catch (Exception e) { return ""; }
  }

  private void stopTracking(boolean tellServer) {
    handler.removeCallbacks(heartbeat);
    try { if (fused != null && callback != null) fused.removeLocationUpdates(callback); } catch (Exception ignored) {}
    updatesStarted = false;
    if (tellServer) sendStop();
    SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
    p.edit()
      .remove("assignment_id").remove("supabase_url").remove("anon_key").remove("tracking_token")
      .putBoolean("running", false)
      .apply();
    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
    stopSelf();
  }

  private void saveCredentials() {
    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
      .putString("assignment_id", assignmentId)
      .putString("supabase_url", supabaseUrl)
      .putString("anon_key", anonKey)
      .putString("tracking_token", trackingToken)
      .putLong("started_at", System.currentTimeMillis())
      .putLong("last_success_at", 0L)
      .putLong("last_error_at", 0L)
      .putString("last_error", "")
      .putBoolean("running", true)
      .apply();
  }

  private void restoreCredentials() {
    SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
    assignmentId = p.getString("assignment_id", "");
    supabaseUrl = p.getString("supabase_url", "");
    anonKey = p.getString("anon_key", "");
    trackingToken = p.getString("tracking_token", "");
  }

  private void setRunning(boolean running) {
    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("running", running).apply();
  }

  private void setError(String error) {
    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
      .putString("last_error", safe(error))
      .putLong("last_error_at", System.currentTimeMillis())
      .apply();
  }

  public static String statusJson(Context context) {
    try {
      SharedPreferences p = context.getSharedPreferences(PREFS, MODE_PRIVATE);
      JSONObject j = new JSONObject();
      j.put("running", p.getBoolean("running", false));
      j.put("assignment_id", p.getString("assignment_id", ""));
      j.put("started_at", p.getLong("started_at", 0L));
      j.put("last_success_at", p.getLong("last_success_at", 0L));
      j.put("last_fix_at", p.getLong("last_fix_at", 0L));
      j.put("last_error_at", p.getLong("last_error_at", 0L));
      j.put("last_error", p.getString("last_error", ""));
      j.put("last_lat", Double.longBitsToDouble(p.getLong("last_lat_bits", Double.doubleToRawLongBits(0d))));
      j.put("last_lng", Double.longBitsToDouble(p.getLong("last_lng_bits", Double.doubleToRawLongBits(0d))));
      j.put("last_accuracy", p.getFloat("last_accuracy", 0f));
      return j.toString();
    } catch (Exception e) {
      return "{\"running\":false,\"last_error\":\"Statut GPS indisponible\"}";
    }
  }

  private Notification buildNotification() {
    Intent open = new Intent(this, MainActivity.class);
    PendingIntent pi = PendingIntent.getActivity(this, 137, open,
      Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
    b.setContentTitle("JKBat Équipe · trajet en direct")
      .setContentText("GPS client actif · position envoyée automatiquement")
      .setSmallIcon(R.drawable.ic_notification)
      .setContentIntent(pi)
      .setOngoing(true)
      .setCategory(Notification.CATEGORY_SERVICE);
    return b.build();
  }

  private void createChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Trajet GPS client", NotificationManager.IMPORTANCE_LOW);
      ch.setDescription("Partage GPS actif uniquement quand le technicien est en route");
      NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
      nm.createNotificationChannel(ch);
    }
  }

  @Override public void onDestroy() {
    handler.removeCallbacks(heartbeat);
    try { if (fused != null && callback != null) fused.removeLocationUpdates(callback); } catch (Exception ignored) {}
    updatesStarted = false;
    network.shutdown();
    super.onDestroy();
  }

  @Override public IBinder onBind(Intent intent) { return null; }
  private static String safe(String s) { return s == null ? "" : s.trim(); }
  private static String safeMessage(Throwable t) {
    String s = t == null ? "" : safe(t.getMessage());
    if (s.length() > 260) s = s.substring(0, 260);
    return s.isEmpty() ? "erreur inconnue" : s;
  }
}

