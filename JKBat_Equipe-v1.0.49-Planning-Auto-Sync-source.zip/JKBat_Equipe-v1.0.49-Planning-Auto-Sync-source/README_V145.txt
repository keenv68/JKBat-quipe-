JKBat Équipe v1.0.45 — SECOURS CONNEXION

Base : v1.0.41 stable.
Objectif : restaurer une connexion manuelle totalement utilisable.
- aucune reconnexion automatique au démarrage
- purge unique de la session locale potentiellement bloquée
- fonctions métier v1.0.41 conservées
- radio et météo temporairement retirées

Après installation, reconnecter une fois le compte salarié.
