JKBat Équipe v1.0.46 — Radio + Météo post-connexion

Base : v1.0.45 Secours Connexion validée.

Règle de sécurité : le code d’authentification/session de la v1.0.45 n’a pas été modifié.
Les nouveautés sont injectées uniquement lorsque l’espace salarié est réellement ouvert.

Ajouts :
- météo sur l’accueil après connexion ;
- position météo via le bridge Android existant, séparée de l’authentification ;
- choix manuel de ville/code postal ;
- Radio JKBat avec recherche de stations, favoris, lecture/pause/stop ;
- carte Radio sur l’accueil ;
- mini lecteur persistant au-dessus de la navigation ;
- accès Radio depuis Mon compte.
