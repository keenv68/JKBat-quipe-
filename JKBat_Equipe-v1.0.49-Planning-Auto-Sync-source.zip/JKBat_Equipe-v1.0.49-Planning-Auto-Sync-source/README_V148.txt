JKBat Équipe v1.0.48

Correctif ciblé radio/météo :
- correction de l’ouverture des panneaux Radio et Météo (helper modal local)
- correction tactile de la météo face au décor du hero
- carte Radio entière cliquable + boutons tactiles explicites
- aucune modification volontaire de l’authentification/session v1.0.47
