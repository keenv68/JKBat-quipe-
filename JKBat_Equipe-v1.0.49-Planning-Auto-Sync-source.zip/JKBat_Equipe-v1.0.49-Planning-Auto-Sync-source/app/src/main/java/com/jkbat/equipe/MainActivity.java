package com.jkbat.equipe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.android.gms.location.LocationServices;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private static final int REQ_FILE=5107, REQ_NOTIF=4207, REQ_LOCATION=4307;
  private static MainActivity instance;
  private WebView webView; private ValueCallback<Uri[]> fileCallback; private boolean pageReady=false;
  private String pendingFcmToken, pendingAssignmentId; private boolean pendingOpenMessages=false;
  private String pendingLiveAssignment="", pendingLiveUrl="", pendingLiveKey="", pendingLiveTrackingToken="";
  private boolean pendingWeatherLocation=false;
  public static MainActivity getInstance(){return instance;}
  @Override protected void onCreate(Bundle b){super.onCreate(b);instance=this;if(Build.VERSION.SDK_INT>=21){getWindow().setNavigationBarColor(Color.rgb(248,245,239));getWindow().setStatusBarColor(Color.rgb(248,245,239));}if(Build.VERSION.SDK_INT>=26)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);webView=new WebView(this);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);webView.addJavascriptInterface(new LiveLocationBridge(this),"JKBatLocation");webView.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return handle(r.getUrl().toString());}@Override @SuppressWarnings("deprecation") public boolean shouldOverrideUrlLoading(WebView v,String u){return handle(u);}@Override public void onPageFinished(WebView v,String u){pageReady=true;injectInsets();flush();}});webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;try{Intent i=p!=null?p.createIntent():new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_FILE);return true;}catch(Exception e){fileCallback=null;return false;}}});setContentView(webView);installInsets();consume(getIntent());webView.loadUrl("file:///android_asset/index.html");requestNotif();FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t->{if(t.isSuccessful()&&t.getResult()!=null)onFcmTokenAvailable(t.getResult());});}

  public class LiveLocationBridge {
    private final Context context;
    LiveLocationBridge(Context c){context=c;}
    @JavascriptInterface public void start(String assignmentId,String url,String key,String trackingToken){
      runOnUiThread(()->requestOrStartLiveLocation(assignmentId,url,key,trackingToken));
    }
    @JavascriptInterface public void stop(String assignmentId){
      runOnUiThread(()->stopLiveLocation(assignmentId));
    }
    @JavascriptInterface public String status(){
      return LiveLocationService.statusJson(context);
    }
    @JavascriptInterface public void requestWeather(){
      runOnUiThread(()->requestWeatherLocation());
    }
  }
  private void requestWeatherLocation(){
    pendingWeatherLocation=true;
    if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION); return;
    }
    sendWeatherLocation();
  }
  private void sendWeatherLocation(){
    try{
      LocationServices.getFusedLocationProviderClient(this).getLastLocation().addOnSuccessListener(loc->{
        pendingWeatherLocation=false;
        if(loc==null){eval("window.jkbatWeatherLocation146&&window.jkbatWeatherLocation146(null,null,'unavailable');");return;}
        eval("window.jkbatWeatherLocation146&&window.jkbatWeatherLocation146("+loc.getLatitude()+","+loc.getLongitude()+",'ok');");
      }).addOnFailureListener(e->{pendingWeatherLocation=false;eval("window.jkbatWeatherLocation146&&window.jkbatWeatherLocation146(null,null,'unavailable');");});
    }catch(Exception e){pendingWeatherLocation=false;eval("window.jkbatWeatherLocation146&&window.jkbatWeatherLocation146(null,null,'unavailable');");}
  }
  private void requestOrStartLiveLocation(String assignmentId,String url,String key,String trackingToken){
    pendingLiveAssignment=assignmentId==null?"":assignmentId; pendingLiveUrl=url==null?"":url; pendingLiveKey=key==null?"":key; pendingLiveTrackingToken=trackingToken==null?"":trackingToken;
    if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION); return;
    }
    startLiveLocationService();
  }
  private void startLiveLocationService(){
    if(pendingLiveAssignment.isEmpty())return;
    Intent i=new Intent(this,LiveLocationService.class); i.setAction(LiveLocationService.ACTION_START);
    i.putExtra("assignment_id",pendingLiveAssignment); i.putExtra("supabase_url",pendingLiveUrl); i.putExtra("anon_key",pendingLiveKey); i.putExtra("tracking_token",pendingLiveTrackingToken);
    if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i);
    eval("window.jkbatLocationPermissionResult&&window.jkbatLocationPermissionResult(true);");
  }
  private void stopLiveLocation(String assignmentId){
    Intent i=new Intent(this,LiveLocationService.class); i.setAction(LiveLocationService.ACTION_STOP); if(assignmentId!=null)i.putExtra("assignment_id",assignmentId);
    startService(i);
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
    super.onRequestPermissionsResult(requestCode,permissions,grantResults);
    if(requestCode==REQ_LOCATION){boolean ok=Build.VERSION.SDK_INT<23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;if(ok){if(pendingWeatherLocation)sendWeatherLocation();if(!pendingLiveAssignment.isEmpty())startLiveLocationService();}else{if(pendingWeatherLocation){pendingWeatherLocation=false;eval("window.jkbatWeatherLocation146&&window.jkbatWeatherLocation146(null,null,'denied');");}if(!pendingLiveAssignment.isEmpty())eval("window.jkbatLocationPermissionResult&&window.jkbatLocationPermissionResult(false);");}}
  }

  private boolean handle(String u){if(u==null)return false;try{if(u.startsWith("tel:")||u.startsWith("sms:")||u.startsWith("mailto:")||u.startsWith("geo:")){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));return true;}}catch(Exception ignored){}return false;}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=REQ_FILE||fileCallback==null)return;Uri[] out=null;if(result==RESULT_OK&&data!=null)out=WebChromeClient.FileChooserParams.parseResult(result,data);fileCallback.onReceiveValue(out);fileCallback=null;}
  @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);consume(i);flush();}
  private void consume(Intent i){if(i==null)return;String id=i.getStringExtra("assignment_id");if(id!=null&&!id.isEmpty())pendingAssignmentId=id;String open=i.getStringExtra("open_staff_messages");if("1".equals(open))pendingOpenMessages=true;}
  public void onFcmTokenAvailable(String t){getSharedPreferences("jkbat_equipe_push",MODE_PRIVATE).edit().putString("fcm_token",t).apply();pendingFcmToken=t;flush();}
  private void flush(){if(!pageReady||webView==null)return;if(pendingFcmToken==null||pendingFcmToken.isEmpty())pendingFcmToken=getSharedPreferences("jkbat_equipe_push",MODE_PRIVATE).getString("fcm_token","");if(pendingFcmToken!=null&&!pendingFcmToken.isEmpty())eval("window.jkbatReceiveFcmToken&&window.jkbatReceiveFcmToken("+JSONObject.quote(pendingFcmToken)+");");if(pendingOpenMessages){eval("window.jkbatOpenMessagesFromNotification123&&window.jkbatOpenMessagesFromNotification123();");pendingOpenMessages=false;pendingAssignmentId=null;}else if(pendingAssignmentId!=null){eval("window.jkbatOpenAssignmentFromNotification&&window.jkbatOpenAssignmentFromNotification("+JSONObject.quote(pendingAssignmentId)+");");pendingAssignmentId=null;}}
  public void onStaffMessagePush(String assignmentId){if(!pageReady||webView==null)return;eval("window.jkbatOnStaffMessagePush123&&window.jkbatOnStaffMessagePush123();");}

  private int navInsetCssPx=0;
  private void installInsets(){
    if(Build.VERSION.SDK_INT>=21){
      webView.setOnApplyWindowInsetsListener((v,insets)->{
        int bottom;
        if(Build.VERSION.SDK_INT>=30) bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
        else bottom=insets.getSystemWindowInsetBottom();
        float density=getResources().getDisplayMetrics().density;
        navInsetCssPx=0;
        injectInsets();
        return insets;
      });
      webView.post(()->webView.requestApplyInsets());
    }
  }
  private void injectInsets(){if(!pageReady||webView==null)return;eval("document.documentElement.style.setProperty('--android-nav-inset','"+navInsetCssPx+"px');window.dispatchEvent(new Event('jkbat-system-insets'));window.dispatchEvent(new Event('resize'));");}
  private void eval(String js){runOnUiThread(()->webView.evaluateJavascript(js,null));}
  private void requestNotif(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);}
  @Override protected void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
}
