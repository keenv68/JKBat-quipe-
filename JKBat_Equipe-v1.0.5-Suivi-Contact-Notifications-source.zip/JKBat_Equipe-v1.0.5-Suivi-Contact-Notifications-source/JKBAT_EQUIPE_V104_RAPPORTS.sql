-- JKBat Équipe v1.0.4 — validation et mises à jour des comptes rendus
-- À exécuter UNE FOIS dans Supabase > SQL Editor.

alter table public.jkbat_staff_reports
  add column if not exists report_status text not null default 'BROUILLON',
  add column if not exists revision integer not null default 0,
  add column if not exists validated_at timestamptz,
  add column if not exists submitted_at timestamptz;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'jkbat_staff_reports_report_status_check'
      and conrelid = 'public.jkbat_staff_reports'::regclass
  ) then
    alter table public.jkbat_staff_reports
      add constraint jkbat_staff_reports_report_status_check
      check (report_status in ('BROUILLON','VALIDÉ','MISE À JOUR'));
  end if;
end $$;

-- Les anciens comptes rendus déjà remplis deviennent VALIDÉS sans générer de révision artificielle.
update public.jkbat_staff_reports r
set report_status = 'VALIDÉ',
    revision = greatest(r.revision, 1),
    validated_at = coalesce(r.validated_at, r.updated_at),
    submitted_at = coalesce(r.submitted_at, r.updated_at)
from public.jkbat_staff_assignments a
where a.id = r.assignment_id
  and trim(coalesce(r.report,'')) <> ''
  and r.report_status = 'BROUILLON'
  and upper(trim(coalesce(a.status,''))) in ('SUR PLACE','EN COURS','TERMINÉE');

create or replace function public.jkbat_staff_save_report(
  p_assignment_id uuid,
  p_report text default '',
  p_issue text default '',
  p_materials text default ''
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_assignment_status text;
  v_old public.jkbat_staff_reports%rowtype;
  v_exists boolean := false;
  v_changed boolean := false;
  v_new_status text := 'BROUILLON';
  v_revision integer := 0;
  v_validated_at timestamptz := null;
  v_report text := coalesce(p_report,'');
  v_issue text := coalesce(p_issue,'');
  v_materials text := coalesce(p_materials,'');
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,'')))
    into v_assignment_status
  from public.jkbat_staff_assignments a
  where a.id = p_assignment_id
    and a.staff_user_id = auth.uid();

  if not found then raise exception 'assignment not found'; end if;

  select * into v_old
  from public.jkbat_staff_reports r
  where r.assignment_id = p_assignment_id;
  v_exists := found;

  if v_exists then
    v_changed := v_old.report is distinct from v_report
      or v_old.issue is distinct from v_issue
      or v_old.materials is distinct from v_materials;
    v_revision := greatest(coalesce(v_old.revision,0),0);
    v_validated_at := v_old.validated_at;
  else
    v_changed := true;
  end if;

  -- Une mission terminée doit conserver un vrai compte rendu.
  if v_assignment_status = 'TERMINÉE'
     and v_exists
     and coalesce(v_old.report_status,'BROUILLON') in ('VALIDÉ','MISE À JOUR')
     and trim(v_report) = '' then
    raise exception 'report required';
  end if;

  if trim(v_report) <> '' and v_assignment_status in ('SUR PLACE','EN COURS','TERMINÉE') then
    if v_assignment_status = 'TERMINÉE'
       and v_exists
       and coalesce(v_old.report_status,'BROUILLON') in ('VALIDÉ','MISE À JOUR')
       and v_changed then
      v_new_status := 'MISE À JOUR';
      v_revision := greatest(v_revision,1) + 1;
      v_validated_at := coalesce(v_validated_at, now());
    else
      v_new_status := case
        when v_exists and v_old.report_status = 'MISE À JOUR' then 'MISE À JOUR'
        else 'VALIDÉ'
      end;
      v_revision := greatest(v_revision,1);
      v_validated_at := coalesce(v_validated_at, now());
    end if;
  elsif v_exists then
    v_new_status := coalesce(v_old.report_status,'BROUILLON');
  end if;

  insert into public.jkbat_staff_reports(
    assignment_id, staff_user_id, report, issue, materials,
    report_status, revision, validated_at, submitted_at, updated_at
  ) values(
    p_assignment_id, auth.uid(), v_report, v_issue, v_materials,
    v_new_status, v_revision, v_validated_at,
    case when v_new_status in ('VALIDÉ','MISE À JOUR') then now() else null end,
    now()
  )
  on conflict(assignment_id) do update set
    staff_user_id = excluded.staff_user_id,
    report = excluded.report,
    issue = excluded.issue,
    materials = excluded.materials,
    report_status = excluded.report_status,
    revision = excluded.revision,
    validated_at = excluded.validated_at,
    submitted_at = case
      when excluded.report_status in ('VALIDÉ','MISE À JOUR') then now()
      else public.jkbat_staff_reports.submitted_at
    end,
    updated_at = now();
end;
$$;

-- Appelé après ajout/suppression d'une photo. Si la mission est déjà terminée,
-- le rapport passe en MISE À JOUR et une nouvelle notification pourra partir vers JKBat Pro.
create or replace function public.jkbat_staff_touch_report(
  p_assignment_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_assignment_status text;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;

  select upper(trim(coalesce(a.status,'')))
    into v_assignment_status
  from public.jkbat_staff_assignments a
  where a.id = p_assignment_id
    and a.staff_user_id = auth.uid();

  if not found then raise exception 'assignment not found'; end if;
  if v_assignment_status <> 'TERMINÉE' then return; end if;

  update public.jkbat_staff_reports
     set report_status = 'MISE À JOUR',
         revision = greatest(coalesce(revision,0),1) + 1,
         submitted_at = now(),
         updated_at = now()
   where assignment_id = p_assignment_id
     and staff_user_id = auth.uid()
     and report_status in ('VALIDÉ','MISE À JOUR');
end;
$$;

revoke all on function public.jkbat_staff_save_report(uuid,text,text,text) from public;
grant execute on function public.jkbat_staff_save_report(uuid,text,text,text) to authenticated;
revoke all on function public.jkbat_staff_touch_report(uuid) from public;
grant execute on function public.jkbat_staff_touch_report(uuid) to authenticated;
