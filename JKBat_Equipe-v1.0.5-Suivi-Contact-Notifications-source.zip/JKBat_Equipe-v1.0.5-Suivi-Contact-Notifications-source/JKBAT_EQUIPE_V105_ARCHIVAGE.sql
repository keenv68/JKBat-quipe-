-- JKBat Équipe / Pro v1.0.5 — archivage du suivi salarié
-- À exécuter UNE FOIS dans Supabase > SQL Editor.

alter table public.jkbat_staff_assignments
  add column if not exists archived_at timestamptz;

create index if not exists jkbat_staff_assignments_archived_idx
  on public.jkbat_staff_assignments(archived_at, updated_at);

create or replace function public.jkbat_admin_set_staff_assignment_archived(
  p_assignment_id uuid,
  p_archived boolean default true
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;

  update public.jkbat_staff_assignments
     set archived_at = case when coalesce(p_archived,true) then now() else null end,
         updated_at = now()
   where id=p_assignment_id;

  if not found then raise exception 'assignment not found'; end if;
end;
$$;

create or replace function public.jkbat_admin_delete_staff_assignment(
  p_assignment_id uuid
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  delete from public.jkbat_staff_assignments where id=p_assignment_id;
  if not found then raise exception 'assignment not found'; end if;
end;
$$;

revoke all on function public.jkbat_admin_set_staff_assignment_archived(uuid,boolean) from public;
revoke all on function public.jkbat_admin_delete_staff_assignment(uuid) from public;
grant execute on function public.jkbat_admin_set_staff_assignment_archived(uuid,boolean) to authenticated;
grant execute on function public.jkbat_admin_delete_staff_assignment(uuid) to authenticated;
