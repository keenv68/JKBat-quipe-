-- Diagnostic rapide : vérifie le token JKBat Pro et la dernière réponse du webhook.
select user_id, platform, updated_at, left(token,30) as token_debut
from public.jkbat_push_tokens
where platform in ('android-admin','android')
order by updated_at desc;

select id,status_code,content,error_msg,created
from net._http_response
order by created desc
limit 10;
