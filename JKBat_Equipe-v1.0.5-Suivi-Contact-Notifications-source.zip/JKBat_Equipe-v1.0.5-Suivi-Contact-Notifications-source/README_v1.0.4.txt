JKBat Équipe v1.0.4 — Rapport validé / mise à jour

- Sur place, un compte rendu rempli puis enregistré passe en VALIDÉ.
- La mission ne peut être terminée qu'après validation du compte rendu.
- Une mission terminée reste modifiable. Toute modification du texte, anomalie, matériel ou photos passe le rapport en MISE À JOUR.
- Les mises à jour sont retransmises à JKBat Pro via Supabase.
- Un webhook jkbat_staff_reports peut appeler l’Edge Function JKBAT_STAFF_REPORT_PUSH_V104_EDGE_FUNCTION pour notifier JKBat Pro.
- Version Android : 1.0.4 / versionCode 5.
