JKBat Équipe v1.0.5

- Statuts terrain beaucoup plus visibles sur les cartes et dans la mission.
- Téléphone et adresse client visibles directement dans la tâche.
- Boutons Appeler / SMS / Itinéraire.
- Les missions archivées côté JKBat Pro sont masquées du salarié.
- Validation / mise à jour de rapport v1.0.4 conservée.
- Edge Function v1.0.5 fournie pour fiabiliser les notifications vers JKBat Pro.

Avant utilisation : exécuter JKBAT_EQUIPE_V105_ARCHIVAGE.sql une fois.
Pour le push : remplacer le code de l'Edge Function existante jkbat-push-staff-report-v104 par JKBAT_STAFF_REPORT_PUSH_V105_EDGE_FUNCTION.txt et redéployer.
