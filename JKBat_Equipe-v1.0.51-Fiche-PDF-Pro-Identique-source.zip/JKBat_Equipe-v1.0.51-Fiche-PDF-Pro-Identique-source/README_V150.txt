JKBat Équipe v1.0.50 — Fonctions métier restaurées

- Conserve l’interface, la radio, la météo, la session persistante et l’auto-sync planning de v1.0.49.
- Restaure le workflow historique des statuts : À faire → En route → Sur place → Terminée.
- Accepte les variantes A FAIRE / À FAIRE / EN_ROUTE / SUR_PLACE / TERMINEE, etc.
- Réaffiche le bouton En route / Je suis sur place si une mission synchronisée utilisait un statut non accentué.
- Conserve GPS live, signaler impossible, compte rendu, photos avant/après, signature client, PDF et clôture de mission.
