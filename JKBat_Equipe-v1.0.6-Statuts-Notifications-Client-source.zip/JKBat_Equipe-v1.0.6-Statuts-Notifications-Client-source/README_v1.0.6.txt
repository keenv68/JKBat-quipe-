JKBat Équipe v1.0.6

- La prochaine mission n'est plus affichée une seconde fois dans la liste Aujourd'hui.
- Coordonnées client (téléphone/adresse) et actions Appeler / SMS / Itinéraire conservées et alimentées par JKBat Pro v6.16.33.
- Notifications JKBat Pro à chaque changement de statut via la nouvelle Edge Function JKBAT_EQUIPE_PUSH_V106_EDGE_FUNCTION.txt.
