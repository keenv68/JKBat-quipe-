-- ============================================================
-- JKBat V173 — Synchronisation RDV Client / Équipe / Pro
-- Correctif 30/09/2026
--
-- Corrige :
-- 1) confirmation client non répercutée vers JKBat Équipe ;
-- 2) nom technicien incohérent (ex. "Oui") ;
-- 3) doublons exacts de rendez-vous Cloud ;
-- 4) verrou serveur avant départ tant que le client n'a pas confirmé.
-- ============================================================

begin;

alter table public.jkbat_staff_assignments
  add column if not exists client_confirmation_required boolean not null default false,
  add column if not exists client_confirmation_confirmed_at timestamptz;

create index if not exists jkbat_staff_assignments_client_confirmation_idx
  on public.jkbat_staff_assignments(staff_user_id,client_confirmation_required,scheduled_date)
  where upper(trim(coalesce(source_type,'')))='RDV' and archived_at is null;

-- Nom affichable côté Client : évite les valeurs booléennes accidentelles.
create or replace function public.jkbat_safe_technician_name(p_name text)
returns text
language sql
immutable
as $$
  select case
    when nullif(trim(coalesce(p_name,'')),'') is null then null
    when lower(trim(p_name)) in ('oui','non','true','false','yes','no','1','0') then null
    when length(trim(p_name)) < 2 then null
    else trim(p_name)
  end;
$$;

-- -----------------------------------------------------------------
-- Rendez-vous Client -> mission Équipe : état de confirmation.
-- -----------------------------------------------------------------
create or replace function public.jkbat_sync_client_confirmation_to_staff_v173()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_confirmed boolean;
  v_at timestamptz;
begin
  v_confirmed := new.confirmation_confirmed_at is not null
                 or upper(trim(coalesce(new.status,''))) in ('CONFIRMÉ CLIENT','CONFIRME CLIENT','CONFIRMÉ','CONFIRME');
  v_at := case when v_confirmed then coalesce(new.confirmation_confirmed_at,now()) else null end;

  update public.jkbat_staff_assignments a
     set client_confirmation_required = not v_confirmed,
         client_confirmation_confirmed_at = v_at,
         updated_at = now()
   where upper(trim(coalesce(a.source_type,'')))='RDV'
     and (
       a.id = new.staff_assignment_id
       or (
         nullif(trim(coalesce(new.source_id,'')),'') is not null
         and upper(trim(coalesce(new.source_type,'')))='RDV'
         and a.source_id = new.source_id
       )
     );

  return new;
end;
$$;

drop trigger if exists jkbat_sync_client_confirmation_to_staff_trg on public.jkbat_client_appointments;
drop trigger if exists jkbat_sync_client_confirmation_to_staff_v173_trg on public.jkbat_client_appointments;
create trigger jkbat_sync_client_confirmation_to_staff_v173_trg
after insert or update of status,confirmation_required,confirmation_confirmed_at,staff_assignment_id,source_type,source_id
on public.jkbat_client_appointments
for each row execute function public.jkbat_sync_client_confirmation_to_staff_v173();

-- Mission Équipe créée après le RDV Client : récupère immédiatement l'état.
create or replace function public.jkbat_staff_load_client_confirmation_v173()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_appt record;
  v_confirmed boolean;
begin
  if upper(trim(coalesce(new.source_type,''))) <> 'RDV' then
    return new;
  end if;

  select c.id,c.status,c.confirmation_required,c.confirmation_confirmed_at
    into v_appt
    from public.jkbat_client_appointments c
   where c.staff_assignment_id=new.id
      or (
        upper(trim(coalesce(c.source_type,'')))='RDV'
        and nullif(trim(coalesce(new.source_id,'')),'') is not null
        and c.source_id=new.source_id
      )
   order by coalesce(c.confirmation_confirmed_at,c.tracking_updated_at,c.start_at) desc nulls last, c.id desc
   limit 1;

  if found then
    v_confirmed := v_appt.confirmation_confirmed_at is not null
                   or upper(trim(coalesce(v_appt.status,''))) in ('CONFIRMÉ CLIENT','CONFIRME CLIENT','CONFIRMÉ','CONFIRME');
    new.client_confirmation_required := not v_confirmed;
    new.client_confirmation_confirmed_at := case when v_confirmed then coalesce(v_appt.confirmation_confirmed_at,now()) else null end;
  else
    -- Pas de compte Client lié : ne pas bloquer une mission historique/non-client.
    new.client_confirmation_required := false;
    new.client_confirmation_confirmed_at := coalesce(new.client_confirmation_confirmed_at,now());
  end if;

  return new;
end;
$$;

drop trigger if exists jkbat_staff_load_client_confirmation_v173_trg on public.jkbat_staff_assignments;
create trigger jkbat_staff_load_client_confirmation_v173_trg
before insert or update of source_type,source_id,staff_user_id
on public.jkbat_staff_assignments
for each row execute function public.jkbat_staff_load_client_confirmation_v173();

-- -----------------------------------------------------------------
-- Confirmation Client atomique : le RDV ET la mission sont déverrouillés.
-- -----------------------------------------------------------------
create or replace function public.jkbat_client_confirm_appointment(p_appointment_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.jkbat_client_appointments%rowtype;
  v_at timestamptz := now();
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;

  select * into v
    from public.jkbat_client_appointments
   where id=p_appointment_id and client_id=auth.uid()
   for update;
  if not found then raise exception 'appointment not found'; end if;

  if upper(trim(coalesce(v.tracking_status,''))) in ('EN ROUTE','SUR PLACE','TERMINÉE','TERMINEE','IMPOSSIBLE') then
    raise exception 'appointment already in progress';
  end if;

  update public.jkbat_client_appointments
     set status='CONFIRMÉ CLIENT',
         confirmation_required=false,
         confirmation_confirmed_at=v_at
   where id=p_appointment_id;

  update public.jkbat_staff_assignments a
     set client_confirmation_required=false,
         client_confirmation_confirmed_at=v_at,
         updated_at=v_at
   where upper(trim(coalesce(a.source_type,'')))='RDV'
     and (
       a.id=v.staff_assignment_id
       or (
         nullif(trim(coalesce(v.source_id,'')),'') is not null
         and a.source_id=v.source_id
       )
     );

  update public.jkbat_maintenance_visits
     set client_confirmed_at=v_at,updated_at=v_at
   where client_appointment_id=p_appointment_id;
end;
$$;

revoke all on function public.jkbat_client_confirm_appointment(uuid) from public;
grant execute on function public.jkbat_client_confirm_appointment(uuid) to authenticated;

-- -----------------------------------------------------------------
-- Verrou serveur : même une ancienne APK Équipe ne peut pas partir
-- avant confirmation du client. Les contrôles historiques rapport +
-- signature client avant TERMINÉE sont conservés.
-- -----------------------------------------------------------------
create or replace function public.jkbat_staff_set_status(p_assignment_id uuid,p_status text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text := upper(trim(coalesce(p_status,'')));
  v_report public.jkbat_staff_reports%rowtype;
  v_assignment public.jkbat_staff_assignments%rowtype;
  v_appt record;
  v_confirmed boolean := false;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if v_status not in ('À FAIRE','EN ROUTE','SUR PLACE','EN COURS','TERMINÉE','IMPOSSIBLE') then raise exception 'invalid status'; end if;

  select * into v_assignment
    from public.jkbat_staff_assignments a
   where a.id=p_assignment_id and a.staff_user_id=auth.uid()
   for update;
  if not found then raise exception 'assignment not found'; end if;

  if upper(trim(coalesce(v_assignment.source_type,'')))='RDV'
     and v_status in ('EN ROUTE','SUR PLACE','EN COURS','TERMINÉE','IMPOSSIBLE') then
    select c.status,c.confirmation_required,c.confirmation_confirmed_at
      into v_appt
      from public.jkbat_client_appointments c
     where c.staff_assignment_id=v_assignment.id
        or (
          upper(trim(coalesce(c.source_type,'')))='RDV'
          and c.source_id=v_assignment.source_id
        )
     order by coalesce(c.confirmation_confirmed_at,c.tracking_updated_at,c.start_at) desc nulls last, c.id desc
     limit 1;

    if found then
      v_confirmed := v_appt.confirmation_confirmed_at is not null
                     or upper(trim(coalesce(v_appt.status,''))) in ('CONFIRMÉ CLIENT','CONFIRME CLIENT','CONFIRMÉ','CONFIRME');
    else
      v_confirmed := not coalesce(v_assignment.client_confirmation_required,false)
                     and v_assignment.client_confirmation_confirmed_at is not null;
    end if;

    if not v_confirmed then
      raise exception 'client confirmation required before start';
    end if;
  end if;

  if v_status='TERMINÉE' then
    select r.* into v_report
      from public.jkbat_staff_reports r
     where r.assignment_id=p_assignment_id and r.staff_user_id=auth.uid();
    if not found then raise exception 'report required before completion'; end if;
    if coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then raise exception 'report must be validated before completion'; end if;
    if nullif(trim(coalesce(v_report.report,'')),'') is null then raise exception 'report required before completion'; end if;
    if v_report.client_signature is null or v_report.signed_at is null then raise exception 'client signature required before completion'; end if;
    if coalesce(v_report.signature_revision,-1) <> coalesce(v_report.revision,0) then raise exception 'client signature outdated: new signature required'; end if;
  end if;

  update public.jkbat_staff_assignments a
     set status=v_status,
         started_at=case when v_status in ('EN ROUTE','SUR PLACE','EN COURS') then coalesce(a.started_at,now()) else a.started_at end,
         completed_at=case when v_status='TERMINÉE' then coalesce(a.completed_at,now()) when v_status<>'TERMINÉE' then null else a.completed_at end,
         updated_at=now()
   where a.id=p_assignment_id and a.staff_user_id=auth.uid();
end;
$$;

-- -----------------------------------------------------------------
-- Suivi Équipe -> Client : ne jamais publier "Oui/Non/true/false"
-- comme nom de technicien.
-- -----------------------------------------------------------------
create or replace function public.jkbat_sync_staff_tracking_to_client()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tracking text;
  v_staff_name text := null;
  v_appt record;
  v_conv uuid;
  v_body text;
  v_old_tracking text := '';
begin
  v_tracking := public.jkbat_tracking_label_from_staff(new.status);

  select public.jkbat_safe_technician_name(p.full_name)
    into v_staff_name
    from public.jkbat_staff_profiles p
   where p.id=new.staff_user_id;

  update public.jkbat_client_appointments a
     set staff_assignment_id=new.id,
         technician_name=coalesce(v_staff_name,public.jkbat_safe_technician_name(a.technician_name),'Technicien JKBat'),
         tracking_status=v_tracking,
         tracking_updated_at=now(),
         en_route_at=case when v_tracking='EN ROUTE' then coalesce(a.en_route_at,now()) else a.en_route_at end,
         on_site_at=case when v_tracking='SUR PLACE' then coalesce(a.on_site_at,now()) else a.on_site_at end,
         intervention_completed_at=case when v_tracking='TERMINÉE' then coalesce(a.intervention_completed_at,now()) else a.intervention_completed_at end
   where a.staff_assignment_id=new.id
      or (
        nullif(trim(coalesce(a.source_type,'')),'') is not null
        and upper(trim(a.source_type))=upper(trim(coalesce(new.source_type,'')))
        and a.source_id=coalesce(new.source_id,'')
      );

  if tg_op='UPDATE' then v_old_tracking:=public.jkbat_tracking_label_from_staff(old.status); end if;

  if v_tracking is distinct from v_old_tracking
     and v_tracking in ('EN ROUTE','SUR PLACE','TERMINÉE','IMPOSSIBLE') then
    for v_appt in
      select a.id,a.client_id,a.title,a.start_at,a.technician_name
        from public.jkbat_client_appointments a
       where a.staff_assignment_id=new.id
    loop
      begin
        select c.id into v_conv
          from public.jkbat_conversations c
         where c.client_id=v_appt.client_id
         order by c.created_at asc limit 1;
        if v_conv is not null then
          v_body:=case v_tracking
            when 'EN ROUTE' then
              case when coalesce(public.jkbat_safe_technician_name(v_appt.technician_name),'Technicien JKBat')='Technicien JKBat'
                then '🚗 Votre technicien JKBat est en route pour votre rendez-vous « '||coalesce(v_appt.title,'Intervention')||' ».'
                else '🚗 Votre technicien '||public.jkbat_safe_technician_name(v_appt.technician_name)||' est en route pour votre rendez-vous « '||coalesce(v_appt.title,'Intervention')||' ».' end
            when 'SUR PLACE' then '📍 Votre technicien est arrivé sur place. L’intervention « '||coalesce(v_appt.title,'Intervention')||' » peut commencer.'
            when 'TERMINÉE' then '✅ Votre intervention « '||coalesce(v_appt.title,'Intervention')||' » est terminée. Les documents seront disponibles dans votre espace JKBat.'
            else '⚠️ Votre intervention « '||coalesce(v_appt.title,'Intervention')||' » nécessite une mise à jour. JKBat vous recontactera si nécessaire.'
          end;
          insert into public.jkbat_messages(conversation_id,sender_id,sender_role,body)
          values(v_conv,new.staff_user_id,'business',v_body);
        end if;
      exception when others then null;
      end;
    end loop;
  end if;

  return new;
end;
$$;

-- -----------------------------------------------------------------
-- Réparation immédiate des données existantes.
-- -----------------------------------------------------------------
with best as (
  select distinct on (a.id)
         a.id as assignment_id,
         c.id as client_appointment_id,
         c.status,
         c.confirmation_confirmed_at
    from public.jkbat_staff_assignments a
    join public.jkbat_client_appointments c
      on c.staff_assignment_id=a.id
      or (upper(trim(coalesce(c.source_type,'')))='RDV' and c.source_id=a.source_id)
   where upper(trim(coalesce(a.source_type,'')))='RDV'
   order by a.id,coalesce(c.confirmation_confirmed_at,c.tracking_updated_at,c.start_at) desc nulls last,c.id desc
)
update public.jkbat_staff_assignments a
   set client_confirmation_required = case
         when b.confirmation_confirmed_at is not null
           or upper(trim(coalesce(b.status,''))) in ('CONFIRMÉ CLIENT','CONFIRME CLIENT','CONFIRMÉ','CONFIRME') then false
         else true end,
       client_confirmation_confirmed_at = case
         when b.confirmation_confirmed_at is not null
           or upper(trim(coalesce(b.status,''))) in ('CONFIRMÉ CLIENT','CONFIRME CLIENT','CONFIRMÉ','CONFIRME') then coalesce(b.confirmation_confirmed_at,now())
         else null end,
       updated_at=now()
  from best b
 where a.id=b.assignment_id;

-- Missions RDV sans rendez-vous Client : ne pas les verrouiller.
update public.jkbat_staff_assignments a
   set client_confirmation_required=false,
       client_confirmation_confirmed_at=coalesce(client_confirmation_confirmed_at,now()),
       updated_at=now()
 where upper(trim(coalesce(a.source_type,'')))='RDV'
   and not exists(
     select 1 from public.jkbat_client_appointments c
      where c.staff_assignment_id=a.id
         or (upper(trim(coalesce(c.source_type,'')))='RDV' and c.source_id=a.source_id)
   );

update public.jkbat_client_appointments
   set technician_name='Technicien JKBat'
 where public.jkbat_safe_technician_name(technician_name) is null
   and nullif(trim(coalesce(technician_name,'')),'') is not null;

-- Supprime uniquement les doublons Cloud qui représentent EXACTEMENT
-- la même source Pro (même client + RDV + source_id). Le plus récent gagne.
with ranked as (
  select id,
         row_number() over(
           partition by client_id,upper(trim(source_type)),source_id
           order by coalesce(confirmation_confirmed_at,intervention_completed_at,tracking_updated_at,start_at) desc nulls last,id desc
         ) as rn
    from public.jkbat_client_appointments
   where nullif(trim(coalesce(source_type,'')),'') is not null
     and nullif(trim(coalesce(source_id,'')),'') is not null
)
delete from public.jkbat_client_appointments c
 using ranked r
 where c.id=r.id and r.rn>1;

create unique index if not exists jkbat_client_appointments_source_unique_v173
  on public.jkbat_client_appointments(client_id,(upper(trim(source_type))),source_id)
  where nullif(trim(coalesce(source_type,'')),'') is not null
    and nullif(trim(coalesce(source_id,'')),'') is not null;

notify pgrst,'reload schema';
commit;

-- Vérification rapide : les lignes doivent être cohérentes après exécution.
select a.id,a.source_id,a.status,a.client_confirmation_required,a.client_confirmation_confirmed_at,
       c.id as client_appointment_id,c.status as client_status,c.confirmation_confirmed_at
  from public.jkbat_staff_assignments a
  left join public.jkbat_client_appointments c
    on c.staff_assignment_id=a.id
    or (upper(trim(coalesce(c.source_type,'')))='RDV' and c.source_id=a.source_id)
 where upper(trim(coalesce(a.source_type,'')))='RDV'
 order by a.updated_at desc
 limit 30;
