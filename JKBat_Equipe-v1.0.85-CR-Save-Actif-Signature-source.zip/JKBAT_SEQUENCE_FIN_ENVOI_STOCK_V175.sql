-- ============================================================
-- JKBat V175 — Fin intervention AVANT envoi PDF + stock terrain libre
-- 01/10/2026
--
-- Règles :
-- 1) signatures client + technicien -> terminer l'intervention ;
-- 2) la fiche PDF ne peut être publiée au client qu'APRÈS TERMINÉE ;
-- 3) le technicien peut saisir un article par son nom :
--    - article existant => utilisation de la fiche stock existante ;
--    - article inconnu => création automatique dans le stock JKBat,
--      puis ajout immédiat dans le tableau d'utilisation de la mission.
-- ============================================================

begin;

-- ------------------------------------------------------------
-- 1) Garde serveur : aucun envoi fiche client avant TERMINÉE.
-- ------------------------------------------------------------
create or replace function public.jkbat_require_completion_before_client_send_v175()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text := '';
begin
  if new.client_sent_at is not null
     and (old.client_sent_at is null or new.client_sent_at is distinct from old.client_sent_at) then

    select upper(trim(coalesce(a.status,'')))
      into v_status
      from public.jkbat_staff_assignments a
     where a.id=new.assignment_id
       and a.staff_user_id=new.staff_user_id;

    if v_status not in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE') then
      raise exception 'intervention must be completed before client PDF send';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_require_completion_before_client_send_v175_trg
  on public.jkbat_staff_reports;
create trigger jkbat_require_completion_before_client_send_v175_trg
before update of client_sent_at
on public.jkbat_staff_reports
for each row
execute function public.jkbat_require_completion_before_client_send_v175();

-- ------------------------------------------------------------
-- 2) Saisie stock par NOM depuis JKBat Équipe.
--    Permet au technicien de remplir le tableau même si l'article
--    n'était pas encore présent dans la liste déroulante.
-- ------------------------------------------------------------
create or replace function public.jkbat_staff_set_stock_usage_by_name(
  p_assignment_id uuid,
  p_item_name text,
  p_qty_used numeric default 0,
  p_qty_to_order numeric default 0,
  p_note text default '',
  p_unit text default 'u'
) returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_item_id uuid;
  v_name text := nullif(trim(coalesce(p_item_name,'')),'');
  v_unit text := coalesce(nullif(trim(coalesce(p_unit,'')),''),'u');
  v_status text := '';
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_staff_is_active(auth.uid()) then raise exception 'staff account inactive'; end if;
  if v_name is null then raise exception 'stock item name required'; end if;

  select upper(trim(coalesce(a.status,'')))
    into v_status
    from public.jkbat_staff_assignments a
   where a.id=p_assignment_id
     and a.staff_user_id=auth.uid();
  if not found then raise exception 'assignment not found'; end if;
  if v_status in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE') then
    raise exception 'stock usage locked after completion';
  end if;

  select i.id
    into v_item_id
    from public.jkbat_stock_items i
   where i.active=true
     and lower(trim(i.name))=lower(v_name)
   order by i.created_at asc
   limit 1;

  if v_item_id is null then
    insert into public.jkbat_stock_items(
      name,category,unit,qty,min_qty,purchase_price,sale_price,supplier,note,active,created_at,updated_at
    ) values (
      v_name,'Ajout terrain',v_unit,0,0,0,0,'',
      'Créé automatiquement depuis une intervention JKBat Équipe',true,now(),now()
    ) returning id into v_item_id;
  end if;

  perform public.jkbat_staff_set_stock_usage(
    p_assignment_id,
    v_item_id,
    greatest(coalesce(p_qty_used,0),0),
    greatest(coalesce(p_qty_to_order,0),0),
    coalesce(p_note,'')
  );

  return v_item_id;
end;
$$;

revoke all on function public.jkbat_staff_set_stock_usage_by_name(uuid,text,numeric,numeric,text,text) from public;
grant execute on function public.jkbat_staff_set_stock_usage_by_name(uuid,text,numeric,numeric,text,text) to authenticated;

commit;

-- Vérification : le RPC doit exister et le trigger doit être actif.
select p.proname
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and p.proname in (
    'jkbat_require_completion_before_client_send_v175',
    'jkbat_staff_set_stock_usage_by_name'
  )
order by p.proname;

select trigger_name,event_manipulation,event_object_table
from information_schema.triggers
where trigger_schema='public'
  and trigger_name='jkbat_require_completion_before_client_send_v175_trg';
