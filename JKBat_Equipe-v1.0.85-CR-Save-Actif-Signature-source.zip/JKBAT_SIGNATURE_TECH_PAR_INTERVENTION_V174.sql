-- ============================================================
-- JKBat V174 — Signature technicien PAR INTERVENTION
-- Correctif 30/09/2026
--
-- Règle :
-- - aucune signature technicien de profil n'est réutilisée ;
-- - le technicien signe chaque intervention séparément ;
-- - la signature est liée à la révision exacte du rapport ;
-- - toute modification du rapport invalide la signature technicien ;
-- - envoi PDF et terminaison sont bloqués côté serveur si la
--   signature technicien de la révision courante est absente.
-- ============================================================

begin;

alter table public.jkbat_staff_reports
  add column if not exists technician_signature text,
  add column if not exists technician_signer_name text,
  add column if not exists technician_signed_at timestamptz,
  add column if not exists technician_signature_revision integer;

create index if not exists jkbat_staff_reports_technician_signature_idx
  on public.jkbat_staff_reports(staff_user_id, technician_signed_at desc)
  where technician_signed_at is not null;

-- ------------------------------------------------------------
-- 1) Toute nouvelle révision du rapport invalide aussi la
--    signature du technicien, exactement comme la signature client.
-- ------------------------------------------------------------
create or replace function public.jkbat_clear_technician_signature_on_revision_v174()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if coalesce(new.revision,0) <> coalesce(old.revision,0) then
    new.technician_signature := null;
    new.technician_signer_name := null;
    new.technician_signed_at := null;
    new.technician_signature_revision := null;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_clear_technician_signature_on_revision_v174_trg
  on public.jkbat_staff_reports;
create trigger jkbat_clear_technician_signature_on_revision_v174_trg
before update of revision
on public.jkbat_staff_reports
for each row
execute function public.jkbat_clear_technician_signature_on_revision_v174();

-- ------------------------------------------------------------
-- 2) Enregistrement de la signature pour UNE mission seulement.
-- ------------------------------------------------------------
create or replace function public.jkbat_staff_save_assignment_technician_signature(
  p_assignment_id uuid,
  p_signature text
) returns timestamptz
language plpgsql
security definer
set search_path=public
as $$
declare
  v_assignment public.jkbat_staff_assignments%rowtype;
  v_report public.jkbat_staff_reports%rowtype;
  v_name text;
  v_at timestamptz := now();
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;
  if not public.jkbat_staff_is_active(auth.uid()) then
    raise exception 'staff account inactive';
  end if;
  if nullif(trim(coalesce(p_signature,'')),'') is null then
    raise exception 'technician signature required';
  end if;

  select * into v_assignment
    from public.jkbat_staff_assignments a
   where a.id=p_assignment_id
     and a.staff_user_id=auth.uid()
   for update;
  if not found then
    raise exception 'assignment not found';
  end if;

  select * into v_report
    from public.jkbat_staff_reports r
   where r.assignment_id=p_assignment_id
     and r.staff_user_id=auth.uid()
   for update;
  if not found then
    raise exception 'validated report required before technician signature';
  end if;

  if coalesce(v_report.report_status,'BROUILLON') not in ('VALIDÉ','MISE À JOUR') then
    raise exception 'report must be validated before technician signature';
  end if;
  if coalesce(v_report.revision,0) <= 0 then
    raise exception 'invalid report revision';
  end if;

  select nullif(trim(coalesce(p.full_name,'')),'')
    into v_name
    from public.jkbat_staff_profiles p
   where p.id=auth.uid()
   limit 1;

  update public.jkbat_staff_reports
     set technician_signature=p_signature,
         technician_signer_name=coalesce(v_name,'Technicien JKBat'),
         technician_signed_at=v_at,
         technician_signature_revision=v_report.revision,
         updated_at=v_at
   where assignment_id=p_assignment_id
     and staff_user_id=auth.uid();

  return v_at;
end;
$$;

revoke all on function public.jkbat_staff_save_assignment_technician_signature(uuid,text) from public;
grant execute on function public.jkbat_staff_save_assignment_technician_signature(uuid,text) to authenticated;

-- ------------------------------------------------------------
-- 3) Garde serveur avant publication de la fiche au client.
-- ------------------------------------------------------------
create or replace function public.jkbat_require_current_technician_signature_on_send_v174()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if new.client_sent_at is not null
     and (old.client_sent_at is null or new.client_sent_at is distinct from old.client_sent_at) then
    if nullif(trim(coalesce(new.technician_signature,'')),'') is null
       or new.technician_signed_at is null
       or coalesce(new.technician_signature_revision,-1) <> coalesce(new.revision,0) then
      raise exception 'current technician signature required before client PDF send';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_require_current_technician_signature_on_send_v174_trg
  on public.jkbat_staff_reports;
create trigger jkbat_require_current_technician_signature_on_send_v174_trg
before update of client_sent_at
on public.jkbat_staff_reports
for each row
execute function public.jkbat_require_current_technician_signature_on_send_v174();

-- ------------------------------------------------------------
-- 4) Garde serveur avant TERMINÉE.
-- ------------------------------------------------------------
create or replace function public.jkbat_require_signatures_before_completion_v174()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_report public.jkbat_staff_reports%rowtype;
  v_new_status text := upper(trim(coalesce(new.status,'')));
  v_old_status text := upper(trim(coalesce(old.status,'')));
begin
  if v_new_status in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE')
     and v_old_status not in ('TERMINÉE','TERMINEE','TERMINÉ','TERMINE') then

    select r.* into v_report
      from public.jkbat_staff_reports r
     where r.assignment_id=new.id
       and r.staff_user_id=new.staff_user_id;

    if not found then
      raise exception 'report required before completion';
    end if;

    if v_report.client_signature is null
       or v_report.signed_at is null
       or coalesce(v_report.signature_revision,-1) <> coalesce(v_report.revision,0) then
      raise exception 'current client signature required before completion';
    end if;

    if nullif(trim(coalesce(v_report.technician_signature,'')),'') is null
       or v_report.technician_signed_at is null
       or coalesce(v_report.technician_signature_revision,-1) <> coalesce(v_report.revision,0) then
      raise exception 'current technician signature required before completion';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_require_signatures_before_completion_v174_trg
  on public.jkbat_staff_assignments;
create trigger jkbat_require_signatures_before_completion_v174_trg
before update of status
on public.jkbat_staff_assignments
for each row
execute function public.jkbat_require_signatures_before_completion_v174();

commit;

-- Vérification rapide : les colonnes doivent être présentes.
select column_name,data_type
from information_schema.columns
where table_schema='public'
  and table_name='jkbat_staff_reports'
  and column_name in (
    'technician_signature',
    'technician_signer_name',
    'technician_signed_at',
    'technician_signature_revision'
  )
order by column_name;
