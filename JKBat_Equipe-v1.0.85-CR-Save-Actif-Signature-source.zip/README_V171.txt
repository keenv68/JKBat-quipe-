JKBat Équipe v1.0.71
- Stock déplacé juste avant « Valider le compte rendu ».
- Notifications JKBat Pro à 4 étapes : compte rendu validé/mis à jour, signature client, signature technicien, mission terminée.
- Déployer JKBAT_STAFF_REPORT_PUSH_V121_EDGE_FUNCTION.txt dans l'Edge Function nommée jkbat-push-staff-report-v121.
- Secrets attendus identiques à l'Edge Function actuelle + SUPABASE_ANON_KEY.
- Aucun nouveau SQL nécessaire pour cette version.
