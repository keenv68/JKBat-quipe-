-- ============================================================
-- JKBat — V148
-- Affectation technicien + information automatique du client
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Effet : lorsqu'un technicien est affecté (ou changé) depuis
-- JKBat Pro, le client reçoit automatiquement un message dans
-- sa conversation. Le webhook push déjà associé à jkbat_messages
-- transforme également ce message en notification Android.
--
-- IMPORTANT : le créneau et client_confirmed_at ne sont pas modifiés.
-- ============================================================

create or replace function public.jkbat_admin_assign_maintenance_visit_staff(
  p_visit_id uuid,
  p_staff_user_id uuid default null,
  p_technician_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_visit public.jkbat_maintenance_visits%rowtype;
  v_contract public.jkbat_maintenance_contracts%rowtype;
  v_assign uuid;
  v_old_staff uuid;
  v_tech_name text := '';
  v_conv uuid;
  v_when text := '';
  v_body text := '';
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;

  select * into v_visit
    from public.jkbat_maintenance_visits
   where id=p_visit_id
   for update;
  if not found then raise exception 'visit not found'; end if;

  if v_visit.scheduled_at is null then
    raise exception 'visit not scheduled';
  end if;

  v_old_staff := v_visit.staff_user_id;

  select * into v_contract
    from public.jkbat_maintenance_contracts
   where id=v_visit.contract_id;
  if not found then raise exception 'contract not found'; end if;
  if not v_contract.active then raise exception 'contract inactive'; end if;

  v_tech_name := nullif(trim(coalesce(p_technician_name,'')),'');
  if p_staff_user_id is not null and v_tech_name is null then
    select coalesce(nullif(trim(p.full_name),''),nullif(trim(p.email),''),'Technicien JKBat')
      into v_tech_name
      from public.jkbat_staff_profiles p
     where p.id=p_staff_user_id;
  end if;
  v_tech_name := coalesce(v_tech_name,'Technicien JKBat');

  -- Affectation existante éventuelle.
  v_assign := v_visit.staff_assignment_id;
  if v_assign is null then
    select id into v_assign
      from public.jkbat_staff_assignments
     where source_type='CONTRAT'
       and source_id=v_visit.id::text
     order by updated_at desc nulls last
     limit 1;
  end if;

  if p_staff_user_id is not null then
    insert into public.jkbat_staff_assignments(
      staff_user_id,source_type,source_id,title,client_name,client_phone,address,trade,
      scheduled_date,scheduled_time,notes,priority,status,client_profile_id,
      maintenance_contract_id,maintenance_visit_id,maintenance_label,updated_at
    ) values(
      p_staff_user_id,'CONTRAT',v_visit.id::text,'Entretien · '||v_contract.title,
      v_contract.client_name,v_contract.client_phone,v_contract.address,v_contract.trade,
      (v_visit.scheduled_at at time zone 'Europe/Paris')::date,
      (v_visit.scheduled_at at time zone 'Europe/Paris')::time,
      trim(both from concat_ws(E'\n',v_contract.notes,'Contrat récurrent · tous les '||v_contract.interval_months||' mois')),
      'NORMALE','À FAIRE',v_contract.client_id,
      v_contract.id,v_visit.id,v_contract.title,now()
    )
    on conflict(source_type,source_id) do update set
      staff_user_id=excluded.staff_user_id,
      title=excluded.title,
      client_name=excluded.client_name,
      client_phone=excluded.client_phone,
      address=excluded.address,
      trade=excluded.trade,
      scheduled_date=excluded.scheduled_date,
      scheduled_time=excluded.scheduled_time,
      notes=excluded.notes,
      client_profile_id=excluded.client_profile_id,
      maintenance_contract_id=excluded.maintenance_contract_id,
      maintenance_visit_id=excluded.maintenance_visit_id,
      maintenance_label=excluded.maintenance_label,
      status=case
        when upper(coalesce(public.jkbat_staff_assignments.status,'')) like 'TERMIN%'
          then public.jkbat_staff_assignments.status
        else 'À FAIRE'
      end,
      updated_at=now()
    returning id into v_assign;
  else
    delete from public.jkbat_staff_assignments
     where (
       id=v_assign
       or (source_type='CONTRAT' and source_id=v_visit.id::text)
     )
       and upper(coalesce(status,'')) not like 'TERMIN%';
    if found then v_assign:=null; end if;
  end if;

  -- IMPORTANT : le rendez-vous client et sa confirmation restent inchangés.
  update public.jkbat_maintenance_visits
     set staff_assignment_id=v_assign,
         staff_user_id=p_staff_user_id,
         technician_name=case when p_staff_user_id is null then '' else v_tech_name end,
         updated_at=now()
   where id=p_visit_id;

  -- Message uniquement lors d'une nouvelle affectation ou d'un changement
  -- de technicien. Aucun doublon si on enregistre à nouveau le même salarié.
  if p_staff_user_id is not null
     and p_staff_user_id is distinct from v_old_staff then

    select c.id into v_conv
      from public.jkbat_conversations c
     where c.client_id=v_contract.client_id
     order by c.created_at asc
     limit 1;

    if v_conv is null then
      begin
        insert into public.jkbat_conversations(client_id)
        values(v_contract.client_id)
        returning id into v_conv;
      exception when unique_violation then
        select c.id into v_conv
          from public.jkbat_conversations c
         where c.client_id=v_contract.client_id
         order by c.created_at asc
         limit 1;
      end;
    end if;

    v_when := to_char(
      v_visit.scheduled_at at time zone 'Europe/Paris',
      'DD/MM/YYYY "à" HH24:MI'
    );

    v_body := '👨‍🔧 Votre intervention « '
      ||coalesce(nullif(trim('Entretien · '||coalesce(v_contract.title,'')),''),'Intervention JKBat')
      ||' » est désormais prise en charge par notre technicien '
      ||v_tech_name
      ||'. Votre rendez-vous est maintenu le '
      ||v_when
      ||'. Vous serez informé dès que le technicien sera en route.';

    if v_conv is not null then
      insert into public.jkbat_messages(
        conversation_id,sender_id,sender_role,body
      ) values (
        v_conv,
        auth.uid(),
        'business',
        v_body
      );
    end if;
  end if;
end;
$$;

revoke all on function public.jkbat_admin_assign_maintenance_visit_staff(uuid,uuid,text) from public;
grant execute on function public.jkbat_admin_assign_maintenance_visit_staff(uuid,uuid,text) to authenticated;

notify pgrst, 'reload schema';

-- Vérification : doit retourner une ligne uuid, uuid, text.
select
  p.proname as function,
  pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and p.proname='jkbat_admin_assign_maintenance_visit_staff';
