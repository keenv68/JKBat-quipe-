-- JKBat Pro / Supabase V147
-- Affecter ou changer un technicien APRES programmation/confirmation client,
-- sans modifier le créneau JKBat Client et sans réinitialiser sa confirmation.

create or replace function public.jkbat_admin_assign_maintenance_visit_staff(
  p_visit_id uuid,
  p_staff_user_id uuid default null,
  p_technician_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_visit public.jkbat_maintenance_visits%rowtype;
  v_contract public.jkbat_maintenance_contracts%rowtype;
  v_assign uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;

  select * into v_visit
    from public.jkbat_maintenance_visits
   where id=p_visit_id
   for update;
  if not found then raise exception 'visit not found'; end if;

  if v_visit.scheduled_at is null then
    raise exception 'visit not scheduled';
  end if;

  select * into v_contract
    from public.jkbat_maintenance_contracts
   where id=v_visit.contract_id;
  if not found then raise exception 'contract not found'; end if;
  if not v_contract.active then raise exception 'contract inactive'; end if;

  -- On récupère l'affectation existante même si la référence historique du passage est vide.
  v_assign := v_visit.staff_assignment_id;
  if v_assign is null then
    select id into v_assign
      from public.jkbat_staff_assignments
     where source_type='CONTRAT'
       and source_id=v_visit.id::text
     order by updated_at desc nulls last
     limit 1;
  end if;

  if p_staff_user_id is not null then
    insert into public.jkbat_staff_assignments(
      staff_user_id,source_type,source_id,title,client_name,client_phone,address,trade,
      scheduled_date,scheduled_time,notes,priority,status,client_profile_id,
      maintenance_contract_id,maintenance_visit_id,maintenance_label,updated_at
    ) values(
      p_staff_user_id,'CONTRAT',v_visit.id::text,'Entretien · '||v_contract.title,
      v_contract.client_name,v_contract.client_phone,v_contract.address,v_contract.trade,
      (v_visit.scheduled_at at time zone 'Europe/Paris')::date,
      (v_visit.scheduled_at at time zone 'Europe/Paris')::time,
      trim(both from concat_ws(E'\n',v_contract.notes,'Contrat récurrent · tous les '||v_contract.interval_months||' mois')),
      'NORMALE','À FAIRE',v_contract.client_id,
      v_contract.id,v_visit.id,v_contract.title,now()
    )
    on conflict(source_type,source_id) do update set
      staff_user_id=excluded.staff_user_id,
      title=excluded.title,
      client_name=excluded.client_name,
      client_phone=excluded.client_phone,
      address=excluded.address,
      trade=excluded.trade,
      scheduled_date=excluded.scheduled_date,
      scheduled_time=excluded.scheduled_time,
      notes=excluded.notes,
      client_profile_id=excluded.client_profile_id,
      maintenance_contract_id=excluded.maintenance_contract_id,
      maintenance_visit_id=excluded.maintenance_visit_id,
      maintenance_label=excluded.maintenance_label,
      status=case
        when upper(coalesce(public.jkbat_staff_assignments.status,'')) like 'TERMIN%'
          then public.jkbat_staff_assignments.status
        else 'À FAIRE'
      end,
      updated_at=now()
    returning id into v_assign;
  else
    -- Désaffectation autorisée tant que la mission salarié n'est pas terminée.
    delete from public.jkbat_staff_assignments
     where (
       id=v_assign
       or (source_type='CONTRAT' and source_id=v_visit.id::text)
     )
       and upper(coalesce(status,'')) not like 'TERMIN%';
    if found then v_assign:=null; end if;
  end if;

  -- IMPORTANT : on ne touche ni au rendez-vous client ni à client_confirmed_at.
  update public.jkbat_maintenance_visits
     set staff_assignment_id=v_assign,
         staff_user_id=p_staff_user_id,
         technician_name=coalesce(p_technician_name,''),
         updated_at=now()
   where id=p_visit_id;
end;
$$;

revoke all on function public.jkbat_admin_assign_maintenance_visit_staff(uuid,uuid,text) from public;
grant execute on function public.jkbat_admin_assign_maintenance_visit_staff(uuid,uuid,text) to authenticated;

notify pgrst, 'reload schema';

-- Vérification : doit retourner une ligne avec les arguments uuid, uuid, text.
select
  p.proname as function,
  pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and p.proname='jkbat_admin_assign_maintenance_visit_staff';
