-- ============================================================
-- JKBat — Chaîne contrat + rendez-vous confirmé V144
-- Pro 6.16.93 / PC 6.17.46 / Client 1.3.23
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Ajoute :
-- 1) retour automatique de la signature client vers JKBat Pro
--    (message client + horodatage de réception),
-- 2) message automatique quand un rendez-vous est planifié/modifié,
-- 3) confirmation obligatoire du créneau côté client,
-- 4) remontée de la confirmation dans les passages de contrat.
-- ============================================================

-- ------------------------------------------------------------
-- CONTRATS : accusé de réception côté JKBat Pro
-- ------------------------------------------------------------
alter table public.jkbat_maintenance_contracts
  add column if not exists pro_received_signed_at timestamptz;

create or replace function public.jkbat_contract_signed_return_to_pro()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_conv uuid;
begin
  if new.client_signed_at is null then
    return new;
  end if;

  if old.client_signed_at is not null then
    return new;
  end if;

  update public.jkbat_maintenance_contracts
     set pro_received_signed_at=coalesce(pro_received_signed_at,now())
   where id=new.id;

  select c.id
    into v_conv
    from public.jkbat_conversations c
   where c.client_id=new.client_id
   order by c.created_at asc
   limit 1;

  if v_conv is null then
    begin
      insert into public.jkbat_conversations(client_id)
      values(new.client_id)
      returning id into v_conv;
    exception when unique_violation then
      select c.id into v_conv
        from public.jkbat_conversations c
       where c.client_id=new.client_id
       order by c.created_at asc
       limit 1;
    end;
  end if;

  if v_conv is not null then
    insert into public.jkbat_messages(
      conversation_id,sender_id,sender_role,body
    ) values (
      v_conv,
      new.client_id,
      'client',
      '✍️ Contrat signé : '
        ||coalesce(nullif(trim(new.title),''),'Contrat JKBat')
        ||'. L’exemplaire signé est maintenant disponible dans JKBat Pro.'
    );
  end if;

  return new;
end;
$$;

drop trigger if exists jkbat_contract_signed_return_to_pro_trg
  on public.jkbat_maintenance_contracts;

create trigger jkbat_contract_signed_return_to_pro_trg
after update of client_signed_at
on public.jkbat_maintenance_contracts
for each row
execute function public.jkbat_contract_signed_return_to_pro();

-- Recalage des contrats déjà signés.
update public.jkbat_maintenance_contracts
   set pro_received_signed_at=coalesce(pro_received_signed_at,client_signed_at)
 where client_signed_at is not null
   and pro_received_signed_at is null;

-- ------------------------------------------------------------
-- RENDEZ-VOUS : confirmation explicite du client
-- ------------------------------------------------------------
alter table public.jkbat_client_appointments
  add column if not exists confirmation_required boolean not null default true,
  add column if not exists confirmation_requested_at timestamptz,
  add column if not exists confirmation_confirmed_at timestamptz;

alter table public.jkbat_maintenance_visits
  add column if not exists client_confirmed_at timestamptz;

create index if not exists jkbat_client_appointments_confirmation_idx
  on public.jkbat_client_appointments(client_id,confirmation_required,start_at);

create or replace function public.jkbat_prepare_appointment_confirmation()
returns trigger
language plpgsql
set search_path=public
as $$
declare
  v_status text := upper(trim(coalesce(new.status,'')));
  v_tracking text := upper(trim(coalesce(new.tracking_status,'')));
  v_schedule_changed boolean := false;
begin
  if tg_op='UPDATE' then
    v_schedule_changed :=
         new.start_at is distinct from old.start_at
      or new.title is distinct from old.title
      or new.address is distinct from old.address;
  end if;

  -- Dès que le déplacement/intervention a réellement commencé,
  -- on ne redemande plus une confirmation de rendez-vous.
  if v_tracking in ('EN ROUTE','SUR PLACE','TERMINÉE','TERMINEE','IMPOSSIBLE')
     or v_status in ('TERMINÉ','TERMINE','ANNULÉ','ANNULE') then
    new.confirmation_required := false;
    return new;
  end if;

  if v_status like 'CONFIRM%' then
    new.confirmation_required := false;
    new.confirmation_confirmed_at := coalesce(new.confirmation_confirmed_at,now());
    return new;
  end if;

  if tg_op='INSERT' then
    new.confirmation_required := true;
    new.confirmation_requested_at := coalesce(new.confirmation_requested_at,now());
    new.confirmation_confirmed_at := null;
  elsif v_schedule_changed then
    -- Toute modification du créneau avant départ doit être reconfirmée.
    new.status := 'PLANIFIÉ';
    new.confirmation_required := true;
    new.confirmation_requested_at := now();
    new.confirmation_confirmed_at := null;
  elsif old.confirmation_required is false
        and new.confirmation_required is true
        and new.confirmation_requested_at is null then
    new.confirmation_requested_at := now();
    new.confirmation_confirmed_at := null;
  end if;

  return new;
end;
$$;

drop trigger if exists jkbat_prepare_appointment_confirmation_trg
  on public.jkbat_client_appointments;

create trigger jkbat_prepare_appointment_confirmation_trg
before insert or update
on public.jkbat_client_appointments
for each row
execute function public.jkbat_prepare_appointment_confirmation();

create or replace function public.jkbat_notify_appointment_confirmation_request()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_conv uuid;
  v_sender uuid;
  v_body text;
  v_when text;
  v_is_change boolean := false;
begin
  if new.confirmation_required is not true
     or new.confirmation_requested_at is null then
    return new;
  end if;

  if tg_op='UPDATE' then
    if new.confirmation_requested_at is not distinct from old.confirmation_requested_at then
      return new;
    end if;
    v_is_change := true;
  end if;

  select c.id
    into v_conv
    from public.jkbat_conversations c
   where c.client_id=new.client_id
   order by c.created_at asc
   limit 1;

  if v_conv is null then
    begin
      insert into public.jkbat_conversations(client_id)
      values(new.client_id)
      returning id into v_conv;
    exception when unique_violation then
      select c.id into v_conv
        from public.jkbat_conversations c
       where c.client_id=new.client_id
       order by c.created_at asc
       limit 1;
    end;
  end if;

  select coalesce(auth.uid(),(
    select a.user_id from public.jkbat_admins a limit 1
  ),new.client_id)
    into v_sender;

  v_when := to_char(
    new.start_at at time zone 'Europe/Paris',
    'DD/MM/YYYY "à" HH24:MI'
  );

  if v_is_change then
    v_body := '🔄 Votre rendez-vous « '
      ||coalesce(nullif(trim(new.title),''),'Intervention JKBat')
      ||' » a été modifié et est maintenant prévu le '
      ||v_when
      ||'. Merci de confirmer ce nouveau créneau dans Mes rendez-vous, ou de demander un autre créneau.';
  else
    v_body := '📅 Votre rendez-vous « '
      ||coalesce(nullif(trim(new.title),''),'Intervention JKBat')
      ||' » est planifié le '
      ||v_when
      ||'. Merci de confirmer le rendez-vous dans Mes rendez-vous, ou de demander un autre créneau.';
  end if;

  if v_conv is not null then
    insert into public.jkbat_messages(
      conversation_id,sender_id,sender_role,body
    ) values (
      v_conv,
      v_sender,
      'business',
      v_body
    );
  end if;

  -- Si le RDV appartient à un contrat, sa confirmation est remise à zéro.
  update public.jkbat_maintenance_visits
     set client_confirmed_at=null,
         updated_at=now()
   where client_appointment_id=new.id;

  return new;
end;
$$;

drop trigger if exists jkbat_notify_appointment_confirmation_request_trg
  on public.jkbat_client_appointments;

create trigger jkbat_notify_appointment_confirmation_request_trg
after insert or update of confirmation_requested_at
on public.jkbat_client_appointments
for each row
execute function public.jkbat_notify_appointment_confirmation_request();

-- Confirmation client : propriété du rendez-vous vérifiée côté serveur.
create or replace function public.jkbat_client_confirm_appointment(
  p_appointment_id uuid
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.jkbat_client_appointments%rowtype;
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;

  select *
    into v
    from public.jkbat_client_appointments
   where id=p_appointment_id
     and client_id=auth.uid()
   for update;

  if not found then
    raise exception 'appointment not found';
  end if;

  if upper(trim(coalesce(v.tracking_status,'')))
       in ('EN ROUTE','SUR PLACE','TERMINÉE','TERMINEE','IMPOSSIBLE') then
    raise exception 'appointment already in progress';
  end if;

  update public.jkbat_client_appointments
     set status='CONFIRMÉ CLIENT',
         confirmation_required=false,
         confirmation_confirmed_at=now()
   where id=p_appointment_id;

  update public.jkbat_maintenance_visits
     set client_confirmed_at=now(),
         updated_at=now()
   where client_appointment_id=p_appointment_id;
end;
$$;

revoke all on function public.jkbat_client_confirm_appointment(uuid) from public;
grant execute on function public.jkbat_client_confirm_appointment(uuid) to authenticated;

-- Les RDV futurs déjà existants passent dans le nouveau circuit.
-- Le trigger ci-dessus enverra un unique message de confirmation.
update public.jkbat_client_appointments
   set confirmation_required=true,
       confirmation_requested_at=now(),
       confirmation_confirmed_at=null
 where start_at >= now()-interval '1 hour'
   and upper(trim(coalesce(status,''))) not like 'CONFIRM%'
   and upper(trim(coalesce(status,''))) not in ('TERMINÉ','TERMINE','ANNULÉ','ANNULE')
   and upper(trim(coalesce(tracking_status,''))) not in ('EN ROUTE','SUR PLACE','TERMINÉE','TERMINEE','IMPOSSIBLE')
   and confirmation_requested_at is null;

notify pgrst, 'reload schema';
