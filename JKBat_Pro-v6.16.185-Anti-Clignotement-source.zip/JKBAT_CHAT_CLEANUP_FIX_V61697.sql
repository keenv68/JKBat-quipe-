-- JKBat Pro v6.16.97 — Correctif suppression des conversations via le balai
-- À exécuter dans Supabase > SQL Editor, une seule fois.
-- Idempotent : peut être relancé sans risque.

begin;

alter table public.jkbat_messages enable row level security;
alter table public.jkbat_conversations enable row level security;

drop policy if exists "jkbat_admin_delete_messages" on public.jkbat_messages;
create policy "jkbat_admin_delete_messages"
on public.jkbat_messages
for delete
to authenticated
using (public.jkbat_is_admin());

drop policy if exists "jkbat_admin_delete_conversations" on public.jkbat_conversations;
create policy "jkbat_admin_delete_conversations"
on public.jkbat_conversations
for delete
to authenticated
using (public.jkbat_is_admin());

create or replace function public.jkbat_admin_delete_client_conversation(p_conversation_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_client_id uuid;
  v_deleted_messages integer := 0;
  v_deleted_conversations integer := 0;
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;

  if not coalesce(public.jkbat_is_admin(), false) then
    raise exception 'admin required';
  end if;

  select client_id
    into v_client_id
  from public.jkbat_conversations
  where id = p_conversation_id;

  if not found then
    return jsonb_build_object('ok', true, 'deleted', false, 'already_absent', true);
  end if;

  delete from public.jkbat_messages
  where conversation_id = p_conversation_id;
  get diagnostics v_deleted_messages = row_count;

  delete from public.jkbat_conversations
  where id = p_conversation_id;
  get diagnostics v_deleted_conversations = row_count;

  if v_deleted_conversations <> 1 then
    raise exception 'conversation not deleted';
  end if;

  return jsonb_build_object(
    'ok', true,
    'deleted', true,
    'client_id', v_client_id,
    'deleted_messages', v_deleted_messages
  );
end;
$$;

revoke all on function public.jkbat_admin_delete_client_conversation(uuid) from public;
grant execute on function public.jkbat_admin_delete_client_conversation(uuid) to authenticated;

commit;

-- Force PostgREST/Supabase à recharger la liste des fonctions RPC.
notify pgrst, 'reload schema';
