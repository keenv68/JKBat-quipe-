-- JKBat Pro v6.16.78 / PC v6.17.31
-- Suppression administrateur d'une conversation client sans supprimer le compte client.
-- Le code de l'application tente d'abord cette RPC puis utilise un DELETE REST direct si la RPC n'est pas installée.
create or replace function public.jkbat_admin_delete_client_conversation(p_conversation_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_client_id uuid;
begin
  if not coalesce(public.jkbat_is_admin(), false) then
    raise exception 'Accès administrateur requis';
  end if;

  select client_id into v_client_id
  from public.jkbat_conversations
  where id = p_conversation_id;

  if v_client_id is null then
    return jsonb_build_object('ok', true, 'deleted', false);
  end if;

  delete from public.jkbat_messages where conversation_id = p_conversation_id;
  delete from public.jkbat_conversations where id = p_conversation_id;

  return jsonb_build_object('ok', true, 'deleted', true, 'client_id', v_client_id);
end;
$$;

grant execute on function public.jkbat_admin_delete_client_conversation(uuid) to authenticated;
