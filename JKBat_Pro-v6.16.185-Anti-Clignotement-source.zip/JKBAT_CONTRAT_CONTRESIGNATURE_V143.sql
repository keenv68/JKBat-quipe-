-- ============================================================
-- JKBat — Contresignature JKBat des anciens contrats V143
-- Pro 6.16.92 / PC 6.17.45 / Client 1.3.22
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Usage :
-- - Les NOUVEAUX contrats conservent le circuit normal :
--   Signature JKBat -> Envoi client -> Signature client.
-- - Ce correctif sert seulement aux contrats déjà signés par le
--   client avant l'ajout de la signature JKBat.
-- ============================================================

create or replace function public.jkbat_admin_countersign_legacy_contract(
  p_contract_id uuid,
  p_signature_data text,
  p_signer_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_contract public.jkbat_maintenance_contracts%rowtype;
  v_signature text := trim(coalesce(p_signature_data,''));
  v_name text := trim(coalesce(p_signer_name,''));
  v_snapshot jsonb;
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;

  if not public.jkbat_is_admin() then
    raise exception 'admin required';
  end if;

  select *
    into v_contract
    from public.jkbat_maintenance_contracts
   where id=p_contract_id;

  if not found then
    raise exception 'contract not found';
  end if;

  if v_contract.client_signed_at is null
     or coalesce(v_contract.client_signature_data,'') = '' then
    raise exception 'legacy countersignature only: client signature required';
  end if;

  if v_contract.provider_signed_at is not null
     and coalesce(v_contract.provider_signature_data,'') <> '' then
    raise exception 'provider signature already exists';
  end if;

  if length(v_signature) < 100
     or position('data:image/' in lower(v_signature)) <> 1 then
    raise exception 'signature required';
  end if;

  if length(v_signature) > 700000 then
    raise exception 'signature too large';
  end if;

  if v_name = '' then
    v_name := 'JKBat Services';
  end if;

  -- Le contenu signé par le client reste strictement inchangé.
  -- On ajoute uniquement la contresignature JKBat avec sa propre date.
  v_snapshot := coalesce(
    v_contract.client_signed_snapshot,
    to_jsonb(v_contract)
      - 'provider_signature_data'
      - 'provider_signer_name'
      - 'provider_signed_at'
      - 'provider_signed_snapshot'
      - 'client_signature_data'
      - 'client_signer_name'
      - 'client_signed_at'
      - 'client_signed_snapshot'
      - 'client_contract_document_id'
  );

  update public.jkbat_maintenance_contracts
     set provider_signature_data=v_signature,
         provider_signer_name=v_name,
         provider_signed_at=now(),
         provider_signed_snapshot=v_snapshot,
         updated_at=now()
   where id=p_contract_id;

  -- Le document reste le même : son statut signale simplement
  -- que les deux signatures sont désormais présentes.
  if v_contract.client_contract_document_id is not null then
    update public.jkbat_client_documents
       set status='SIGNÉ DES DEUX CÔTÉS'
     where id=v_contract.client_contract_document_id
       and client_id=v_contract.client_id;
  end if;
end;
$$;

revoke all on function public.jkbat_admin_countersign_legacy_contract(uuid,text,text) from public;
grant execute on function public.jkbat_admin_countersign_legacy_contract(uuid,text,text) to authenticated;

notify pgrst, 'reload schema';
