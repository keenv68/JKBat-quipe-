-- ============================================================
-- JKBat v6.16.159 / Client v1.3.45
-- Devis : signature CLIENT uniquement + retour automatique vers Pro
-- PDF signé : génération serveur autonome (Edge Function V3)
-- À exécuter APRÈS le déploiement de jkbat-signed-pdf-auto V3.
-- ============================================================

begin;

create extension if not exists pg_net with schema extensions;

alter table public.jkbat_client_documents
  add column if not exists signature_data text,
  add column if not exists signer_name text,
  add column if not exists signed_at timestamptz,
  add column if not exists signed_file_url text,
  add column if not exists signed_pdf_archived_at timestamptz,
  add column if not exists pro_received_signed_at timestamptz,
  add column if not exists signed_pdf_generation_status text,
  add column if not exists signed_pdf_generation_error text,
  add column if not exists signed_pdf_generation_attempted_at timestamptz,
  add column if not exists signed_pdf_generated_by text,
  add column if not exists is_deposit boolean not null default false;

-- Le client est le seul signataire d'un devis.
-- Dès la signature : retour logique dans Pro + mise en file de génération PDF.
create or replace function public.jkbat_client_sign_document(
  p_document_id text,
  p_signature_data text,
  p_signer_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sig text := trim(coalesce(p_signature_data,''));
  v_name text := trim(coalesce(p_signer_name,''));
  v_kind text;
  v_title text;
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;
  if length(v_sig) < 100 or position('data:image/' in lower(v_sig)) <> 1 then
    raise exception 'signature required';
  end if;
  if length(v_sig) > 700000 then
    raise exception 'signature too large';
  end if;

  select upper(coalesce(kind,'')), upper(coalesce(title,''))
    into v_kind, v_title
  from public.jkbat_client_documents
  where id::text=p_document_id
    and client_id=auth.uid();

  if not found then
    raise exception 'document not found';
  end if;

  if v_kind not like '%DEVIS%'
     and v_kind not like '%FACT%'
     and v_title not like '%ACOMPTE%'
     and v_title not like '%ACP-%' then
    raise exception 'document not signable';
  end if;

  update public.jkbat_client_documents
     set signature_data=v_sig,
         signer_name=nullif(v_name,''),
         signed_at=now(),
         status='SIGNÉ CLIENT',
         pro_received_signed_at=now(),
         signed_file_url=null,
         signed_pdf_archived_at=null,
         signed_pdf_generation_status='QUEUED',
         signed_pdf_generation_error=null,
         signed_pdf_generation_attempted_at=null,
         signed_pdf_generated_by=null
   where id::text=p_document_id
     and client_id=auth.uid();
end;
$$;

revoke all on function public.jkbat_client_sign_document(text,text,text) from public;
grant execute on function public.jkbat_client_sign_document(text,text,text) to authenticated;

-- Backup serveur : le trigger appelle l'Edge Function V3 dès la signature.
create or replace function public.jkbat_call_signed_pdf_auto()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  webhook_secret text;
begin
  if upper(coalesce(new.kind,'')) not like '%DEVIS%'
     and coalesce(new.is_deposit,false)=false
     and upper(coalesce(new.title,'')) not like '%ACOMPTE%'
     and upper(coalesce(new.title,'')) not like '%ACP-%' then
    return new;
  end if;

  if new.signed_at is null or coalesce(new.signature_data,'') = '' then
    return new;
  end if;

  if coalesce(new.signed_file_url,'') <> '' and new.signed_pdf_archived_at is not null then
    return new;
  end if;

  select decrypted_secret
    into webhook_secret
  from vault.decrypted_secrets
  where name='jkbat_push_webhook_secret'
  order by created_at desc
  limit 1;

  if coalesce(webhook_secret,'') = '' then
    -- Le Client v1.3.45 appellera aussi directement l'Edge Function.
    return new;
  end if;

  perform net.http_post(
    url := 'https://qyvmbbvjbsbzyapdjjps.supabase.co/functions/v1/jkbat-signed-pdf-auto',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-jkbat-secret',webhook_secret
    ),
    body := jsonb_build_object('document_id',new.id,'source','postgres-trigger-v159')
  );

  return new;
end;
$$;

drop trigger if exists jkbat_signed_pdf_auto_trigger on public.jkbat_client_documents;
create trigger jkbat_signed_pdf_auto_trigger
after insert or update of signed_at, signature_data, signed_file_url, is_deposit
on public.jkbat_client_documents
for each row
execute function public.jkbat_call_signed_pdf_auto();

-- Refile les documents déjà signés mais encore bloqués sur « PDF signé en préparation ».
update public.jkbat_client_documents
set signed_pdf_generation_status='QUEUED',
    signed_pdf_generation_error=null
where signed_at is not null
  and coalesce(signature_data,'') <> ''
  and (
       upper(coalesce(kind,'')) like '%DEVIS%'
    or coalesce(is_deposit,false)=true
    or upper(coalesce(title,'')) like '%ACOMPTE%'
    or upper(coalesce(title,'')) like '%ACP-%'
  )
  and (coalesce(signed_file_url,'')='' or signed_pdf_archived_at is null);

commit;

-- Relance immédiate côté serveur pour les documents en attente.
with secret as (
  select decrypted_secret as s
  from vault.decrypted_secrets
  where name='jkbat_push_webhook_secret'
  order by created_at desc
  limit 1
), pending as (
  select id
  from public.jkbat_client_documents
  where signed_at is not null
    and coalesce(signature_data,'') <> ''
    and (
         upper(coalesce(kind,'')) like '%DEVIS%'
      or coalesce(is_deposit,false)=true
      or upper(coalesce(title,'')) like '%ACOMPTE%'
      or upper(coalesce(title,'')) like '%ACP-%'
    )
    and (coalesce(signed_file_url,'')='' or signed_pdf_archived_at is null)
  order by signed_at desc
  limit 50
)
select net.http_post(
  url := 'https://qyvmbbvjbsbzyapdjjps.supabase.co/functions/v1/jkbat-signed-pdf-auto',
  headers := jsonb_build_object('Content-Type','application/json','x-jkbat-secret',secret.s),
  body := jsonb_build_object('document_id',pending.id,'source','backfill-v159')
)
from pending cross join secret
where coalesce(secret.s,'') <> '';

-- Contrôle final.
select
  id,
  kind,
  title,
  status,
  signer_name,
  signed_at,
  pro_received_signed_at,
  signed_pdf_generation_status,
  signed_pdf_generation_error,
  signed_file_url,
  signed_pdf_archived_at
from public.jkbat_client_documents
where signed_at is not null
  and (
       upper(coalesce(kind,'')) like '%DEVIS%'
    or coalesce(is_deposit,false)=true
    or upper(coalesce(title,'')) like '%ACOMPTE%'
    or upper(coalesce(title,'')) like '%ACP-%'
  )
order by signed_at desc
limit 20;
