-- ============================================================
-- JKBat — Paiement du solde de facture côté Client
-- Compatible : JKBat Pro 6.16.174 / Client 1.3.54
--
-- IMPORTANT : paiement déclaré != paiement confirmé.
-- Le client peut déclarer le règlement du solde ; JKBat Pro reste
-- le seul endroit qui confirme l'encaissement.
-- ============================================================
begin;

create or replace function public.jkbat_client_ack_payment_request(
  p_document_id text
) returns timestamptz
language plpgsql
security definer
set search_path=public
as $$
declare v_seen timestamptz;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;

  update public.jkbat_client_documents d
     set payment_client_seen_at=coalesce(d.payment_client_seen_at,now())
   where d.id::text=p_document_id
     and d.client_id=auth.uid()
     and (
       coalesce(d.is_payment_request,false)=true
       or (
         upper(coalesce(d.kind,'')) like '%FACT%'
         and d.payment_requested_at is not null
         and coalesce(d.balance_due,d.amount,0)>0
       )
     )
  returning d.payment_client_seen_at into v_seen;

  if v_seen is null then raise exception 'payable document not found'; end if;
  return v_seen;
end;
$$;
revoke all on function public.jkbat_client_ack_payment_request(text) from public;
grant execute on function public.jkbat_client_ack_payment_request(text) to authenticated;

create or replace function public.jkbat_client_declare_payment_sent(
  p_document_id text
) returns timestamptz
language plpgsql
security definer
set search_path=public
as $$
declare
  v_doc public.jkbat_client_documents%rowtype;
  v_at timestamptz;
  v_conv uuid;
  v_ref text;
  v_amount numeric;
  v_final_invoice boolean;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;

  select d.* into v_doc
  from public.jkbat_client_documents d
  where d.id::text=p_document_id
    and d.client_id=auth.uid()
    and coalesce(d.balance_due,d.amount,0)>0
    and (
      coalesce(d.is_payment_request,false)=true
      or (upper(coalesce(d.kind,'')) like '%FACT%' and d.payment_requested_at is not null)
    )
  for update;

  if not found then raise exception 'payable document not found'; end if;
  v_at:=coalesce(v_doc.payment_client_declared_paid_at,now());
  v_final_invoice:=not coalesce(v_doc.is_payment_request,false) and upper(coalesce(v_doc.kind,'')) like '%FACT%';

  update public.jkbat_client_documents
     set payment_client_declared_paid_at=v_at
   where id=v_doc.id;

  -- Une seule notification Pro par déclaration. Le statut financier reste inchangé.
  if v_doc.payment_pro_notified_at is null then
    select c.id into v_conv
    from public.jkbat_conversations c
    where c.client_id=v_doc.client_id
    order by c.created_at asc limit 1;

    if v_conv is null then
      begin
        insert into public.jkbat_conversations(client_id) values(v_doc.client_id) returning id into v_conv;
      exception when unique_violation then
        select c.id into v_conv from public.jkbat_conversations c where c.client_id=v_doc.client_id order by c.created_at asc limit 1;
      end;
    end if;

    v_ref:=coalesce(
      nullif(trim(v_doc.payment_reference),''),
      nullif(trim(v_doc.payment_source_quote_no),''),
      nullif(trim(v_doc.source_snapshot->>'invoiceNo'),''),
      nullif(trim(v_doc.title),''),
      'document'
    );
    v_amount:=greatest(0,coalesce(v_doc.balance_due,v_doc.amount,0));

    if v_conv is not null then
      insert into public.jkbat_messages(conversation_id,sender_id,sender_role,body)
      values(
        v_conv,v_doc.client_id,'client',
        '💶 Paiement indiqué par le client : '
        || replace(to_char(v_amount,'FM999999990.00'),'.',',') || ' € · '
        || case when v_final_invoice then 'solde facture ' else 'acompte / paiement ' end
        || v_ref || '. Encaissement à vérifier et confirmer dans JKBat Pro.'
      );
      update public.jkbat_client_documents set payment_pro_notified_at=now() where id=v_doc.id;
    end if;
  end if;

  return v_at;
end;
$$;
revoke all on function public.jkbat_client_declare_payment_sent(text) from public;
grant execute on function public.jkbat_client_declare_payment_sent(text) to authenticated;

create or replace function public.jkbat_client_get_payment_methods(
  p_document_id text
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  d public.jkbat_client_documents%rowtype;
  s public.jkbat_payment_settings%rowtype;
  v_link text; v_iban text; v_bic text; v_beneficiary text; v_reference text; v_method text;
  v_explicit boolean; v_final boolean;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;

  select * into d from public.jkbat_client_documents
  where id::text=p_document_id and client_id=auth.uid() limit 1;
  if not found then raise exception 'payable document not found'; end if;

  v_explicit := coalesce(d.is_payment_request,false)
    or upper(coalesce(d.kind,''))='PAIEMENT'
    or upper(coalesce(d.title,'')) like 'DEMANDE DE PAIEMENT%'
    or lower(coalesce(d.source_snapshot->>'isPaymentRequest',''))='true';
  v_final := upper(coalesce(d.kind,'')) like '%FACT%'
    and not v_explicit
    and d.payment_requested_at is not null
    and coalesce(d.balance_due,d.amount,0)>0;

  if not (v_explicit or v_final) then raise exception 'document is not payable'; end if;

  select * into s from public.jkbat_payment_settings where id=1;
  v_link:=coalesce(nullif(trim(coalesce(d.payment_link,'')),''),nullif(trim(coalesce(d.source_snapshot->>'paymentLink','')),''),case when found then nullif(trim(coalesce(s.payment_link,'')),'') else null end);
  v_iban:=coalesce(nullif(trim(coalesce(d.payment_iban,'')),''),nullif(trim(coalesce(d.source_snapshot->>'paymentIban','')),''),case when found then nullif(trim(coalesce(s.payment_iban,'')),'') else null end);
  v_bic:=coalesce(nullif(trim(coalesce(d.payment_bic,'')),''),nullif(trim(coalesce(d.source_snapshot->>'paymentBic','')),''),case when found then nullif(trim(coalesce(s.payment_bic,'')),'') else null end);
  v_beneficiary:=coalesce(nullif(trim(coalesce(d.payment_beneficiary,'')),''),nullif(trim(coalesce(d.source_snapshot->>'paymentBeneficiary','')),''),case when found then nullif(trim(coalesce(s.payment_beneficiary,'')),'') else null end,'JKBat Services');
  v_reference:=coalesce(nullif(trim(coalesce(d.payment_reference,'')),''),nullif(trim(coalesce(d.source_snapshot->>'paymentReference','')),''),nullif(trim(coalesce(d.source_snapshot->>'invoiceNo','')),''),nullif(trim(coalesce(d.payment_source_quote_no,'')),''),nullif(trim(coalesce(d.title,'')),''));
  v_method:=case when v_link is not null and v_iban is not null then 'BOTH' when v_link is not null then 'ONLINE' when v_iban is not null then 'TRANSFER' else 'CONTACT' end;

  update public.jkbat_client_documents
  set payment_link=v_link,payment_iban=v_iban,payment_bic=v_bic,payment_beneficiary=v_beneficiary,
      payment_reference=coalesce(payment_reference,v_reference),payment_method=v_method,
      source_snapshot=coalesce(source_snapshot,'{}'::jsonb) || jsonb_build_object(
        'paymentMethod',v_method,'paymentLink',v_link,'paymentIban',v_iban,'paymentBic',v_bic,
        'paymentBeneficiary',v_beneficiary,'paymentReference',v_reference,'paymentPurpose',case when v_final then 'FINAL_INVOICE' else 'PAYMENT_REQUEST' end
      )
  where id=d.id;

  return jsonb_build_object(
    'is_payment_request',v_explicit,'payable_invoice',v_final,'payment_method',v_method,
    'payment_link',v_link,'payment_iban',v_iban,'payment_bic',v_bic,
    'payment_beneficiary',v_beneficiary,'payment_reference',v_reference,
    'configured',(v_link is not null or v_iban is not null)
  );
end;
$$;
revoke all on function public.jkbat_client_get_payment_methods(text) from public;
grant execute on function public.jkbat_client_get_payment_methods(text) to authenticated;

notify pgrst, 'reload schema';
commit;
