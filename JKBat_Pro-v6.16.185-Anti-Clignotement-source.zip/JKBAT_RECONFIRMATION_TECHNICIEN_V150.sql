-- ============================================================
-- JKBat — V150
-- Reconfirmation après report + rappel automatique du technicien
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Cas corrigé :
--   1) le client avait confirmé un RDV ;
--   2) un technicien avait déjà été affecté ;
--   3) JKBat Pro reporte le RDV ;
--   4) le client confirme le nouveau créneau ;
--   5) le client reçoit alors automatiquement un message rappelant
--      le technicien déjà affecté et la nouvelle date/heure.
--
-- Aucun changement de technicien et aucune nouvelle affectation.
-- Le push Android continue d'utiliser le circuit jkbat_messages existant.
-- ============================================================

alter table public.jkbat_client_appointments
  add column if not exists reconfirmation_after_report boolean not null default false;

-- ------------------------------------------------------------
-- Report : marque explicitement que la prochaine confirmation
-- est une REconfirmation après changement de créneau.
-- ------------------------------------------------------------
create or replace function public.jkbat_admin_postpone_maintenance_visit(
  p_visit_id uuid,
  p_new_date date
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.jkbat_maintenance_visits%rowtype;
  v_contract_id uuid;
  v_new_start timestamptz;
  v_time time;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_new_date is null then raise exception 'date required'; end if;

  select * into v
    from public.jkbat_maintenance_visits
   where id=p_visit_id
   for update;
  if not found then raise exception 'visit not found'; end if;

  v_contract_id:=v.contract_id;

  if v.scheduled_at is not null then
    v_time:=(v.scheduled_at at time zone 'Europe/Paris')::time;
    v_new_start:=(p_new_date::timestamp + v_time) at time zone 'Europe/Paris';

    if v.client_appointment_id is not null then
      update public.jkbat_client_appointments
         set start_at=v_new_start,
             status='PLANIFIÉ',
             confirmation_required=true,
             confirmation_requested_at=now(),
             confirmation_confirmed_at=null,
             reconfirmation_after_report=true
       where id=v.client_appointment_id;
    end if;

    -- Le technicien reste affecté et sa mission suit le nouveau créneau.
    if v.staff_assignment_id is not null then
      update public.jkbat_staff_assignments
         set scheduled_date=p_new_date,
             scheduled_time=v_time,
             status='À FAIRE',
             completed_at=null,
             updated_at=now()
       where id=v.staff_assignment_id
         and upper(coalesce(status,'')) not like 'TERMIN%';
    end if;

    update public.jkbat_maintenance_visits
       set due_date=p_new_date,
           scheduled_at=v_new_start,
           status='PLANIFIE',
           client_confirmed_at=null,
           client_request_note='',
           client_request_at=null,
           updated_at=now()
     where id=p_visit_id;
  else
    update public.jkbat_maintenance_visits
       set due_date=p_new_date,
           status='A_PLANIFIER',
           client_confirmed_at=null,
           client_request_note='',
           client_request_at=null,
           updated_at=now()
     where id=p_visit_id;
  end if;

  update public.jkbat_maintenance_contracts
     set next_due_date=p_new_date,
         updated_at=now()
   where id=v_contract_id;
end;
$$;

revoke all on function public.jkbat_admin_postpone_maintenance_visit(uuid,date) from public;
grant execute on function public.jkbat_admin_postpone_maintenance_visit(uuid,date) to authenticated;

-- ------------------------------------------------------------
-- Confirmation client : si elle suit un report ET qu'un technicien
-- est déjà affecté, envoie le rappel de prise en charge au client.
-- ------------------------------------------------------------
drop function if exists public.jkbat_client_confirm_appointment(text);

create or replace function public.jkbat_client_confirm_appointment(
  p_appointment_id uuid
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_appt public.jkbat_client_appointments%rowtype;
  v_visit public.jkbat_maintenance_visits%rowtype;
  v_contract public.jkbat_maintenance_contracts%rowtype;
  v_conv uuid;
  v_sender uuid;
  v_tech_name text := '';
  v_title text := '';
  v_when text := '';
  v_body text := '';
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;

  select *
    into v_appt
    from public.jkbat_client_appointments
   where id=p_appointment_id
     and client_id=auth.uid()
   for update;

  if not found then
    raise exception 'appointment not found';
  end if;

  if upper(trim(coalesce(v_appt.tracking_status,'')))
       in ('EN ROUTE','SUR PLACE','TERMINÉE','TERMINEE','IMPOSSIBLE') then
    raise exception 'appointment already in progress';
  end if;

  -- Charge le passage avant de remettre le marqueur de reconfirmation à false.
  select *
    into v_visit
    from public.jkbat_maintenance_visits
   where client_appointment_id=p_appointment_id
   order by updated_at desc nulls last
   limit 1;

  if v_visit.id is not null then
    select * into v_contract
      from public.jkbat_maintenance_contracts
     where id=v_visit.contract_id;
  end if;

  update public.jkbat_client_appointments
     set status='CONFIRMÉ CLIENT',
         confirmation_required=false,
         confirmation_confirmed_at=now(),
         reconfirmation_after_report=false
   where id=p_appointment_id;

  update public.jkbat_maintenance_visits
     set client_confirmed_at=now(),
         updated_at=now()
   where client_appointment_id=p_appointment_id;

  -- Message uniquement après un REPORT + RECONFIRMATION et seulement
  -- si un technicien est déjà affecté. Ainsi, aucune duplication lors
  -- d'une première confirmation classique.
  if coalesce(v_appt.reconfirmation_after_report,false)
     and v_visit.id is not null
     and (v_visit.staff_user_id is not null
          or nullif(trim(coalesce(v_visit.technician_name,'')),'') is not null) then

    v_tech_name := nullif(trim(coalesce(v_visit.technician_name,'')),'');

    if v_tech_name is null and v_visit.staff_user_id is not null then
      select coalesce(
               nullif(trim(p.full_name),''),
               nullif(trim(p.email),''),
               'Technicien JKBat'
             )
        into v_tech_name
        from public.jkbat_staff_profiles p
       where p.id=v_visit.staff_user_id;
    end if;

    v_tech_name := coalesce(v_tech_name,'Technicien JKBat');
    v_title := coalesce(
      nullif(trim(v_appt.title),''),
      nullif(trim('Entretien · '||coalesce(v_contract.title,'')),''),
      'Intervention JKBat'
    );
    v_when := to_char(
      v_appt.start_at at time zone 'Europe/Paris',
      'DD/MM/YYYY "à" HH24:MI'
    );

    select c.id into v_conv
      from public.jkbat_conversations c
     where c.client_id=v_appt.client_id
     order by c.created_at asc
     limit 1;

    if v_conv is null then
      begin
        insert into public.jkbat_conversations(client_id)
        values(v_appt.client_id)
        returning id into v_conv;
      exception when unique_violation then
        select c.id into v_conv
          from public.jkbat_conversations c
         where c.client_id=v_appt.client_id
         order by c.created_at asc
         limit 1;
      end;
    end if;

    select coalesce(
      (select a.user_id from public.jkbat_admins a limit 1),
      auth.uid()
    ) into v_sender;

    v_body := '👨‍🔧 Votre nouveau rendez-vous est confirmé. Votre intervention « '
      ||v_title
      ||' » reste prise en charge par notre technicien '
      ||v_tech_name
      ||'. Rendez-vous le '
      ||v_when
      ||'. Vous serez informé dès que le technicien sera en route.';

    if v_conv is not null then
      insert into public.jkbat_messages(
        conversation_id,sender_id,sender_role,body
      ) values (
        v_conv,
        v_sender,
        'business',
        v_body
      );
    end if;
  end if;
end;
$$;

revoke all on function public.jkbat_client_confirm_appointment(uuid) from public;
grant execute on function public.jkbat_client_confirm_appointment(uuid) to authenticated;

notify pgrst, 'reload schema';

-- Vérifications
select
  p.proname as function,
  pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and p.proname in (
    'jkbat_client_confirm_appointment',
    'jkbat_admin_postpone_maintenance_visit'
  )
order by p.proname;
