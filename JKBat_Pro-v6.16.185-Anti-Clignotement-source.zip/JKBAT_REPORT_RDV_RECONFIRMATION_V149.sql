-- ============================================================
-- JKBat — V149
-- Report d'un rendez-vous = nouveau message + reconfirmation client
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
--
-- Effet quand JKBat Pro reporte un passage déjà programmé :
--   - conserve l'heure du rendez-vous ;
--   - déplace le rendez-vous client et la mission JKBat Équipe ;
--   - annule l'ancienne confirmation client ;
--   - repasse le rendez-vous à « À confirmer » ;
--   - envoie automatiquement un message au client ;
--   - le client doit confirmer le nouveau créneau dans JKBat Client.
-- ============================================================

alter table public.jkbat_client_appointments
  add column if not exists confirmation_required boolean not null default true,
  add column if not exists confirmation_requested_at timestamptz,
  add column if not exists confirmation_confirmed_at timestamptz;

alter table public.jkbat_maintenance_visits
  add column if not exists client_confirmed_at timestamptz;

-- Message automatique à chaque nouvelle demande de confirmation.
create or replace function public.jkbat_notify_appointment_confirmation_request()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_conv uuid;
  v_sender uuid;
  v_body text;
  v_when text;
  v_is_change boolean := false;
begin
  if new.confirmation_required is not true
     or new.confirmation_requested_at is null then
    return new;
  end if;

  if tg_op='UPDATE' then
    if new.confirmation_requested_at is not distinct from old.confirmation_requested_at then
      return new;
    end if;
    v_is_change := true;
  end if;

  select c.id
    into v_conv
    from public.jkbat_conversations c
   where c.client_id=new.client_id
   order by c.created_at asc
   limit 1;

  if v_conv is null then
    begin
      insert into public.jkbat_conversations(client_id)
      values(new.client_id)
      returning id into v_conv;
    exception when unique_violation then
      select c.id into v_conv
        from public.jkbat_conversations c
       where c.client_id=new.client_id
       order by c.created_at asc
       limit 1;
    end;
  end if;

  select coalesce(
    auth.uid(),
    (select a.user_id from public.jkbat_admins a limit 1),
    new.client_id
  ) into v_sender;

  v_when := to_char(
    new.start_at at time zone 'Europe/Paris',
    'DD/MM/YYYY "à" HH24:MI'
  );

  if v_is_change then
    v_body := '🔄 Votre rendez-vous « '
      ||coalesce(nullif(trim(new.title),''),'Intervention JKBat')
      ||' » a été reporté au '
      ||v_when
      ||'. Merci de confirmer ce nouveau créneau dans Mes rendez-vous. Si ce créneau ne vous convient pas, vous pouvez demander un autre créneau.';
  else
    v_body := '📅 Votre rendez-vous « '
      ||coalesce(nullif(trim(new.title),''),'Intervention JKBat')
      ||' » est planifié le '
      ||v_when
      ||'. Merci de confirmer le rendez-vous dans Mes rendez-vous, ou de demander un autre créneau.';
  end if;

  if v_conv is not null then
    insert into public.jkbat_messages(
      conversation_id,sender_id,sender_role,body
    ) values (
      v_conv,
      v_sender,
      'business',
      v_body
    );
  end if;

  -- Le passage contrat repasse lui aussi en attente de confirmation.
  update public.jkbat_maintenance_visits
     set client_confirmed_at=null,
         updated_at=now()
   where client_appointment_id=new.id;

  return new;
end;
$$;

drop trigger if exists jkbat_notify_appointment_confirmation_request_trg
  on public.jkbat_client_appointments;

create trigger jkbat_notify_appointment_confirmation_request_trg
after insert or update of confirmation_requested_at
on public.jkbat_client_appointments
for each row
execute function public.jkbat_notify_appointment_confirmation_request();

-- Report depuis JKBat Pro.
create or replace function public.jkbat_admin_postpone_maintenance_visit(
  p_visit_id uuid,
  p_new_date date
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.jkbat_maintenance_visits%rowtype;
  v_contract_id uuid;
  v_new_start timestamptz;
  v_time time;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.jkbat_is_admin() then raise exception 'admin required'; end if;
  if p_new_date is null then raise exception 'date required'; end if;

  select * into v
    from public.jkbat_maintenance_visits
   where id=p_visit_id
   for update;
  if not found then raise exception 'visit not found'; end if;

  v_contract_id:=v.contract_id;

  if v.scheduled_at is not null then
    v_time:=(v.scheduled_at at time zone 'Europe/Paris')::time;
    v_new_start:=(p_new_date::timestamp + v_time) at time zone 'Europe/Paris';

    -- Nouveau créneau client = ancienne confirmation annulée.
    -- La mise à jour de confirmation_requested_at déclenche le message ci-dessus
    -- et donc également le push via le circuit jkbat_messages existant.
    if v.client_appointment_id is not null then
      update public.jkbat_client_appointments
         set start_at=v_new_start,
             status='PLANIFIÉ',
             confirmation_required=true,
             confirmation_requested_at=now(),
             confirmation_confirmed_at=null
       where id=v.client_appointment_id;
    end if;

    -- La mission Équipe conserve le technicien, mais revient à faire
    -- et prend la nouvelle date / la même heure.
    if v.staff_assignment_id is not null then
      update public.jkbat_staff_assignments
         set scheduled_date=p_new_date,
             scheduled_time=v_time,
             status='À FAIRE',
             completed_at=null,
             updated_at=now()
       where id=v.staff_assignment_id
         and upper(coalesce(status,'')) not like 'TERMIN%';
    end if;

    update public.jkbat_maintenance_visits
       set due_date=p_new_date,
           scheduled_at=v_new_start,
           status='PLANIFIE',
           client_confirmed_at=null,
           client_request_note='',
           client_request_at=null,
           updated_at=now()
     where id=p_visit_id;
  else
    -- Aucun rendez-vous programmé : on décale seulement l'échéance.
    update public.jkbat_maintenance_visits
       set due_date=p_new_date,
           status='A_PLANIFIER',
           client_confirmed_at=null,
           client_request_note='',
           client_request_at=null,
           updated_at=now()
     where id=p_visit_id;
  end if;

  update public.jkbat_maintenance_contracts
     set next_due_date=p_new_date,
         updated_at=now()
   where id=v_contract_id;
end;
$$;

revoke all on function public.jkbat_admin_postpone_maintenance_visit(uuid,date) from public;
grant execute on function public.jkbat_admin_postpone_maintenance_visit(uuid,date) to authenticated;

notify pgrst, 'reload schema';

-- Vérification : une seule fonction de report attendue.
select
  p.proname as function,
  pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and p.proname='jkbat_admin_postpone_maintenance_visit';
