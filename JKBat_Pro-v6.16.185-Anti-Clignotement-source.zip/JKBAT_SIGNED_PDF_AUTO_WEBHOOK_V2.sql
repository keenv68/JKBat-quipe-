-- ============================================================
-- JKBat — PDF signé automatique côté Supabase V2 — devis + acompte
-- À exécuter APRÈS avoir déployé l'Edge Function : jkbat-signed-pdf-auto
-- Réutilise le secret Vault existant : jkbat_push_webhook_secret
-- ============================================================

create extension if not exists pg_net with schema extensions;

alter table public.jkbat_client_documents
  add column if not exists signed_pdf_generation_status text,
  add column if not exists signed_pdf_generation_error text,
  add column if not exists signed_pdf_generation_attempted_at timestamptz,
  add column if not exists signed_pdf_generated_by text;

create or replace function public.jkbat_call_signed_pdf_auto()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  webhook_secret text;
begin
  -- Devis signés OU factures d'acompte signées dont le PDF final n'est pas encore archivé.
  if upper(coalesce(new.kind,'')) not like '%DEVIS%'
     and coalesce(new.is_deposit,false)=false
     and upper(coalesce(new.title,'')) not like '%ACOMPTE%' then
    return new;
  end if;
  if new.signed_at is null or coalesce(new.signature_data,'') = '' then
    return new;
  end if;
  if coalesce(new.signed_file_url,'') <> '' and new.signed_pdf_archived_at is not null then
    return new;
  end if;
  if new.source_snapshot is null then
    return new;
  end if;

  select decrypted_secret
    into webhook_secret
  from vault.decrypted_secrets
  where name = 'jkbat_push_webhook_secret'
  order by created_at desc
  limit 1;

  if webhook_secret is null or webhook_secret = '' then
    raise warning 'Secret Vault jkbat_push_webhook_secret introuvable';
    return new;
  end if;

  perform net.http_post(
    url := 'https://qyvmbbvjbsbzyapdjjps.supabase.co/functions/v1/jkbat-signed-pdf-auto',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-jkbat-secret', webhook_secret
    ),
    body := jsonb_build_object('document_id', new.id)
  );

  return new;
end;
$$;

drop trigger if exists jkbat_signed_pdf_auto_trigger on public.jkbat_client_documents;
create trigger jkbat_signed_pdf_auto_trigger
after insert or update of signed_at, signature_data, source_snapshot, signed_file_url, is_deposit
on public.jkbat_client_documents
for each row
execute function public.jkbat_call_signed_pdf_auto();

-- Backfill : devis et acomptes déjà signés mais encore sans PDF final.
with secret as (
  select decrypted_secret as s
  from vault.decrypted_secrets
  where name='jkbat_push_webhook_secret'
  order by created_at desc
  limit 1
), pending as (
  select id
  from public.jkbat_client_documents
  where (upper(coalesce(kind,'')) like '%DEVIS%' or coalesce(is_deposit,false)=true or upper(coalesce(title,'')) like '%ACOMPTE%')
    and signed_at is not null
    and coalesce(signature_data,'') <> ''
    and source_snapshot is not null
    and (coalesce(signed_file_url,'') = '' or signed_pdf_archived_at is null)
  order by signed_at desc
  limit 50
)
select net.http_post(
  url := 'https://qyvmbbvjbsbzyapdjjps.supabase.co/functions/v1/jkbat-signed-pdf-auto',
  headers := jsonb_build_object('Content-Type','application/json','x-jkbat-secret',secret.s),
  body := jsonb_build_object('document_id', pending.id)
)
from pending cross join secret
where coalesce(secret.s,'') <> '';

-- Vérification de l'installation.
select
  trigger_name,
  event_manipulation,
  event_object_table
from information_schema.triggers
where trigger_schema='public'
  and trigger_name='jkbat_signed_pdf_auto_trigger';
