-- ============================================================
-- JKBat Pro v6.16.160 / Client v1.3.46
-- Workflow devis -> acompte éventuel -> paiement -> facture -> intervention
--
-- Règles :
-- 1) Le devis peut prévoir un acompte (%), mais aucun document d'acompte
--    séparé n'est créé à ce stade.
-- 2) Seul le CLIENT signe le devis.
-- 3) Le PDF signé est généré côté Supabase et revient dans JKBat Pro.
-- 4) Après signature, JKBat Pro peut envoyer une DEMANDE DE PAIEMENT
--    liée au devis. Cette demande ne demande aucune signature.
-- 5) Une fois l'acompte payé, JKBat Pro crée la facture en déduisant
--    l'acompte, puis programme l'intervention.
--
-- À exécuter APRÈS le déploiement de l'Edge Function
-- jkbat-signed-pdf-auto V4.
-- ============================================================

begin;

create extension if not exists pg_net with schema extensions;

alter table public.jkbat_client_documents
  add column if not exists signature_data text,
  add column if not exists signer_name text,
  add column if not exists signed_at timestamptz,
  add column if not exists signed_file_url text,
  add column if not exists signed_pdf_archived_at timestamptz,
  add column if not exists pro_received_signed_at timestamptz,
  add column if not exists signed_pdf_generation_status text,
  add column if not exists signed_pdf_generation_error text,
  add column if not exists signed_pdf_generation_attempted_at timestamptz,
  add column if not exists signed_pdf_generated_by text,
  add column if not exists is_deposit boolean not null default false,
  add column if not exists payment_status text,
  add column if not exists amount_paid numeric(12,2) not null default 0,
  add column if not exists balance_due numeric(12,2),
  add column if not exists payment_requested_at timestamptz,
  add column if not exists payment_due_at date,
  add column if not exists payment_link text,
  add column if not exists payment_note text,
  add column if not exists deposit_percent numeric(5,2),
  add column if not exists source_quote_document_id text,
  add column if not exists is_payment_request boolean not null default false,
  add column if not exists payment_request_type text,
  add column if not exists payment_source_quote_no text;

create index if not exists jkbat_client_documents_payment_request_idx
  on public.jkbat_client_documents(client_id, is_payment_request, payment_status, created_at desc);

create index if not exists jkbat_client_documents_payment_quote_idx
  on public.jkbat_client_documents(source_quote_document_id)
  where source_quote_document_id is not null;

-- ------------------------------------------------------------
-- SIGNATURE : le RPC générique ne signe désormais que les DEVIS.
-- Une demande de paiement n'est jamais signable.
-- ------------------------------------------------------------
create or replace function public.jkbat_client_sign_document(
  p_document_id text,
  p_signature_data text,
  p_signer_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sig text := trim(coalesce(p_signature_data,''));
  v_name text := trim(coalesce(p_signer_name,''));
  v_kind text;
  v_payment_request boolean;
begin
  if auth.uid() is null then
    raise exception 'authentication required';
  end if;

  if length(v_sig) < 100 or position('data:image/' in lower(v_sig)) <> 1 then
    raise exception 'signature required';
  end if;
  if length(v_sig) > 700000 then
    raise exception 'signature too large';
  end if;

  select upper(coalesce(kind,'')), coalesce(is_payment_request,false)
    into v_kind, v_payment_request
  from public.jkbat_client_documents
  where id::text=p_document_id
    and client_id=auth.uid();

  if not found then
    raise exception 'document not found';
  end if;

  if v_payment_request then
    raise exception 'payment request is not signable';
  end if;

  if v_kind not like '%DEVIS%' then
    raise exception 'only quotes are signable with this function';
  end if;

  update public.jkbat_client_documents
     set signature_data=v_sig,
         signer_name=nullif(v_name,''),
         signed_at=now(),
         status='SIGNÉ CLIENT',
         pro_received_signed_at=now(),
         signed_file_url=null,
         signed_pdf_archived_at=null,
         signed_pdf_generation_status='QUEUED',
         signed_pdf_generation_error=null,
         signed_pdf_generation_attempted_at=null,
         signed_pdf_generated_by=null
   where id::text=p_document_id
     and client_id=auth.uid();
end;
$$;

revoke all on function public.jkbat_client_sign_document(text,text,text) from public;
grant execute on function public.jkbat_client_sign_document(text,text,text) to authenticated;

-- ------------------------------------------------------------
-- GARDE-FOU : une demande de paiement ne doit jamais devenir
-- un document signé, même avec une ancienne version du client.
-- ------------------------------------------------------------
create or replace function public.jkbat_guard_payment_request_signature()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if coalesce(new.is_payment_request,false) then
    new.is_deposit := false;
    new.signature_data := null;
    new.signer_name := null;
    new.signed_at := null;
    new.signed_file_url := null;
    new.signed_pdf_archived_at := null;
    new.pro_received_signed_at := null;
    new.signed_pdf_generation_status := null;
    new.signed_pdf_generation_error := null;
    new.signed_pdf_generation_attempted_at := null;
    new.signed_pdf_generated_by := null;
  end if;
  return new;
end;
$$;

drop trigger if exists jkbat_guard_payment_request_signature_trg
  on public.jkbat_client_documents;
create trigger jkbat_guard_payment_request_signature_trg
before insert or update on public.jkbat_client_documents
for each row
execute function public.jkbat_guard_payment_request_signature();

-- ------------------------------------------------------------
-- PDF signé autonome : uniquement les DEVIS signés.
-- ------------------------------------------------------------
create or replace function public.jkbat_call_signed_pdf_auto()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  webhook_secret text;
begin
  if upper(coalesce(new.kind,'')) not like '%DEVIS%' then
    return new;
  end if;

  if coalesce(new.is_payment_request,false) then
    return new;
  end if;

  if new.signed_at is null or coalesce(new.signature_data,'')='' then
    return new;
  end if;

  if coalesce(new.signed_file_url,'')<>'' and new.signed_pdf_archived_at is not null then
    return new;
  end if;

  select decrypted_secret
    into webhook_secret
  from vault.decrypted_secrets
  where name='jkbat_push_webhook_secret'
  order by created_at desc
  limit 1;

  if coalesce(webhook_secret,'')='' then
    -- Le Client v1.3.46 appelle aussi directement l'Edge Function V4.
    return new;
  end if;

  perform net.http_post(
    url := 'https://qyvmbbvjbsbzyapdjjps.supabase.co/functions/v1/jkbat-signed-pdf-auto',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-jkbat-secret',webhook_secret
    ),
    body := jsonb_build_object(
      'document_id',new.id,
      'source','postgres-trigger-v160'
    )
  );

  return new;
end;
$$;

drop trigger if exists jkbat_signed_pdf_auto_trigger on public.jkbat_client_documents;
create trigger jkbat_signed_pdf_auto_trigger
after insert or update of signed_at, signature_data, signed_file_url
on public.jkbat_client_documents
for each row
execute function public.jkbat_call_signed_pdf_auto();

-- Les anciennes « factures d'acompte » restent archivées, mais elles ne
-- doivent plus être proposées comme nouveau workflow de signature.
update public.jkbat_client_documents
set is_payment_request=false
where coalesce(is_payment_request,false)=false;

-- Répare les demandes de paiement V160 existantes si elles ont déjà été créées.
update public.jkbat_client_documents
set is_deposit=false,
    signature_data=null,
    signer_name=null,
    signed_at=null,
    signed_file_url=null,
    signed_pdf_archived_at=null,
    pro_received_signed_at=null
where coalesce(is_payment_request,false)=true;

-- Refile les devis signés encore bloqués en « PDF signé en préparation ».
update public.jkbat_client_documents
set signed_pdf_generation_status='QUEUED',
    signed_pdf_generation_error=null
where upper(coalesce(kind,'')) like '%DEVIS%'
  and coalesce(is_payment_request,false)=false
  and signed_at is not null
  and coalesce(signature_data,'')<>''
  and (coalesce(signed_file_url,'')='' or signed_pdf_archived_at is null);

notify pgrst, 'reload schema';

commit;

-- Relance immédiate des devis signés encore en attente.
with secret as (
  select decrypted_secret as s
  from vault.decrypted_secrets
  where name='jkbat_push_webhook_secret'
  order by created_at desc
  limit 1
), pending as (
  select id
  from public.jkbat_client_documents
  where upper(coalesce(kind,'')) like '%DEVIS%'
    and coalesce(is_payment_request,false)=false
    and signed_at is not null
    and coalesce(signature_data,'')<>''
    and (coalesce(signed_file_url,'')='' or signed_pdf_archived_at is null)
  order by signed_at desc
  limit 50
)
select net.http_post(
  url := 'https://qyvmbbvjbsbzyapdjjps.supabase.co/functions/v1/jkbat-signed-pdf-auto',
  headers := jsonb_build_object(
    'Content-Type','application/json',
    'x-jkbat-secret',secret.s
  ),
  body := jsonb_build_object(
    'document_id',pending.id,
    'source','backfill-v160'
  )
)
from pending cross join secret
where coalesce(secret.s,'')<>'';

-- Contrôle final.
select
  id,
  kind,
  title,
  status,
  is_payment_request,
  payment_request_type,
  payment_source_quote_no,
  source_quote_document_id,
  payment_status,
  amount,
  amount_paid,
  balance_due,
  signer_name,
  signed_at,
  signed_file_url,
  signed_pdf_archived_at
from public.jkbat_client_documents
where upper(coalesce(kind,'')) like '%DEVIS%'
   or coalesce(is_payment_request,false)=true
order by created_at desc
limit 30;
