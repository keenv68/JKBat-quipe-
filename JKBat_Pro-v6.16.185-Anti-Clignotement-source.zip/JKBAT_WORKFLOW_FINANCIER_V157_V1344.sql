-- ============================================================
-- JKBat — Workflow financier v6.16.157 / Client v1.3.44
-- Devis -> acompte signé client -> paiement -> intervention -> facture finale
-- À exécuter UNE FOIS dans Supabase > SQL Editor > Run
-- ============================================================

-- 1) Métadonnées de paiement sur les documents visibles côté client.
alter table public.jkbat_client_documents
  add column if not exists payment_status text,
  add column if not exists amount_paid numeric(12,2) not null default 0,
  add column if not exists balance_due numeric(12,2),
  add column if not exists payment_requested_at timestamptz,
  add column if not exists payment_due_at date,
  add column if not exists payment_link text,
  add column if not exists payment_note text,
  add column if not exists is_deposit boolean not null default false,
  add column if not exists deposit_percent numeric(5,2),
  add column if not exists source_quote_document_id text;

create index if not exists jkbat_client_documents_payment_idx
  on public.jkbat_client_documents(client_id, payment_status, created_at desc);

create index if not exists jkbat_client_documents_source_quote_idx
  on public.jkbat_client_documents(source_quote_document_id)
  where source_quote_document_id is not null;

-- 2) Normalisation automatique des informations financières.
create or replace function public.jkbat_normalize_client_document_finance()
returns trigger
language plpgsql
security definer
set search_path=public,pg_catalog
as $$
declare
  v_kind text := upper(coalesce(new.kind,''));
  v_status text := upper(coalesce(new.status,''));
  v_snap jsonb := new.source_snapshot;
  v_paid numeric := coalesce(new.amount_paid,0);
  v_amount numeric := coalesce(new.amount,0);
  v_tmp text;
begin
  if v_kind not like '%FACT%' then
    return new;
  end if;

  -- Reprend les données de JKBat Pro quand elles sont présentes dans le snapshot.
  if v_snap is not null then
    if coalesce(new.source_quote_document_id,'')='' then
      new.source_quote_document_id := nullif(coalesce(v_snap->>'depositForQuoteId',v_snap->>'sourceQuoteId',v_snap->>'parentId',''),'');
    end if;

    if coalesce(new.is_deposit,false)=false then
      new.is_deposit := coalesce(
        case when lower(coalesce(v_snap->>'isDeposit','')) in ('true','1','yes') then true else false end,
        false
      ) or upper(coalesce(v_snap->>'nature','')) like '%ACOMPTE%';
    end if;

    if new.deposit_percent is null then
      v_tmp := nullif(v_snap->>'depositPercent','');
      if v_tmp ~ '^[0-9]+([.,][0-9]+)?$' then
        new.deposit_percent := replace(v_tmp,',','.')::numeric;
      end if;
    end if;

    if new.payment_due_at is null then
      v_tmp := nullif(coalesce(v_snap->>'paymentDueDate',v_snap->>'dueDate',''),'');
      if v_tmp ~ '^\d{4}-\d{2}-\d{2}$' then new.payment_due_at := v_tmp::date; end if;
    end if;

    if coalesce(new.payment_link,'')='' then
      new.payment_link := nullif(v_snap->>'paymentLink','');
    end if;

    if new.payment_requested_at is null then
      v_tmp := nullif(v_snap->>'paymentRequestedAt','');
      begin
        if v_tmp is not null then new.payment_requested_at := v_tmp::timestamptz; end if;
      exception when others then null;
      end;
    end if;
  end if;

  -- Pour un acompte, la signature client débloque automatiquement le paiement.
  -- La facture d'acompte peut donc être envoyée avec le statut « À signer » :
  -- aucune demande de paiement n'est active tant que signed_at est vide.
  if coalesce(new.is_deposit,false)=true
     and new.signed_at is not null
     and new.payment_requested_at is null then
    new.payment_requested_at := now();
  end if;

  -- Un statut « À régler » transmis par Pro correspond à une demande de paiement.
  if new.payment_requested_at is null
     and (v_status like '%RÉGLER%' or v_status like '%REGLER%') then
    new.payment_requested_at := now();
  end if;

  new.amount_paid := greatest(0,coalesce(new.amount_paid,0));
  new.balance_due := greatest(0,v_amount-new.amount_paid);

  if v_amount > 0 and new.balance_due <= 0.009 then
    new.payment_status := 'PAYÉ';
  elsif new.amount_paid > 0 then
    new.payment_status := 'PARTIEL';
  elsif new.payment_requested_at is not null or v_status like '%RÉGLER%' or v_status like '%REGLER%' then
    new.payment_status := 'À RÉGLER';
  elsif coalesce(new.payment_status,'')='' then
    new.payment_status := 'NON DEMANDÉ';
  end if;

  return new;
end;
$$;

drop trigger if exists jkbat_client_documents_finance_normalize
  on public.jkbat_client_documents;
create trigger jkbat_client_documents_finance_normalize
before insert or update of amount, status, amount_paid, payment_requested_at,
  payment_due_at, payment_link, source_snapshot, is_deposit, deposit_percent,
  source_quote_document_id, signed_at
on public.jkbat_client_documents
for each row
execute function public.jkbat_normalize_client_document_finance();

-- 3) Backfill non destructif des factures déjà présentes.
update public.jkbat_client_documents
set
  amount_paid = coalesce(amount_paid,0),
  balance_due = greatest(0,coalesce(amount,0)-coalesce(amount_paid,0)),
  payment_status = case
    when coalesce(amount,0)>0 and greatest(0,coalesce(amount,0)-coalesce(amount_paid,0))<=0.009 then 'PAYÉ'
    when coalesce(amount_paid,0)>0 then 'PARTIEL'
    when upper(coalesce(status,'')) like '%RÉGLER%' or upper(coalesce(status,'')) like '%REGLER%' then 'À RÉGLER'
    else coalesce(nullif(payment_status,''),'NON DEMANDÉ')
  end
where upper(coalesce(kind,'')) like '%FACT%';

-- Force l'exécution du normaliseur pour les snapshots existants de factures.
update public.jkbat_client_documents
set source_snapshot=source_snapshot
where upper(coalesce(kind,'')) like '%FACT%'
  and source_snapshot is not null;

-- 3b) Les acomptes déjà signés mais encore « NON DEMANDÉ » sont débloqués.
update public.jkbat_client_documents
set payment_requested_at=coalesce(payment_requested_at,signed_at,now())
where upper(coalesce(kind,'')) like '%FACT%'
  and coalesce(is_deposit,false)=true
  and signed_at is not null
  and payment_requested_at is null
  and coalesce(amount,0)>coalesce(amount_paid,0);

-- Recalcul après le déblocage des acomptes signés.
update public.jkbat_client_documents
set signed_at=signed_at
where coalesce(is_deposit,false)=true
  and signed_at is not null;

-- 4) RPC de contrôle (lecture uniquement du client connecté).
create or replace function public.jkbat_client_my_financial_documents()
returns setof public.jkbat_client_documents
language sql
stable
security definer
set search_path=public,pg_catalog
as $$
  select d.*
  from public.jkbat_client_documents d
  where auth.uid() is not null
    and d.client_id=auth.uid()
    and coalesce(d.client_visible,true)=true
    and upper(coalesce(d.kind,'')) like '%FACT%'
  order by d.created_at desc
  limit 100;
$$;

revoke all on function public.jkbat_client_my_financial_documents() from public;
grant execute on function public.jkbat_client_my_financial_documents() to authenticated;

notify pgrst, 'reload schema';

-- 5) Vérification.
select
  trigger_name,
  event_manipulation,
  event_object_table
from information_schema.triggers
where trigger_schema='public'
  and trigger_name='jkbat_client_documents_finance_normalize'
order by event_manipulation;
