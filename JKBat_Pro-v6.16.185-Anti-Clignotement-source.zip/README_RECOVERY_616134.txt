JKBat Pro v6.16.134 — RECOVERY FONCTIONS

Base fonctionnelle : JKBat Pro v6.16.121 exacte.
Seuls versionCode/versionName ont été augmentés pour permettre une mise à jour au-dessus des versions UI2.
Aucune fonction métier, aucun écran, aucun flux Supabase, PDF, signature, Client, Équipe, GPS, planning, devis, facture, tâche, rendez-vous ou fiche d'intervention n'a été réécrit.

But : revenir à un état fonctionnel de référence avant de réappliquer l'interface UI2 séparément.
