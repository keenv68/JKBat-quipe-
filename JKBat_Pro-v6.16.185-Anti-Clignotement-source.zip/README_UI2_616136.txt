JKBat Pro v6.16.136
Base: v6.16.135 validée.
Modification: UI2 appliquée uniquement à l'accueil + écran Interventions (#terrain).
Aucune fonction métier, handler, synchronisation, PDF, signature, GPS, planning ou suivi n'a été réécrit.
