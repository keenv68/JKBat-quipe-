JKBat Pro v6.16.137 — UI2 écran Clients uniquement

Base : v6.16.136 validée.
Modifications : couche CSS visuelle uniquement sur #clients + numéro de version.
Aucune fonction métier Clients, Suivi client, devis/factures, documents, messages, rendez-vous, tâches ou synchronisation n'est réécrite.
Accueil et Interventions UI2 de la base v6.16.136 sont conservés.
