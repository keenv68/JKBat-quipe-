JKBat Pro v6.16.135 — UI2 Accueil Test

Base métier : v6.16.134 RECOVERY, elle-même identique au moteur v6.16.121.
Modifications volontaires :
- style CSS strictement limité à #dashboard ;
- copie de l'asset visuel ui2-hero-house.jpg ;
- ajout d'un quatrième raccourci accueil « Nouvelle tâche » appelant la fonction historique openTask().
- versionCode/versionName.
Aucun écran métier, stockage, Supabase, PDF, signature, document, planning, suivi client/équipe, GPS ou message n'est réécrit.
