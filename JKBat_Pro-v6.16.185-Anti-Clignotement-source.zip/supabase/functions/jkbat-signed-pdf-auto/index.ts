// JKBat — PDF signé automatique côté Supabase
// Edge Function : jkbat-signed-pdf-auto
// Génère le PDF final d'un devis dès que le client signe, même si JKBat Pro est fermé.
// Secrets requis : SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, JKBAT_PUSH_WEBHOOK_SECRET

import { createClient } from "npm:@supabase/supabase-js@2";
import { PDFDocument, StandardFonts, rgb } from "npm:pdf-lib@1.17.1";

type AnyObj = Record<string, any>;

const corsHeaders = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "authorization, x-client-info, apikey, content-type, x-jkbat-secret",
  "access-control-allow-methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, "content-type": "application/json; charset=utf-8" },
});

const GOLD = rgb(0.80, 0.58, 0.28);
const GOLD_LIGHT = rgb(0.97, 0.94, 0.88);
const BLACK = rgb(0.08, 0.08, 0.08);
const GRAY = rgb(0.43, 0.43, 0.43);
const LINE = rgb(0.84, 0.82, 0.78);
const WHITE = rgb(1, 1, 1);
const GREEN = rgb(0.18, 0.48, 0.29);
const GREEN_LIGHT = rgb(0.91, 0.97, 0.93);

function txt(v: unknown): string { return String(v ?? "").trim(); }
function safePdfText(v: unknown): string {
  return txt(v)
    .replace(/\u00a0/g, " ")
    .replace(/[’‘]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, "-")
    .replace(/…/g, "...")
    .replace(/€/g, " EUR")
    .replace(/[^\u0009\u000A\u000D\u0020-\u00FF]/g, "");
}
function n(v: unknown): number { const x = Number(v); return Number.isFinite(x) ? x : 0; }
function money(v: unknown): string {
  return `${n(v).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} EUR`;
}
function dateFr(v: unknown, withTime = false): string {
  if (!v) return "";
  try {
    const d = new Date(String(v));
    return new Intl.DateTimeFormat("fr-FR", withTime
      ? { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" }
      : { dateStyle: "medium", timeZone: "Europe/Paris" }).format(d);
  } catch { return txt(v); }
}
function calc(d: AnyObj) {
  const rows = Array.isArray(d.rows) ? d.rows : [];
  const sub = rows.reduce((s: number, r: AnyObj) => s + n(r.qty) * n(r.price), 0);
  const disc = Math.max(0, Math.min(100, n(d.discount)));
  const after = sub * (1 - disc / 100);
  const vat = Math.max(0, n(d.vat));
  const tax = after * vat / 100;
  return { sub, disc, after, vat, tax, total: after + tax };
}
function filename(v: unknown): string {
  return safePdfText(v || "Devis")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9_-]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "Devis";
}
function wrapText(font: any, raw: unknown, size: number, maxWidth: number): string[] {
  const value = safePdfText(raw);
  if (!value) return [""];
  const out: string[] = [];
  for (const para of value.split(/\r?\n/)) {
    const words = para.split(/\s+/).filter(Boolean);
    if (!words.length) { out.push(""); continue; }
    let line = "";
    for (const word0 of words) {
      let word = word0;
      const candidate = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(candidate, size) <= maxWidth) { line = candidate; continue; }
      if (line) { out.push(line); line = ""; }
      if (font.widthOfTextAtSize(word, size) <= maxWidth) { line = word; continue; }
      let part = "";
      for (const ch of word) {
        const test = part + ch;
        if (font.widthOfTextAtSize(test, size) > maxWidth && part) { out.push(part); part = ch; }
        else part = test;
      }
      line = part;
    }
    if (line) out.push(line);
  }
  return out.length ? out : [""];
}
function dataUrlBytes(dataUrl: string): { mime: string; bytes: Uint8Array } | null {
  const m = /^data:([^;]+);base64,(.+)$/i.exec(txt(dataUrl));
  if (!m) return null;
  try {
    const bin = atob(m[2]);
    const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    return { mime: m[1].toLowerCase(), bytes };
  } catch { return null; }
}

async function buildSignedQuotePdf(row: AnyObj): Promise<Uint8Array> {
  let snap: AnyObj = {};
  if (row.source_snapshot && typeof row.source_snapshot === "object") snap = structuredClone(row.source_snapshot);
  else if (typeof row.source_snapshot === "string") { try { snap = JSON.parse(row.source_snapshot); } catch { snap = {}; } }
  if (!Object.keys(snap).length) throw new Error("source_snapshot manquant");

  snap.kind = "DEVIS";
  snap.signature = row.signature_data || snap.signature || "";
  snap.clientSigner = row.signer_name || snap.clientSigner || snap.clientName || "Client";
  snap.signedAt = row.signed_at || snap.signedAt || "";
  snap.status = "ACCEPTE";

  const pdf = await PDFDocument.create();
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const W = 595.28, H = 841.89, M = 42;
  let page: any;
  let y = 0;

  function newPage(continuation = false) {
    page = pdf.addPage([W, H]); y = H - M;
    page.drawRectangle({ x: 0, y: H - 7, width: W, height: 7, color: GOLD });
    if (continuation) {
      page.drawText("JKBat'Services - Devis signe (suite)", { x: M, y: y - 8, size: 9, font: bold, color: GOLD });
      y -= 28;
    }
  }
  function ensure(h: number, continuation = true) { if (y - h < 58) newPage(continuation); }
  function line(x1: number, x2: number, yy: number, color = LINE, thickness = 0.7) {
    page.drawLine({ start: { x: x1, y: yy }, end: { x: x2, y: yy }, thickness, color });
  }
  function drawWrapped(raw: unknown, x: number, maxWidth: number, size = 9, font = regular, color = BLACK, leading = 12) {
    const lines = wrapText(font, raw, size, maxWidth);
    ensure(lines.length * leading + 4);
    for (const l of lines) { page.drawText(l, { x, y, size, font, color }); y -= leading; }
    return lines.length;
  }
  function footer() {
    const pages = pdf.getPages();
    pages.forEach((p, i) => {
      p.drawLine({ start: { x: M, y: 36 }, end: { x: W - M, y: 36 }, thickness: 0.8, color: GOLD });
      p.drawText("JKBat' Services - 20 Rue Sainte-Claire Deville - 68310 Wittelsheim", { x: M, y: 23, size: 7.3, font: regular, color: GRAY });
      p.drawText(`SIRET 93757255000013 - 06 59 89 28 17 - contact@jkbat.fr`, { x: M, y: 12, size: 7.3, font: regular, color: GRAY });
      const pg = `Page ${i + 1} / ${pages.length}`;
      p.drawText(pg, { x: W - M - regular.widthOfTextAtSize(pg, 7.3), y: 12, size: 7.3, font: regular, color: GRAY });
    });
  }

  newPage(false);

  // Logo vectoriel + identité
  page.drawCircle({ x: 74, y: y - 24, size: 27, borderColor: GOLD, borderWidth: 2.2, color: WHITE });
  page.drawText("JK", { x: 55, y: y - 35, size: 26, font: bold, color: BLACK });
  page.drawText("JKBat'SERVICES", { x: 112, y: y - 14, size: 19, font: bold, color: BLACK });
  page.drawText("Travaux - renovation - depannage", { x: 112, y: y - 31, size: 9, font: regular, color: GRAY });

  const refRaw = txt(snap.invoiceNo || row.title || "");
  const ref = /^DEV-/i.test(refRaw) ? refRaw : (refRaw ? `DEV-${refRaw}` : "DEVIS");
  page.drawRectangle({ x: W - M - 176, y: y - 52, width: 176, height: 54, color: GOLD_LIGHT, borderColor: GOLD, borderWidth: 0.8 });
  page.drawText("DEVIS SIGNE", { x: W - M - 163, y: y - 15, size: 13, font: bold, color: BLACK });
  page.drawText(safePdfText(ref), { x: W - M - 163, y: y - 31, size: 9, font: bold, color: GOLD });
  page.drawText(`Date : ${safePdfText(dateFr(snap.date || row.created_at))}`, { x: W - M - 163, y: y - 45, size: 8.2, font: regular, color: GRAY });
  y -= 72;

  // Société / client
  page.drawRectangle({ x: M, y: y - 71, width: 245, height: 71, color: GOLD_LIGHT, borderColor: LINE, borderWidth: 0.7 });
  page.drawText("JKBat' Services", { x: M + 12, y: y - 18, size: 10, font: bold, color: BLACK });
  page.drawText("20 Rue Sainte-Claire Deville", { x: M + 12, y: y - 34, size: 8.2, font: regular, color: GRAY });
  page.drawText("68310 Wittelsheim", { x: M + 12, y: y - 47, size: 8.2, font: regular, color: GRAY });
  page.drawText("06 59 89 28 17 - contact@jkbat.fr", { x: M + 12, y: y - 61, size: 8.2, font: regular, color: GRAY });

  page.drawRectangle({ x: M + 258, y: y - 71, width: W - 2 * M - 258, height: 71, color: WHITE, borderColor: LINE, borderWidth: 0.7 });
  page.drawText("CLIENT", { x: M + 270, y: y - 17, size: 8.5, font: bold, color: GOLD });
  page.drawText(safePdfText(snap.clientName || "Client"), { x: M + 270, y: y - 34, size: 10, font: bold, color: BLACK });
  const addrLines = wrapText(regular, snap.clientAddress || "", 8.2, W - 2 * M - 285);
  let ay = y - 48;
  for (const l of addrLines.slice(0, 2)) { page.drawText(l, { x: M + 270, y: ay, size: 8.2, font: regular, color: GRAY }); ay -= 11; }
  y -= 86;

  page.drawRectangle({ x: M, y: y - 27, width: W - 2 * M, height: 27, color: GOLD_LIGHT, borderColor: GOLD, borderWidth: 0.7 });
  page.drawText(`Nature de l'intervention : ${safePdfText(snap.trade || snap.category || snap.nature || "Non categorise")}`, { x: M + 10, y: y - 18, size: 9, font: bold, color: BLACK });
  y -= 40;

  const commentParts = [snap.intervention, snap.control, snap.inspection].filter(Boolean);
  if (commentParts.length || snap.recommendation || snap.result) {
    ensure(80);
    page.drawText("Commentaires ou instructions speciales", { x: M, y, size: 10, font: bold, color: GOLD }); y -= 15;
    for (const c of commentParts) { drawWrapped(c, M, W - 2 * M, 8.5, regular, BLACK, 11); y -= 3; }
    if (snap.recommendation) { page.drawText("Preconisation :", { x: M, y, size: 8.5, font: bold, color: BLACK }); y -= 11; drawWrapped(snap.recommendation, M, W - 2 * M, 8.5, regular, BLACK, 11); }
    if (snap.result) { page.drawText("Resultat :", { x: M, y, size: 8.5, font: bold, color: BLACK }); y -= 11; drawWrapped(snap.result, M, W - 2 * M, 8.5, regular, BLACK, 11); }
    y -= 8;
  }

  // Tableau prestations
  const rows = Array.isArray(snap.rows) ? snap.rows : [];
  const cols = [90, 250, 42, 62, 67];
  const xs = [M, M + cols[0], M + cols[0] + cols[1], M + cols[0] + cols[1] + cols[2], M + cols[0] + cols[1] + cols[2] + cols[3]];
  function tableHeader() {
    ensure(26);
    page.drawRectangle({ x: M, y: y - 22, width: W - 2 * M, height: 22, color: GOLD });
    ["NOM", "Description", "Qte", "Prix unit.", "Montant"].forEach((h, i) => page.drawText(h, { x: xs[i] + 5, y: y - 15, size: 7.8, font: bold, color: BLACK }));
    y -= 22;
  }
  tableHeader();
  if (!rows.length) {
    page.drawRectangle({ x: M, y: y - 28, width: W - 2 * M, height: 28, borderColor: LINE, borderWidth: 0.6, color: WHITE }); y -= 28;
  } else {
    for (const r of rows) {
      const descLines = wrapText(regular, r.description || "", 7.7, cols[1] - 10);
      const nameLines = wrapText(bold, r.label || "", 7.7, cols[0] - 10);
      const rowH = Math.max(28, Math.max(descLines.length, nameLines.length) * 10 + 10);
      if (y - rowH < 80) { newPage(true); tableHeader(); }
      page.drawRectangle({ x: M, y: y - rowH, width: W - 2 * M, height: rowH, borderColor: LINE, borderWidth: 0.55, color: WHITE });
      for (let i = 1; i < xs.length; i++) page.drawLine({ start: { x: xs[i], y }, end: { x: xs[i], y: y - rowH }, thickness: 0.45, color: LINE });
      let ty = y - 12;
      nameLines.forEach((l, j) => page.drawText(l, { x: xs[0] + 5, y: ty - j * 10, size: 7.7, font: bold, color: BLACK }));
      descLines.forEach((l, j) => page.drawText(l, { x: xs[1] + 5, y: ty - j * 10, size: 7.7, font: regular, color: BLACK }));
      page.drawText(safePdfText(n(r.qty)), { x: xs[2] + 7, y: ty, size: 7.7, font: regular, color: BLACK });
      page.drawText(safePdfText(money(r.price)), { x: xs[3] + 4, y: ty, size: 7.2, font: regular, color: BLACK });
      page.drawText(safePdfText(money(n(r.qty) * n(r.price))), { x: xs[4] + 4, y: ty, size: 7.2, font: bold, color: BLACK });
      y -= rowH;
    }
  }
  y -= 12;

  const totals = calc(snap);
  ensure(115);
  const bx = W - M - 215, bw = 215;
  const totalRows: Array<[string, string, boolean]> = [
    ["Sous-total", money(totals.sub), false],
    ["Remise", totals.disc ? `${totals.disc.toLocaleString("fr-FR")} %` : "0 %", false],
  ];
  if (totals.vat) totalRows.push([`TVA ${totals.vat.toLocaleString("fr-FR")} %`, money(totals.tax), false]);
  totalRows.push(["TOTAL", money(totals.total), true]);
  for (const [label, val, grand] of totalRows) {
    const h = grand ? 29 : 23;
    page.drawRectangle({ x: bx, y: y - h, width: bw, height: h, color: grand ? GOLD : WHITE, borderColor: LINE, borderWidth: 0.6 });
    page.drawText(label, { x: bx + 10, y: y - h + 8, size: grand ? 10 : 8.5, font: grand ? bold : regular, color: BLACK });
    const tw = (grand ? bold : regular).widthOfTextAtSize(safePdfText(val), grand ? 10 : 8.5);
    page.drawText(safePdfText(val), { x: bx + bw - 10 - tw, y: y - h + 8, size: grand ? 10 : 8.5, font: grand ? bold : regular, color: BLACK });
    y -= h;
  }
  y -= 18;

  // Signature finale
  ensure(150);
  page.drawRectangle({ x: M, y: y - 126, width: W - 2 * M, height: 126, color: GREEN_LIGHT, borderColor: GREEN, borderWidth: 0.9 });
  page.drawText("BON POUR ACCORD - DEVIS SIGNE", { x: M + 14, y: y - 20, size: 11, font: bold, color: GREEN });
  page.drawText(`Signataire : ${safePdfText(snap.clientSigner || row.signer_name || snap.clientName || "Client")}`, { x: M + 14, y: y - 39, size: 8.8, font: bold, color: BLACK });
  page.drawText(`Signe le : ${safePdfText(dateFr(snap.signedAt || row.signed_at, true))}`, { x: M + 14, y: y - 55, size: 8.4, font: regular, color: GRAY });
  page.drawText("La signature electronique vaut acceptation du present devis.", { x: M + 14, y: y - 72, size: 8.2, font: regular, color: GRAY });

  const sig = dataUrlBytes(txt(snap.signature || row.signature_data));
  if (sig) {
    try {
      const img = sig.mime.includes("png") ? await pdf.embedPng(sig.bytes) : await pdf.embedJpg(sig.bytes);
      const maxW = 185, maxH = 80;
      const scale = Math.min(maxW / img.width, maxH / img.height, 1);
      const iw = img.width * scale, ih = img.height * scale;
      page.drawImage(img, { x: W - M - 15 - iw, y: y - 23 - ih, width: iw, height: ih });
    } catch { /* signature texte reste présente */ }
  }
  y -= 142;
  page.drawText("Merci pour votre confiance.", { x: M, y, size: 9, font: bold, color: GOLD });

  footer();
  pdf.setTitle(`Devis signe ${ref}`);
  pdf.setAuthor("JKBat' Services");
  pdf.setSubject("Devis signe electroniquement");
  pdf.setCreator("JKBat Supabase PDF Auto");
  return await pdf.save();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const expectedSecret = Deno.env.get("JKBAT_PUSH_WEBHOOK_SECRET") || "";
  if (!expectedSecret || req.headers.get("x-jkbat-secret") !== expectedSecret) return json({ error: "unauthorized" }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  if (!supabaseUrl || !serviceRole) return json({ error: "server_not_configured" }, 500);

  let body: AnyObj = {};
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const documentId = txt(body.document_id || body.record?.id);
  if (!documentId) return json({ error: "document_id_required" }, 400);

  const sb = createClient(supabaseUrl, serviceRole, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: row, error: readError } = await sb.from("jkbat_client_documents").select("*").eq("id", documentId).maybeSingle();
  if (readError) return json({ error: "document_lookup_failed", detail: readError.message }, 500);
  if (!row) return json({ error: "document_not_found" }, 404);

  if (!String(row.kind || "").toUpperCase().includes("DEVIS")) return json({ ok: true, skipped: true, reason: "not_quote" });
  if (!row.signed_at || !row.signature_data) return json({ ok: true, skipped: true, reason: "not_signed" });
  if (row.signed_file_url && row.signed_pdf_archived_at) return json({ ok: true, skipped: true, reason: "already_archived", signed_file_url: row.signed_file_url });
  if (!row.source_snapshot) return json({ error: "source_snapshot_missing" }, 409);

  await sb.from("jkbat_client_documents").update({
    signed_pdf_generation_status: "PROCESSING",
    signed_pdf_generation_error: null,
    signed_pdf_generation_attempted_at: new Date().toISOString(),
  }).eq("id", documentId);

  try {
    const bytes = await buildSignedQuotePdf(row);
    const snap = typeof row.source_snapshot === "object" ? row.source_snapshot : {};
    const ref = filename((snap as AnyObj)?.invoiceNo || row.title || "Devis");
    const path = `${row.client_id}/signed/${documentId}-${ref}-SIGNE.pdf`;
    const { error: uploadError } = await sb.storage.from("jkbat-client-documents").upload(path, bytes, {
      contentType: "application/pdf",
      cacheControl: "3600",
      upsert: true,
    });
    if (uploadError) throw new Error(`storage: ${uploadError.message}`);

    const now = new Date().toISOString();
    const { error: updateError } = await sb.from("jkbat_client_documents").update({
      signed_file_url: `storage:${path}`,
      signed_pdf_archived_at: now,
      pro_received_signed_at: row.pro_received_signed_at || row.signed_at || now,
      signed_pdf_generation_status: "DONE",
      signed_pdf_generation_error: null,
      signed_pdf_generated_by: "SUPABASE_AUTO_V1",
    }).eq("id", documentId);
    if (updateError) throw new Error(`database: ${updateError.message}`);

    return json({ ok: true, generated: true, document_id: documentId, path, bytes: bytes.length });
  } catch (e) {
    const message = String((e as Error)?.message || e || "generation_failed").slice(0, 1000);
    await sb.from("jkbat_client_documents").update({
      signed_pdf_generation_status: "ERROR",
      signed_pdf_generation_error: message,
      signed_pdf_generation_attempted_at: new Date().toISOString(),
      signed_pdf_generated_by: "SUPABASE_AUTO_V1",
    }).eq("id", documentId);
    return json({ error: "generation_failed", detail: message }, 500);
  }
});
