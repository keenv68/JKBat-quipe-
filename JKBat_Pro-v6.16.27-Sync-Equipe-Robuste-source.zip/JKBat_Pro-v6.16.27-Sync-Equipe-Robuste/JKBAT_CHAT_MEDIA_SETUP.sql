-- JKBat — Messagerie photos & vidéos
-- À exécuter UNE FOIS dans Supabase > SQL Editor avant d'utiliser JKBat'Services v1.2.4.
-- Compatible avec JKBat Pro v6.16.18.

-- 1) Colonnes média sur les messages (les anciens messages restent compatibles).
alter table public.jkbat_messages
  add column if not exists media_type text,
  add column if not exists media_path text,
  add column if not exists media_name text,
  add column if not exists media_mime text,
  add column if not exists media_size bigint;

comment on column public.jkbat_messages.media_type is 'image ou video';
comment on column public.jkbat_messages.media_path is 'Chemin privé dans le bucket jkbat-chat-media';

-- 2) Bucket privé de messagerie.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'jkbat-chat-media',
  'jkbat-chat-media',
  false,
  52428800,
  array[
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
    'image/heic',
    'image/heif',
    'video/mp4',
    'video/webm',
    'video/quicktime',
    'video/3gpp'
  ]
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Les chemins créés par l'application sont :
--   <conversation_id>/<user_id>/<timestamp>-<nom_du_fichier>

-- 3) Lecture : le client de la conversation ou un administrateur JKBat.
drop policy if exists "jkbat_chat_media_select" on storage.objects;
create policy "jkbat_chat_media_select"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'jkbat-chat-media'
  and exists (
    select 1
    from public.jkbat_conversations c
    where c.id::text = (storage.foldername(name))[1]
      and (
        c.client_id = auth.uid()
        or public.jkbat_is_admin()
      )
  )
);

-- 4) Envoi : uniquement dans une conversation à laquelle le compte a accès.
-- Le deuxième dossier doit correspondre à l'utilisateur connecté.
drop policy if exists "jkbat_chat_media_insert" on storage.objects;
create policy "jkbat_chat_media_insert"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'jkbat-chat-media'
  and (storage.foldername(name))[2] = auth.uid()::text
  and exists (
    select 1
    from public.jkbat_conversations c
    where c.id::text = (storage.foldername(name))[1]
      and (
        c.client_id = auth.uid()
        or public.jkbat_is_admin()
      )
  )
);

-- 5) Suppression : le client de sa conversation ou un administrateur JKBat.
drop policy if exists "jkbat_chat_media_delete" on storage.objects;
create policy "jkbat_chat_media_delete"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'jkbat-chat-media'
  and exists (
    select 1
    from public.jkbat_conversations c
    where c.id::text = (storage.foldername(name))[1]
      and (
        c.client_id = auth.uid()
        or public.jkbat_is_admin()
      )
  )
);
