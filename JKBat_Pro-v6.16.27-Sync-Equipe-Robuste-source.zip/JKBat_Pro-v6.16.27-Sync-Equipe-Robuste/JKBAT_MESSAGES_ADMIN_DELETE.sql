-- JKBat Pro 6.16.12 — suppression des messages par l’administrateur
-- À exécuter une seule fois dans Supabase SQL Editor.

alter table public.jkbat_messages enable row level security;

drop policy if exists "jkbat_admin_delete_messages"
on public.jkbat_messages;

create policy "jkbat_admin_delete_messages"
on public.jkbat_messages
for delete
to authenticated
using (public.jkbat_is_admin());
