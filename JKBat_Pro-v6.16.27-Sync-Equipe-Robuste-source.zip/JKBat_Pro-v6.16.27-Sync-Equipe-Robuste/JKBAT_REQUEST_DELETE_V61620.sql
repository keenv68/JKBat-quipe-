-- JKBat Pro v6.16.20 — autoriser l'administrateur JKBat à supprimer une demande client
-- À exécuter UNE SEULE FOIS dans Supabase > SQL Editor.

drop policy if exists "request admin delete" on public.jkbat_service_requests;

create policy "request admin delete"
on public.jkbat_service_requests
for delete
using (public.jkbat_is_admin());

select policyname, cmd
from pg_policies
where schemaname='public'
  and tablename='jkbat_service_requests'
  and policyname='request admin delete';
