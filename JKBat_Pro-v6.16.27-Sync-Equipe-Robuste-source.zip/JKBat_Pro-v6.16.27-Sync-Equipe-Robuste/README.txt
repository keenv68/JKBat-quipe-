JKBat Pro v6.16.19 — Suivi client complet

JKBat Pro mobile v6.16.16 – Finitions générales

Base : v6.16.15 Accueil simplifié + Pilotage complet.

Finitions :
- accueil plus compact : hero, actions, raccourcis, sections et cartes mieux équilibrés ;
- écran Documents nettoyé : brouillons repliés, ligne de liste masquée lorsqu’elle est inutile, état vide plus compact ;
- bouton flottant + légèrement remonté ;
- Pilotage plus dense : hero, périodes, indicateurs, encaissements, activités et graphique mieux alignés ;
- homogénéisation des rayons, espacements et hauteurs sur les trois écrans retravaillés ;
- aucune modification de la logique Cloud, messagerie, factures, devis, fiches, planning ou techniciens.

Build GitHub Release : utiliser la même clé/signature JKBat Pro que les versions précédentes.


v6.16.18 — Messagerie médias complète
- Réception et lecture photos/vidéos conservées.
- Envoi de photos et vidéos depuis JKBat Pro vers le client.
- Upload vidéo natif Android avec progression, jusqu’à 50 Mo.
- Photos jusqu’à 15 Mo.
- Aucun nouveau SQL si JKBAT_CHAT_MEDIA_SETUP a déjà été exécuté.
