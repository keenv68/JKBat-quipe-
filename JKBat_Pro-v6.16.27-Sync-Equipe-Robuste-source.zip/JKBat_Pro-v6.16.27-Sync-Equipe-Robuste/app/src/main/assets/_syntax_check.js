

'use strict';
const SEED={"jkbat_seq_2026_08":"26","jkbat_company_email":"contact@jkbat.fr","jkbat_seq_DEV_2026_09":"18","jkbat_theme":"light","jkbat_clients":"[{\"name\":\"Aleos\",\"address\":\"73 rue du Rhône 68300, Saint-louis\",\"ref\":\"PART\"},{\"name\":\"ANNA BAUMGARTNER\",\"address\":\"10 rue de la forêt, 68190 Readersheim\",\"ref\":\"PART\"},{\"name\":\"Dumousseau Kévin\",\"address\":\"20 rue sainte claire deville 68310 wittelsheim\",\"ref\":\"PART\",\"phone\":\"0659892817\"},{\"name\":\"Fraysse Isabelle\",\"address\":\"\",\"ref\":\"\"},{\"name\":\"Kévin Dumousseau\",\"address\":\"20 rue sainte claire deville 68 310 wittelsheim\",\"ref\":\"\"}]","jkbat_appointments":"[]","jkbat_company_name":"JKBat Services","jkbat_company_phone":"06 59 89 28 17","jkbat_client_phones":"{\"dumousseau kévin\":\"0659892817\",\"kévin dumousseau\":\"0659892817\",\"test\":\"0606\"}","jkbat_company_siret":"937 572 550 00013","jkbat_history":"[]","jkbat_invoice_pwa":"{\"date\":\"2026-09-07\",\"invoiceNo\":\"DEV-09202618\",\"clientRef\":\"PART\",\"clientName\":\"\",\"clientAddress\":\"\",\"intervention\":\"\",\"control\":\"\",\"inspection\":\"\",\"recommendation\":\"\",\"result\":\"\",\"discount\":\"0\",\"rows\":[]}","jkbat_company_address":"20 Rue Sainte-Claire Déville - 68310 Wittelsheim","jkbat_seq_2026_09":"58"};
const LS=localStorage,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
let currentScreen='dashboard',_rows=[],_editingDoc=null,_editingDocIndex=-1,_sigCanvas=null,_sigCtx=null,_drawing=false,_toastTimer=null,_draftTimer=null;
const jget=(k,d)=>{try{let v=LS.getItem(k);return v==null?d:JSON.parse(v)}catch{return d}},jset=(k,v)=>LS.setItem(k,JSON.stringify(v));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const euro=n=>new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(Number(n)||0);
const fmtDate=d=>{if(!d)return'';let x=new Date(d+'T12:00:00');return isNaN(x)?d:x.toLocaleDateString('fr-FR')};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
function toast(t){let el=$('#toast');el.textContent=t;el.classList.add('show');clearTimeout(_toastTimer);_toastTimer=setTimeout(()=>el.classList.remove('show'),2200)}
function seed(force=false){if(force){for(let i=LS.length-1;i>=0;i--){let k=LS.key(i);if(k&&k.startsWith('jkbat_'))LS.removeItem(k)}}Object.entries(SEED).forEach(([k,v])=>{if(LS.getItem(k)==null)LS.setItem(k,String(v))});if(LS.getItem('jkbat_default_vat')==null)LS.setItem('jkbat_default_vat','20');if(LS.getItem('jkbat_terms')==null)LS.setItem('jkbat_terms','');if(LS.getItem('jkbat_theme')==null)LS.setItem('jkbat_theme','dark');if(LS.getItem('jkbat_last_autosave')==null)LS.setItem('jkbat_last_autosave',new Date().toISOString())}
function migrate(){let h=jget('jkbat_history',[]),changed=false;h=h.map(d=>{if(!d.id){d.id=uid();changed=true}if(!d.kind)d.kind=(String(d.invoiceNo||'').startsWith('FAC')?'FACTURE':'DEVIS');if(!d.status)d.status='BROUILLON';if(d.vat==null)d.vat=Number(LS.getItem('jkbat_default_vat')||20);if(!d.photos)d.photos=[];return d});if(changed)jset('jkbat_history',h)}
function clients(){return jget('jkbat_clients',[])} function docs(){return jget('jkbat_history',[])} function appointments(){return jget('jkbat_appointments',[])}
function saveAuto(){LS.setItem('jkbat_last_autosave',new Date().toISOString());renderSettingsMeta()}
function company(){return {name:LS.getItem('jkbat_company_name')||'JKBat Services',siret:LS.getItem('jkbat_company_siret')||'',address:LS.getItem('jkbat_company_address')||'',phone:LS.getItem('jkbat_company_phone')||'',email:LS.getItem('jkbat_company_email')||'',logo:LS.getItem('jkbat_company_logo')||'',terms:LS.getItem('jkbat_terms')||''}}
function applyTheme(){document.documentElement.classList.toggle('light',LS.getItem('jkbat_theme')==='light')} function toggleTheme(){LS.setItem('jkbat_theme',LS.getItem('jkbat_theme')==='light'?'dark':'light');applyTheme();saveAuto()}
function renderLogo(){let c=company();$('#companyMini').textContent=c.name.replace(/^JKBat\s*/i,'')||'Services';$('#headerMark').innerHTML=c.logo?`<img src="${c.logo}">`:'JK'}
function go(id){currentScreen=id;$$('.screen').forEach(x=>x.classList.toggle('active',x.id===id));$$('.nav button').forEach(x=>x.classList.toggle('active',x.dataset.go===id));renderAll();window.scrollTo(0,0)}
function fabAction(){if(currentScreen==='clients')openClient();else if(currentScreen==='agenda')openAppointment();else openDocument(true)}
function openModal(title,html){$('#modalTitle').textContent=title;$('#modalBody').innerHTML=html;$('#modal').classList.add('open')}function closeModal(){$('#modal').classList.remove('open');_sigCanvas=null}
let _jkConfirmResolve6164=null;
function askConfirm6164(message,title='Confirmation JKBat'){return new Promise(resolve=>{_jkConfirmResolve6164=resolve;let m=document.getElementById('jkConfirm6164'),t=document.getElementById('jkConfirmText6164'),h=document.getElementById('jkConfirmTitle6164');if(h)h.textContent=title;if(t)t.textContent=String(message||'Confirmer cette action ?');if(m)m.classList.add('open')})}
function resolveJkConfirm6164(value){let m=document.getElementById('jkConfirm6164');if(m)m.classList.remove('open');let r=_jkConfirmResolve6164;_jkConfirmResolve6164=null;if(r)r(!!value)}
window.askConfirm6164=askConfirm6164;window.resolveJkConfirm6164=resolveJkConfirm6164;
function calc(d){let sub=(d.rows||[]).reduce((s,r)=>s+(Number(r.qty)||0)*(Number(r.price)||0),0),disc=Math.max(0,Math.min(100,Number(d.discount)||0)),after=sub*(1-disc/100),vat=Math.max(0,Number(d.vat)||0),tax=after*vat/100;return{sub,disc,after,vat,tax,total:after+tax}}
function statusClass(s){return s==='PAYÉ'||s==='ACCEPTÉ'?'ok':s==='REFUSÉ'?'bad':s==='ENVOYÉ'?'warn':''}
function statusOptions(kind,current){let a=kind==='FACTURE'?['BROUILLON','ENVOYÉ','PAYÉ']:['BROUILLON','ENVOYÉ','ACCEPTÉ','REFUSÉ'];return a.map(x=>`<option ${x===current?'selected':''}>${x}</option>`).join('')}
function renderAll(){renderLogo();renderDashboard();renderClients();renderDocs();renderAgenda();renderSettings()}
function renderDashboard(){let ds=docs(),cs=clients(),aps=appointments(),paid=ds.filter(d=>d.kind==='FACTURE'&&d.status==='PAYÉ').reduce((s,d)=>s+calc(d).total,0),billed=ds.filter(d=>d.kind==='FACTURE').reduce((s,d)=>s+calc(d).total,0),pipeline=ds.filter(d=>d.kind==='DEVIS'&&!['REFUSÉ'].includes(d.status)).reduce((s,d)=>s+calc(d).total,0);$('#stats').innerHTML=`<div class="stat"><i>€</i><span>CA encaissé</span><b>${euro(paid)}</b></div><div class="stat"><i>▤</i><span>Facturé</span><b>${euro(billed)}</b></div><div class="stat"><i>↗</i><span>Devis actifs</span><b>${euro(pipeline)}</b></div><div class="stat"><i>♟</i><span>Clients</span><b>${cs.length}</b></div>`;renderBars(ds);let today=new Date().toISOString().slice(0,10),up=aps.filter(a=>(a.date||'')>=today).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,4);$('#apptHint').textContent=up.length?`${up.length} prochain(s)`:'Aucun';$('#nextAppointments').innerHTML=up.length?up.map(a=>`<div class="card row" onclick="openAppointment('${esc(a.id||'')}')"><div class="avatar">${(a.time||'--').slice(0,2)}</div><div class="grow"><b>${esc(a.title||a.client||'Rendez-vous')}</b><div class="muted">${fmtDate(a.date)} ${esc(a.time||'')} · ${esc(a.address||'')}</div></div></div>`).join(''):'<div class="empty">Aucun rendez-vous à venir.</div>';let rec=ds.slice().sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date))).slice(0,4);$('#recentDocs').innerHTML=rec.length?rec.map(d=>docCard(d,ds.findIndex(x=>x.id===d.id))).join(''):'<div class="empty">Tes prochains devis et factures apparaîtront ici.</div>'}
function renderBars(ds){let now=new Date(),months=[];for(let i=5;i>=0;i--){let d=new Date(now.getFullYear(),now.getMonth()-i,1),k=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');months.push({k,label:d.toLocaleDateString('fr-FR',{month:'short'}),v:0})}ds.filter(d=>d.kind==='FACTURE').forEach(d=>{let m=months.find(x=>String(d.date||'').startsWith(x.k));if(m)m.v+=calc(d).total});let max=Math.max(1,...months.map(x=>x.v));$('#revenueBars').innerHTML=months.map(m=>`<div class="bar" title="${euro(m.v)}"><i style="height:${Math.max(4,m.v/max*68)}px"></i><small>${esc(m.label)}</small></div>`).join('')}
function renderClients(){let q=($('#clientSearch')?.value||'').toLowerCase().trim(),arr=clients().map((c,i)=>({...c,_i:i})).filter(c=>!q||[c.name,c.address,c.phone,c.ref].join(' ').toLowerCase().includes(q));if($('#clientCount'))$('#clientCount').textContent=`${arr.length} client(s)`;if($('#clientList'))$('#clientList').innerHTML=arr.length?arr.map(c=>`<div class="card row" onclick="showClient(${c._i})"><div class="avatar">${esc((c.name||'?').trim().slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(c.name||'Sans nom')}</b><div class="muted">${esc(c.address||'Adresse non renseignée')}</div><div class="chips">${c.phone?'<span class="chip">☎ '+esc(c.phone)+'</span>':''}${c.ref?'<span class="chip">'+esc(c.ref)+'</span>':''}</div></div><span class="tap">›</span></div>`).join(''):'<div class="empty">Aucun client trouvé.</div>'}
function openClient(i=null){let c=i==null?{}:clients()[i];openModal(i==null?'Nouveau client':'Modifier le client',`<div class="form"><div><label class="label">Nom</label><input class="field" id="cName" value="${esc(c.name||'')}"></div><div><label class="label">Adresse</label><textarea class="field" id="cAddress">${esc(c.address||'')}</textarea></div><div class="form two"><div><label class="label">Téléphone</label><input class="field" inputmode="tel" id="cPhone" value="${esc(c.phone||'')}"></div><div><label class="label">Référence</label><input class="field" id="cRef" value="${esc(c.ref||'PART')}"></div></div><div><label class="label">E-mail</label><input class="field" inputmode="email" id="cEmail" value="${esc(c.email||'')}"></div><button class="btn primary" onclick="saveClient(${i==null?'null':i})">Enregistrer</button>${i!=null?`<button class="btn danger" onclick="deleteClient(${i})">Supprimer</button>`:''}</div>`)}
function saveClient(i){let c={name:$('#cName').value.trim(),address:$('#cAddress').value.trim(),phone:$('#cPhone').value.trim(),ref:$('#cRef').value.trim(),email:$('#cEmail').value.trim()};if(!c.name)return toast('Nom du client requis');let a=clients();if(i==null)a.push(c);else a[i]=c;jset('jkbat_clients',a);saveAuto();closeModal();renderAll();toast('Client enregistré')}
async function deleteClient(i){if(!await askConfirm6164('Supprimer ce client ?'))return;let a=clients();a.splice(i,1);jset('jkbat_clients',a);saveAuto();closeModal();renderAll();toast('Client supprimé')}
function cleanPhone(p){return String(p||'').replace(/[^+0-9]/g,'')}function mapHref(a){return 'geo:0,0?q='+encodeURIComponent(a||'')}function showClient(i){let c=clients()[i],p=cleanPhone(c.phone);openModal(c.name||'Client',`<div class="card"><b>${esc(c.name||'')}</b><p class="muted">${esc(c.address||'Adresse non renseignée').replace(/\n/g,'<br>')}</p>${c.phone?`<p>☎ ${esc(c.phone)}</p>`:''}${c.email?`<p>✉ ${esc(c.email)}</p>`:''}<div class="actions">${p?`<a class="btn primary" href="tel:${p}">Appeler</a><a class="btn" href="sms:${p}">SMS</a>`:''}${c.email?`<a class="btn" href="mailto:${encodeURIComponent(c.email)}">E-mail</a>`:''}${c.address?`<a class="btn" href="${mapHref(c.address)}">Navigation</a>`:''}</div></div><div class="actions"><button class="btn" onclick="closeModal();openDocument(true,null,${i})">Créer un devis</button><button class="btn" onclick="closeModal();openAppointment(null,${i})">Créer un RDV</button><button class="btn ghost" onclick="closeModal();openClient(${i})">Modifier</button></div>`)}
function nextNo(kind){let n=new Date(),y=n.getFullYear(),m=String(n.getMonth()+1).padStart(2,'0');if(kind==='FACTURE'){let k=`jkbat_seq_${y}_${m}`,v=parseInt(LS.getItem(k)||0,10)+1;return `FAC-${m}${y}${String(v).padStart(2,'0')}`}let k=`jkbat_seq_DEV_${y}_${m}`,v=parseInt(LS.getItem(k)||0,10)+1;return `DEV-${m}${y}${String(v).padStart(2,'0')}`}
function commitSeq(d){let n=(String(d.invoiceNo||'').match(/(\d{2})$/)||[])[1];if(!n)return;let dt=d.date?new Date(d.date+'T12:00:00'):new Date(),y=dt.getFullYear(),m=String(dt.getMonth()+1).padStart(2,'0'),k=d.kind==='FACTURE'?`jkbat_seq_${y}_${m}`:`jkbat_seq_DEV_${y}_${m}`,v=parseInt(n,10);if(v>parseInt(LS.getItem(k)||0,10))LS.setItem(k,String(v))}
function openDocument(isNew=true,existing=null,clientIndex=null){let d;if(isNew){let c=clientIndex==null?null:clients()[clientIndex];d={id:uid(),kind:'DEVIS',status:'BROUILLON',date:new Date().toISOString().slice(0,10),invoiceNo:nextNo('DEVIS'),clientRef:c?.ref||'PART',clientName:c?.name||'',clientAddress:c?.address||'',clientPhone:c?.phone||'',clientEmail:c?.email||'',intervention:'',recommendation:'',discount:0,vat:Number(LS.getItem('jkbat_default_vat')||20),rows:[],photos:[],signature:'',signedAt:''};_editingDocIndex=-1}else{d=JSON.parse(JSON.stringify(existing||{}));_editingDocIndex=docs().findIndex(x=>x.id===d.id)}_editingDoc=d;_rows=(d.rows||[]).map(r=>({...r}));let opts=clients().map((c,i)=>`<option value="${i}">${esc(c.name)}</option>`).join('');openModal(isNew?'Nouveau devis':(d.invoiceNo||'Document'),`<div class="form" oninput="scheduleDraft()"><div class="form three"><div><label class="label">Type</label><select class="field" id="dKind" onchange="kindChanged()"><option ${d.kind!=='FACTURE'?'selected':''}>DEVIS</option><option ${d.kind==='FACTURE'?'selected':''}>FACTURE</option></select></div><div><label class="label">Statut</label><select class="field" id="dStatus">${statusOptions(d.kind||'DEVIS',d.status||'BROUILLON')}</select></div><div><label class="label">Date</label><input type="date" class="field" id="dDate" value="${esc(d.date||'')}"></div></div><div><label class="label">N° document</label><input class="field" id="dNo" value="${esc(d.invoiceNo||nextNo(d.kind||'DEVIS'))}"></div><div><label class="label">Client existant</label><select class="field" onchange="pickClient(this.value)"><option value="">— choisir —</option>${opts}</select></div><div class="form two"><div><label class="label">Client</label><input class="field" id="dClient" value="${esc(d.clientName||'')}"></div><div><label class="label">Téléphone</label><input class="field" id="dClientPhone" value="${esc(d.clientPhone||'')}"></div></div><div><label class="label">Adresse client</label><textarea class="field" id="dAddress">${esc(d.clientAddress||'')}</textarea></div><div><label class="label">E-mail client</label><input class="field" id="dClientEmail" value="${esc(d.clientEmail||'')}"></div><div><label class="label">Objet / intervention</label><textarea class="field" id="dIntervention">${esc(d.intervention||'')}</textarea></div><div class="section-title" style="margin-top:2px"><h3>Prestations</h3><button type="button" class="btn small" onclick="addLine()">＋ Ligne</button></div><div id="lines"></div><div class="form two"><div><label class="label">Remise %</label><input class="field" type="number" step="0.1" id="dDiscount" value="${esc(d.discount??0)}" oninput="updateTotal()"></div><div><label class="label">TVA %</label><input class="field" type="number" step="0.1" id="dVat" value="${esc(d.vat??LS.getItem('jkbat_default_vat')??20)}" oninput="updateTotal()"></div></div><div class="card"><div class="muted">Total TTC</div><div class="invoice-total" id="dTotal">0 €</div><div class="tiny" id="dBreakdown"></div></div><div><label class="label">Notes / recommandations</label><textarea class="field" id="dRecommendation">${esc(d.recommendation||'')}</textarea></div><div class="section-title" style="margin-top:2px"><h3>Photos chantier</h3><span>4 max / document</span></div><div id="photoEditor"></div><div class="actions"><label class="btn file-label">🖼 Galerie (plusieurs)<input type="file" accept="image/*" multiple onchange="addPhotos(this.files);this.value=''" /></label></div><div class="tiny muted">Photos : galerie uniquement pour garantir la stabilité sur Samsung.</div><div class="section-title" style="margin-top:2px"><h3>Signature client</h3><span id="sigState">${d.signature?'Signé':'Non signé'}</span></div><div id="sigEditor"></div><div class="actions"><button type="button" class="btn" onclick="openSignature()">✍ Faire signer</button>${d.signature?'<button type="button" class="btn danger" onclick="clearSignature()">Effacer</button>':''}</div><div class="actions"><button type="button" class="btn primary" onclick="saveDocument()">Enregistrer</button><button type="button" class="btn" onclick="previewEditing()">Aperçu</button></div></div>`);renderLines();renderPhotoEditor();renderSigEditor();scheduleDraft()}
function pickClient(i){if(i==='')return;let c=clients()[Number(i)];$('#dClient').value=c.name||'';$('#dAddress').value=c.address||'';$('#dClientPhone').value=c.phone||'';$('#dClientEmail').value=c.email||'';scheduleDraft()}
function kindChanged(){let k=$('#dKind').value,s=$('#dStatus');s.innerHTML=statusOptions(k,'BROUILLON');let no=$('#dNo');if((k==='FACTURE'&&String(no.value).startsWith('DEV-'))||(k==='DEVIS'&&String(no.value).startsWith('FAC-')))no.value=nextNo(k);scheduleDraft()}
function addLine(){_rows.push({label:'',qty:1,price:0});renderLines();scheduleDraft()}function delLine(i){_rows.splice(i,1);renderLines();scheduleDraft()}function lineSet(i,k,v){_rows[i][k]=v;updateTotal();scheduleDraft()}
function renderLines(){let el=$('#lines');if(!el)return;el.innerHTML=_rows.length?_rows.map((r,i)=>`<div class="lineitem"><input class="field" placeholder="Désignation" value="${esc(r.label||r.description||'')}" oninput="lineSet(${i},'label',this.value)"><input class="field" type="number" step="0.01" value="${esc(r.qty??1)}" oninput="lineSet(${i},'qty',this.value)"><input class="field" type="number" step="0.01" value="${esc(r.price??0)}" oninput="lineSet(${i},'price',this.value)"><button type="button" class="mini-x" onclick="delLine(${i})">×</button></div>`).join(''):'<div class="empty">Ajoute une prestation, une quantité et un prix unitaire HT.</div>';updateTotal()}
function editingDoc(){if(!$('#dKind'))return _editingDoc||{};return {...(_editingDoc||{}),kind:$('#dKind').value,status:$('#dStatus').value,date:$('#dDate').value,invoiceNo:$('#dNo').value.trim(),clientName:$('#dClient').value.trim(),clientAddress:$('#dAddress').value.trim(),clientPhone:$('#dClientPhone').value.trim(),clientEmail:$('#dClientEmail').value.trim(),intervention:$('#dIntervention').value.trim(),recommendation:$('#dRecommendation').value.trim(),discount:Number($('#dDiscount').value)||0,vat:Number($('#dVat').value)||0,rows:_rows.map(r=>({label:r.label||'',qty:Number(r.qty)||0,price:Number(r.price)||0})),photos:_editingDoc?.photos||[],signature:_editingDoc?.signature||'',signedAt:_editingDoc?.signedAt||''}}
function updateTotal(){if(!$('#dTotal'))return;let c=calc(editingDoc());$('#dTotal').textContent=euro(c.total);$('#dBreakdown').textContent=`HT ${euro(c.after)} · TVA ${euro(c.tax)}`}
function scheduleDraft(){clearTimeout(_draftTimer);_draftTimer=setTimeout(()=>{if(!$('#dKind'))return;let d=editingDoc();_editingDoc={...d};LS.setItem('jkbat_invoice_pwa',JSON.stringify(d));saveAuto()},250)}
function saveDocument(){let d=editingDoc();if(!d.invoiceNo)return toast('Numéro requis');if(!d.clientName)return toast('Client requis');d.savedAt=new Date().toISOString();let a=docs(),i=a.findIndex(x=>x.id===d.id);if(i>=0)a[i]=d;else a.push(d);jset('jkbat_history',a);LS.setItem('jkbat_invoice_pwa',JSON.stringify(d));commitSeq(d);saveAuto();closeModal();renderAll();toast(`${d.kind==='FACTURE'?'Facture':'Devis'} enregistré`)}
function duplicateDoc(i){let d=JSON.parse(JSON.stringify(docs()[i]));d.id=uid();d.invoiceNo=nextNo(d.kind);d.status='BROUILLON';d.date=new Date().toISOString().slice(0,10);d.signature='';d.signedAt='';closeModal();openDocument(false,d)}
function convertToInvoice(i){let d=JSON.parse(JSON.stringify(docs()[i]));d.id=uid();d.kind='FACTURE';d.invoiceNo=nextNo('FACTURE');d.status='BROUILLON';d.date=new Date().toISOString().slice(0,10);closeModal();openDocument(false,d)}
async function deleteDoc(i){if(!await askConfirm6164('Supprimer ce document ?'))return;let a=docs();a.splice(i,1);jset('jkbat_history',a);saveAuto();closeModal();renderAll();toast('Document supprimé')}
function docCard(d,i){let c=calc(d);return `<div class="card row" onclick="showDocument(${i})"><div class="avatar">${d.kind==='FACTURE'?'F':'D'}</div><div class="grow"><b>${esc(d.invoiceNo||d.kind)} · ${esc(d.clientName||'Client')}</b><div class="muted">${fmtDate(d.date)} · ${esc(d.intervention||'Sans objet')}</div><div class="chips"><span class="chip ${statusClass(d.status)}">${esc(d.status||'BROUILLON')}</span><span class="chip">${euro(c.total)}</span>${d.signature?'<span class="chip ok">✍ signé</span>':''}${(d.photos||[]).length?`<span class="chip">📷 ${(d.photos||[]).length}</span>`:''}</div></div><span class="tap">›</span></div>`}
function renderDocs(){let q=($('#docSearch')?.value||'').toLowerCase().trim(),f=$('#docFilter')?.value||'',a=docs().map((d,i)=>({...d,_i:i})).filter(d=>(!f||d.kind===f)&&(!q||[d.invoiceNo,d.clientName,d.intervention,d.status].join(' ').toLowerCase().includes(q))).sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date)));if($('#docCount'))$('#docCount').textContent=`${a.length} document(s)`;if($('#docList'))$('#docList').innerHTML=a.length?a.map(d=>docCard(d,d._i)).join(''):'<div class="empty">Aucun document.</div>';let draft=jget('jkbat_invoice_pwa',null);if($('#draftBanner'))$('#draftBanner').innerHTML=draft&&draft.invoiceNo?`<div class="card draft-card6153" style="margin-bottom:10px"><div class="grow"><b>📝 Brouillon automatique</b><div class="muted">${esc(draft.invoiceNo)} · ${esc(draft.clientName||'sans client')}</div></div><div class="actions draft-actions6153"><button class="btn small" onclick="openDocument(false,jget('jkbat_invoice_pwa',{}))">Reprendre</button><button class="btn small danger" onclick="deleteAutoDraft6153()">🗑 Supprimer</button></div></div>`:''}
function showDocument(i){let d=docs()[i];openModal(d.invoiceNo||d.kind,`<div>${documentHtml(d)}</div><div class="actions"><button class="btn primary" onclick="openPrint(${i})">📄 PDF / Imprimer</button><button class="btn" onclick="closeModal();openDocument(false,docs()[${i}])">Modifier</button>${d.kind==='DEVIS'?`<button class="btn ok" onclick="convertToInvoice(${i})">→ Facture</button>`:''}<button class="btn" onclick="duplicateDoc(${i})">Dupliquer</button><button class="btn danger" onclick="deleteDoc(${i})">Supprimer</button></div>`)}
function previewEditing(){let d=editingDoc();openModal('Aperçu',documentHtml(d)+`<div class="actions"><button class="btn primary" onclick="openPrintDraft()">📄 PDF / Imprimer</button><button class="btn" onclick="closeModal();openDocument(false,_editingDoc)">Retour modifier</button></div>`);_editingDoc=d}
function documentHtml(d){let c=company(),x=calc(d),rows=(d.rows||[]).map(r=>`<tr><td>${esc(r.label||'')}</td><td>${Number(r.qty)||0}</td><td class="right">${euro(r.price)}</td><td class="right">${euro((Number(r.qty)||0)*(Number(r.price)||0))}</td></tr>`).join('');return `<div class="doc-paper"><div class="doc-head"><div class="doc-company"><div class="doc-logo">${c.logo?`<img src="${c.logo}">`:'JK'}</div><div><h2>${esc(c.name)}</h2><p style="margin:3px 0">${esc(c.address).replace(/\n/g,'<br>')}<br>${esc(c.phone)} ${c.email?'· '+esc(c.email):''}<br>${c.siret?'SIRET '+esc(c.siret):''}</p></div></div><div class="right"><div style="font-size:11px;color:#66758a">${esc(d.status||'BROUILLON')}</div><h1>${esc(d.kind||'DEVIS')}</h1><b>${esc(d.invoiceNo||'')}</b><div style="font-size:12px;margin-top:4px">${fmtDate(d.date)}</div></div></div><div style="margin-top:18px;padding:12px;background:#f4f6f8;border-radius:10px"><b>${esc(d.clientName||'Client')}</b><p style="margin:4px 0">${esc(d.clientAddress||'').replace(/\n/g,'<br>')}${d.clientPhone?'<br>'+esc(d.clientPhone):''}${d.clientEmail?'<br>'+esc(d.clientEmail):''}</p></div>${d.intervention?`<p><b>Objet :</b> ${esc(d.intervention).replace(/\n/g,'<br>')}</p>`:''}<table><thead><tr><th>Désignation</th><th>Qté</th><th class="right">PU HT</th><th class="right">Total HT</th></tr></thead><tbody>${rows||'<tr><td colspan="4">Aucune ligne</td></tr>'}</tbody></table><div class="totals"><div><span>Sous-total HT</span><b>${euro(x.sub)}</b></div>${x.disc?`<div><span>Remise ${x.disc}%</span><b>− ${euro(x.sub-x.after)}</b></div>`:''}<div><span>HT après remise</span><b>${euro(x.after)}</b></div><div><span>TVA ${x.vat}%</span><b>${euro(x.tax)}</b></div><div class="grand"><span>Total TTC</span><span>${euro(x.total)}</span></div></div>${d.recommendation?`<p><b>Notes :</b><br>${esc(d.recommendation).replace(/\n/g,'<br>')}</p>`:''}${(d.photos||[]).length?`<div style="margin-top:18px"><b>Photos chantier</b><div class="doc-photos">${d.photos.map(p=>`<img src="${p}">`).join('')}</div></div>`:''}${d.signature?`<div class="doc-sign"><div><img src="${d.signature}"><small>Signature client${d.signedAt?' · '+new Date(d.signedAt).toLocaleString('fr-FR'):''}</small></div></div>`:''}${c.terms?`<p style="margin-top:18px"><b>Conditions :</b> ${esc(c.terms)}</p>`:''}</div>`}
function openPrint(i){let d=docs()[i];closeModal();showPrintDoc(d)}function openPrintDraft(){let d=_editingDoc||editingDoc();closeModal();showPrintDoc(d)}function showPrintDoc(d){$('#printLayer').innerHTML=`<div class="print-controls"><button class="btn primary" onclick="triggerPrint()">Créer le PDF / Imprimer</button><button class="btn" onclick="exitPrint()">Retour à l’application</button></div>${documentHtml(d)}`;document.body.classList.add('print-mode');window.scrollTo(0,0)}function triggerPrint(){location.href='jkbatprint://document'}function exitPrint(){document.body.classList.remove('print-mode');$('#printLayer').innerHTML=''}
function renderPhotoEditor(){let el=$('#photoEditor');if(!el)return;let a=_editingDoc?.photos||[];el.innerHTML=a.length?`<div class="photo-grid">${a.map((p,i)=>`<div class="photo"><img src="${p}"><button type="button" onclick="removePhoto(${i})">×</button></div>`).join('')}</div>`:'<div class="empty">Aucune photo jointe.</div>'}
function removePhoto(i){_editingDoc.photos.splice(i,1);renderPhotoEditor();scheduleDraft()}
function addPhotos(files){if(!files||!files.length)return;let a=[...files].slice(0,Math.max(0,4-(_editingDoc.photos||[]).length));if(!a.length)return toast('Maximum 4 photos');Promise.all(a.map(resizeImage)).then(imgs=>{_editingDoc.photos=[...(_editingDoc.photos||[]),...imgs].slice(0,4);renderPhotoEditor();scheduleDraft();toast(`${imgs.length} photo(s) ajoutée(s)`)})}
function resizeImage(file,max=700,q=.64){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=e=>{let img=new Image();img.onload=()=>{let s=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*s));c.height=Math.max(1,Math.round(img.height*s));c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',q))};img.onerror=reject;img.src=e.target.result};r.onerror=reject;r.readAsDataURL(file)})}
function renderSigEditor(){let el=$('#sigEditor');if(!el)return;el.innerHTML=_editingDoc?.signature?`<div class="sig-preview"><img src="${_editingDoc.signature}"></div>`:'<div class="empty">Le client peut signer directement au doigt.</div>';if($('#sigState'))$('#sigState').textContent=_editingDoc?.signature?'Signé':'Non signé'}
function openSignature(){_editingDoc=editingDoc();clearTimeout(_draftTimer);LS.setItem('jkbat_invoice_pwa',JSON.stringify(_editingDoc));saveAuto();openModal('Signature client',`<p class="muted">Fais signer dans la zone blanche.</p><div class="canvas-wrap"><canvas id="sigCanvas"></canvas></div><div class="actions"><button class="btn" onclick="clearCanvas()">Effacer</button><button class="btn primary" onclick="saveSignature()">Valider la signature</button></div>`);setTimeout(initSignature,30)}
function initSignature(){let c=$('#sigCanvas');if(!c)return;let r=c.getBoundingClientRect(),d=Math.max(1,window.devicePixelRatio||1);c.width=Math.round(r.width*d);c.height=Math.round(190*d);_sigCanvas=c;_sigCtx=c.getContext('2d');_sigCtx.scale(d,d);_sigCtx.lineWidth=2.3;_sigCtx.lineCap='round';_sigCtx.strokeStyle='#111';let pos=e=>{let rr=c.getBoundingClientRect(),t=e.touches?e.touches[0]:e;return{x:t.clientX-rr.left,y:t.clientY-rr.top}};let down=e=>{e.preventDefault();_drawing=true;let p=pos(e);_sigCtx.beginPath();_sigCtx.moveTo(p.x,p.y)},move=e=>{if(!_drawing)return;e.preventDefault();let p=pos(e);_sigCtx.lineTo(p.x,p.y);_sigCtx.stroke()},up=e=>{if(e)e.preventDefault();_drawing=false};c.addEventListener('touchstart',down,{passive:false});c.addEventListener('touchmove',move,{passive:false});c.addEventListener('touchend',up,{passive:false});c.addEventListener('mousedown',down);c.addEventListener('mousemove',move);window.addEventListener('mouseup',up,{once:true})}
function clearCanvas(){if(_sigCtx&&_sigCanvas)_sigCtx.clearRect(0,0,_sigCanvas.width,_sigCanvas.height)}function saveSignature(){if(!_sigCanvas)return;_editingDoc.signature=_sigCanvas.toDataURL('image/png');_editingDoc.signedAt=new Date().toISOString();closeModal();openDocument(false,_editingDoc);toast('Signature enregistrée')}function clearSignature(){_editingDoc.signature='';_editingDoc.signedAt='';renderSigEditor();scheduleDraft()}
function openAppointment(id=null,clientIndex=null){let a=id?appointments().find(x=>x.id===id):{},c=clientIndex==null?null:clients()[clientIndex];a={...a,client:a.client||c?.name||'',address:a.address||c?.address||'',phone:a.phone||c?.phone||''};openModal(id?'Modifier le rendez-vous':'Nouveau rendez-vous',`<div class="form"><div><label class="label">Titre / client</label><input class="field" id="aTitle" value="${esc(a.title||a.client||'')}"></div><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="aDate" value="${esc(a.date||new Date().toISOString().slice(0,10))}"></div><div><label class="label">Heure</label><input type="time" class="field" id="aTime" value="${esc(a.time||'09:00')}"></div></div><div><label class="label">Adresse</label><textarea class="field" id="aAddress">${esc(a.address||'')}</textarea></div><div><label class="label">Téléphone</label><input class="field" id="aPhone" value="${esc(a.phone||'')}"></div><div><label class="label">Notes</label><textarea class="field" id="aNotes">${esc(a.notes||'')}</textarea></div><button class="btn primary" onclick="saveAppointment('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteAppointment('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveAppointment(id){let o={id:id||uid(),title:$('#aTitle').value.trim(),client:$('#aTitle').value.trim(),date:$('#aDate').value,time:$('#aTime').value,address:$('#aAddress').value.trim(),phone:$('#aPhone').value.trim(),notes:$('#aNotes').value.trim()};if(!o.title||!o.date)return toast('Titre et date requis');let a=appointments(),i=a.findIndex(x=>x.id===o.id);if(i>=0)a[i]=o;else a.push(o);jset('jkbat_appointments',a);saveAuto();closeModal();renderAll();toast('Rendez-vous enregistré')}
async function deleteAppointment(id){if(!await askConfirm6164('Supprimer ce rendez-vous ?'))return;let a=appointments().filter(x=>x.id!==id);jset('jkbat_appointments',a);saveAuto();closeModal();renderAll()}
function renderAgenda(){let a=appointments().slice().sort((x,y)=>(x.date+x.time).localeCompare(y.date+y.time));if($('#agendaCount'))$('#agendaCount').textContent=`${a.length} rendez-vous`;if($('#agendaList'))$('#agendaList').innerHTML=a.length?a.map(x=>`<div class="card"><div class="card row" style="padding:0;border:0;box-shadow:none"><div class="avatar">${(x.time||'--').slice(0,2)}</div><div class="grow"><b>${esc(x.title||x.client)}</b><div class="muted">${fmtDate(x.date)} ${esc(x.time||'')} · ${esc(x.address||'')}</div></div><button class="btn small" onclick="openAppointment('${esc(x.id)}')">Modifier</button></div><div class="actions">${x.phone?`<a class="btn small" href="tel:${cleanPhone(x.phone)}">Appeler</a><a class="btn small" href="sms:${cleanPhone(x.phone)}">SMS</a>`:''}${x.address?`<a class="btn small" href="${mapHref(x.address)}">Navigation</a>`:''}</div>${x.notes?`<div class="muted" style="margin-top:8px">${esc(x.notes)}</div>`:''}</div>`).join(''):'<div class="empty">Ton agenda est vide.</div>'}
function renderSettings(){if(!$('#setCompany'))return;let c=company();$('#setCompany').value=c.name;$('#setSiret').value=c.siret;$('#setAddress').value=c.address;$('#setPhone').value=c.phone;$('#setEmail').value=c.email;$('#setVat').value=LS.getItem('jkbat_default_vat')||'20';$('#setTerms').value=c.terms;renderSettingsMeta()}
function renderSettingsMeta(){let el=$('#autoSaveInfo'),d=LS.getItem('jkbat_last_autosave');if(el)el.textContent=d?'auto · '+new Date(d).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}):'automatique'}
function saveSettings(){LS.setItem('jkbat_company_name',$('#setCompany').value.trim());LS.setItem('jkbat_company_siret',$('#setSiret').value.trim());LS.setItem('jkbat_company_address',$('#setAddress').value.trim());LS.setItem('jkbat_company_phone',$('#setPhone').value.trim());LS.setItem('jkbat_company_email',$('#setEmail').value.trim());LS.setItem('jkbat_default_vat',$('#setVat').value||'20');LS.setItem('jkbat_terms',$('#setTerms').value.trim());saveAuto();renderAll();toast('Réglages enregistrés')}
function loadCompanyLogo(files){if(!files||!files[0])return;resizeImage(files[0],320,.78).then(x=>{LS.setItem('jkbat_company_logo',x);saveAuto();renderLogo();toast('Logo enregistré')})}function clearLogo(){LS.removeItem('jkbat_company_logo');saveAuto();renderLogo();toast('Logo retiré')}
function exportBackup(){let o={format:'JKBat Backup',version:1,createdAt:new Date().toISOString(),itemCount:0,localStorage:{}};for(let i=0;i<LS.length;i++){let k=LS.key(i);if(k&&k.startsWith('jkbat_'))o.localStorage[k]=LS.getItem(k)}o.itemCount=Object.keys(o.localStorage).length;return JSON.stringify(o,null,2)}
function copyText(text){let ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast('Copié dans le presse-papiers')}catch{try{navigator.clipboard?.writeText(text).then(()=>toast('Copié dans le presse-papiers')).catch(()=>toast('Copie impossible automatiquement'))}catch(e){toast('Copie impossible automatiquement')}}ta.remove()}
function showExport(){let t=exportBackup();openModal('Exporter la sauvegarde',`<p class="muted">Copie ce contenu dans un fichier <b>.json</b>. Les photos et signatures sont incluses, donc le fichier peut être volumineux.</p><textarea class="field" id="backupText" style="min-height:330px">${esc(t)}</textarea><button class="btn primary full" onclick="copyText($('#backupText').value)">Copier tout</button>`)}
function importFile(files){if(!files||!files[0])return;let r=new FileReader();r.onload=e=>doImportText(e.target.result);r.readAsText(files[0])}function doImportText(t){try{let b=JSON.parse(t);if(b.format!=='JKBat Backup'||!b.localStorage)throw 0;Object.entries(b.localStorage).forEach(([k,v])=>LS.setItem(k,String(v)));migrate();applyTheme();saveAuto();renderAll();closeModal();toast('Sauvegarde importée')}catch{toast('Sauvegarde invalide')}}
async function resetApp(){if(!await askConfirm6164('Restaurer les données de la sauvegarde initiale ? Les modifications locales seront remplacées.'))return;seed(true);migrate();applyTheme();saveAuto();renderAll();toast('Base initiale restaurée')}

/* --- Fonctions JKBat 2.1 : logo, facture exacte, rapport exact --- */
function applyBrandMigration(){
  if(LS.getItem('jkbat_brand_version')!=='2.1'){
    LS.setItem('jkbat_company_logo','jkbat-logo.png');
    LS.setItem('jkbat_brand_version','2.1');
  }
}
function company(){return {name:LS.getItem('jkbat_company_name')||'JKBat Services',siret:LS.getItem('jkbat_company_siret')||'',address:LS.getItem('jkbat_company_address')||'',phone:LS.getItem('jkbat_company_phone')||'',email:LS.getItem('jkbat_company_email')||'',logo:LS.getItem('jkbat_company_logo')||'jkbat-logo.png',terms:LS.getItem('jkbat_terms')||''}}
function nextNo(kind){let n=new Date(),y=n.getFullYear(),m=String(n.getMonth()+1).padStart(2,'0');if(kind==='FACTURE'){let k=`jkbat_seq_${y}_${m}`,v=parseInt(LS.getItem(k)||0,10)+1;return `FACT-${m}${y}${String(v).padStart(2,'0')}`}let k=`jkbat_seq_DEV_${y}_${m}`,v=parseInt(LS.getItem(k)||0,10)+1;return `DEV-${m}${y}${String(v).padStart(2,'0')}`}
function kindChanged(){let k=$('#dKind').value,s=$('#dStatus');s.innerHTML=statusOptions(k,'BROUILLON');let no=$('#dNo');if((k==='FACTURE'&&(String(no.value).startsWith('DEV-')||!String(no.value).startsWith('FACT-')))||(k==='DEVIS'&&(String(no.value).startsWith('FACT-')||String(no.value).startsWith('FAC-'))))no.value=nextNo(k);scheduleDraft()}
function pickClient(i){if(i==='')return;let c=clients()[Number(i)];$('#dClient').value=c.name||'';$('#dAddress').value=c.address||'';$('#dClientPhone').value=c.phone||'';$('#dClientEmail').value=c.email||'';if($('#dClientRef'))$('#dClientRef').value=c.ref||'PART';scheduleDraft()}
function addLine(){_rows.push({label:'',description:'',qty:1,price:0});renderLines();scheduleDraft()}
function renderLines(){let el=$('#lines');if(!el)return;el.innerHTML=_rows.length?_rows.map((r,i)=>`<div class="lineitem2"><input class="field" placeholder="Nom" value="${esc(r.label||'')}" oninput="lineSet(${i},'label',this.value)"><textarea class="field" placeholder="Description détaillée" oninput="lineSet(${i},'description',this.value)">${esc(r.description||'')}</textarea><input class="field" type="number" step="0.01" value="${esc(r.qty??1)}" oninput="lineSet(${i},'qty',this.value)"><input class="field" type="number" step="0.01" value="${esc(r.price??0)}" oninput="lineSet(${i},'price',this.value)"><button type="button" class="mini-x" onclick="delLine(${i})">×</button></div>`).join(''):'<div class="empty">Ajoute le nom, la description, la quantité et le prix unitaire.</div>';updateTotal()}
function editingDoc(){if(!$('#dKind'))return _editingDoc||{};return {...(_editingDoc||{}),kind:$('#dKind').value,status:$('#dStatus').value,date:$('#dDate').value,invoiceNo:$('#dNo').value.trim(),clientRef:$('#dClientRef')?.value.trim()||'PART',clientName:$('#dClient').value.trim(),clientAddress:$('#dAddress').value.trim(),clientPhone:$('#dClientPhone').value.trim(),clientEmail:$('#dClientEmail').value.trim(),intervention:$('#dIntervention').value.trim(),inspection:$('#dInspection')?.value.trim()||'',control:$('#dControl')?.value.trim()||'',result:$('#dResult')?.value.trim()||'',recommendation:$('#dRecommendation').value.trim(),duration:$('#dDuration')?.value.trim()||'',paymentMode:$('#dPaymentMode')?.value.trim()||'',paidDate:$('#dPaidDate')?.value||'',discount:Number($('#dDiscount').value)||0,vat:Number($('#dVat').value)||0,rows:_rows.map(r=>({label:r.label||'',description:r.description||'',qty:Number(r.qty)||0,price:Number(r.price)||0})),photos:_editingDoc?.photos||[],signature:_editingDoc?.signature||'',signedAt:_editingDoc?.signedAt||''}}
function openDocument(isNew=true,existing=null,clientIndex=null){let d;if(isNew){let c=clientIndex==null?null:clients()[clientIndex];d={id:uid(),kind:'DEVIS',status:'BROUILLON',date:new Date().toISOString().slice(0,10),invoiceNo:nextNo('DEVIS'),clientRef:c?.ref||'PART',clientName:c?.name||'',clientAddress:c?.address||'',clientPhone:c?.phone||'',clientEmail:c?.email||'',intervention:'',inspection:'',control:'',result:'',recommendation:'',duration:'',paymentMode:'',paidDate:'',discount:0,vat:Number(LS.getItem('jkbat_default_vat')||0),rows:[],photos:[],signature:'',signedAt:''};_editingDocIndex=-1}else{d=JSON.parse(JSON.stringify(existing||{}));d.photos=d.photos||[];d.rows=(d.rows||[]).map(r=>({label:r.label||r.description||'',description:r.description||'',qty:r.qty??1,price:r.price??0}));_editingDocIndex=docs().findIndex(x=>x.id===d.id)}_editingDoc=d;_rows=(d.rows||[]).map(r=>({...r}));let opts=clients().map((c,i)=>`<option value="${i}">${esc(c.name)}</option>`).join('');openModal(isNew?'Nouveau devis':(d.invoiceNo||'Document'),`<div class="form" oninput="scheduleDraft()"><div class="form three"><div><label class="label">Type</label><select class="field" id="dKind" onchange="kindChanged()"><option ${d.kind!=='FACTURE'?'selected':''}>DEVIS</option><option ${d.kind==='FACTURE'?'selected':''}>FACTURE</option></select></div><div><label class="label">Statut</label><select class="field" id="dStatus">${statusOptions(d.kind||'DEVIS',d.status||'BROUILLON')}</select></div><div><label class="label">Date</label><input type="date" class="field" id="dDate" value="${esc(d.date||'')}"></div></div><div class="form two"><div><label class="label">N° document</label><input class="field" id="dNo" value="${esc(d.invoiceNo||nextNo(d.kind||'DEVIS'))}"></div><div><label class="label">Réf. client</label><input class="field" id="dClientRef" value="${esc(d.clientRef||'PART')}"></div></div><div><label class="label">Client existant</label><select class="field" onchange="pickClient(this.value)"><option value="">— choisir —</option>${opts}</select></div><div class="form two"><div><label class="label">Client</label><input class="field" id="dClient" value="${esc(d.clientName||'')}"></div><div><label class="label">Téléphone</label><input class="field" id="dClientPhone" value="${esc(d.clientPhone||'')}"></div></div><div><label class="label">Adresse client</label><textarea class="field" id="dAddress">${esc(d.clientAddress||'')}</textarea></div><div><label class="label">E-mail client</label><input class="field" id="dClientEmail" value="${esc(d.clientEmail||'')}"></div><div class="section-title"><h3>Rapport d’intervention</h3><span>champs repris dans le PDF 4 pages</span></div><div><label class="label">Travaux réalisés / intervention</label><textarea class="field" id="dIntervention">${esc(d.intervention||'')}</textarea></div><div><label class="label">Constat initial / inspection caméra</label><textarea class="field" id="dInspection">${esc(d.inspection||'')}</textarea></div><div><label class="label">Éléments accessibles / contrôle</label><textarea class="field" id="dControl">${esc(d.control||'')}</textarea></div><div><label class="label">Résultat / contrôle final</label><textarea class="field" id="dResult">${esc(d.result||'')}</textarea></div><div><label class="label">Préconisation</label><textarea class="field" id="dRecommendation">${esc(d.recommendation||'')}</textarea></div><div><label class="label">Durée / remarque de synthèse</label><input class="field" id="dDuration" value="${esc(d.duration||'')}"></div><div class="section-title" style="margin-top:2px"><h3>Prestations facture</h3><button type="button" class="btn small" onclick="addLine()">＋ Ligne</button></div><div id="lines"></div><div class="form two"><div><label class="label">Remise %</label><input class="field" type="number" step="0.1" id="dDiscount" value="${esc(d.discount??0)}" oninput="updateTotal()"></div><div><label class="label">TVA %</label><input class="field" type="number" step="0.1" id="dVat" value="${esc(d.vat??0)}" oninput="updateTotal()"></div></div><div class="card"><div class="muted">Total TTC</div><div class="invoice-total" id="dTotal">0 €</div><div class="tiny" id="dBreakdown"></div></div><div class="form two"><div><label class="label">Mode de paiement</label><input class="field" id="dPaymentMode" placeholder="Chèque, CB, virement…" value="${esc(d.paymentMode||'')}"></div><div><label class="label">Date d’encaissement</label><input type="date" class="field" id="dPaidDate" value="${esc(d.paidDate||'')}"></div></div><div class="section-title" style="margin-top:2px"><h3>Photos rapport</h3><span>Avant / Après</span></div><div id="photoEditor"></div><div class="section-title" style="margin-top:2px"><h3>Signature client</h3><span id="sigState">${d.signature?'Signé':'Non signé'}</span></div><div id="sigEditor"></div><div class="actions"><button type="button" class="btn" onclick="openSignature()">✍ Faire signer</button>${d.signature?'<button type="button" class="btn danger" onclick="clearSignature()">Effacer</button>':''}</div><div class="actions"><button type="button" class="btn primary" onclick="saveDocument()">Enregistrer</button><button type="button" class="btn" onclick="previewEditing()">Aperçu</button></div></div>`);renderLines();renderPhotoEditor();renderSigEditor();scheduleDraft()}
function renderPhotoEditor(){let el=$('#photoEditor');if(!el)return;let a=_editingDoc?.photos||[];let slot=(idx,title)=>`<div class="photo-slot"><b>${title}</b><div class="photo" style="margin-top:8px">${a[idx]?`<img src="${a[idx]}">`:`<img src="jkbat-logo.png" style="object-fit:contain;background:#fff;padding:15px;opacity:.55">`}</div><label class="btn file-label full">🖼 Choisir dans la galerie<input type="file" accept="image/*" onchange="setReportPhoto(this.files,${idx});this.value=''" /></label>${a[idx]?`<button type="button" class="btn danger full" style="margin-top:6px" onclick="removeReportPhoto(${idx})">Retirer</button>`:''}</div>`;el.innerHTML=`<div class="photo-pair-editor">${slot(0,'AVANT INTERVENTION')}${slot(1,'APRÈS INTERVENTION')}</div>`}
function setReportPhoto(files,index){if(!files||!files[0])return;resizeImage(files[0],1100,.76).then(img=>{_editingDoc.photos=_editingDoc.photos||[];_editingDoc.photos[index]=img;renderPhotoEditor();scheduleDraft();toast('Photo enregistrée')})}
function removeReportPhoto(index){_editingDoc.photos=_editingDoc.photos||[];_editingDoc.photos[index]='';renderPhotoEditor();scheduleDraft()}
function invoiceHtml(d){let c=company(),x=calc(d),rows=(d.rows||[]).map(r=>`<tr><td class="c-name">${esc(r.label||'')}</td><td class="c-desc">${esc(r.description||'').replace(/\n/g,'<br>')}</td><td class="c-qty">${Number(r.qty)||0}</td><td class="c-pu">${euro(r.price)}</td><td class="c-amt">${euro((Number(r.qty)||0)*(Number(r.price)||0))}</td></tr>`).join('');let comments=[d.intervention,d.control,d.inspection].filter(Boolean).map(t=>`<p>${esc(t).replace(/\n/g,'<br>')}</p>`).join('');let rem=x.disc?euro(x.sub-x.after):'';let vat=x.vat?`<tr><td>TVA ${x.vat}%</td><td>${euro(x.tax)}</td></tr>`:'';return `<div class="jk-doc-page invoice-page"><div class="invoice-top"><div><img class="jk-logo-img invoice-top-logo" src="${c.logo||'jkbat-logo.png'}"></div><div class="invoice-meta"><div class="invoice-meta-row"><b>Date</b><span>${fmtDate(d.date)}</span></div><div class="invoice-meta-row"><b>${d.kind==='FACTURE'?'FACT :':'DEVIS :'}</b><span>${esc(d.invoiceNo||'')}</span></div><div class="invoice-meta-row"><b>Réf. client</b><span>${esc(d.clientRef||'PART')}</span></div></div></div><div class="invoice-company"><h3>Adresse de la société</h3>${esc(c.address).replace(/\n/g,'<br>')}<br>Tél : ${esc(c.phone)}<br>Mail : ${esc(c.email)}</div><div class="invoice-client">${esc(d.clientName||'')}<div class="addr">${esc(d.clientAddress||'').replace(/\n/g,'<br>')}</div></div><div class="invoice-comments"><h3>Commentaires ou instructions spéciales</h3>${comments||'<p>&nbsp;</p>'}${d.recommendation?`<p><b>Préconisation :</b> ${esc(d.recommendation).replace(/\n/g,'<br>')}</p>`:''}${d.result?`<p><b>Résultat :</b> ${esc(d.result).replace(/\n/g,'<br>')}</p>`:''}</div><div class="invoice-payline"><div><b>Statut :</b> ${esc(d.status==='PAYÉ'?'Payée':d.status||'')}</div><div><b>Mode :</b> ${esc(d.paymentMode||'')}</div><div><b>Date d'encaissement :</b> ${d.paidDate?fmtDate(d.paidDate):''}</div></div><table class="invoice-table"><thead><tr><th class="c-name">NOM</th><th class="c-desc">Description</th><th class="c-qty">Qte</th><th class="c-pu">Prix unitaire</th><th class="c-amt">Montant</th></tr></thead><tbody>${rows||'<tr><td colspan="5">&nbsp;</td></tr>'}</tbody></table><table class="invoice-totals"><tr><td>Sous-total</td><td>${euro(x.sub)}</td></tr><tr class="discount"><td>Remise</td><td>${rem}</td></tr>${vat}<tr class="grand"><td>TOTAL</td><td>${euro(x.total)}</td></tr></table><div class="invoice-thanks"><b>Merci pour votre confiance</b><br>Nous restons à votre disposition.</div><div class="invoice-footer"><img src="${c.logo||'jkbat-logo.png'}"><div class="details">${esc(c.name)} - ${esc(c.address)}<br>Siret : ${esc(c.siret).replace(/\s/g,'')}<br>Tél : ${esc(c.phone)} - Mail : ${esc(c.email)}</div></div></div>`}
function reportPhoto(d,index){let p=(d.photos||[])[index];return p||'jkbat-logo.png'}
function reportHtml(d){let c=company(),dur=esc(d.duration||'Intervention réalisée selon les constatations du rapport.');return `<div class="jk-doc-page report-page"><img class="jk-logo-img report-logo-top" src="${c.logo||'jkbat-logo.png'}"><div class="report-title">RAPPORT D’INTERVENTION</div><div class="report-subtitle">Compte rendu d’intervention</div><table class="report-info"><tr><td class="lab">CLIENT</td><td>${esc(d.clientName||'')}</td><td class="lab">DATE</td><td>${fmtDate(d.date)}</td></tr><tr><td class="lab">LIEU</td><td>${esc(d.clientAddress||'')}</td><td class="lab">RÉFÉRENCE</td><td>${esc(d.invoiceNo||'')}</td></tr></table><div class="report-section"><h2>Constat initial</h2><p>${esc(d.inspection||'').replace(/\n/g,'<br>')}</p></div><div class="report-section"><h2>Travaux réalisés</h2><p>${esc(d.intervention||'').replace(/\n/g,'<br>')}</p></div><div class="report-section"><h2>Résultat</h2><div class="result-box"><p>${esc(d.result||'').replace(/\n/g,'<br>')}</p></div></div><div class="report-preco"><b>Préconisation :</b> ${esc(d.recommendation||'')}</div><div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page 1</span></div></div><div class="jk-doc-page report-page"><div class="report-photo-title">AVANT INTERVENTION</div><div class="report-photo-box"><img src="${reportPhoto(d,0)}"></div><div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page 2</span></div></div><div class="jk-doc-page report-page"><div class="report-photo-title">APRÈS INTERVENTION</div><div class="report-photo-box"><img src="${reportPhoto(d,1)}"></div><div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page 3</span></div></div><div class="jk-doc-page report-page"><div class="report-synth-title">SYNTHÈSE D’INTERVENTION</div><table class="report-synth"><thead><tr><th>Opération</th><th>Constat / résultat</th></tr></thead><tbody><tr><td>Inspection caméra</td><td>${esc(d.inspection||'')}</td></tr><tr><td>Débouchage mécanique</td><td>${esc(d.intervention||'')}</td></tr><tr><td>Éléments accessibles</td><td>${esc(d.control||'')}</td></tr><tr><td>Contrôle final</td><td>${esc(d.result||'')}</td></tr><tr><td>Durée</td><td>${dur}</td></tr></tbody></table><div class="report-company-block"><h2>JKBat’ Services</h2>${esc(c.address).replace(/\n/g,'<br>')}<br>SIRET : ${esc(c.siret)}<br>Tél. : ${esc(c.phone)} - Mail : ${esc(c.email)}</div><div class="report-note">Rapport établi à partir des constatations réalisées lors de l’intervention et des photographies fournies.</div><div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page 4</span></div></div>`}
function documentHtml(d){return invoiceHtml(d)}
function showDocument(i){let d=docs()[i];openModal(d.invoiceNo||d.kind,`<div>${invoiceHtml(d)}</div><div class="actions"><button class="btn primary" onclick="openPrint(${i},'invoice')">📄 Facture / devis PDF</button><button class="btn primary" onclick="openPrint(${i},'report')">🛠 Rapport intervention PDF</button><button class="btn" onclick="closeModal();openDocument(false,docs()[${i}])">Modifier</button>${d.kind==='DEVIS'?`<button class="btn ok" onclick="convertToInvoice(${i})">→ Facture</button>`:''}<button class="btn" onclick="duplicateDoc(${i})">Dupliquer</button><button class="btn danger" onclick="deleteDoc(${i})">Supprimer</button></div>`)}
function previewEditing(){let d=editingDoc();_editingDoc=d;openModal('Aperçu',invoiceHtml(d)+`<div class="actions"><button class="btn primary" onclick="openPrintDraft('invoice')">📄 Facture / devis PDF</button><button class="btn primary" onclick="openPrintDraft('report')">🛠 Rapport intervention PDF</button><button class="btn" onclick="closeModal();openDocument(false,_editingDoc)">Retour modifier</button></div>`)}
function openPrint(i,type='invoice'){let d=docs()[i];closeModal();showPrintDoc(d,type)}function openPrintDraft(type='invoice'){let d=_editingDoc||editingDoc();closeModal();showPrintDoc(d,type)}function showPrintDoc(d,type='invoice'){$('#printLayer').innerHTML=`<div class="print-controls"><button class="btn primary" onclick="triggerPrint()">Créer le PDF / Imprimer</button><button class="btn" onclick="exitPrint()">Retour à l’application</button></div>${type==='report'?reportHtml(d):invoiceHtml(d)}`;document.body.classList.add('print-mode');window.scrollTo(0,0)}


/* --- JKBat Pro 3.0 Full : gestion entreprise hors ligne --- */
const V3_CATALOG=[
 {id:'cam',name:'Inspection caméra',category:'Plomberie',description:"Inspection caméra de la canalisation : recherche et localisation des zones d'obstruction, contrôle de la canalisation et présentation des images au client.",unit:'forfait',price:50},
 {id:'deb',name:'Débouchage mécanique',category:'Plomberie',description:"Débouchage mécanique de la canalisation : passages successifs au furet électrique, contrôle du passage et vérification de l'évacuation.",unit:'forfait',price:110},
 {id:'dep',name:'Dépannage',category:'Dépannage divers',description:'Diagnostic, recherche de panne et intervention de dépannage.',unit:'h',price:0},
 {id:'elec',name:'Électricité',category:'Électricité',description:'Travaux électriques selon constat et demande client.',unit:'h',price:0},
 {id:'peint',name:'Peinture',category:'Peinture',description:'Préparation des supports et travaux de peinture selon surfaces définies.',unit:'m²',price:0},
 {id:'reno',name:'Rénovation',category:'Rénovation',description:'Travaux de rénovation selon descriptif et état des supports.',unit:'forfait',price:0},
 {id:'serr',name:'Serrurerie',category:'Serrurerie',description:'Diagnostic et intervention de serrurerie.',unit:'forfait',price:0}
];
function todayISO(){return new Date().toISOString().slice(0,10)}
function addDaysISO(date,days){let d=new Date((date||todayISO())+'T12:00:00');d.setDate(d.getDate()+(Number(days)||0));return d.toISOString().slice(0,10)}
function expenses(){return jget('jkbat_expenses',[])} function catalog(){return jget('jkbat_catalog',[])} function inventory(){return jget('jkbat_inventory',[])} function tasks(){return jget('jkbat_tasks',[])} function activity(){return jget('jkbat_activity',[])}
function logActivity(type,label,detail=''){let a=activity();a.unshift({id:uid(),at:new Date().toISOString(),type,label,detail});jset('jkbat_activity',a.slice(0,200))}
function migrateV3(){
 if(LS.getItem('jkbat_default_due_days')==null)LS.setItem('jkbat_default_due_days','30');if(LS.getItem('jkbat_default_quote_days')==null)LS.setItem('jkbat_default_quote_days','30');
 if(LS.getItem('jkbat_catalog')==null)jset('jkbat_catalog',V3_CATALOG);if(LS.getItem('jkbat_expenses')==null)jset('jkbat_expenses',[]);if(LS.getItem('jkbat_inventory')==null)jset('jkbat_inventory',[]);if(LS.getItem('jkbat_tasks')==null)jset('jkbat_tasks',[]);if(LS.getItem('jkbat_activity')==null)jset('jkbat_activity',[]);
 let cs=clients(),cc=false;cs=cs.map(c=>{if(!c.id){c.id=uid();cc=true}if(!c.type){c.type='PARTICULIER';cc=true}if(c.notes==null){c.notes='';cc=true}if(c.tags==null){c.tags='';cc=true}if(!c.createdAt){c.createdAt=new Date().toISOString();cc=true}return c});if(cc)jset('jkbat_clients',cs);
 let ds=docs(),dc=false;ds=ds.map(d=>{if(d.amountPaid==null){d.amountPaid=d.status==='PAYÉ'?calc(d).total:0;dc=true}if(!d.dueDate&&d.kind==='FACTURE'){d.dueDate=addDaysISO(d.date,LS.getItem('jkbat_default_due_days'));dc=true}if(!d.validUntil&&d.kind==='DEVIS'){d.validUntil=addDaysISO(d.date,LS.getItem('jkbat_default_quote_days'));dc=true}if(!d.workflow){d.workflow={arrival:false,before:false,diagnosis:false,work:false,after:false,signature:!!d.signature};dc=true}if(d.internalNotes==null){d.internalNotes='';dc=true}if(d.jobType==null){d.jobType='';dc=true}return d});if(dc)jset('jkbat_history',ds);
 let ap=appointments(),ac=false;ap=ap.map(a=>{if(!a.status){a.status='À FAIRE';ac=true}if(!a.id){a.id=uid();ac=true}return a});if(ac)jset('jkbat_appointments',ap);
 if(LS.getItem('jkbat_v3_migrated')!=='1'){LS.setItem('jkbat_v3_migrated','1');logActivity('SYSTEM','Passage à JKBat Pro 3.0','Données existantes conservées')}
}
function paidAmount(d){let t=calc(d).total;if(d.status==='PAYÉ')return t;return Math.max(0,Math.min(t,Number(d.amountPaid)||0))}
function outstanding(d){return d.kind==='FACTURE'?Math.max(0,calc(d).total-paidAmount(d)):0}
function isOverdue(d){return d.kind==='FACTURE'&&outstanding(d)>.009&&d.dueDate&&d.dueDate<todayISO()&&!['ANNULÉ'].includes(d.status)}
function quoteExpired(d){return d.kind==='DEVIS'&&d.validUntil&&d.validUntil<todayISO()&&!['ACCEPTÉ','REFUSÉ'].includes(d.status)}
function statusClass(s){return ['PAYÉ','ACCEPTÉ','TERMINÉ'].includes(s)?'ok':['REFUSÉ','ANNULÉ','EN RETARD','EXPIRÉ'].includes(s)?'bad':['ENVOYÉ','PARTIEL','À FAIRE'].includes(s)?'warn':''}
function statusOptions(kind,current){let a=kind==='FACTURE'?['BROUILLON','ENVOYÉ','PARTIEL','PAYÉ','ANNULÉ']:['BROUILLON','ENVOYÉ','ACCEPTÉ','REFUSÉ','EXPIRÉ'];return a.map(x=>`<option ${x===current?'selected':''}>${x}</option>`).join('')}
function renderAll(){renderLogo();renderDashboard();renderClients();renderDocs();renderAgenda();renderPilotage();renderSettings()}
function renderDashboard(){
 let ds=docs(),cs=clients(),aps=appointments(),ex=expenses(),paid=ds.filter(d=>d.kind==='FACTURE').reduce((s,d)=>s+paidAmount(d),0),billed=ds.filter(d=>d.kind==='FACTURE').reduce((s,d)=>s+calc(d).total,0),due=ds.reduce((s,d)=>s+outstanding(d),0),pipeline=ds.filter(d=>d.kind==='DEVIS'&&!['REFUSÉ','EXPIRÉ'].includes(d.status)).reduce((s,d)=>s+calc(d).total,0),cost=ex.reduce((s,e)=>s+(Number(e.amount)||0),0);
 $('#stats').innerHTML=`<div class="stat"><i>€</i><span>CA encaissé</span><b>${euro(paid)}</b></div><div class="stat"><i>⌛</i><span>À encaisser</span><b>${euro(due)}</b></div><div class="stat"><i>↗</i><span>Devis actifs</span><b>${euro(pipeline)}</b></div><div class="stat"><i>◆</i><span>Marge brute suivi</span><b>${euro(paid-cost)}</b></div><div class="stat"><i>♟</i><span>Clients</span><b>${cs.length}</b></div><div class="stat"><i>▤</i><span>Facturé</span><b>${euro(billed)}</b></div>`;
 renderBars(ds);let today=todayISO(),up=aps.filter(a=>(a.date||'')>=today&&a.status!=='TERMINÉ').sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,4);$('#apptHint').textContent=up.length?`${up.length} prochain(s)`:'Aucun';$('#nextAppointments').innerHTML=up.length?up.map(a=>`<div class="card row" onclick="openAppointment('${esc(a.id||'')}')"><div class="avatar">${(a.time||'--').slice(0,2)}</div><div class="grow"><b>${esc(a.title||a.client||'Rendez-vous')}</b><div class="muted">${fmtDate(a.date)} ${esc(a.time||'')} · ${esc(a.address||'')}</div></div></div>`).join(''):'<div class="empty">Aucun rendez-vous à venir.</div>';
 let rec=ds.slice().sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date))).slice(0,4);$('#recentDocs').innerHTML=rec.length?rec.map(d=>docCard(d,ds.findIndex(x=>x.id===d.id))).join(''):'<div class="empty">Tes prochains devis et factures apparaîtront ici.</div>';
 renderDashboardAlerts();$('#quickTools').innerHTML=`<button class="btn primary" onclick="openDocument(true)">＋ Devis</button><button class="btn" onclick="openDocument(true,{kind:'FACTURE'})">＋ Facture</button><button class="btn" onclick="openAppointment()">◫ RDV</button><button class="btn" onclick="showGlobalSearch()">⌕ Recherche</button><button class="btn" onclick="openExpense()">− Dépense</button><button class="btn" onclick="go('pilotage')">◆ Pilotage</button>`;
}
function renderDashboardAlerts(){let el=$('#dashboardAlerts');if(!el)return;let od=docs().filter(isOverdue),qe=docs().filter(d=>d.kind==='DEVIS'&&!quoteExpired(d)&&d.validUntil&&d.validUntil<=addDaysISO(todayISO(),7)&&!['ACCEPTÉ','REFUSÉ'].includes(d.status)),low=inventory().filter(x=>Number(x.qty)<=Number(x.minQty||0));let n=od.length+qe.length+low.length;if(!n){el.innerHTML='';return}el.innerHTML=`<div class="section-title"><h3>À traiter</h3><span>${n} alerte(s)</span></div><div class="cards">${od.slice(0,2).map(d=>`<div class="card compact alert-card bad" onclick="showDocument(${docs().findIndex(x=>x.id===d.id)})"><b>Facture en retard · ${esc(d.invoiceNo)}</b><div class="muted">${esc(d.clientName)} · reste ${euro(outstanding(d))}</div></div>`).join('')}${qe.slice(0,2).map(d=>`<div class="card compact alert-card" onclick="showDocument(${docs().findIndex(x=>x.id===d.id)})"><b>Devis à relancer · ${esc(d.invoiceNo)}</b><div class="muted">Valide jusqu’au ${fmtDate(d.validUntil)}</div></div>`).join('')}${low.slice(0,2).map(x=>`<div class="card compact alert-card bad" onclick="go('pilotage')"><b>Stock bas · ${esc(x.name)}</b><div class="muted">${Number(x.qty)||0} ${esc(x.unit||'')}</div></div>`).join('')}</div>`}
function clientDocs(c){return docs().filter(d=>(c.id&&d.clientId===c.id)||String(d.clientName||'').toLowerCase()===String(c.name||'').toLowerCase())}
function renderClients(){let q=($('#clientSearch')?.value||'').toLowerCase().trim(),arr=clients().map((c,i)=>({...c,_i:i})).filter(c=>!q||[c.name,c.address,c.phone,c.ref,c.email,c.tags,c.notes].join(' ').toLowerCase().includes(q));if($('#clientCount'))$('#clientCount').textContent=`${arr.length} client(s)`;if($('#clientList'))$('#clientList').innerHTML=arr.length?arr.map(c=>{let ds=clientDocs(c),sum=ds.filter(d=>d.kind==='FACTURE').reduce((s,d)=>s+calc(d).total,0);return `<div class="card row" onclick="showClient(${c._i})"><div class="avatar">${esc((c.name||'?').trim().slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(c.name||'Sans nom')}</b><div class="muted">${esc(c.address||'Adresse non renseignée')}</div><div class="chips"><span class="chip">${esc(c.type||'PARTICULIER')}</span>${c.phone?'<span class="chip">☎ '+esc(c.phone)+'</span>':''}${ds.length?`<span class="chip">${ds.length} docs</span>`:''}${sum?`<span class="chip ok">${euro(sum)}</span>`:''}</div></div><span class="tap">›</span></div>`}).join(''):'<div class="empty">Aucun client trouvé.</div>'}
function openClient(i=null){let c=i==null?{}:clients()[i];openModal(i==null?'Nouveau client':'Modifier le client',`<div class="form"><div class="form two"><div><label class="label">Type</label><select class="field" id="cType"><option ${c.type!=='PRO'?'selected':''}>PARTICULIER</option><option ${c.type==='PRO'?'selected':''}>PRO</option></select></div><div><label class="label">Référence</label><input class="field" id="cRef" value="${esc(c.ref||'PART')}"></div></div><div><label class="label">Nom / société</label><input class="field" id="cName" value="${esc(c.name||'')}"></div><div><label class="label">Adresse</label><textarea class="field" id="cAddress">${esc(c.address||'')}</textarea></div><div class="form two"><div><label class="label">Téléphone</label><input class="field" inputmode="tel" id="cPhone" value="${esc(c.phone||'')}"></div><div><label class="label">E-mail</label><input class="field" inputmode="email" id="cEmail" value="${esc(c.email||'')}"></div></div><div><label class="label">Tags</label><input class="field" id="cTags" placeholder="fidèle, syndic, urgence…" value="${esc(c.tags||'')}"></div><div><label class="label">Notes client</label><textarea class="field" id="cNotes">${esc(c.notes||'')}</textarea></div><button class="btn primary" onclick="saveClient(${i==null?'null':i})">Enregistrer</button>${i!=null?`<button class="btn danger" onclick="deleteClient(${i})">Supprimer</button>`:''}</div>`)}
function saveClient(i){let old=i==null?{}:clients()[i],c={...old,id:old.id||uid(),createdAt:old.createdAt||new Date().toISOString(),type:$('#cType').value,name:$('#cName').value.trim(),address:$('#cAddress').value.trim(),phone:$('#cPhone').value.trim(),ref:$('#cRef').value.trim(),email:$('#cEmail').value.trim(),tags:$('#cTags').value.trim(),notes:$('#cNotes').value.trim()};if(!c.name)return toast('Nom du client requis');let a=clients();if(i==null)a.push(c);else a[i]=c;jset('jkbat_clients',a);logActivity('CLIENT',i==null?'Client créé':'Client modifié',c.name);saveAuto();closeModal();renderAll();toast('Client enregistré')}
function showClient(i){let c=clients()[i],p=cleanPhone(c.phone),ds=clientDocs(c),inv=ds.filter(d=>d.kind==='FACTURE'),billed=inv.reduce((s,d)=>s+calc(d).total,0),paid=inv.reduce((s,d)=>s+paidAmount(d),0),due=inv.reduce((s,d)=>s+outstanding(d),0),aps=appointments().filter(a=>String(a.client||a.title||'').toLowerCase().includes(String(c.name||'').toLowerCase())).slice(-5);openModal(c.name||'Client',`<div class="card"><div class="row-between"><div><b>${esc(c.name||'')}</b><div class="muted">${esc(c.type||'PARTICULIER')} · ${esc(c.ref||'')}</div></div><span class="chip">${esc(c.tags||'')}</span></div><p class="muted">${esc(c.address||'Adresse non renseignée').replace(/\n/g,'<br>')}</p>${c.phone?`<p>☎ ${esc(c.phone)}</p>`:''}${c.email?`<p>✉ ${esc(c.email)}</p>`:''}${c.notes?`<div class="card compact"><b>Notes</b><div class="muted">${esc(c.notes).replace(/\n/g,'<br>')}</div></div>`:''}<div class="client-kpis"><div><span class="tiny">Facturé</span><b>${euro(billed)}</b></div><div><span class="tiny">Encaissé</span><b>${euro(paid)}</b></div><div><span class="tiny">À encaisser</span><b>${euro(due)}</b></div></div><div class="actions">${p?`<a class="btn primary" href="tel:${p}">Appeler</a><a class="btn" href="sms:${p}">SMS</a>`:''}${c.email?`<a class="btn" href="mailto:${encodeURIComponent(c.email)}">E-mail</a>`:''}${c.address?`<a class="btn" href="${mapHref(c.address)}">Navigation</a>`:''}</div></div><div class="section-title"><h3>Historique</h3><span>${ds.length} document(s)</span></div>${ds.length?ds.slice().reverse().slice(0,6).map(d=>`<div class="card compact row" onclick="closeModal();showDocument(${docs().findIndex(x=>x.id===d.id)})"><div class="badge-number">${d.kind==='FACTURE'?'F':'D'}</div><div class="grow"><b>${esc(d.invoiceNo)}</b><div class="muted">${fmtDate(d.date)} · ${euro(calc(d).total)}</div></div><span class="chip ${statusClass(d.status)}">${esc(d.status)}</span></div>`).join(''):'<div class="empty">Aucun document</div>'}<div class="actions"><button class="btn primary" onclick="closeModal();openDocument(true,null,${i})">Créer un devis</button><button class="btn" onclick="closeModal();openAppointment(null,${i})">Créer un RDV</button><button class="btn ghost" onclick="closeModal();openClient(${i})">Modifier</button></div>`)}
function docCard(d,i){let c=calc(d),late=isOverdue(d),left=outstanding(d);return `<div class="card row ${late?'overdue':''}" onclick="showDocument(${i})"><div class="avatar">${d.kind==='FACTURE'?'F':'D'}</div><div class="grow"><b>${esc(d.invoiceNo||d.kind)} · ${esc(d.clientName||'Client')}</b><div class="muted">${fmtDate(d.date)} · ${esc(d.intervention||d.jobType||'Sans objet')}</div><div class="chips"><span class="chip ${late?'bad':statusClass(d.status)}">${late?'EN RETARD':esc(d.status||'BROUILLON')}</span><span class="chip">${euro(c.total)}</span>${left>0&&d.kind==='FACTURE'?`<span class="chip warn">reste ${euro(left)}</span>`:''}${d.signature?'<span class="chip ok">✍ signé</span>':''}${(d.photos||[]).filter(Boolean).length?`<span class="chip">📷 ${(d.photos||[]).filter(Boolean).length}</span>`:''}</div></div><span class="tap">›</span></div>`}
function renderDocs(){let q=($('#docSearch')?.value||'').toLowerCase().trim(),f=$('#docFilter')?.value||'',a=docs().map((d,i)=>({...d,_i:i})).filter(d=>(!f||d.kind===f)&&(!q||[d.invoiceNo,d.clientName,d.intervention,d.status,d.clientRef,d.jobType].join(' ').toLowerCase().includes(q))).sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date)));if($('#docCount'))$('#docCount').textContent=`${a.length} document(s)`;if($('#docList'))$('#docList').innerHTML=a.length?a.map(d=>docCard(d,d._i)).join(''):'<div class="empty">Aucun document.</div>';let draft=jget('jkbat_invoice_pwa',null);if($('#draftBanner'))$('#draftBanner').innerHTML=draft&&draft.invoiceNo?`<div class="card" style="margin-bottom:10px"><div class="grow"><b>📝 Brouillon automatique</b><div class="muted">${esc(draft.invoiceNo)} · ${esc(draft.clientName||'sans client')}</div></div><div class="actions"><button class="btn small" onclick="openDocument(false,jget('jkbat_invoice_pwa',{}))">Reprendre</button></div></div>`:''}
function addCatalogToRows(v){if(v==='')return;let x=catalog()[Number(v)];if(!x)return;_rows.push({label:x.name,description:x.description||'',qty:1,price:Number(x.price)||0});renderLines();scheduleDraft();toast('Prestation ajoutée')}
function workflowBox(d){let w=d.workflow||{};return `<div class="workflow"><label><input type="checkbox" id="wfArrival" ${w.arrival?'checked':''}> Arrivée sur chantier</label><label><input type="checkbox" id="wfBefore" ${w.before?'checked':''}> Photo avant</label><label><input type="checkbox" id="wfDiagnosis" ${w.diagnosis?'checked':''}> Diagnostic / constat</label><label><input type="checkbox" id="wfWork" ${w.work?'checked':''}> Travaux réalisés</label><label><input type="checkbox" id="wfAfter" ${w.after?'checked':''}> Photo après</label><label><input type="checkbox" id="wfSignature" ${w.signature||d.signature?'checked':''}> Signature client</label></div>`}
function editingDoc(){if(!$('#dKind'))return _editingDoc||{};return {...(_editingDoc||{}),kind:$('#dKind').value,status:$('#dStatus').value,date:$('#dDate').value,invoiceNo:$('#dNo').value.trim(),clientRef:$('#dClientRef')?.value.trim()||'PART',clientName:$('#dClient').value.trim(),clientAddress:$('#dAddress').value.trim(),clientPhone:$('#dClientPhone').value.trim(),clientEmail:$('#dClientEmail').value.trim(),jobType:$('#dJobType')?.value.trim()||'',intervention:$('#dIntervention').value.trim(),inspection:$('#dInspection')?.value.trim()||'',control:$('#dControl')?.value.trim()||'',result:$('#dResult')?.value.trim()||'',recommendation:$('#dRecommendation').value.trim(),duration:$('#dDuration')?.value.trim()||'',paymentMode:$('#dPaymentMode')?.value.trim()||'',paidDate:$('#dPaidDate')?.value||'',dueDate:$('#dDueDate')?.value||'',validUntil:$('#dValidUntil')?.value||'',amountPaid:Number($('#dAmountPaid')?.value)||0,internalNotes:$('#dInternalNotes')?.value.trim()||'',discount:Number($('#dDiscount').value)||0,vat:Number($('#dVat').value)||0,rows:_rows.map(r=>({label:r.label||'',description:r.description||'',qty:Number(r.qty)||0,price:Number(r.price)||0})),photos:_editingDoc?.photos||[],signature:_editingDoc?.signature||'',signedAt:_editingDoc?.signedAt||'',workflow:{arrival:!!$('#wfArrival')?.checked,before:!!$('#wfBefore')?.checked,diagnosis:!!$('#wfDiagnosis')?.checked,work:!!$('#wfWork')?.checked,after:!!$('#wfAfter')?.checked,signature:!!$('#wfSignature')?.checked}}}
function openDocument(isNew=true,existing=null,clientIndex=null){let d;if(isNew){let c=clientIndex==null?null:clients()[clientIndex],requested=existing&&existing.kind==='FACTURE'?'FACTURE':'DEVIS',date=todayISO();d={id:uid(),kind:requested,status:'BROUILLON',date,invoiceNo:nextNo(requested),clientId:c?.id||'',clientRef:c?.ref||'PART',clientName:c?.name||'',clientAddress:c?.address||'',clientPhone:c?.phone||'',clientEmail:c?.email||'',jobType:'',intervention:'',inspection:'',control:'',result:'',recommendation:'',duration:'',paymentMode:'',paidDate:'',dueDate:requested==='FACTURE'?addDaysISO(date,LS.getItem('jkbat_default_due_days')):'',validUntil:requested==='DEVIS'?addDaysISO(date,LS.getItem('jkbat_default_quote_days')):'',amountPaid:0,internalNotes:'',discount:0,vat:Number(LS.getItem('jkbat_default_vat')||0),rows:[],photos:[],signature:'',signedAt:'',workflow:{arrival:false,before:false,diagnosis:false,work:false,after:false,signature:false}};_editingDocIndex=-1}else{d=JSON.parse(JSON.stringify(existing||{}));d.photos=d.photos||[];d.rows=(d.rows||[]).map(r=>({label:r.label||r.description||'',description:r.description||'',qty:r.qty??1,price:r.price??0}));d.workflow=d.workflow||{};_editingDocIndex=docs().findIndex(x=>x.id===d.id)}_editingDoc=d;_rows=(d.rows||[]).map(r=>({...r}));let opts=clients().map((c,i)=>`<option value="${i}">${esc(c.name)}</option>`).join(''),cat=catalog().map((x,i)=>`<option value="${i}">${esc(x.category)} · ${esc(x.name)}${Number(x.price)?' · '+euro(x.price):''}</option>`).join('');openModal(isNew?(d.kind==='FACTURE'?'Nouvelle facture':'Nouveau devis'):(d.invoiceNo||'Document'),`<div class="form" oninput="scheduleDraft()"><div class="form three"><div><label class="label">Type</label><select class="field" id="dKind" onchange="kindChanged()"><option ${d.kind!=='FACTURE'?'selected':''}>DEVIS</option><option ${d.kind==='FACTURE'?'selected':''}>FACTURE</option></select></div><div><label class="label">Statut</label><select class="field" id="dStatus">${statusOptions(d.kind||'DEVIS',d.status||'BROUILLON')}</select></div><div><label class="label">Date</label><input type="date" class="field" id="dDate" value="${esc(d.date||'')}"></div></div><div class="form two"><div><label class="label">N° document</label><input class="field" id="dNo" value="${esc(d.invoiceNo||nextNo(d.kind||'DEVIS'))}"></div><div><label class="label">Réf. client</label><input class="field" id="dClientRef" value="${esc(d.clientRef||'PART')}"></div></div><div><label class="label">Client existant</label><select class="field" onchange="pickClient(this.value)"><option value="">— choisir —</option>${opts}</select></div><div class="form two"><div><label class="label">Client</label><input class="field" id="dClient" value="${esc(d.clientName||'')}"></div><div><label class="label">Téléphone</label><input class="field" id="dClientPhone" value="${esc(d.clientPhone||'')}"></div></div><div><label class="label">Adresse client</label><textarea class="field" id="dAddress">${esc(d.clientAddress||'')}</textarea></div><div><label class="label">E-mail client</label><input class="field" id="dClientEmail" value="${esc(d.clientEmail||'')}"></div><div><label class="label">Métier / activité</label><select class="field trade-select" id="dJobType" onchange="refreshCatalogForEditingTrade();scheduleDraft()">${tradeSelectOptions(d.jobType||'')}</select></div><div class="section-title"><h3>Rapport d’intervention</h3><span>format PDF JKBat · couleurs métier · photos multiples</span></div><div><label class="label">Travaux réalisés / intervention</label><textarea class="field" id="dIntervention">${esc(d.intervention||'')}</textarea></div><div><label class="label">Constat initial / inspection caméra</label><textarea class="field" id="dInspection">${esc(d.inspection||'')}</textarea></div><div><label class="label">Éléments accessibles / contrôle</label><textarea class="field" id="dControl">${esc(d.control||'')}</textarea></div><div><label class="label">Résultat / contrôle final</label><textarea class="field" id="dResult">${esc(d.result||'')}</textarea></div><div><label class="label">Préconisation</label><textarea class="field" id="dRecommendation">${esc(d.recommendation||'')}</textarea></div><div><label class="label">Durée / remarque de synthèse</label><input class="field" id="dDuration" value="${esc(d.duration||'')}"></div><div class="section-title"><h3>Mode chantier</h3><span>check-list terrain</span></div>${workflowBox(d)}<div class="section-title" style="margin-top:2px"><h3>Prestations facture</h3><button type="button" class="btn small" onclick="addLine()">＋ Ligne</button></div><div class="catalog-select"><select class="field" id="dCatalogSelect" onchange="addCatalogToRows(this.value);this.value=''"><option value="">＋ Ajouter depuis le catalogue…</option>${cat}</select><button type="button" class="btn" onclick="go('pilotage');closeModal()">Gérer</button></div><div id="lines"></div><div class="form two"><div><label class="label">Remise %</label><input class="field" type="number" step="0.1" id="dDiscount" value="${esc(d.discount??0)}" oninput="updateTotal()"></div><div><label class="label">TVA %</label><input class="field" type="number" step="0.1" id="dVat" value="${esc(d.vat??0)}" oninput="updateTotal()"></div></div><div class="card"><div class="muted">Total TTC</div><div class="invoice-total" id="dTotal">0 €</div><div class="tiny" id="dBreakdown"></div></div><div class="form two"><div><label class="label">Mode de paiement</label><input class="field" id="dPaymentMode" placeholder="Chèque, CB, virement…" value="${esc(d.paymentMode||'')}"></div><div><label class="label">Montant encaissé</label><input type="number" step="0.01" class="field" id="dAmountPaid" value="${esc(d.amountPaid||0)}"></div></div><div class="form two"><div><label class="label">Échéance facture</label><input type="date" class="field" id="dDueDate" value="${esc(d.dueDate||'')}"></div><div><label class="label">Validité devis</label><input type="date" class="field" id="dValidUntil" value="${esc(d.validUntil||'')}"></div></div><div><label class="label">Date d’encaissement</label><input type="date" class="field" id="dPaidDate" value="${esc(d.paidDate||'')}"></div><div><label class="label">Notes internes (non imprimées)</label><textarea class="field" id="dInternalNotes">${esc(d.internalNotes||'')}</textarea></div><div class="section-title" style="margin-top:2px"><h3>Photos rapport</h3><span>Avant / Après</span></div><div id="photoEditor"></div><div class="section-title" style="margin-top:2px"><h3>Signature client</h3><span id="sigState">${d.signature?'Signé':'Non signé'}</span></div><div id="sigEditor"></div><div class="actions"><button type="button" class="btn" onclick="openSignature()">✍ Faire signer</button>${d.signature?'<button type="button" class="btn danger" onclick="clearSignature()">Effacer</button>':''}</div><div class="actions"><button type="button" class="btn primary" onclick="saveDocument()">Enregistrer</button><button type="button" class="btn" onclick="previewEditing()">Aperçu</button></div></div>`);renderLines();renderPhotoEditor();renderSigEditor();scheduleDraft()}
function saveDocument(){let d=editingDoc();if(!d.invoiceNo)return toast('Numéro requis');if(!d.clientName)return toast('Client requis');let c=clients().find(x=>String(x.name||'').toLowerCase()===d.clientName.toLowerCase());if(c)d.clientId=c.id||'';if(d.kind==='FACTURE'&&!d.dueDate)d.dueDate=addDaysISO(d.date,LS.getItem('jkbat_default_due_days'));if(d.kind==='DEVIS'&&!d.validUntil)d.validUntil=addDaysISO(d.date,LS.getItem('jkbat_default_quote_days'));if(d.status==='PAYÉ'){d.amountPaid=calc(d).total;if(!d.paidDate)d.paidDate=todayISO()}else if(d.kind==='FACTURE'&&d.amountPaid>0&&d.amountPaid<calc(d).total&&d.status==='BROUILLON')d.status='PARTIEL';d.savedAt=new Date().toISOString();let a=docs(),i=a.findIndex(x=>x.id===d.id),created=i<0;if(i>=0)a[i]=d;else a.push(d);jset('jkbat_history',a);LS.setItem('jkbat_invoice_pwa',JSON.stringify(d));commitSeq(d);logActivity('DOCUMENT',created?'Document créé':'Document modifié',`${d.invoiceNo} · ${d.clientName} · ${euro(calc(d).total)}`);saveAuto();closeModal();renderAll();toast(`${d.kind==='FACTURE'?'Facture':'Devis'} enregistré`)}
function kindChanged(){let k=$('#dKind').value,s=$('#dStatus');s.innerHTML=statusOptions(k,'BROUILLON');let no=$('#dNo');if((k==='FACTURE'&&(String(no.value).startsWith('DEV-')||!String(no.value).startsWith('FACT-')))||(k==='DEVIS'&&String(no.value).startsWith('FACT-')))no.value=nextNo(k);let date=$('#dDate').value||todayISO();if(k==='FACTURE'&&$('#dDueDate')&&!$('#dDueDate').value)$('#dDueDate').value=addDaysISO(date,LS.getItem('jkbat_default_due_days'));if(k==='DEVIS'&&$('#dValidUntil')&&!$('#dValidUntil').value)$('#dValidUntil').value=addDaysISO(date,LS.getItem('jkbat_default_quote_days'));scheduleDraft()}
function pickClient(i){if(i==='')return;let c=clients()[Number(i)];_editingDoc.clientId=c.id||'';$('#dClient').value=c.name||'';$('#dAddress').value=c.address||'';$('#dClientPhone').value=c.phone||'';$('#dClientEmail').value=c.email||'';if($('#dClientRef'))$('#dClientRef').value=c.ref||'PART';scheduleDraft()}
function markPaid(i){let a=docs(),d=a[i];if(!d)return;d.status='PAYÉ';d.amountPaid=calc(d).total;d.paidDate=todayISO();d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);logActivity('PAIEMENT','Facture payée',`${d.invoiceNo} · ${euro(calc(d).total)}`);closeModal();renderAll();toast('Facture marquée payée')}
function relanceText(d){return `Bonjour ${d.clientName||''}, nous vous rappelons que la facture ${d.invoiceNo||''} d’un montant de ${euro(calc(d).total)} présente un solde de ${euro(outstanding(d))}${d.dueDate?' avec une échéance au '+fmtDate(d.dueDate):''}. Merci de votre règlement. JKBat Services.`}
function openRelance(i){let d=docs()[i],t=relanceText(d),p=cleanPhone(d.clientPhone);openModal('Relance '+(d.invoiceNo||''),`<textarea class="field" id="relanceTxt" style="min-height:180px">${esc(t)}</textarea><div class="actions">${p?`<a class="btn primary" href="sms:${p}?body=${encodeURIComponent(t)}">SMS</a>`:''}${d.clientEmail?`<a class="btn" href="mailto:${encodeURIComponent(d.clientEmail)}?subject=${encodeURIComponent('Relance '+d.invoiceNo)}&body=${encodeURIComponent(t)}">E-mail</a>`:''}<button class="btn" onclick="copyText($('#relanceTxt').value);logActivity('RELANCE','Relance copiée','${esc(d.invoiceNo||'')}')">Copier</button></div>`)}
function showDocument(i){let d=docs()[i],late=isOverdue(d);openModal(d.invoiceNo||d.kind,`<div>${invoiceHtml(d)}</div>${d.internalNotes?`<div class="card"><b>Notes internes</b><div class="muted">${esc(d.internalNotes).replace(/\n/g,'<br>')}</div></div>`:''}<div class="actions"><button class="btn primary" onclick="openPrint(${i},'invoice')">📄 Facture / devis PDF</button><button class="btn primary" onclick="openPrint(${i},'report')">🛠 Rapport PDF</button><button class="btn" onclick="closeModal();openJobMode(${i})">🧰 Mode chantier</button><button class="btn" onclick="closeModal();openDocument(false,docs()[${i}])">Modifier</button>${d.kind==='DEVIS'?`<button class="btn ok" onclick="convertToInvoice(${i})">→ Facture</button>`:''}${d.kind==='FACTURE'&&d.status!=='PAYÉ'?`<button class="btn ok" onclick="markPaid(${i})">✓ Payée</button><button class="btn ${late?'danger':''}" onclick="openRelance(${i})">↗ Relancer</button>`:''}<button class="btn" onclick="duplicateDoc(${i})">Dupliquer</button><button class="btn danger" onclick="deleteDoc(${i})">Supprimer</button></div>`)}
function toggleWorkflow(i,key){let a=docs(),d=a[i];d.workflow=d.workflow||{};d.workflow[key]=!d.workflow[key];if(key==='before'&&d.workflow[key]&&!d.photos?.[0])toast('Ajoute la photo avant depuis Modifier');if(key==='after'&&d.workflow[key]&&!d.photos?.[1])toast('Ajoute la photo après depuis Modifier');a[i]=d;jset('jkbat_history',a);saveAuto();openJobMode(i)}
function openJobMode(i){let d=docs()[i],w=d.workflow||{},steps=[['arrival','Arrivée sur chantier'],['before','Photo avant'],['diagnosis','Diagnostic / constat'],['work','Travaux réalisés'],['after','Photo après'],['signature','Signature client']],done=steps.filter(x=>w[x[0]]||(x[0]==='signature'&&d.signature)).length,p=Math.round(done/steps.length*100);openModal('Mode chantier · '+(d.clientName||''),`<div class="card"><div class="row-between"><div><b>${esc(d.invoiceNo)}</b><div class="muted">${esc(d.clientAddress||'')}</div></div><b>${p}%</b></div><div class="progress"><i style="width:${p}%"></i></div></div><div class="workflow" style="margin-top:12px">${steps.map(([k,l])=>{let checked=w[k]||(k==='signature'&&d.signature);return `<label onclick="toggleWorkflow(${i},'${k}')"><input type="checkbox" ${checked?'checked':''} onclick="event.preventDefault()"> ${l}</label>`}).join('')}</div><div class="actions">${d.clientPhone?`<a class="btn primary" href="tel:${cleanPhone(d.clientPhone)}">Appeler</a>`:''}${d.clientAddress?`<a class="btn" href="${mapHref(d.clientAddress)}">Navigation</a>`:''}<button class="btn" onclick="closeModal();openDocument(false,docs()[${i}])">Ouvrir dossier</button></div>`)}
function duplicateDoc(i){let d=JSON.parse(JSON.stringify(docs()[i]));d.id=uid();d.invoiceNo=nextNo(d.kind);d.status='BROUILLON';d.date=todayISO();d.dueDate=d.kind==='FACTURE'?addDaysISO(d.date,LS.getItem('jkbat_default_due_days')):'';d.validUntil=d.kind==='DEVIS'?addDaysISO(d.date,LS.getItem('jkbat_default_quote_days')):'';d.amountPaid=0;d.paidDate='';d.signature='';d.signedAt='';d.workflow={arrival:false,before:false,diagnosis:false,work:false,after:false,signature:false};logActivity('DOCUMENT','Document dupliqué',d.invoiceNo);closeModal();openDocument(false,d)}
function convertToInvoice(i){let d=JSON.parse(JSON.stringify(docs()[i]));d.id=uid();d.kind='FACTURE';d.invoiceNo=nextNo('FACTURE');d.status='BROUILLON';d.date=todayISO();d.dueDate=addDaysISO(d.date,LS.getItem('jkbat_default_due_days'));d.validUntil='';d.amountPaid=0;d.paidDate='';logActivity('DOCUMENT','Devis converti en facture',`${docs()[i].invoiceNo} → ${d.invoiceNo}`);closeModal();openDocument(false,d)}
function openAppointment(id=null,clientIndex=null){let a=id?appointments().find(x=>x.id===id):{},c=clientIndex==null?null:clients()[clientIndex];a={...a,client:a.client||c?.name||'',address:a.address||c?.address||'',phone:a.phone||c?.phone||'',status:a.status||'À FAIRE'};openModal(id?'Modifier le rendez-vous':'Nouveau rendez-vous',`<div class="form"><div class="form two"><div><label class="label">Titre / client</label><input class="field" id="aTitle" value="${esc(a.title||a.client||'')}"></div><div><label class="label">Statut</label><select class="field" id="aStatus"><option ${a.status==='À FAIRE'?'selected':''}>À FAIRE</option><option ${a.status==='CONFIRMÉ'?'selected':''}>CONFIRMÉ</option><option ${a.status==='TERMINÉ'?'selected':''}>TERMINÉ</option><option ${a.status==='ANNULÉ'?'selected':''}>ANNULÉ</option></select></div></div><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="aDate" value="${esc(a.date||todayISO())}"></div><div><label class="label">Heure</label><input type="time" class="field" id="aTime" value="${esc(a.time||'09:00')}"></div></div><div><label class="label">Adresse</label><textarea class="field" id="aAddress">${esc(a.address||'')}</textarea></div><div><label class="label">Téléphone</label><input class="field" id="aPhone" value="${esc(a.phone||'')}"></div><div><label class="label">Référence document</label><input class="field" id="aDocRef" value="${esc(a.docRef||'')}"></div><div><label class="label">Notes</label><textarea class="field" id="aNotes">${esc(a.notes||'')}</textarea></div><button class="btn primary" onclick="saveAppointment('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteAppointment('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveAppointment(id){let o={id:id||uid(),title:$('#aTitle').value.trim(),client:$('#aTitle').value.trim(),status:$('#aStatus').value,date:$('#aDate').value,time:$('#aTime').value,address:$('#aAddress').value.trim(),phone:$('#aPhone').value.trim(),docRef:$('#aDocRef').value.trim(),notes:$('#aNotes').value.trim()};if(!o.title||!o.date)return toast('Titre et date requis');let a=appointments(),i=a.findIndex(x=>x.id===o.id);if(i>=0)a[i]=o;else a.push(o);jset('jkbat_appointments',a);logActivity('AGENDA',i>=0?'Rendez-vous modifié':'Rendez-vous créé',`${o.title} · ${fmtDate(o.date)} ${o.time}`);saveAuto();closeModal();renderAll();toast('Rendez-vous enregistré')}
function renderAgenda(){let a=appointments().slice().sort((x,y)=>(x.date+x.time).localeCompare(y.date+y.time));if($('#agendaCount'))$('#agendaCount').textContent=`${a.length} rendez-vous`;if($('#agendaList'))$('#agendaList').innerHTML=a.length?a.map(x=>`<div class="card ${x.status==='TERMINÉ'?'done':''}"><div class="card row" style="padding:0;border:0;box-shadow:none"><div class="avatar">${(x.time||'--').slice(0,2)}</div><div class="grow"><b>${esc(x.title||x.client)}</b><div class="muted">${fmtDate(x.date)} ${esc(x.time||'')} · ${esc(x.address||'')}</div><div class="chips"><span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span>${x.docRef?`<span class="chip">${esc(x.docRef)}</span>`:''}</div></div><button class="btn small" onclick="openAppointment('${esc(x.id)}')">Modifier</button></div><div class="actions">${x.phone?`<a class="btn small" href="tel:${cleanPhone(x.phone)}">Appeler</a><a class="btn small" href="sms:${cleanPhone(x.phone)}">SMS</a>`:''}${x.address?`<a class="btn small" href="${mapHref(x.address)}">Navigation</a>`:''}${x.status!=='TERMINÉ'?`<button class="btn small ok" onclick="setAppointmentDone('${esc(x.id)}')">Terminé</button>`:''}</div>${x.notes?`<div class="muted" style="margin-top:8px">${esc(x.notes)}</div>`:''}</div>`).join(''):'<div class="empty">Ton agenda est vide.</div>'}
function setAppointmentDone(id){let a=appointments(),i=a.findIndex(x=>x.id===id);if(i<0)return;a[i].status='TERMINÉ';jset('jkbat_appointments',a);logActivity('AGENDA','Intervention terminée',a[i].title||a[i].client);renderAll();toast('Rendez-vous terminé')}
function openCatalogItem(id=null){let a=id?catalog().find(x=>x.id===id):{};openModal(id?'Modifier la prestation':'Nouvelle prestation',`<div class="form"><div class="form two"><div><label class="label">Nom</label><input class="field" id="catName" value="${esc(a.name||'')}"></div><div><label class="label">Catégorie</label><input class="field" id="catCategory" value="${esc(a.category||'')}"></div></div><div><label class="label">Description</label><textarea class="field" id="catDesc">${esc(a.description||'')}</textarea></div><div class="form two"><div><label class="label">Unité</label><input class="field" id="catUnit" value="${esc(a.unit||'forfait')}"></div><div><label class="label">Prix unitaire HT</label><input type="number" step="0.01" class="field" id="catPrice" value="${esc(a.price||0)}"></div></div><button class="btn primary" onclick="saveCatalogItem('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteCatalogItem('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveCatalogItem(id){let x={id:id||uid(),name:$('#catName').value.trim(),category:$('#catCategory').value.trim(),description:$('#catDesc').value.trim(),unit:$('#catUnit').value.trim(),price:Number($('#catPrice').value)||0};if(!x.name)return toast('Nom requis');let a=catalog(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_catalog',a);logActivity('CATALOGUE',i>=0?'Prestation modifiée':'Prestation ajoutée',x.name);closeModal();renderAll();toast('Catalogue enregistré')}
async function deleteCatalogItem(id){if(!await askConfirm6164('Supprimer cette prestation ?'))return;let a=catalog().filter(x=>x.id!==id);jset('jkbat_catalog',a);logActivity('CATALOGUE','Prestation supprimée',id);closeModal();renderAll()}
function openExpense(id=null){let a=id?expenses().find(x=>x.id===id):{};let refs=docs().filter(d=>d.kind==='FACTURE').slice().reverse().map(d=>`<option ${a.docRef===d.invoiceNo?'selected':''}>${esc(d.invoiceNo)}</option>`).join('');openModal(id?'Modifier la dépense':'Nouvelle dépense',`<div class="form"><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="eDate" value="${esc(a.date||todayISO())}"></div><div><label class="label">Montant TTC</label><input type="number" step="0.01" class="field" id="eAmount" value="${esc(a.amount||0)}"></div></div><div class="form two"><div><label class="label">Catégorie</label><select class="field" id="eCat"><option>Matériaux</option><option>Carburant</option><option>Outillage</option><option>Sous-traitance</option><option>Frais</option><option>Autre</option></select></div><div><label class="label">Document lié</label><select class="field" id="eDoc"><option value="">— aucun —</option>${refs}</select></div></div><div><label class="label">Fournisseur / libellé</label><input class="field" id="eLabel" value="${esc(a.label||'')}"></div><div><label class="label">Note</label><textarea class="field" id="eNote">${esc(a.note||'')}</textarea></div><button class="btn primary" onclick="saveExpense('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteExpense('${esc(id)}')">Supprimer</button>`:''}</div>`);if(a.category&&$('#eCat'))$('#eCat').value=a.category}
function saveExpense(id){let x={id:id||uid(),date:$('#eDate').value,amount:Number($('#eAmount').value)||0,category:$('#eCat').value,docRef:$('#eDoc').value,label:$('#eLabel').value.trim(),note:$('#eNote').value.trim()};if(!x.amount)return toast('Montant requis');let a=expenses(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_expenses',a);logActivity('DÉPENSE',i>=0?'Dépense modifiée':'Dépense ajoutée',`${x.label||x.category} · ${euro(x.amount)}`);closeModal();renderAll();toast('Dépense enregistrée')}
async function deleteExpense(id){if(!await askConfirm6164('Supprimer cette dépense ?'))return;jset('jkbat_expenses',expenses().filter(x=>x.id!==id));logActivity('DÉPENSE','Dépense supprimée',id);closeModal();renderAll()}
function openInventoryItem(id=null){let a=id?inventory().find(x=>x.id===id):{};openModal(id?'Modifier le stock':'Nouvel article',`<div class="form"><div><label class="label">Article</label><input class="field" id="iName" value="${esc(a.name||'')}"></div><div class="form three"><div><label class="label">Quantité</label><input type="number" step="0.01" class="field" id="iQty" value="${esc(a.qty||0)}"></div><div><label class="label">Seuil mini</label><input type="number" step="0.01" class="field" id="iMin" value="${esc(a.minQty||0)}"></div><div><label class="label">Unité</label><input class="field" id="iUnit" value="${esc(a.unit||'u')}"></div></div><div><label class="label">Emplacement / note</label><input class="field" id="iNote" value="${esc(a.note||'')}"></div><button class="btn primary" onclick="saveInventoryItem('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteInventoryItem('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveInventoryItem(id){let x={id:id||uid(),name:$('#iName').value.trim(),qty:Number($('#iQty').value)||0,minQty:Number($('#iMin').value)||0,unit:$('#iUnit').value.trim(),note:$('#iNote').value.trim()};if(!x.name)return toast('Article requis');let a=inventory(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_inventory',a);logActivity('STOCK',i>=0?'Stock modifié':'Article ajouté',`${x.name} · ${x.qty} ${x.unit}`);closeModal();renderAll()}
async function deleteInventoryItem(id){if(!await askConfirm6164('Supprimer cet article ?'))return;jset('jkbat_inventory',inventory().filter(x=>x.id!==id));closeModal();renderAll()}
function adjustStock(id,delta){let a=inventory(),i=a.findIndex(x=>x.id===id);if(i<0)return;a[i].qty=(Number(a[i].qty)||0)+Number(delta);jset('jkbat_inventory',a);logActivity('STOCK','Mouvement de stock',`${a[i].name} ${delta>0?'+':''}${delta}`);renderAll()}
function openTask(id=null){let a=id?tasks().find(x=>x.id===id):{};openModal(id?'Modifier la tâche':'Nouvelle tâche',`<div class="form"><div><label class="label">Tâche / relance</label><input class="field" id="tTitle" value="${esc(a.title||'')}"></div><div class="form two"><div><label class="label">Échéance</label><input type="date" class="field" id="tDate" value="${esc(a.date||todayISO())}"></div><div><label class="label">Priorité</label><select class="field" id="tPriority"><option>NORMALE</option><option>HAUTE</option><option>BASSE</option></select></div></div><div><label class="label">Note</label><textarea class="field" id="tNote">${esc(a.note||'')}</textarea></div><button class="btn primary" onclick="saveTask('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteTask('${esc(id)}')">Supprimer</button>`:''}</div>`);if(a.priority&&$('#tPriority'))$('#tPriority').value=a.priority}
function saveTask(id){let x={id:id||uid(),title:$('#tTitle').value.trim(),date:$('#tDate').value,priority:$('#tPriority').value,note:$('#tNote').value.trim(),done:id?(tasks().find(y=>y.id===id)?.done||false):false};if(!x.title)return toast('Tâche requise');let a=tasks(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_tasks',a);logActivity('TÂCHE',i>=0?'Tâche modifiée':'Tâche créée',x.title);closeModal();renderAll()}
function toggleTask(id){let a=tasks(),i=a.findIndex(x=>x.id===id);if(i<0)return;a[i].done=!a[i].done;jset('jkbat_tasks',a);logActivity('TÂCHE',a[i].done?'Tâche terminée':'Tâche réouverte',a[i].title);renderAll()}
async function deleteTask(id){if(!await askConfirm6164('Supprimer cette tâche ?'))return;jset('jkbat_tasks',tasks().filter(x=>x.id!==id));closeModal();renderAll()}
function renderPilotage(){if(!$('#proStats'))return;let ds=docs(),ex=expenses(),yr=String(new Date().getFullYear()),inv=ds.filter(d=>d.kind==='FACTURE'&&String(d.date||'').startsWith(yr)),quotes=ds.filter(d=>d.kind==='DEVIS'&&String(d.date||'').startsWith(yr)),paid=inv.reduce((s,d)=>s+paidAmount(d),0),billed=inv.reduce((s,d)=>s+calc(d).total,0),vat=inv.reduce((s,d)=>s+calc(d).tax,0),cost=ex.filter(e=>String(e.date||'').startsWith(yr)).reduce((s,e)=>s+(Number(e.amount)||0),0),accepted=quotes.filter(d=>d.status==='ACCEPTÉ').length,decided=quotes.filter(d=>['ACCEPTÉ','REFUSÉ'].includes(d.status)).length,conv=decided?Math.round(accepted/decided*100):0;$('#proStats').innerHTML=`<div class="stat"><span>CA encaissé ${yr}</span><b>${euro(paid)}</b></div><div class="stat"><span>À encaisser</span><b>${euro(inv.reduce((s,d)=>s+outstanding(d),0))}</b></div><div class="stat"><span>Dépenses suivies</span><b>${euro(cost)}</b></div><div class="stat"><span>Résultat suivi</span><b>${euro(paid-cost)}</b></div><div class="stat"><span>TVA facturée</span><b>${euro(vat)}</b></div><div class="stat"><span>Conversion devis</span><b>${conv}%</b></div>`;let al=[...ds.filter(isOverdue).map(d=>({bad:true,title:`Facture en retard ${d.invoiceNo}`,sub:`${d.clientName} · ${euro(outstanding(d))}`,action:`openRelance(${docs().findIndex(x=>x.id===d.id)})`})),...ds.filter(quoteExpired).map(d=>({bad:true,title:`Devis expiré ${d.invoiceNo}`,sub:d.clientName,action:`showDocument(${docs().findIndex(x=>x.id===d.id)})`})),...tasks().filter(t=>!t.done&&t.date<todayISO()).map(t=>({bad:true,title:`Tâche en retard`,sub:t.title,action:`openTask('${t.id}')`}))];$('#proAlertCount').textContent=`${al.length} alerte(s)`;$('#proAlerts').innerHTML=al.length?al.slice(0,8).map(x=>`<div class="card compact alert-card ${x.bad?'bad':''}" onclick="${x.action}"><b>${esc(x.title)}</b><div class="muted">${esc(x.sub)}</div></div>`).join(''):'<div class="empty">Aucune alerte critique.</div>';$('#catalogList').innerHTML=catalog().length?catalog().map(x=>`<div class="card compact row"><div class="grow"><b>${esc(x.name)}</b><div class="muted">${esc(x.category)} · ${esc(x.unit||'')} ${Number(x.price)?'· '+euro(x.price):''}</div></div><button class="btn small" onclick="openCatalogItem('${esc(x.id)}')">Modifier</button></div>`).join(''):'<div class="empty">Catalogue vide.</div>';$('#expenseSummary').innerHTML=`<div class="card" style="margin-bottom:10px"><div class="row-between"><span>Dépenses ${yr}</span><b>${euro(cost)}</b></div><div class="row-between muted"><span>Facturé</span><span>${euro(billed)}</span></div></div>`;$('#expenseList').innerHTML=ex.length?ex.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,10).map(x=>`<div class="card compact row"><div class="badge-number">−</div><div class="grow"><b>${esc(x.label||x.category)}</b><div class="muted">${fmtDate(x.date)} · ${esc(x.category)} ${x.docRef?'· '+esc(x.docRef):''}</div></div><b>${euro(x.amount)}</b><button class="btn small" onclick="openExpense('${esc(x.id)}')">✎</button></div>`).join(''):'<div class="empty">Aucune dépense suivie.</div>';$('#inventoryList').innerHTML=inventory().length?inventory().map(x=>`<div class="card compact row"><div class="grow"><b class="${Number(x.qty)<=Number(x.minQty||0)?'stock-low':''}">${esc(x.name)}</b><div class="muted">${Number(x.qty)||0} ${esc(x.unit||'')} · seuil ${Number(x.minQty)||0}</div></div><button class="btn small" onclick="adjustStock('${esc(x.id)}',-1)">−1</button><button class="btn small" onclick="adjustStock('${esc(x.id)}',1)">+1</button><button class="btn small" onclick="openInventoryItem('${esc(x.id)}')">✎</button></div>`).join(''):'<div class="empty">Aucun article en stock.</div>';$('#taskList').innerHTML=tasks().length?tasks().slice().sort((a,b)=>(a.done-b.done)||String(a.date).localeCompare(String(b.date))).map(x=>`<div class="card compact row ${x.done?'done':''}"><button class="btn small ${x.done?'ok':''}" onclick="toggleTask('${esc(x.id)}')">${x.done?'✓':'○'}</button><div class="grow"><b>${esc(x.title)}</b><div class="muted">${fmtDate(x.date)} · ${esc(x.priority||'NORMALE')}</div></div><button class="btn small" onclick="openTask('${esc(x.id)}')">✎</button></div>`).join(''):'<div class="empty">Aucune tâche.</div>';$('#activityList').innerHTML=activity().length?activity().slice(0,12).map(x=>`<div class="card compact"><div class="row-between"><b>${esc(x.label)}</b><span class="tiny">${new Date(x.at).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</span></div><div class="muted">${esc(x.type)}${x.detail?' · '+esc(x.detail):''}</div></div>`).join(''):'<div class="empty">Le journal se remplira automatiquement.</div>'}
function csvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"'}
function showCSV(kind){let rows=[],name='';if(kind==='clients'){name='clients';rows=[['Nom','Type','Référence','Téléphone','Email','Adresse','Tags'],...clients().map(c=>[c.name,c.type,c.ref,c.phone,c.email,c.address,c.tags])]}else if(kind==='expenses'){name='depenses';rows=[['Date','Catégorie','Libellé','Montant','Document','Note'],...expenses().map(e=>[e.date,e.category,e.label,e.amount,e.docRef,e.note])]}else{name='documents';rows=[['Type','Numéro','Date','Client','Statut','HT','TVA','TTC','Encaissé','Reste','Échéance'],...docs().map(d=>{let x=calc(d);return[d.kind,d.invoiceNo,d.date,d.clientName,d.status,x.after,x.tax,x.total,paidAmount(d),outstanding(d),d.dueDate||d.validUntil]})]}let t=rows.map(r=>r.map(csvCell).join(';')).join('\n');openModal('Export CSV · '+name,`<p class="muted">Compatible tableur français (séparateur point-virgule). Copie puis enregistre en .csv.</p><textarea class="field" id="csvText" style="min-height:330px">${esc(t)}</textarea><button class="btn primary full" onclick="copyText($('#csvText').value)">Copier CSV</button>`)}
function showBusinessSummary(){let ds=docs().filter(d=>d.kind==='FACTURE'),ex=expenses(),x={ht:0,tax:0,ttc:0,paid:0,due:0};ds.forEach(d=>{let c=calc(d);x.ht+=c.after;x.tax+=c.tax;x.ttc+=c.total;x.paid+=paidAmount(d);x.due+=outstanding(d)});let cost=ex.reduce((s,e)=>s+(Number(e.amount)||0),0);openModal('Synthèse activité',`<div class="stack"><div class="card row-between"><span>Total HT facturé</span><b>${euro(x.ht)}</b></div><div class="card row-between"><span>TVA facturée</span><b>${euro(x.tax)}</b></div><div class="card row-between"><span>Total TTC facturé</span><b>${euro(x.ttc)}</b></div><div class="card row-between"><span>Encaissé</span><b class="money-positive">${euro(x.paid)}</b></div><div class="card row-between"><span>Reste à encaisser</span><b>${euro(x.due)}</b></div><div class="card row-between"><span>Dépenses suivies</span><b class="money-negative">${euro(cost)}</b></div><div class="card row-between"><span>Résultat suivi</span><b>${euro(x.paid-cost)}</b></div></div><p class="muted">Synthèse de pilotage interne basée uniquement sur les données enregistrées dans l’application. Elle ne remplace pas une comptabilité réglementaire.</p>`)}
function showGlobalSearch(){openModal('Recherche globale',`<div class="form"><input class="field" id="globalQ" placeholder="Client, téléphone, facture, adresse, rendez-vous…" oninput="renderGlobalSearch(this.value)"><div id="globalResults" class="cards"></div></div>`);setTimeout(()=>$('#globalQ')?.focus(),100)}
function renderGlobalSearch(q){let el=$('#globalResults');q=String(q||'').toLowerCase().trim();if(!q){el.innerHTML='<div class="empty">Tape au moins un mot.</div>';return}let r=[];clients().forEach((c,i)=>{if([c.name,c.phone,c.email,c.address,c.ref,c.tags].join(' ').toLowerCase().includes(q))r.push(`<div class="card compact" onclick="closeModal();showClient(${i})"><b>Client · ${esc(c.name)}</b><div class="muted">${esc(c.phone||c.address||'')}</div></div>`)});docs().forEach((d,i)=>{if([d.invoiceNo,d.clientName,d.intervention,d.clientRef].join(' ').toLowerCase().includes(q))r.push(`<div class="card compact" onclick="closeModal();showDocument(${i})"><b>${esc(d.kind)} · ${esc(d.invoiceNo)}</b><div class="muted">${esc(d.clientName)} · ${euro(calc(d).total)}</div></div>`)});appointments().forEach(a=>{if([a.title,a.address,a.phone,a.notes].join(' ').toLowerCase().includes(q))r.push(`<div class="card compact" onclick="closeModal();openAppointment('${esc(a.id)}')"><b>RDV · ${esc(a.title)}</b><div class="muted">${fmtDate(a.date)} ${esc(a.time||'')}</div></div>`)});el.innerHTML=r.slice(0,30).join('')||'<div class="empty">Aucun résultat.</div>'}
function renderSettings(){if(!$('#setCompany'))return;let c=company();$('#setCompany').value=c.name;$('#setSiret').value=c.siret;$('#setAddress').value=c.address;$('#setPhone').value=c.phone;$('#setEmail').value=c.email;$('#setVat').value=LS.getItem('jkbat_default_vat')||'20';$('#setTerms').value=c.terms;$('#setDueDays').value=LS.getItem('jkbat_default_due_days')||'30';$('#setQuoteDays').value=LS.getItem('jkbat_default_quote_days')||'30';renderSettingsMeta()}
function saveSettings(){LS.setItem('jkbat_company_name',$('#setCompany').value.trim());LS.setItem('jkbat_company_siret',$('#setSiret').value.trim());LS.setItem('jkbat_company_address',$('#setAddress').value.trim());LS.setItem('jkbat_company_phone',$('#setPhone').value.trim());LS.setItem('jkbat_company_email',$('#setEmail').value.trim());LS.setItem('jkbat_default_vat',$('#setVat').value||'20');LS.setItem('jkbat_terms',$('#setTerms').value.trim());LS.setItem('jkbat_default_due_days',$('#setDueDays').value||'30');LS.setItem('jkbat_default_quote_days',$('#setQuoteDays').value||'30');logActivity('RÉGLAGES','Paramètres entreprise modifiés','');saveAuto();renderAll();toast('Réglages enregistrés')}



/* --- JKBat Pro 6.3 FICHE DIRECTE: terrain, paiements, récurrence, QR, sécurité --- */
function mileage(){return jget('jkbat_mileage',[])}
function suppliers(){return jget('jkbat_suppliers',[])}
function recurring(){return jget('jkbat_recurring',[])}
function timerState(){return jget('jkbat_job_timer',null)}
function fnvPin(s){let h=2166136261;for(let i=0;i<String(s).length;i++){h^=String(s).charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
function migrateV4(){
 if(LS.getItem('jkbat_mileage')==null)jset('jkbat_mileage',[]);if(LS.getItem('jkbat_suppliers')==null)jset('jkbat_suppliers',[]);if(LS.getItem('jkbat_recurring')==null)jset('jkbat_recurring',[]);
 let ds=docs(),dc=false;ds=ds.map(d=>{if(!Array.isArray(d.payments)){d.payments=[];dc=true}if(d.jobTimeMin==null){d.jobTimeMin=0;dc=true}if(d.materialsCost==null){d.materialsCost=0;dc=true}if(d.parentId==null){d.parentId='';dc=true}if(d.nature==null){d.nature='';dc=true}return d});if(dc)jset('jkbat_history',ds);
 let ca=catalog(),cc=false;ca=ca.map(x=>{if(x.favorite==null){x.favorite=false;cc=true}if(x.cost==null){x.cost=0;cc=true}return x});if(cc)jset('jkbat_catalog',ca);
 runRecurring();
}
function paidAmount(d){if(Array.isArray(d.payments)&&d.payments.length)return d.payments.reduce((s,p)=>s+(Number(p.amount)||0),0);if(d.paidAmount!=null&&Number(d.paidAmount)>0)return Number(d.paidAmount)||0;return d.status==='PAYÉ'?Math.max(0,calc(d).total):0}
function outstanding(d){return d.kind==='FACTURE'?Math.max(0,calc(d).total-paidAmount(d)):0}
function statusClass(s){return s==='PAYÉ'||s==='ACCEPTÉ'||s==='TERMINÉ'?'ok':s==='REFUSÉ'||s==='ANNULÉ'||s==='EXPIRÉ'?'bad':s==='ENVOYÉ'||s==='PARTIEL'||s==='CONFIRMÉ'?'warn':''}
function fabAction(){if(currentScreen==='clients')openClient();else if(currentScreen==='agenda')openAppointment();else if(currentScreen==='terrain')openExpress();else if(currentScreen==='pilotage')showGlobalSearch();else openDocument(true)}
function renderAll(){renderLogo();renderDashboard();renderClients();renderDocs();renderAgenda();renderPilotage();renderTerrain();renderSettings();renderV4Extras()}
function renderV4Extras(){
 let q=$('#quickTools');if(q&&!q.querySelector('[data-v4-express]'))q.insertAdjacentHTML('afterbegin','<button data-v4-express="1" class="btn primary" onclick="openExpress()">⚡ Express</button>')
 let el=$('#supplierList');if(el){let a=suppliers();el.innerHTML=a.length?a.slice().sort((x,y)=>String(x.name).localeCompare(String(y.name))).map(x=>`<div class="card compact row"><div class="grow"><b>${esc(x.name)}</b><div class="muted">${esc(x.category||'Fournisseur')} ${x.phone?'· '+esc(x.phone):''}</div></div><button class="btn small" onclick="openSupplier('${esc(x.id)}')">Modifier</button></div>`).join(''):'<div class="empty">Aucun fournisseur enregistré.</div>'}
}
function renderTerrain(){if(!$('#terrainToday'))return;let t=todayISO(),a=appointments().filter(x=>x.date===t).sort((x,y)=>String(x.time||'').localeCompare(String(y.time||'')));$('#terrainTodayCount').textContent=`${a.length} intervention(s)`;$('#terrainToday').innerHTML=a.length?a.map(x=>`<div class="card"><div class="row-between"><div><b>${esc(x.time||'--:--')} · ${esc(x.title||x.client||'Intervention')}</b><div class="muted">${esc(x.client||'')} · ${esc(x.address||'')}</div></div><span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span></div><div class="actions">${x.phone?`<a class="btn small" href="tel:${cleanPhone(x.phone)}">Appeler</a>`:''}${x.address?`<a class="btn small" href="${mapHref(x.address)}">GPS</a>`:''}<button class="btn small primary" onclick="openExpress('${esc(x.id)}')">Intervenir</button></div></div>`).join(''):'<div class="empty">Aucune intervention aujourd’hui.</div>';
 renderTimer();let r=recurring();$('#recurringList').innerHTML=r.length?r.map(x=>{let c=clients().find(c=>c.id===x.clientId);return `<div class="card compact row"><div class="grow"><b>${esc(x.title)}</b><div class="muted">${esc(c?.name||x.clientName||'')} · ${esc(x.frequency)} · prochain ${fmtDate(x.nextDate)}</div></div><button class="btn small" onclick="openRecurring('${esc(x.id)}')">Modifier</button></div>`}).join(''):'<div class="empty">Aucune intervention récurrente.</div>';
 let m=mileage(),yr=String(new Date().getFullYear()),km=m.filter(x=>String(x.date||'').startsWith(yr)).reduce((s,x)=>s+(Number(x.km)||0),0);$('#mileageSummary').innerHTML=`<div class="card" style="margin-bottom:10px"><div class="row-between"><span>Kilométrage ${yr}</span><b>${km.toFixed(1)} km</b></div></div>`;$('#mileageList').innerHTML=m.length?m.slice().sort((x,y)=>String(y.date).localeCompare(String(x.date))).slice(0,8).map(x=>`<div class="card compact row"><div class="avatar">↗</div><div class="grow"><b>${esc(x.reason||'Déplacement')}</b><div class="muted">${fmtDate(x.date)} · ${Number(x.km)||0} km · ${esc(x.from||'')} → ${esc(x.to||'')}</div></div><button class="btn small" onclick="openMileage('${esc(x.id)}')">Modifier</button></div>`).join(''):'<div class="empty">Aucun trajet enregistré.</div>'}
function expressClientOptions(selected=''){return clients().map(c=>`<option value="${esc(c.id)}" ${c.id===selected?'selected':''}>${esc(c.name)}</option>`).join('')}
function expressCatalogOptions(){return catalog().map(x=>`<option value="${esc(x.id)}">${esc(x.name)}${Number(x.price)?' · '+euro(x.price):''}</option>`).join('')}
function openExpress(appointmentId=''){let ap=appointmentId?appointments().find(x=>x.id===appointmentId):null,cid=ap?.clientId||clients().find(c=>c.name===ap?.client)?.id||'',c=clients().find(x=>x.id===cid);openModal('⚡ Intervention express',`<div class="form"><div class="form two"><div><label class="label">Client</label><select class="field" id="xClient" onchange="expressPickClient()"><option value="">— choisir —</option>${expressClientOptions(cid)}</select></div><div><label class="label">Date</label><input type="date" class="field" id="xDate" value="${esc(ap?.date||todayISO())}"></div></div><div><label class="label">Adresse</label><textarea class="field" id="xAddress">${esc(ap?.address||c?.address||'')}</textarea></div><div class="form two"><div><label class="label">Prestation rapide</label><select class="field" id="xCatalog" onchange="expressPickCatalog()"><option value="">— catalogue —</option>${expressCatalogOptions()}</select></div><div><label class="label">Montant HT</label><input type="number" step="0.01" class="field" id="xPrice" value="0"></div></div>${voiceField('xConstat','Constat initial','')}${voiceField('xTravaux','Travaux réalisés',ap?.notes||'')}${voiceField('xResult','Résultat','')}${voiceField('xReco','Préconisation','')}<div class="form two"><div><label class="label">Photo AVANT</label><label class="btn file-label full">🖼 Galerie<input id="xBefore" type="file" accept="image/*"></label></div><div><label class="label">Photo APRÈS</label><label class="btn file-label full">🖼 Galerie<input id="xAfter" type="file" accept="image/*"></label></div></div><div class="form three"><div><label class="label">Document</label><select class="field" id="xKind"><option>FACTURE</option><option>DEVIS</option></select></div><div><label class="label">TVA %</label><input type="number" step="0.1" class="field" id="xVat" value="${esc(LS.getItem('jkbat_default_vat')||20)}"></div><div><label class="label">Durée (min)</label><input type="number" class="field" id="xMinutes" value="0"></div></div><label style="display:flex;gap:9px;align-items:center"><input type="checkbox" id="xCloseAppt" ${ap?'checked':''}> <span class="muted">Marquer le rendez-vous terminé</span></label><button class="btn primary full" onclick="saveExpress('${esc(appointmentId)}')">Créer le dossier chantier</button></div>`)}
function voiceField(id,label,value=''){return `<div><div class="row-between"><label class="label">${esc(label)}</label><button class="btn small" type="button" onclick="dictateTo('${id}')">🎙 Dicter</button></div><textarea class="field" id="${id}">${esc(value)}</textarea></div>`}
function dictateTo(id){let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return toast('Dictée non disponible sur ce WebView');let r=new SR();r.lang='fr-FR';r.interimResults=false;r.maxAlternatives=1;r.onresult=e=>{let el=document.getElementById(id);if(el)el.value=(el.value?el.value+' ':'')+e.results[0][0].transcript};r.onerror=()=>toast('Dictée interrompue');r.start();toast('Parle…')}
function expressPickClient(){let c=clients().find(x=>x.id===$('#xClient').value);if(c)$('#xAddress').value=c.address||''}
function expressPickCatalog(){let x=catalog().find(x=>x.id===$('#xCatalog').value);if(!x)return;$('#xPrice').value=Number(x.price)||0;let t=$('#xTravaux');if(t&&!t.value)t.value=x.description||x.name}
async function saveExpress(appointmentId=''){let c=clients().find(x=>x.id===$('#xClient').value);if(!c)return toast('Choisis un client');let kind=$('#xKind').value,cat=catalog().find(x=>x.id===$('#xCatalog').value),price=Number($('#xPrice').value)||0,photos=[];try{let f1=$('#xBefore').files[0],f2=$('#xAfter').files[0];if(f1)photos.push(await resizeImage(f1,1100,.76));if(f2){if(!f1)photos.push('');photos.push(await resizeImage(f2,1100,.76))}}catch(e){toast('Une photo n’a pas pu être lue')}let d={id:uid(),kind,status:'BROUILLON',date:$('#xDate').value||todayISO(),invoiceNo:nextNo(kind),clientId:c.id,clientRef:c.ref||'PART',clientName:c.name,clientAddress:$('#xAddress').value.trim()||c.address||'',clientPhone:c.phone||'',clientEmail:c.email||'',inspection:$('#xConstat').value.trim(),intervention:$('#xTravaux').value.trim(),control:'',result:$('#xResult').value.trim(),recommendation:$('#xReco').value.trim(),duration:(Number($('#xMinutes').value)||0)?`${Number($('#xMinutes').value)} min`:'',jobTimeMin:Number($('#xMinutes').value)||0,paymentMode:'',paidDate:'',discount:0,vat:Number($('#xVat').value)||0,rows:[{label:cat?.name||'Intervention',description:$('#xTravaux').value.trim()||cat?.description||'Intervention',qty:1,price}],photos,signature:'',signedAt:'',payments:[],materialsCost:0,parentId:'',nature:'',appointmentId,workflow:{arrival:true,before:!!photos[0],diagnosis:!!$('#xConstat').value.trim(),work:!!$('#xTravaux').value.trim(),after:!!photos[1],signature:false},savedAt:new Date().toISOString()};let h=docs();h.push(d);jset('jkbat_history',h);commitSeq(d);LS.removeItem('jkbat_invoice_pwa');if(appointmentId&&$('#xCloseAppt').checked){let a=appointments(),i=a.findIndex(x=>x.id===appointmentId);if(i>=0){a[i].status='TERMINÉ';a[i].docRef=d.invoiceNo;a[i].docId=d.id;jset('jkbat_appointments',a)}}logActivity('CHANTIER','Intervention express créée',`${d.invoiceNo} · ${c.name}`);saveAuto();closeModal();renderAll();toast('Dossier chantier créé');setTimeout(()=>showDocument(docs().findIndex(x=>x.id===d.id)),80)}
function openPayment(i){let d=docs()[i];if(!d||d.kind!=='FACTURE')return;let remain=outstanding(d);openModal('Encaisser un paiement',`<div class="form"><div class="ultimate-banner"><b>${esc(d.invoiceNo)}</b><p>${esc(d.clientName)} · reste à payer <b class="gold">${euro(remain)}</b></p></div><div class="form two"><div><label class="label">Montant</label><input class="field" type="number" step="0.01" id="pAmount" value="${remain.toFixed(2)}"></div><div><label class="label">Date</label><input class="field" type="date" id="pDate" value="${todayISO()}"></div></div><div><label class="label">Mode</label><select class="field" id="pMode"><option>Virement</option><option>Chèque</option><option>Espèces</option><option>Carte</option><option>Autre</option></select></div><div><label class="label">Note</label><input class="field" id="pNote" placeholder="Référence, acompte, solde…"></div><button class="btn primary" onclick="savePayment(${i})">Valider l’encaissement</button></div>`)}
function savePayment(i){let a=docs(),d=a[i],amt=Number($('#pAmount').value)||0;if(!d||amt<=0)return toast('Montant invalide');d.payments=Array.isArray(d.payments)?d.payments:[];d.payments.push({id:uid(),date:$('#pDate').value||todayISO(),amount:amt,mode:$('#pMode').value,note:$('#pNote').value.trim()});let rem=Math.max(0,calc(d).total-d.payments.reduce((s,p)=>s+(Number(p.amount)||0),0));d.status=rem<.01?'PAYÉ':'PARTIEL';if(d.status==='PAYÉ')d.paidDate=$('#pDate').value||todayISO();a[i]=d;jset('jkbat_history',a);logActivity('PAIEMENT','Paiement encaissé',`${d.invoiceNo} · ${euro(amt)}`);closeModal();renderAll();toast(rem<.01?'Facture soldée':'Paiement enregistré')}
async function deletePayment(di,pid){if(!await askConfirm6164('Supprimer ce paiement ?'))return;let a=docs(),d=a[di];d.payments=(d.payments||[]).filter(p=>p.id!==pid);let p=paidAmount(d);d.status=p<=0?'ENVOYÉ':outstanding(d)<.01?'PAYÉ':'PARTIEL';a[di]=d;jset('jkbat_history',a);renderAll();closeModal();showDocument(di)}
function paymentHistoryHtml(d,i){let ps=d.payments||[];return `<div class="section-title"><h3>Paiements</h3><span>${euro(paidAmount(d))} / ${euro(calc(d).total)}</span></div>${ps.length?`<div class="card">${ps.map(p=>`<div class="payment-row"><div><b>${euro(p.amount)}</b><div class="tiny">${fmtDate(p.date)} · ${esc(p.mode||'')} ${p.note?'· '+esc(p.note):''}</div></div><button class="btn small danger" onclick="deletePayment(${i},'${esc(p.id)}')">×</button></div>`).join('')}</div>`:'<div class="empty">Aucun paiement détaillé.</div>'}`}
function qrSvg(text,size=116){if(!window.JKQRCode)return'';try{let qr=new JKQRCode(-1,(window.JKQRErrorCorrectLevel||{}).M||0);qr.addData(String(text));qr.make();let n=qr.getModuleCount(),pad=4,cell=4,w=(n+pad*2)*cell,path='';for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(qr.isDark(r,c))path+=`M${(c+pad)*cell} ${(r+pad)*cell}h${cell}v${cell}h-${cell}z`;return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${w}" width="${size}" height="${size}" role="img"><rect width="100%" height="100%" fill="#fff"/><path d="${path}" fill="#111"/></svg>`}catch(e){return''}}
function docQrData(d){return `JKBAT|${d.invoiceNo||''}|${d.clientName||''}|${calc(d).total.toFixed(2)}|${d.date||''}`}
function shareText(title,text){if(navigator.share){navigator.share({title,text}).catch(()=>{})}else{copyText(text);toast('Texte copié pour partage')}}
function shareDoc(i){let d=docs()[i],c=company(),txt=`${d.kind==='DEVIS'?'Devis':'Facture'} ${d.invoiceNo} - ${d.clientName}\nMontant : ${euro(calc(d).total)}${d.kind==='FACTURE'?`\nReste à payer : ${euro(outstanding(d))}`:''}\n${c.name} - ${c.phone} - ${c.email}`;shareText(d.invoiceNo,txt)}
function showDocument(i){let d=docs()[i];if(!d)return;let kids=docs().filter(x=>x.parentId===d.id),par=d.parentId?docs().find(x=>x.id===d.parentId):null,qr=qrSvg(docQrData(d));openModal(d.invoiceNo||d.kind,`<div>${invoiceHtml(d)}</div><div class="card" style="margin-top:12px"><div class="row-between"><div><b>Dossier numérique</b><div class="muted">${d.nature?esc(d.nature)+' · ':''}${d.jobTimeMin?esc(d.jobTimeMin)+' min · ':''}${d.signature?'signé':''}</div></div>${qr?`<div class="qrbox">${qr}</div>`:''}</div>${par?`<div class="tiny" style="margin-top:8px">Document parent : ${esc(par.invoiceNo)}</div>`:''}${kids.length?`<div class="tiny">Liés : ${kids.map(x=>esc(x.invoiceNo)).join(', ')}</div>`:''}</div>${d.kind==='FACTURE'?paymentHistoryHtml(d,i):''}<div class="actions"><button class="btn primary" onclick="openPrint(${i},'invoice')">📄 Facture / devis PDF</button><button class="btn primary" onclick="openPrint(${i},'report')">🛠 Rapport intervention PDF</button>${d.kind==='FACTURE'?`<button class="btn ok" onclick="openPayment(${i})">€ Encaisser</button>`:''}<button class="btn" onclick="shareDoc(${i})">↗ Partager</button><button class="btn" onclick="closeModal();openDocument(false,docs()[${i}])">Modifier</button>${d.kind==='DEVIS'?`<button class="btn ok" onclick="convertToInvoice(${i})">→ Facture</button><button class="btn" onclick="createDeposit(${i})">Acompte</button>`:''}${d.kind==='FACTURE'?`<button class="btn" onclick="createCredit(${i})">Avoir</button>`:''}<button class="btn" onclick="chooseTimerDoc('${esc(d.id)}')">⏱ Chrono</button><button class="btn" onclick="duplicateDoc(${i})">Dupliquer</button><button class="btn danger" onclick="deleteDoc(${i})">Supprimer</button></div>`)}
function customNo(prefix){let n=new Date(),y=n.getFullYear(),m=String(n.getMonth()+1).padStart(2,'0'),k=`jkbat_seq_${prefix}_${y}_${m}`,v=parseInt(LS.getItem(k)||0,10)+1;LS.setItem(k,String(v));return `${prefix}-${m}${y}${String(v).padStart(2,'0')}`}
function createDeposit(i){let src=docs()[i];if(!src)return;openModal('Facture d’acompte',`<div class="form"><div class="ultimate-banner"><b>${esc(src.invoiceNo)}</b><p>${esc(src.clientName)} · ${euro(calc(src).total)}</p></div><div class="form two"><div><label class="label">Acompte € HT</label><input class="field" id="depAmount" type="number" step="0.01" value="${(calc(src).after*.3).toFixed(2)}"></div><div><label class="label">TVA %</label><input class="field" id="depVat" type="number" step="0.1" value="${Number(src.vat)||0}"></div></div><button class="btn primary" onclick="saveDeposit(${i})">Créer l’acompte</button></div>`)}
function saveDeposit(i){let a=docs(),src=a[i],amt=Number($('#depAmount').value)||0;if(!src||amt<=0)return toast('Montant invalide');let d={...JSON.parse(JSON.stringify(src)),id:uid(),kind:'FACTURE',nature:'FACTURE D’ACOMPTE',parentId:src.id,invoiceNo:customNo('ACP'),date:todayISO(),status:'BROUILLON',rows:[{label:'Acompte',description:`Acompte sur ${src.invoiceNo}`,qty:1,price:amt}],discount:0,vat:Number($('#depVat').value)||0,payments:[],photos:[],signature:'',signedAt:'',savedAt:new Date().toISOString()};a.push(d);jset('jkbat_history',a);logActivity('DOCUMENT','Facture d’acompte créée',`${d.invoiceNo} → ${src.invoiceNo}`);closeModal();renderAll();toast('Acompte créé')}
function createCredit(i){let src=docs()[i];if(!src)return;openModal('Créer un avoir',`<div class="form"><div class="ultimate-banner"><b>${esc(src.invoiceNo)}</b><p>${esc(src.clientName)} · facture ${euro(calc(src).total)}</p></div><div class="form two"><div><label class="label">Montant HT à créditer</label><input class="field" id="crAmount" type="number" step="0.01" value="${Math.abs(calc(src).after).toFixed(2)}"></div><div><label class="label">TVA %</label><input class="field" id="crVat" type="number" step="0.1" value="${Number(src.vat)||0}"></div></div><div><label class="label">Motif</label><input class="field" id="crReason" value="Avoir sur ${esc(src.invoiceNo)}"></div><button class="btn primary" onclick="saveCredit(${i})">Créer l’avoir</button></div>`)}
function saveCredit(i){let a=docs(),src=a[i],amt=Math.abs(Number($('#crAmount').value)||0);if(!src||amt<=0)return toast('Montant invalide');let reason=$('#crReason').value.trim();let d={...JSON.parse(JSON.stringify(src)),id:uid(),kind:'FACTURE',nature:'AVOIR',parentId:src.id,invoiceNo:customNo('AVR'),date:todayISO(),status:'BROUILLON',rows:[{label:'Avoir',description:reason||`Avoir sur ${src.invoiceNo}`,qty:1,price:-amt}],discount:0,vat:Number($('#crVat').value)||0,payments:[],photos:[],signature:'',signedAt:'',savedAt:new Date().toISOString()};a.push(d);jset('jkbat_history',a);logActivity('DOCUMENT','Avoir créé',`${d.invoiceNo} → ${src.invoiceNo}`);closeModal();renderAll();toast('Avoir créé')}
function chooseTimerDoc(preselect=''){let a=docs().filter(d=>['FACTURE','DEVIS'].includes(d.kind)).slice().reverse().slice(0,30);openModal('Chrono chantier',`<div class="form"><div><label class="label">Dossier</label><select class="field" id="tmDoc">${a.map(d=>`<option value="${esc(d.id)}" ${d.id===preselect?'selected':''}>${esc(d.invoiceNo)} · ${esc(d.clientName)}</option>`).join('')}</select></div><div class="actions"><button class="btn primary" onclick="startJobTimer($('#tmDoc').value)">▶ Démarrer</button>${timerState()?'<button class="btn danger" onclick="stopJobTimer()">■ Arrêter le chrono actuel</button>':''}</div></div>`)}
function startJobTimer(docId){if(!docId)return toast('Choisis un dossier');jset('jkbat_job_timer',{docId,start:Date.now()});closeModal();renderTerrain();toast('Chrono démarré')}
function stopJobTimer(){let t=timerState();if(!t)return;let mins=Math.max(1,Math.round((Date.now()-Number(t.start))/60000)),a=docs(),i=a.findIndex(d=>d.id===t.docId);if(i>=0){a[i].jobTimeMin=(Number(a[i].jobTimeMin)||0)+mins;jset('jkbat_history',a);logActivity('CHANTIER','Temps chantier ajouté',`${a[i].invoiceNo} · ${mins} min`)}LS.removeItem('jkbat_job_timer');closeModal();renderAll();toast(`${mins} min ajoutées au chantier`)}
function renderTimer(){let el=$('#terrainTimer');if(!el)return;let t=timerState();if(!t){el.innerHTML='<div class="empty">Aucun chrono en cours.</div>';return}let d=docs().find(x=>x.id===t.docId),sec=Math.max(0,Math.floor((Date.now()-Number(t.start))/1000)),h=String(Math.floor(sec/3600)).padStart(2,'0'),m=String(Math.floor(sec%3600/60)).padStart(2,'0'),ss=String(sec%60).padStart(2,'0');el.innerHTML=`<div class="card"><div class="row-between"><div><b>${esc(d?.invoiceNo||'Chantier')}</b><div class="muted">${esc(d?.clientName||'')}</div></div><div class="timer-live">${h}:${m}:${ss}</div></div><div class="actions"><button class="btn danger" onclick="stopJobTimer()">■ Arrêter</button></div></div>`;clearTimeout(window._jkTimerRender);window._jkTimerRender=setTimeout(()=>{if(currentScreen==='terrain')renderTimer()},1000)}
function nextRecurringDate(date,freq){let d=new Date((date||todayISO())+'T12:00:00');if(freq==='HEBDOMADAIRE')d.setDate(d.getDate()+7);else if(freq==='BIMENSUELLE')d.setDate(d.getDate()+14);else if(freq==='TRIMESTRIELLE')d.setMonth(d.getMonth()+3);else if(freq==='ANNUELLE')d.setFullYear(d.getFullYear()+1);else d.setMonth(d.getMonth()+1);return d.toISOString().slice(0,10)}
function runRecurring(){let r=recurring(),changed=false,a=appointments(),today=todayISO();for(let x of r){if(x.active===false)continue;let guard=0;while(x.nextDate&&x.nextDate<=today&&guard++<12){if(!a.some(ap=>ap.recurrenceId===x.id&&ap.date===x.nextDate)){let c=clients().find(c=>c.id===x.clientId);a.push({id:uid(),clientId:x.clientId,client:c?.name||x.clientName||'',phone:c?.phone||'',address:c?.address||'',title:x.title,date:x.nextDate,time:x.time||'08:00',notes:x.notes||'',status:'À FAIRE',recurrenceId:x.id})}x.nextDate=nextRecurringDate(x.nextDate,x.frequency);changed=true}}if(changed){jset('jkbat_recurring',r);jset('jkbat_appointments',a)}}
function openRecurring(id=''){let x=id?recurring().find(y=>y.id===id):{};openModal(id?'Modifier la récurrence':'Nouvelle récurrence',`<div class="form"><div><label class="label">Client</label><select class="field" id="rClient"><option value="">— choisir —</option>${expressClientOptions(x.clientId||'')}</select></div><div><label class="label">Intervention</label><input class="field" id="rTitle" value="${esc(x.title||'Entretien / intervention récurrente')}"></div><div class="form three"><div><label class="label">Prochaine date</label><input type="date" class="field" id="rDate" value="${esc(x.nextDate||todayISO())}"></div><div><label class="label">Heure</label><input type="time" class="field" id="rTime" value="${esc(x.time||'08:00')}"></div><div><label class="label">Fréquence</label><select class="field" id="rFreq"><option>MENSUELLE</option><option>HEBDOMADAIRE</option><option>BIMENSUELLE</option><option>TRIMESTRIELLE</option><option>ANNUELLE</option></select></div></div><div><label class="label">Notes</label><textarea class="field" id="rNotes">${esc(x.notes||'')}</textarea></div><label style="display:flex;gap:8px"><input type="checkbox" id="rActive" ${x.active===false?'':'checked'}> Active</label><button class="btn primary" onclick="saveRecurring('${esc(x.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteRecurring('${esc(id)}')">Supprimer</button>`:''}</div>`);if(x.frequency)$('#rFreq').value=x.frequency}
function saveRecurring(id){let c=clients().find(x=>x.id===$('#rClient').value);if(!c)return toast('Client requis');let x={id:id||uid(),clientId:c.id,clientName:c.name,title:$('#rTitle').value.trim(),nextDate:$('#rDate').value, time:$('#rTime').value,frequency:$('#rFreq').value,notes:$('#rNotes').value.trim(),active:$('#rActive').checked};if(!x.title||!x.nextDate)return toast('Titre et date requis');let a=recurring(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_recurring',a);runRecurring();logActivity('RÉCURRENCE',i>=0?'Récurrence modifiée':'Récurrence créée',`${x.title} · ${c.name}`);closeModal();renderAll()}
async function deleteRecurring(id){if(!await askConfirm6164('Supprimer cette récurrence ?'))return;jset('jkbat_recurring',recurring().filter(x=>x.id!==id));closeModal();renderAll()}
function openMileage(id=''){let x=id?mileage().find(y=>y.id===id):{};openModal(id?'Modifier le trajet':'Nouveau trajet',`<div class="form"><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="mDate" value="${esc(x.date||todayISO())}"></div><div><label class="label">Kilomètres</label><input type="number" step="0.1" class="field" id="mKm" value="${esc(x.km||0)}"></div></div><div class="form two"><div><label class="label">Départ</label><input class="field" id="mFrom" value="${esc(x.from||company().address)}"></div><div><label class="label">Arrivée</label><input class="field" id="mTo" value="${esc(x.to||'')}"></div></div><div><label class="label">Motif</label><input class="field" id="mReason" value="${esc(x.reason||'Chantier client')}"></div><button class="btn primary" onclick="saveMileage('${esc(x.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteMileage('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveMileage(id){let x={id:id||uid(),date:$('#mDate').value,km:Number($('#mKm').value)||0,from:$('#mFrom').value.trim(),to:$('#mTo').value.trim(),reason:$('#mReason').value.trim()};if(x.km<=0)return toast('Kilométrage requis');let a=mileage(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_mileage',a);logActivity('TRAJET','Kilométrage enregistré',`${x.km} km · ${x.reason}`);closeModal();renderAll()}
function deleteMileage(id){jset('jkbat_mileage',mileage().filter(x=>x.id!==id));closeModal();renderAll()}
function openSupplier(id=''){let x=id?suppliers().find(y=>y.id===id):{};openModal(id?'Modifier le fournisseur':'Nouveau fournisseur',`<div class="form"><div><label class="label">Nom / société</label><input class="field" id="sName" value="${esc(x.name||'')}"></div><div class="form two"><div><label class="label">Catégorie</label><input class="field" id="sCat" value="${esc(x.category||'Matériaux')}"></div><div><label class="label">Téléphone</label><input class="field" id="sPhone" inputmode="tel" value="${esc(x.phone||'')}"></div></div><div><label class="label">E-mail</label><input class="field" id="sEmail" inputmode="email" value="${esc(x.email||'')}"></div><div><label class="label">Adresse</label><textarea class="field" id="sAddress">${esc(x.address||'')}</textarea></div><div><label class="label">Notes</label><textarea class="field" id="sNotes">${esc(x.notes||'')}</textarea></div><button class="btn primary" onclick="saveSupplier('${esc(x.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteSupplier('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveSupplier(id){let x={id:id||uid(),name:$('#sName').value.trim(),category:$('#sCat').value.trim(),phone:$('#sPhone').value.trim(),email:$('#sEmail').value.trim(),address:$('#sAddress').value.trim(),notes:$('#sNotes').value.trim()};if(!x.name)return toast('Nom requis');let a=suppliers(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_suppliers',a);logActivity('FOURNISSEUR',i>=0?'Fournisseur modifié':'Fournisseur créé',x.name);closeModal();renderAll()}
async function deleteSupplier(id){if(!await askConfirm6164('Supprimer ce fournisseur ?'))return;jset('jkbat_suppliers',suppliers().filter(x=>x.id!==id));closeModal();renderAll()}
function showPaymentsOverview(){let inv=docs().filter(d=>d.kind==='FACTURE').slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));openModal('Paiements & encaissements',`<div class="kpi-strip"><div class="mini-kpi"><span>Encaissé</span><b>${euro(inv.reduce((s,d)=>s+paidAmount(d),0))}</b></div><div class="mini-kpi"><span>À encaisser</span><b>${euro(inv.reduce((s,d)=>s+outstanding(d),0))}</b></div><div class="mini-kpi"><span>Factures</span><b>${inv.length}</b></div></div><div class="cards" style="margin-top:12px">${inv.map(d=>{let i=docs().findIndex(x=>x.id===d.id);return `<div class="card compact row"><div class="grow"><b>${esc(d.invoiceNo)} · ${esc(d.clientName)}</b><div class="muted">encaissé ${euro(paidAmount(d))} · reste ${euro(outstanding(d))}</div></div><button class="btn small ${outstanding(d)>0?'primary':''}" onclick="${outstanding(d)>0?`openPayment(${i})`:`showDocument(${i})`}">${outstanding(d)>0?'Encaisser':'Voir'}</button></div>`}).join('')}</div>`)}
function showRecurringOverview(){openModal('Contrats / récurrences',`<div class="actions"><button class="btn primary" onclick="openRecurring()">＋ Nouvelle récurrence</button></div><div class="cards" style="margin-top:10px">${recurring().map(x=>`<div class="card compact"><b>${esc(x.title)}</b><div class="muted">${esc(x.clientName||'')} · ${esc(x.frequency)} · ${fmtDate(x.nextDate)}</div></div>`).join('')||'<div class="empty">Aucune récurrence.</div>'}</div>`)}
function showAccountingExport(){let lines=[['TYPE','DATE','NUMERO','CLIENT/FOURNISSEUR','HT','TVA','TTC','ENCAISSE','RESTE','MODE/NOTE']];docs().filter(d=>d.kind==='FACTURE').forEach(d=>{let x=calc(d);lines.push(['FACTURE',d.date,d.invoiceNo,d.clientName,x.after,x.tax,x.total,paidAmount(d),outstanding(d),d.nature||''])});expenses().forEach(e=>lines.push(['DEPENSE',e.date,'',e.label||e.category,'','','',-(Number(e.amount)||0),'',e.note||'']));mileage().forEach(m=>lines.push(['KM',m.date,'',m.reason,'','','',m.km,'',`${m.from} > ${m.to}`]));let csv=lines.map(r=>r.map(csvCell).join(';')).join('\n');showExportText('Export comptable CSV',csv,'Copie ce CSV dans ton logiciel comptable ou un tableur.')}
function showExportText(title,text,help=''){openModal(title,`<p class="muted">${esc(help)}</p><textarea class="field" style="min-height:300px" id="v4Export">${esc(text)}</textarea><button class="btn primary full" onclick="copyText($('#v4Export').value)">Copier</button>`)}
function showAnnualArchives(){let years={};docs().forEach(d=>{let y=String(d.date||'').slice(0,4)||'Sans date';(years[y]||(years[y]=[])).push(d)});let html=Object.keys(years).sort().reverse().map(y=>{let a=years[y],inv=a.filter(d=>d.kind==='FACTURE'),total=inv.reduce((s,d)=>s+calc(d).total,0),paid=inv.reduce((s,d)=>s+paidAmount(d),0);return `<div class="card"><div class="row-between"><b>${esc(y)}</b><span class="chip badge-gold">${a.length} docs</span></div><div class="muted">Facturé ${euro(total)} · encaissé ${euro(paid)}</div></div>`}).join('');openModal('Archives annuelles',html||'<div class="empty">Aucune archive.</div>')}
function setLocalPin(){let p=$('#setPin')?.value||'';if(!/^\d{4,8}$/.test(p))return toast('PIN de 4 à 8 chiffres');LS.setItem('jkbat_pin_hash',fnvPin(p));$('#setPin').value='';toast('PIN activé')}
async function clearLocalPin(){if(!await askConfirm6164('Retirer le verrouillage PIN ?'))return;LS.removeItem('jkbat_pin_hash');$('#lockScreen')?.classList.remove('open');toast('PIN retiré')}
function lockNow(){if(!LS.getItem('jkbat_pin_hash'))return toast('Définis d’abord un PIN');$('#unlockPin').value='';$('#lockScreen').classList.add('open');setTimeout(()=>$('#unlockPin')?.focus(),100)}
function checkLock(){if(LS.getItem('jkbat_pin_hash')){$('#unlockPin').value='';$('#lockScreen').classList.add('open')}}
function unlockApp(){let p=$('#unlockPin').value;if(fnvPin(p)===LS.getItem('jkbat_pin_hash')){$('#lockScreen').classList.remove('open');$('#unlockPin').value='';toast('Déverrouillé')}else{toast('PIN incorrect');$('#unlockPin').value='';$('#unlockPin').focus()}}


/* --- JKBat Pro 6.3 FICHE DIRECTE UX --- */
function signatureGreeting(){let h=new Date().getHours();return h<12?'Bonjour.':h<18?'Bon après-midi.':'Bonsoir.'}
function signatureDate(){try{return new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'numeric',month:'long'}).format(new Date()).replace(/^./,c=>c.toUpperCase())}catch{return 'Aujourd’hui'}}
function updateSignatureChrome(){let g=$('#heroGreeting'),d=$('#heroDate');if(g)g.textContent=signatureGreeting();if(d)d.textContent=signatureDate();}
function haptic(ms=8){try{if(navigator.vibrate)navigator.vibrate(ms)}catch{}}
function fabAction(){haptic();openModal('Créer',`<div class="create-grid"><button class="create-tile primary-create" onclick="closeModal();openExpress()"><span>⚡</span><b>Intervention</b><small>Mode terrain</small></button><button class="create-tile" onclick="closeModal();openDocument(true)"><span>＋</span><b>Devis</b><small>Nouveau devis</small></button><button class="create-tile" onclick="closeModal();openDocument(true,{kind:'FACTURE'})"><span>€</span><b>Facture</b><small>Facturer</small></button><button class="create-tile" onclick="closeModal();openClient()"><span>◎</span><b>Client</b><small>Nouveau contact</small></button><button class="create-tile" onclick="closeModal();openAppointment()"><span>◫</span><b>Rendez-vous</b><small>Planifier</small></button><button class="create-tile" onclick="closeModal();openExpense()"><span>−</span><b>Dépense</b><small>Enregistrer</small></button></div>`)}
function go(id){haptic(5);currentScreen=id;$$('.screen').forEach(x=>x.classList.toggle('active',x.id===id));$$('.nav button').forEach(x=>x.classList.toggle('active',x.dataset.go===id));renderAll();updateSignatureChrome();window.scrollTo({top:0,behavior:'smooth'})}
function renderAll(){renderLogo();renderDashboard();renderClients();renderDocs();renderAgenda();renderPilotage();renderTerrain();renderSettings();renderV4Extras();updateSignatureChrome()}
function dismissSplash(){setTimeout(()=>$('#splash')?.classList.add('hide'),520)}



/* --- JKBat Pro 6.3 FICHE DIRECTE : command center, focus engine, weekly planner --- */
let _maxWeekOffset=0,_maxSelectedDate='';
function maxStartOfWeek(offset=0){let n=new Date(),day=(n.getDay()+6)%7;n.setHours(12,0,0,0);n.setDate(n.getDate()-day+offset*7);return n}
function isoLocal(d){let y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),da=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${da}`}
function smartFocus(){let ds=docs(),aps=appointments(),ts=tasks(),today=todayISO();let overdue=ds.filter(isOverdue).sort((a,b)=>String(a.dueDate||a.date).localeCompare(String(b.dueDate||b.date)))[0];if(overdue){let i=ds.findIndex(x=>x.id===overdue.id);return{ico:'€',title:`${euro(outstanding(overdue))} à encaisser`,sub:`${overdue.clientName} · ${overdue.invoiceNo} est en retard.`,label:'Relancer',act:`openRelance(${i})`,tone:'bad'}}let ap=aps.filter(x=>x.date===today&&x.status!=='TERMINÉ').sort((a,b)=>String(a.time||'').localeCompare(String(b.time||'')))[0];if(ap)return{ico:'⚡',title:ap.title||ap.client||'Intervention du jour',sub:`${ap.time||''} · ${ap.client||''}${ap.address?' · '+ap.address:''}`,label:'Ouvrir',act:`openExpress('${esc(ap.id)}')`,tone:'gold'};let task=ts.filter(t=>!t.done&&t.date<=today).sort((a,b)=>String(a.date).localeCompare(String(b.date)))[0];if(task)return{ico:'✓',title:task.title,sub:`Tâche ${task.date<today?'en retard':'prévue aujourd’hui'} · ${task.priority||'NORMALE'}`,label:'Traiter',act:`openTask('${esc(task.id)}')`,tone:'warn'};let quote=ds.filter(d=>d.kind==='DEVIS'&&!['ACCEPTÉ','REFUSÉ'].includes(d.status)&&d.validUntil).sort((a,b)=>String(a.validUntil).localeCompare(String(b.validUntil)))[0];if(quote){let i=ds.findIndex(x=>x.id===quote.id);return{ico:'▤',title:`Devis ${quote.invoiceNo}`,sub:`${quote.clientName} · valable jusqu’au ${fmtDate(quote.validUntil)}`,label:'Voir',act:`showDocument(${i})`,tone:'gold'}}return{ico:'◆',title:'Journée sous contrôle',sub:'Aucune urgence détectée. Tu peux préparer le prochain chantier.',label:'Planning',act:`go('agenda')`,tone:'ok'}}
function renderMaxFocus(){let el=$('#maxFocus');if(!el)return;let f=smartFocus();el.innerHTML=`<div class="max-focus"><div class="focus-kicker">Priorité intelligente</div><div class="focus-main"><div class="focus-symbol">${f.ico}</div><div class="grow"><b>${esc(f.title)}</b><p>${esc(f.sub)}</p></div><button class="btn small ${f.tone==='bad'?'danger':f.tone==='ok'?'ok':'primary'} focus-action" onclick="${f.act}">${esc(f.label)}</button></div></div>`}
function renderMaxPulse(){let el=$('#maxPulse');if(!el)return;let today=todayISO(),aps=appointments().filter(a=>a.date===today),done=aps.filter(a=>a.status==='TERMINÉ').length,pct=aps.length?Math.round(done/aps.length*100):0,inv=docs().filter(d=>d.kind==='FACTURE'),out=inv.reduce((s,d)=>s+outstanding(d),0),paid=inv.reduce((s,d)=>s+paidAmount(d),0);el.innerHTML=`<div class="pulse-card"><div class="pulse-row"><div><b>Rythme du jour</b><small>${done}/${aps.length} intervention(s) terminée(s)</small></div><div class="progress-ring" style="--p:${pct}"><span>${pct}%</span></div></div></div><div class="pulse-card"><div class="cash-stack"><small>Trésorerie suivie</small><b>${euro(paid)}</b><small>${euro(out)} restant à encaisser</small></div></div>`}
function renderMissionConsole(){let el=$('#missionConsole');if(!el)return;let today=todayISO(),a=appointments().filter(x=>x.date===today),done=a.filter(x=>x.status==='TERMINÉ').length,t=timerState(),openDocs=docs().filter(d=>d.kind==='FACTURE'&&outstanding(d)>0).length;let p=a.length?Math.max(1,Math.round(done/a.length*6)):0;el.innerHTML=`<div class="mission-head"><div><b>Mission Control</b><div class="tiny">Client → photos → travaux → signature → document → paiement</div></div><span class="chip badge-gold">MAX</span></div><div class="mission-steps">${Array.from({length:6},(_,i)=>`<i class="mission-step ${i<p?'on':''}"></i>`).join('')}</div><div class="mission-metrics"><div class="mission-metric"><b>${a.length}</b><small>aujourd’hui</small></div><div class="mission-metric"><b>${t?'ON':'—'}</b><small>chrono</small></div><div class="mission-metric"><b>${openDocs}</b><small>à encaisser</small></div></div>`}
function weekDays(){let start=maxStartOfWeek(_maxWeekOffset);return Array.from({length:7},(_,i)=>{let d=new Date(start);d.setDate(start.getDate()+i);return d})}
function selectWeekDate(date){_maxSelectedDate=date;renderAgenda()}
function shiftWeek(n){_maxWeekOffset+=n;_maxSelectedDate='';renderAgenda()}
function jumpToday(){_maxWeekOffset=0;_maxSelectedDate=todayISO();renderAgenda()}
function renderAgenda(){if(!$('#weekStrip'))return;let days=weekDays(),today=todayISO();if(!_maxSelectedDate||!days.some(d=>isoLocal(d)===_maxSelectedDate))_maxSelectedDate=days.some(d=>isoLocal(d)===today)?today:isoLocal(days[0]);let opts={weekday:'short'},all=appointments(),monthA=days[0].toLocaleDateString('fr-FR',{day:'numeric',month:'short'}),monthB=days[6].toLocaleDateString('fr-FR',{day:'numeric',month:'short',year:'numeric'});$('#weekLabel').textContent=`${monthA} — ${monthB}`;$('#agendaCount').textContent=`${all.length} rendez-vous`;$('#weekStrip').innerHTML=days.map(d=>{let iso=isoLocal(d),n=all.filter(a=>a.date===iso).length;return `<button class="week-day ${iso===today?'today':''} ${iso===_maxSelectedDate?'selected':''} ${n?'has':''}" onclick="selectWeekDate('${iso}')"><span class="wd">${d.toLocaleDateString('fr-FR',opts).replace('.','')}</span><span class="dn">${d.getDate()}</span><i class="dot"></i></button>`}).join('');let arr=all.filter(a=>a.date===_maxSelectedDate).sort((a,b)=>String(a.time||'').localeCompare(String(b.time||''))),d=new Date(_maxSelectedDate+'T12:00:00');$('#daySummary').innerHTML=`<div class="day-summary-card"><div><b>${d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'}).replace(/^./,c=>c.toUpperCase())}</b><span>${arr.length?`${arr.length} rendez-vous planifié(s)`:'Journée disponible'}</span></div><span class="chip ${arr.length?'badge-gold':'ok'}">${arr.length?arr.length+' RDV':'LIBRE'}</span></div>`;$('#agendaList').innerHTML=arr.length?arr.map(x=>`<div class="card row"><div class="agenda-time">${esc(x.time||'--:--')}</div><div class="grow"><b>${esc(x.title||x.client||'Rendez-vous')}</b><div class="muted">${esc(x.client||'')} ${x.address?'· '+esc(x.address):''}</div><div class="chips"><span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span></div></div><button class="btn small" onclick="openAppointment('${esc(x.id)}')">›</button></div>`).join(''):'<div class="empty">Aucun chantier ce jour. <span class="tap" onclick="openAppointment()">Ajouter un rendez-vous</span></div>'}
function commandSearch(q){q=String(q||'').trim().toLowerCase();let r=[];if(!q)return r;clients().forEach((c,i)=>{if([c.name,c.phone,c.email,c.address,c.ref,c.tags].join(' ').toLowerCase().includes(q))r.push({t:'Client',name:c.name||'Sans nom',sub:c.phone||c.address||'',act:`closeModal();showClient(${i})`})});docs().forEach((d,i)=>{if([d.invoiceNo,d.clientName,d.intervention,d.status].join(' ').toLowerCase().includes(q))r.push({t:d.kind,name:d.invoiceNo||'',sub:`${d.clientName||''} · ${euro(calc(d).total)}`,act:`closeModal();showDocument(${i})`})});appointments().forEach(a=>{if([a.title,a.client,a.address,a.phone].join(' ').toLowerCase().includes(q))r.push({t:'RDV',name:a.title||a.client||'',sub:`${fmtDate(a.date)} ${a.time||''}`,act:`closeModal();openAppointment('${esc(a.id)}')`})});return r.slice(0,16)}
function renderCommandResults(q){let el=$('#commandResults');if(!el)return;let r=commandSearch(q);el.innerHTML=q?(r.length?r.map(x=>`<button class="command-result" onclick="${x.act}"><b>${esc(x.t)} · ${esc(x.name)}</b><small>${esc(x.sub)}</small></button>`).join(''):'<div class="empty">Aucun résultat.</div>'):'<div class="tiny">Tape un nom, un numéro, une adresse ou un document.</div>'}
function openCommandCenter(){haptic();openModal('⌘ Commande universelle',`<input class="field" id="commandInput" placeholder="Client, facture, adresse…" oninput="renderCommandResults(this.value)"><div class="command-grid"><button class="command-action primary" onclick="closeModal();openExpress()"><b>⚡ Intervention</b><small>Créer un dossier terrain</small></button><button class="command-action" onclick="closeModal();openDocument(true)"><b>＋ Devis</b><small>Nouveau document</small></button><button class="command-action" onclick="closeModal();openDocument(true,{kind:'FACTURE'})"><b>€ Facture</b><small>Facturer maintenant</small></button><button class="command-action" onclick="closeModal();showPaymentsOverview()"><b>✓ Encaisser</b><small>Soldes et paiements</small></button><button class="command-action" onclick="closeModal();openClient()"><b>◎ Client</b><small>Ajouter un contact</small></button><button class="command-action" onclick="closeModal();go('agenda')"><b>◫ Planning</b><small>Voir la semaine</small></button></div><div class="command-results" id="commandResults"></div>`);setTimeout(()=>$('#commandInput')?.focus(),80)}
const _renderDashboardV6=renderDashboard;renderDashboard=function(){_renderDashboardV6();renderMaxFocus();renderMaxPulse()}
const _renderTerrainV6=renderTerrain;renderTerrain=function(){_renderTerrainV6();renderMissionConsole()}
const _showGlobalSearchV6=showGlobalSearch;showGlobalSearch=function(){openCommandCenter()}


/* --- JKBat Pro 6.3 FICHE DIRECTE : moteur métiers --- */
const JKBAT_TRADES=[
 {id:'PLOMBERIE',label:'Plomberie',color:'#326b8c',desc:'Canalisations, sanitaires, débouchage',icon:'drop'},
 {id:'ÉLECTRICITÉ',label:'Électricité',color:'#c69a2d',desc:'Pannes, prises, tableaux, luminaires',icon:'bolt'},
 {id:'PEINTURE',label:'Peinture',color:'#a95f4f',desc:'Préparation, murs, plafonds, finitions',icon:'roller'},
 {id:'SERRURERIE',label:'Serrurerie',color:'#66717d',desc:'Serrures, clés, ouvertures, sécurité',icon:'key'},
 {id:'RÉNOVATION',label:'Rénovation',color:'#6c7e63',desc:'Second œuvre et remise en état',icon:'home'},
 {id:'DÉPANNAGE DIVERS',label:'Dépannage',color:'#776b82',desc:'Diagnostic et intervention multi-service',icon:'tools'}
];
const JKBAT_TRADE_NONE={id:'',label:'Non catégorisé',color:'#8b8b8b',desc:'À classer',icon:'circle'};
let _clientTrade='ALL',_docTrade='ALL',_agendaTrade='ALL',_catalogTrade='ALL',_terrainTrade='ALL',_expressTrade='';
function tradeNorm(v){return String(v||'').trim().toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/’/g,"'")}
function tradeById(v){let n=tradeNorm(v);return JKBAT_TRADES.find(t=>tradeNorm(t.id)===n||tradeNorm(t.label)===n)||JKBAT_TRADE_NONE}
function tradeFromCategory(v){let n=tradeNorm(v);if(!n)return JKBAT_TRADE_NONE;if(n.includes('PLOMB'))return tradeById('PLOMBERIE');if(n.includes('ELECT'))return tradeById('ÉLECTRICITÉ');if(n.includes('PEINT'))return tradeById('PEINTURE');if(n.includes('SERR'))return tradeById('SERRURERIE');if(n.includes('RENOV'))return tradeById('RÉNOVATION');if(n.includes('DEPANN'))return tradeById('DÉPANNAGE DIVERS');return JKBAT_TRADE_NONE}
function tradeOfDoc(d){return tradeFromCategory(d?.jobType||'')}
function tradeOfAppointment(a){return tradeFromCategory(a?.jobType||'')}
function tradeOfCatalog(x){return tradeFromCategory(x?.category||'')}
function tradeIconSvg(name){let p='';if(name==='drop')p='<path d="M12 2.7S6.4 9 6.4 13.1a5.6 5.6 0 0 0 11.2 0C17.6 9 12 2.7 12 2.7Z"/><path d="M9.2 13.3c.3 1.6 1.3 2.5 2.8 2.8"/>';else if(name==='bolt')p='<path d="M13.4 2.5 5.7 13h5.1l-.5 8.5 8-11.3h-5.1l.2-7.7Z"/>';else if(name==='roller')p='<path d="M4 5h12v5H4z"/><path d="M16 7.5h2.3v4.3H12v2.4"/><path d="M12 14v7"/><path d="M10.2 21h3.6"/>';else if(name==='key')p='<circle cx="8.2" cy="11.5" r="3.4"/><path d="m11.4 11.5 8.1 0M16.4 11.5v2.2M18.4 11.5v1.5"/>';else if(name==='home')p='<path d="m3.5 11 8.5-7 8.5 7"/><path d="M5.5 9.5V20h13V9.5"/><path d="M9.3 20v-5.5h5.4V20"/>';else if(name==='tools')p='<path d="m4.3 4.2 5.2 5.2M14.5 14.4l5.2 5.3"/><path d="M7.4 3.6a4 4 0 0 0 4.7 5.2l7.4 7.4a2.1 2.1 0 1 1-3 3l-7.4-7.4a4 4 0 0 0-5.2-4.7l2.7 2.7 2.3-2.3-1.5-3.9Z"/>';else p='<circle cx="12" cy="12" r="5"/>';
 return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`}
function tradeBadge(v){let t=tradeById(v);return `<span class="trade-badge" style="--trade:${t.color}"><span class="trade-mini">${tradeIconSvg(t.icon)}</span>${esc(t.label)}</span>`}
function tradeIcon(v,cls='trade-icon'){let t=tradeById(v);return `<span class="${cls}" style="--trade:${t.color}">${tradeIconSvg(t.icon)}</span>`}
function tradeSelectOptions(selected=''){let t=tradeById(selected),val=t.id;return `<option value="" ${!val?'selected':''}>Non catégorisé</option>`+JKBAT_TRADES.map(x=>`<option value="${esc(x.id)}" ${x.id===val?'selected':''}>${esc(x.label)}</option>`).join('')}
function tradeFilterHtml(active,fn,includeAll=true){let out=includeAll?`<button class="trade-filter-btn ${active==='ALL'?'active':''}" style="--trade:var(--accent)" onclick="${fn}('ALL')"><span>◆</span>Tous</button>`:'';out+=JKBAT_TRADES.map(t=>`<button class="trade-filter-btn ${active===t.id?'active':''}" style="--trade:${t.color}" onclick="${fn}('${t.id}')"><span class="trade-mini">${tradeIconSvg(t.icon)}</span>${esc(t.label)}</button>`).join('');out+=`<button class="trade-filter-btn ${active===''?'active':''}" style="--trade:${JKBAT_TRADE_NONE.color}" onclick="${fn}('')"><span class="trade-mini">${tradeIconSvg('circle')}</span>Non classé</button>`;return out}
function matchesTrade(obj,filter,type='doc'){if(filter==='ALL')return true;let t=type==='appointment'?tradeOfAppointment(obj):type==='catalog'?tradeOfCatalog(obj):tradeOfDoc(obj);return t.id===filter}
function clientTrades(c){let set=new Set();docs().filter(d=>(c.id&&d.clientId===c.id)||(!c.id&&String(d.clientName||'').toLowerCase()===String(c.name||'').toLowerCase())).forEach(d=>{let t=tradeOfDoc(d);if(t.id)set.add(t.id)});appointments().filter(a=>(c.id&&a.clientId===c.id)||String(a.client||'').toLowerCase()===String(c.name||'').toLowerCase()).forEach(a=>{let t=tradeOfAppointment(a);if(t.id)set.add(t.id)});return [...set]}
function clientMatchesTrade(c,filter){if(filter==='ALL')return true;let ts=clientTrades(c);return filter===''?ts.length===0:ts.includes(filter)}
function migrateV61(){if(LS.getItem('jkbat_v61_migrated'))return;let ds=docs(),dc=false;ds=ds.map(d=>{if(d.jobType==null){d.jobType='';dc=true}return d});if(dc)jset('jkbat_history',ds);let ap=appointments(),ac=false;ap=ap.map(a=>{if(a.jobType==null){a.jobType='';ac=true}return a});if(ac)jset('jkbat_appointments',ap);LS.setItem('jkbat_v61_migrated','1')}
function setClientTrade(v){_clientTrade=v;renderClients()} function setDocTrade(v){_docTrade=v;renderDocs()} function setAgendaTrade(v){_agendaTrade=v;renderAgenda()} function setCatalogTrade(v){_catalogTrade=v;renderPilotage()} function setTerrainTrade(v){_terrainTrade=v;renderTerrain()}
function renderTradeFilters(){if($('#clientTradeFilter'))$('#clientTradeFilter').innerHTML=tradeFilterHtml(_clientTrade,'setClientTrade');if($('#docTradeFilter'))$('#docTradeFilter').innerHTML=tradeFilterHtml(_docTrade,'setDocTrade');if($('#agendaTradeFilter'))$('#agendaTradeFilter').innerHTML=tradeFilterHtml(_agendaTrade,'setAgendaTrade');if($('#catalogTradeFilter'))$('#catalogTradeFilter').innerHTML=tradeFilterHtml(_catalogTrade,'setCatalogTrade')}
function renderTradeDashboard(){let el=$('#tradeDashboard');if(!el)return;let year=String(new Date().getFullYear()),ds=docs().filter(d=>d.kind==='FACTURE'&&String(d.date||'').startsWith(year));el.innerHTML=`<div class="trade-dashboard"><div class="trade-dashboard-head"><div><span class="section-kicker">Activités</span><b>JKBat par métier</b></div><span>${year}</span></div><div class="trade-grid">${JKBAT_TRADES.map(t=>{let dd=ds.filter(d=>tradeOfDoc(d).id===t.id),ca=dd.reduce((s,d)=>s+calc(d).total,0),ap=appointments().filter(a=>tradeOfAppointment(a).id===t.id&&a.date>=todayISO()).length;return `<button class="trade-kpi" style="--trade:${t.color}" onclick="openTradeHub('${t.id}')">${tradeIcon(t.id)}<b>${esc(t.label)}</b><strong>${euro(ca)}</strong><small>${dd.length} facture(s) · ${ap} à venir</small></button>`}).join('')}</div></div>`}
function openTradeHub(id){let t=tradeById(id),ds=docs().filter(d=>tradeOfDoc(d).id===t.id),inv=ds.filter(d=>d.kind==='FACTURE'),ap=appointments().filter(a=>tradeOfAppointment(a).id===t.id),cl=clients().filter(c=>clientTrades(c).includes(t.id)),billed=inv.reduce((s,d)=>s+calc(d).total,0),paid=inv.reduce((s,d)=>s+paidAmount(d),0);openModal(t.label,`<div class="card trade-card" style="--trade:${t.color}"><div class="row" style="align-items:center">${tradeIcon(t.id)}<div class="grow"><b>${esc(t.label)}</b><div class="muted">${esc(t.desc)}</div></div></div><div class="client-kpis"><div><span class="tiny">Facturé</span><b>${euro(billed)}</b></div><div><span class="tiny">Encaissé</span><b>${euro(paid)}</b></div><div><span class="tiny">Clients</span><b>${cl.length}</b></div></div></div><div class="actions"><button class="btn primary" onclick="closeModal();startExpressTrade('${t.id}')">Nouvelle intervention</button><button class="btn" onclick="closeModal();_docTrade='${t.id}';go('documents')">Documents</button><button class="btn" onclick="closeModal();_agendaTrade='${t.id}';go('agenda')">Planning</button></div><div class="section-title"><h3>À venir</h3><span>${ap.filter(a=>a.date>=todayISO()).length}</span></div><div class="cards">${ap.filter(a=>a.date>=todayISO()).sort((a,b)=>String(a.date+a.time).localeCompare(String(b.date+b.time))).slice(0,5).map(a=>`<div class="card compact trade-card" style="--trade:${t.color}"><b>${fmtDate(a.date)} ${esc(a.time||'')} · ${esc(a.title||a.client||'Intervention')}</b><div class="muted">${esc(a.address||'')}</div></div>`).join('')||'<div class="empty">Aucune intervention planifiée.</div>'}</div>`)}
function renderClients(){let q=($('#clientSearch')?.value||'').toLowerCase().trim(),arr=clients().map((c,i)=>({...c,_i:i})).filter(c=>(!q||[c.name,c.address,c.phone,c.ref,c.tags].join(' ').toLowerCase().includes(q))&&clientMatchesTrade(c,_clientTrade));if($('#clientCount'))$('#clientCount').textContent=`${arr.length} client(s)`;if($('#clientList'))$('#clientList').innerHTML=arr.length?arr.map(c=>{let ts=clientTrades(c);return `<div class="card row" onclick="showClient(${c._i})"><div class="avatar">${esc((c.name||'?').trim().slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(c.name||'Sans nom')}</b><div class="muted">${esc(c.address||'Adresse non renseignée')}</div><div class="trade-client-meta">${ts.length?ts.slice(0,4).map(tradeBadge).join(''):tradeBadge('')}</div></div><span class="tap">›</span></div>`}).join(''):'<div class="empty">Aucun client pour ce filtre.</div>';if($('#clientTradeFilter'))$('#clientTradeFilter').innerHTML=tradeFilterHtml(_clientTrade,'setClientTrade')}
function showClient(i){let c=clients()[i],p=cleanPhone(c.phone),ds=docs().filter(d=>(c.id&&d.clientId===c.id)||String(d.clientName||'').toLowerCase()===String(c.name||'').toLowerCase()),inv=ds.filter(d=>d.kind==='FACTURE'),billed=inv.reduce((s,d)=>s+calc(d).total,0),paid=inv.reduce((s,d)=>s+paidAmount(d),0),ts=clientTrades(c);openModal(c.name||'Client',`<div class="card"><div class="row"><div class="avatar">${esc((c.name||'?').slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(c.name||'')}</b><div class="muted">${esc(c.address||'Adresse non renseignée').replace(/\n/g,'<br>')}</div><div class="trade-client-meta">${ts.length?ts.map(tradeBadge).join(''):tradeBadge('')}</div></div></div><div class="client-kpis"><div><span class="tiny">Facturé</span><b>${euro(billed)}</b></div><div><span class="tiny">Encaissé</span><b>${euro(paid)}</b></div><div><span class="tiny">Reste</span><b>${euro(Math.max(0,billed-paid))}</b></div></div><div class="actions">${p?`<a class="btn primary" href="tel:${p}">Appeler</a><a class="btn" href="sms:${p}">SMS</a>`:''}${c.email?`<a class="btn" href="mailto:${encodeURIComponent(c.email)}">E-mail</a>`:''}${c.address?`<a class="btn" href="${mapHref(c.address)}">Navigation</a>`:''}</div></div><div class="actions"><button class="btn primary" onclick="closeModal();openClientTradeAction(${i})">＋ Intervention</button><button class="btn" onclick="closeModal();openDocument(true,null,${i})">Créer un devis</button><button class="btn" onclick="closeModal();openAppointment(null,${i})">Créer un RDV</button><button class="btn ghost" onclick="closeModal();openClient(${i})">Modifier</button></div><div class="section-title"><h3>Historique métier</h3><span>${ds.length} document(s)</span></div><div class="cards">${ds.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,8).map(d=>{let di=docs().findIndex(x=>x.id===d.id);return `<div class="card compact trade-card" style="--trade:${tradeOfDoc(d).color}" onclick="showDocument(${di})"><div class="row"><div class="grow"><b>${esc(d.invoiceNo||d.kind)}</b><div class="muted">${fmtDate(d.date)} · ${euro(calc(d).total)}</div></div>${tradeBadge(d.jobType)}</div></div>`}).join('')||'<div class="empty">Aucun document.</div>'}</div>`)}
function openClientTradeAction(i){openTradePicker('Choisir le métier',id=>{closeModal();setTimeout(()=>startExpressTrade(id,'',clients()[i]?.id||''),80)})}
function docCard(d,i){let c=calc(d),late=isOverdue(d),left=outstanding(d),t=tradeOfDoc(d);return `<div class="card row trade-card ${late?'overdue':''}" style="--trade:${t.color}" onclick="showDocument(${i})"><div class="trade-icon" style="--trade:${t.color}">${tradeIconSvg(t.icon)}</div><div class="grow"><b>${esc(d.invoiceNo||d.kind)} · ${esc(d.clientName||'Client')}</b><div class="muted">${fmtDate(d.date)} · ${esc(d.intervention||d.jobType||'Sans objet')}</div><div class="trade-doc-meta">${tradeBadge(d.jobType)}<span class="chip ${late?'bad':statusClass(d.status)}">${late?'EN RETARD':esc(d.status||'BROUILLON')}</span><span class="chip">${euro(c.total)}</span>${left>0&&d.kind==='FACTURE'?`<span class="chip warn">reste ${euro(left)}</span>`:''}</div></div><span class="tap">›</span></div>`}
function renderDocs(){let q=($('#docSearch')?.value||'').toLowerCase().trim(),f=$('#docFilter')?.value||'',a=docs().map((d,i)=>({...d,_i:i})).filter(d=>(!f||d.kind===f)&&matchesTrade(d,_docTrade,'doc')&&(!q||[d.invoiceNo,d.clientName,d.intervention,d.status,d.clientRef,d.jobType].join(' ').toLowerCase().includes(q))).sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date)));if($('#docCount'))$('#docCount').textContent=`${a.length} document(s)`;if($('#docList'))$('#docList').innerHTML=a.length?a.map(d=>docCard(d,d._i)).join(''):'<div class="empty">Aucun document pour ce métier.</div>';let draft=jget('jkbat_invoice_pwa',null);if($('#draftBanner'))$('#draftBanner').innerHTML=draft&&draft.invoiceNo?`<div class="card" style="margin-bottom:10px"><div class="grow"><b>Brouillon automatique</b><div class="muted">${esc(draft.invoiceNo)} · ${esc(draft.clientName||'sans client')}</div></div><div class="actions"><button class="btn small" onclick="openDocument(false,jget('jkbat_invoice_pwa',{}))">Reprendre</button></div></div>`:'';if($('#docTradeFilter'))$('#docTradeFilter').innerHTML=tradeFilterHtml(_docTrade,'setDocTrade')}
function refreshCatalogForEditingTrade(){let sel=$('#dCatalogSelect');if(!sel)return;let tr=tradeById($('#dJobType')?.value||'').id,items=catalog().map((x,i)=>({...x,_i:i})).filter(x=>!tr||tradeOfCatalog(x).id===tr);sel.innerHTML='<option value="">＋ Ajouter depuis le catalogue…</option>'+items.map(x=>`<option value="${x._i}">${esc(x.category)} · ${esc(x.name)}${Number(x.price)?' · '+euro(x.price):''}</option>`).join('')}
const _addCatalogToRows61=addCatalogToRows;addCatalogToRows=function(v){if(v==='')return;let x=catalog()[Number(v)];if(x&&$('#dJobType')&&!$('#dJobType').value){$('#dJobType').value=tradeOfCatalog(x).id;_editingDoc.jobType=$('#dJobType').value}return _addCatalogToRows61(v)}
function openTradePicker(title,cb){window.__tradePickerCb=cb;openModal(title,`<div class="trade-choice-grid">${JKBAT_TRADES.map(t=>`<button class="trade-choice" style="--trade:${t.color}" onclick="window.__tradePickerCb&&window.__tradePickerCb('${t.id}')">${tradeIcon(t.id)}<span><b>${esc(t.label)}</b><small>${esc(t.desc)}</small></span></button>`).join('')}</div>`)}
function startExpressTrade(id,appointmentId='',clientId=''){_expressTrade=id;openExpress(appointmentId,clientId)}
function expressCatalogOptionsV61(trade){let arr=catalog().filter(x=>!trade||tradeOfCatalog(x).id===trade);return arr.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}${Number(x.price)?' · '+euro(x.price):''}</option>`).join('')}
function renderExpressTradeChoices(){let el=$('#xTradeChoices');if(!el)return;el.innerHTML=JKBAT_TRADES.map(t=>`<button class="trade-choice ${_expressTrade===t.id?'active':''}" style="--trade:${t.color}" onclick="selectExpressTrade('${t.id}')">${tradeIcon(t.id)}<span><b>${esc(t.label)}</b><small>${esc(t.desc)}</small></span></button>`).join('')}
function selectExpressTrade(id){_expressTrade=id;renderExpressTradeChoices();let s=$('#xCatalog');if(s)s.innerHTML='<option value="">— catalogue '+tradeById(id).label+' —</option>'+expressCatalogOptionsV61(id)}
function openExpress(appointmentId='',forcedClientId=''){let ap=appointmentId?appointments().find(x=>x.id===appointmentId):null,cid=forcedClientId||ap?.clientId||clients().find(c=>c.name===ap?.client)?.id||'',c=clients().find(x=>x.id===cid);_expressTrade=tradeOfAppointment(ap).id||_expressTrade||'';openModal('Intervention express',`<div class="form"><div class="trade-section-label">1 · Métier</div><div class="trade-choice-grid" id="xTradeChoices"></div><div class="trade-section-label">2 · Client & chantier</div><div class="form two"><div><label class="label">Client</label><select class="field" id="xClient" onchange="expressPickClient()"><option value="">— choisir —</option>${expressClientOptions(cid)}</select></div><div><label class="label">Date</label><input type="date" class="field" id="xDate" value="${esc(ap?.date||todayISO())}"></div></div><div><label class="label">Adresse</label><textarea class="field" id="xAddress">${esc(ap?.address||c?.address||'')}</textarea></div><div class="trade-section-label">3 · Prestation</div><div class="form two"><div><label class="label">Prestation rapide</label><select class="field" id="xCatalog" onchange="expressPickCatalog()"><option value="">— choisir le métier —</option>${expressCatalogOptionsV61(_expressTrade)}</select></div><div><label class="label">Montant HT</label><input type="number" step="0.01" class="field" id="xPrice" value="0"></div></div>${voiceField('xConstat','Constat initial','')}${voiceField('xTravaux','Travaux réalisés',ap?.notes||'')}${voiceField('xResult','Résultat','')}${voiceField('xReco','Préconisation','')}<div class="form two"><div><label class="label">Photo AVANT</label><label class="btn file-label full">🖼 Galerie<input id="xBefore" type="file" accept="image/*"></label></div><div><label class="label">Photo APRÈS</label><label class="btn file-label full">🖼 Galerie<input id="xAfter" type="file" accept="image/*"></label></div></div><div class="form three"><div><label class="label">Document</label><select class="field" id="xKind"><option>FACTURE</option><option>DEVIS</option></select></div><div><label class="label">TVA %</label><input type="number" step="0.1" class="field" id="xVat" value="${esc(LS.getItem('jkbat_default_vat')||20)}"></div><div><label class="label">Durée (min)</label><input type="number" class="field" id="xMinutes" value="0"></div></div><label style="display:flex;gap:9px;align-items:center"><input type="checkbox" id="xCloseAppt" ${ap?'checked':''}> <span class="muted">Marquer le rendez-vous terminé</span></label><button class="btn primary full" onclick="saveExpress('${esc(appointmentId)}')">Créer le dossier chantier</button></div>`);renderExpressTradeChoices()}
async function saveExpress(appointmentId=''){let c=clients().find(x=>x.id===$('#xClient').value);if(!c)return toast('Choisis un client');if(!_expressTrade)return toast('Choisis le métier');let kind=$('#xKind').value,cat=catalog().find(x=>x.id===$('#xCatalog').value),price=Number($('#xPrice').value)||0,photos=[];try{let f1=$('#xBefore').files[0],f2=$('#xAfter').files[0];if(f1)photos.push(await resizeImage(f1,1100,.76));if(f2){if(!f1)photos.push('');photos.push(await resizeImage(f2,1100,.76))}}catch(e){toast('Une photo n’a pas pu être lue')}let d={id:uid(),kind,status:'BROUILLON',date:$('#xDate').value||todayISO(),invoiceNo:nextNo(kind),clientId:c.id,clientRef:c.ref||'PART',clientName:c.name,clientAddress:$('#xAddress').value.trim()||c.address||'',clientPhone:c.phone||'',clientEmail:c.email||'',jobType:_expressTrade,inspection:$('#xConstat').value.trim(),intervention:$('#xTravaux').value.trim(),control:'',result:$('#xResult').value.trim(),recommendation:$('#xReco').value.trim(),duration:(Number($('#xMinutes').value)||0)?`${Number($('#xMinutes').value)} min`:'',jobTimeMin:Number($('#xMinutes').value)||0,paymentMode:'',paidDate:'',discount:0,vat:Number($('#xVat').value)||0,rows:[{label:cat?.name||tradeById(_expressTrade).label,description:$('#xTravaux').value.trim()||cat?.description||'Intervention',qty:1,price}],photos,signature:'',signedAt:'',payments:[],materialsCost:0,parentId:'',nature:'',appointmentId,savedAt:new Date().toISOString()};let h=docs();h.push(d);jset('jkbat_history',h);commitSeq(d);LS.removeItem('jkbat_invoice_pwa');if(appointmentId&&$('#xCloseAppt').checked){let a=appointments(),i=a.findIndex(x=>x.id===appointmentId);if(i>=0){a[i].status='TERMINÉ';a[i].docRef=d.invoiceNo;a[i].docId=d.id;a[i].jobType=_expressTrade;jset('jkbat_appointments',a)}}logActivity('CHANTIER','Intervention express créée',`${tradeById(_expressTrade).label} · ${d.invoiceNo} · ${c.name}`);saveAuto();closeModal();_expressTrade='';renderAll();toast('Dossier chantier créé');setTimeout(()=>showDocument(docs().findIndex(x=>x.id===d.id)),80)}
function openAppointment(id=null,clientIndex=null){let a=id?appointments().find(x=>x.id===id):{},c=clientIndex==null?null:clients()[clientIndex];a={...a,clientId:a.clientId||c?.id||'',client:a.client||c?.name||'',address:a.address||c?.address||'',phone:a.phone||c?.phone||'',status:a.status||'À FAIRE',jobType:a.jobType||''};openModal(id?'Modifier le rendez-vous':'Nouveau rendez-vous',`<div class="form"><div><label class="label">Métier</label><select class="field trade-select" id="aTrade">${tradeSelectOptions(a.jobType)}</select></div><div class="form two"><div><label class="label">Titre / client</label><input class="field" id="aTitle" value="${esc(a.title||a.client||'')}"></div><div><label class="label">Statut</label><select class="field" id="aStatus"><option ${a.status==='À FAIRE'?'selected':''}>À FAIRE</option><option ${a.status==='CONFIRMÉ'?'selected':''}>CONFIRMÉ</option><option ${a.status==='TERMINÉ'?'selected':''}>TERMINÉ</option><option ${a.status==='ANNULÉ'?'selected':''}>ANNULÉ</option></select></div></div><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="aDate" value="${esc(a.date||todayISO())}"></div><div><label class="label">Heure</label><input type="time" class="field" id="aTime" value="${esc(a.time||'09:00')}"></div></div><div><label class="label">Adresse</label><textarea class="field" id="aAddress">${esc(a.address||'')}</textarea></div><div><label class="label">Téléphone</label><input class="field" id="aPhone" value="${esc(a.phone||'')}"></div><div><label class="label">Référence document</label><input class="field" id="aDocRef" value="${esc(a.docRef||'')}"></div><div><label class="label">Notes</label><textarea class="field" id="aNotes">${esc(a.notes||'')}</textarea></div><button class="btn primary" onclick="saveAppointment('${esc(a.id||'')}','${esc(a.clientId||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteAppointment('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveAppointment(id,clientId=''){let old=id?appointments().find(x=>x.id===id):{},o={...old,id:id||uid(),clientId:clientId||old?.clientId||'',jobType:$('#aTrade').value||'',title:$('#aTitle').value.trim(),client:$('#aTitle').value.trim(),status:$('#aStatus').value,date:$('#aDate').value,time:$('#aTime').value,address:$('#aAddress').value.trim(),phone:$('#aPhone').value.trim(),docRef:$('#aDocRef').value.trim(),notes:$('#aNotes').value.trim()};if(!o.title||!o.date)return toast('Titre et date requis');let a=appointments(),i=a.findIndex(x=>x.id===o.id);if(i>=0)a[i]=o;else a.push(o);jset('jkbat_appointments',a);logActivity('AGENDA',i>=0?'Rendez-vous modifié':'Rendez-vous créé',`${tradeById(o.jobType).label} · ${o.title} · ${fmtDate(o.date)} ${o.time}`);saveAuto();closeModal();renderAll();toast('Rendez-vous enregistré')}
function renderAgenda(){if(!$('#weekStrip'))return;let days=weekDays(),today=todayISO(),allRaw=appointments(),all=allRaw.filter(a=>matchesTrade(a,_agendaTrade,'appointment'));if(!_maxSelectedDate||!days.some(d=>isoLocal(d)===_maxSelectedDate))_maxSelectedDate=days.some(d=>isoLocal(d)===today)?today:isoLocal(days[0]);let opts={weekday:'short'},monthA=days[0].toLocaleDateString('fr-FR',{day:'numeric',month:'short'}),monthB=days[6].toLocaleDateString('fr-FR',{day:'numeric',month:'short',year:'numeric'});$('#weekLabel').textContent=`${monthA} — ${monthB}`;$('#agendaCount').textContent=`${all.length}/${allRaw.length} rendez-vous`;$('#weekStrip').innerHTML=days.map(d=>{let iso=isoLocal(d),n=all.filter(a=>a.date===iso).length;return `<button class="week-day ${iso===today?'today':''} ${iso===_maxSelectedDate?'selected':''} ${n?'has':''}" onclick="selectWeekDate('${iso}')"><span class="wd">${d.toLocaleDateString('fr-FR',opts).replace('.','')}</span><span class="dn">${d.getDate()}</span><i class="dot"></i></button>`}).join('');let arr=all.filter(a=>a.date===_maxSelectedDate).sort((a,b)=>String(a.time||'').localeCompare(String(b.time||''))),d=new Date(_maxSelectedDate+'T12:00:00');$('#daySummary').innerHTML=`<div class="day-summary-card"><div><b>${d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'}).replace(/^./,c=>c.toUpperCase())}</b><span>${arr.length?`${arr.length} rendez-vous planifié(s)`:'Journée disponible'}</span></div><span class="chip ${arr.length?'badge-gold':'ok'}">${arr.length?arr.length+' RDV':'LIBRE'}</span></div>`;$('#agendaList').innerHTML=arr.length?arr.map(x=>{let t=tradeOfAppointment(x);return `<div class="card row trade-agenda-card" style="--trade:${t.color}"><div class="agenda-time">${esc(x.time||'--:--')}</div>${tradeIcon(x.jobType)}<div class="grow"><b>${esc(x.title||x.client||'Rendez-vous')}</b><div class="muted">${esc(x.client||'')} ${x.address?'· '+esc(x.address):''}</div><div class="trade-doc-meta">${tradeBadge(x.jobType)}<span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span></div></div><button class="btn small" onclick="openAppointment('${esc(x.id)}')">›</button></div>`}).join(''):'<div class="empty">Aucun chantier ce jour pour ce métier.</div>';if($('#agendaTradeFilter'))$('#agendaTradeFilter').innerHTML=tradeFilterHtml(_agendaTrade,'setAgendaTrade')}
function renderTerrainTradeHub(){let el=$('#terrainTradeHub');if(!el)return;let today=todayISO();el.innerHTML=`<div class="trade-hub"><div class="trade-dashboard-head"><div><span class="section-kicker">Métiers</span><b>Intervention par activité</b></div><span>terrain</span></div><div class="trade-grid">${JKBAT_TRADES.map(t=>{let a=appointments().filter(x=>x.date===today&&tradeOfAppointment(x).id===t.id),todo=a.filter(x=>x.status!=='TERMINÉ').length;return `<button class="trade-kpi" style="--trade:${t.color}" onclick="startExpressTrade('${t.id}')">${tradeIcon(t.id)}<b>${esc(t.label)}</b><strong>${todo}</strong><small>à faire aujourd’hui · toucher pour intervenir</small></button>`}).join('')}</div><div class="trade-filter" style="margin-top:8px">${tradeFilterHtml(_terrainTrade,'setTerrainTrade')}</div></div>`}
const _renderTerrain61Base=renderTerrain;renderTerrain=function(){_renderTerrain61Base();renderMissionConsole();renderTerrainTradeHub();let el=$('#terrainToday'),today=todayISO();if(el){let a=appointments().filter(x=>x.date===today&&matchesTrade(x,_terrainTrade,'appointment')).sort((x,y)=>String(x.time||'').localeCompare(String(y.time||'')));$('#terrainTodayCount').textContent=`${a.length} intervention(s)`;el.innerHTML=a.length?a.map(x=>{let t=tradeOfAppointment(x);return `<div class="card trade-card" style="--trade:${t.color}"><div class="row-between"><div class="row" style="align-items:center">${tradeIcon(x.jobType)}<div><b>${esc(x.time||'--:--')} · ${esc(x.title||x.client||'Intervention')}</b><div class="muted">${esc(x.client||'')} · ${esc(x.address||'')}</div><div class="trade-doc-meta">${tradeBadge(x.jobType)}<span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span></div></div></div></div><div class="actions">${x.phone?`<a class="btn small" href="tel:${cleanPhone(x.phone)}">Appeler</a>`:''}${x.address?`<a class="btn small" href="${mapHref(x.address)}">GPS</a>`:''}<button class="btn small primary" onclick="startExpressTrade('${t.id}','${esc(x.id)}')">Intervenir</button></div></div>`}).join(''):'<div class="empty">Aucune intervention aujourd’hui pour ce métier.</div>'}}
function openCatalogItem(id=null){let a=id?catalog().find(x=>x.id===id):{};openModal(id?'Modifier la prestation':'Nouvelle prestation',`<div class="form"><div><label class="label">Métier</label><select class="field trade-select" id="catCategory">${tradeSelectOptions(a.category||'')}</select></div><div><label class="label">Nom</label><input class="field" id="catName" value="${esc(a.name||'')}"></div><div><label class="label">Description facture / rapport</label><textarea class="field" id="catDesc">${esc(a.description||'')}</textarea></div><div class="form two"><div><label class="label">Unité</label><input class="field" id="catUnit" value="${esc(a.unit||'forfait')}"></div><div><label class="label">Prix unitaire HT</label><input type="number" step="0.01" class="field" id="catPrice" value="${esc(a.price||0)}"></div></div><div class="form two"><div><label class="label">Coût matière estimé</label><input type="number" step="0.01" class="field" id="catCost" value="${esc(a.cost||0)}"></div><label style="display:flex;gap:8px;align-items:center;margin-top:19px"><input type="checkbox" id="catFav" ${a.favorite?'checked':''}> <span class="muted">Favori terrain</span></label></div><button class="btn primary" onclick="saveCatalogItem('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteCatalogItem('${esc(id)}')">Supprimer</button>`:''}</div>`)}
function saveCatalogItem(id){let x={id:id||uid(),name:$('#catName').value.trim(),category:$('#catCategory').value||'',description:$('#catDesc').value.trim(),unit:$('#catUnit').value.trim(),price:Number($('#catPrice').value)||0,cost:Number($('#catCost').value)||0,favorite:!!$('#catFav').checked};if(!x.name)return toast('Nom requis');let a=catalog(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_catalog',a);logActivity('CATALOGUE',i>=0?'Prestation modifiée':'Prestation ajoutée',`${tradeById(x.category).label} · ${x.name}`);closeModal();renderAll();toast('Catalogue enregistré')}
function renderTradePilotage(){let el=$('#tradePilotage');if(!el)return;let yr=String(new Date().getFullYear()),inv=docs().filter(d=>d.kind==='FACTURE'&&String(d.date||'').startsWith(yr)),max=Math.max(1,...JKBAT_TRADES.map(t=>inv.filter(d=>tradeOfDoc(d).id===t.id).reduce((s,d)=>s+calc(d).total,0)));el.innerHTML=`<div class="trade-pilotage"><div class="section-title"><div><span class="section-kicker">Rentabilité</span><h3>CA par activité</h3></div><span>${yr}</span></div><div class="card">${JKBAT_TRADES.map(t=>{let a=inv.filter(d=>tradeOfDoc(d).id===t.id),ca=a.reduce((s,d)=>s+calc(d).total,0),cost=catalog().filter(x=>tradeOfCatalog(x).id===t.id).reduce((s,x)=>s+(Number(x.cost)||0),0);return `<div class="trade-revenue-row" style="--trade:${t.color}">${tradeIcon(t.id)}<div><b>${esc(t.label)}</b><div class="trade-bar"><i style="width:${Math.round(ca/max*100)}%"></i></div><small>${a.length} facture(s)</small></div><strong>${euro(ca)}</strong></div>`}).join('')}</div></div>`}
const _renderPilotage61Base=renderPilotage;renderPilotage=function(){_renderPilotage61Base();renderTradePilotage();let list=$('#catalogList');if(list){let a=catalog().filter(x=>matchesTrade(x,_catalogTrade,'catalog'));list.innerHTML=a.length?a.map(x=>{let t=tradeOfCatalog(x);return `<div class="card compact row trade-card" style="--trade:${t.color}">${tradeIcon(x.category)}<div class="grow"><b>${esc(x.name)}</b><div class="muted">${esc(t.label)} · ${esc(x.unit||'')} ${Number(x.price)?'· '+euro(x.price):''}${x.favorite?' · Favori':''}</div></div><button class="btn small" onclick="openCatalogItem('${esc(x.id)}')">Modifier</button></div>`}).join(''):'<div class="empty">Aucune prestation pour ce métier.</div>'}if($('#catalogTradeFilter'))$('#catalogTradeFilter').innerHTML=tradeFilterHtml(_catalogTrade,'setCatalogTrade')}
const _invoiceHtml61=invoiceHtml;invoiceHtml=function(d){let h=_invoiceHtml61(d),t=tradeOfDoc(d);if(!t.id)return h;return h.replace('<div class="invoice-comments">',`<div class="pdf-trade-line"><b>Nature de l’intervention :</b> ${esc(t.label)}</div><div class="invoice-comments">`)}
const _reportHtml61=reportHtml;reportHtml=function(d){let h=_reportHtml61(d),t=tradeOfDoc(d);if(!t.id)return h;return h.replace('<div class="report-title">RAPPORT D’INTERVENTION</div><div class="report-subtitle">Compte rendu d’intervention</div>',`<div class="report-title-wrap"><div class="report-title">RAPPORT D’INTERVENTION</div><div class="report-subtitle">Compte rendu d’intervention</div><div class="report-trade-chip">${esc(t.label)}</div></div>`)}

const _openDocument61Base=openDocument;openDocument=function(isNew=true,existing=null,clientIndex=null){if(isNew&&!existing&&_docTrade&&_docTrade!=='ALL')existing={jobType:_docTrade};_openDocument61Base(isNew,existing,clientIndex);if(isNew&&existing?.jobType&&$('#dJobType')){$('#dJobType').value=existing.jobType;_editingDoc.jobType=existing.jobType}setTimeout(refreshCatalogForEditingTrade,0)}
function renderTradeChrome(){renderTradeFilters();renderTradeDashboard()}
const _renderDashboard61Base=renderDashboard;renderDashboard=function(){_renderDashboard61Base();renderMaxFocus();renderMaxPulse();renderTradeDashboard()}
const _renderAll61Base=renderAll;renderAll=function(){_renderAll61Base();renderTradeChrome();renderTradePilotage();renderTerrainTradeHub()}



/* --- JKBat Pro 6.2 INTERVENTION SIGNATURE + PDF --- */
let _intSignIndex=-1,_intSignDirty=false;
function interventionRef(d){if(d?.interventionRef)return d.interventionRef;let base=String(d?.invoiceNo||d?.id||uid()).replace(/^(FAC|DEV|FACT)-?/i,'');return 'INT-'+base}
function interventionBrief(v,max=520){v=String(v||'').trim();if(v.length<=max)return esc(v).replace(/\n/g,'<br>');return esc(v.slice(0,max).trim()).replace(/\n/g,'<br>')+'… <b>Voir détails page 2</b>'}
function interventionNeedsDetails(d){return [d.inspection,d.intervention,d.result,d.recommendation,d.materialsUsed,d.clientObservations].some(v=>String(v||'').length>520)}
function interventionSplitText(v,max=1500){v=String(v||'').trim();let out=[];while(v.length>max){let cut=v.lastIndexOf(' ',max);if(cut<Math.floor(max*.62))cut=max;out.push(v.slice(0,cut).trim());v=v.slice(cut).trim()}if(v)out.push(v);return out}
function interventionDetailPages(d){if(!interventionNeedsDetails(d))return [];let defs=[['Constat / diagnostic',d.inspection],['Travaux réalisés',d.intervention],['Résultat / contrôle final',d.result||d.control],['Préconisations',d.recommendation],['Matériel / pièces utilisés',d.materialsUsed],['Observations du client',d.clientObservations]],items=[];defs.filter(x=>String(x[1]||'').trim()).forEach(([label,text])=>interventionSplitText(text).forEach((part,i)=>items.push({label:label+(i?' (suite)':''),text:part})));let pages=[],cur=[],size=0;items.forEach(item=>{let n=item.text.length+220;if(cur.length&&size+n>3100){pages.push(cur);cur=[];size=0}cur.push(item);size+=n});if(cur.length)pages.push(cur);return pages}
function interventionSheetHtml(d){let c=company(),t=tradeOfDoc(d),ref=interventionRef(d),detailPages=interventionDetailPages(d),total=1+detailPages.length,sig=d.signature?`<img class="int-sign-img" src="${d.signature}">`:`<div class="int-sign-placeholder">Signature non recueillie</div>`,signed=d.signedAt?new Date(d.signedAt).toLocaleString('fr-FR'):'',times=[d.interventionStart,d.interventionEnd].filter(Boolean).join(' - ');let page1=`<div class="jk-doc-page intervention-sheet"><div class="int-head"><img class="jk-logo-img int-logo" src="${c.logo||'jkbat-logo.png'}"><div class="int-title-wrap"><div class="int-kicker">JKBat Services · document chantier</div><div class="int-title">FICHE D’INTERVENTION</div><div class="int-ref">Référence ${esc(ref)}</div></div></div><div class="int-gold-line"></div><table class="int-meta"><tr><td class="lab">Client</td><td class="value">${esc(d.clientName||'')}</td><td class="lab">Date</td><td class="value">${fmtDate(d.date)}</td></tr><tr><td class="lab">Adresse</td><td>${esc(d.clientAddress||'').replace(/\n/g,'<br>')}</td><td class="lab">Horaires</td><td>${esc(times||'Non renseignés')}</td></tr><tr><td class="lab">Téléphone</td><td>${esc(d.clientPhone||'')}</td><td class="lab">Technicien</td><td>${esc(d.interventionTech||'JKBat Services')}</td></tr><tr><td class="lab">Document lié</td><td>${esc(d.invoiceNo||'')}</td><td class="lab">Durée</td><td>${esc(d.duration||((d.jobTimeMin||0)?d.jobTimeMin+' min':'Non renseignée'))}</td></tr></table><div class="int-trade-row"><b>Nature :</b><span class="int-trade-pill">${esc(t.id?t.label:'Non catégorisé')}</span>${d.nature?`<span>${esc(d.nature)}</span>`:''}</div><div class="int-sections"><div class="int-block"><h3>Constat / diagnostic</h3><p>${interventionBrief(d.inspection||'')}</p></div><div class="int-block"><h3>Travaux réalisés</h3><p>${interventionBrief(d.intervention||'')}</p></div><div class="int-block"><h3>Résultat / contrôle final</h3><p>${interventionBrief(d.result||d.control||'')}</p></div><div class="int-block"><h3>Préconisations</h3><p>${interventionBrief(d.recommendation||'')}</p></div></div><div class="int-summary"><div class="int-block"><h3>Matériel / pièces utilisés</h3><p>${interventionBrief(d.materialsUsed||'',320)}</p></div><div class="int-block"><h3>Observations du client</h3><p>${interventionBrief(d.clientObservations||'',320)}</p></div></div><div class="int-sign-zone"><div class="int-accept">Le client reconnaît que l’intervention décrite ci-dessus a été réalisée et que les informations portées sur cette fiche correspondent aux constatations faites à la fin de l’intervention. La signature atteste la prise de connaissance de la fiche, sans modifier les garanties légales ou contractuelles applicables.${detailPages.length?'<br><br><b>Des détails complémentaires figurent sur les pages suivantes.</b>':''}</div><div class="int-sign-card"><b>Signature du client</b>${sig}<div class="int-sign-meta">${esc(d.clientSigner||d.clientName||'')}${signed?'<br>Signé le '+esc(signed):''}</div></div></div><div class="int-footer"><span>${esc(c.name)} · ${esc(c.phone)} · ${esc(c.email)}</span><span>${esc(ref)} · Page 1${total>1?' / '+total:''}</span></div></div>`;let extra=detailPages.map((items,pi)=>`<div class="jk-doc-page intervention-sheet"><div class="int-head"><img class="jk-logo-img int-logo" src="${c.logo||'jkbat-logo.png'}"><div class="int-title-wrap"><div class="int-kicker">JKBat Services · complément</div><div class="int-detail-title">DÉTAILS D’INTERVENTION</div><div class="int-ref">${esc(ref)} · ${esc(d.clientName||'')}</div></div></div><div class="int-gold-line"></div>${items.map(x=>`<div class="int-detail-block"><h3>${esc(x.label)}</h3><p>${esc(x.text).replace(/\n/g,'<br>')}</p></div>`).join('')}<div class="int-footer"><span>${esc(c.name)} · ${esc(c.phone)} · ${esc(c.email)}</span><span>${esc(ref)} · Page ${pi+2} / ${total}</span></div></div>`).join('');return page1+extra}
function openInterventionSheet(i){let d=docs()[i];if(!d)return toast('Document introuvable');let sig=d.signature?`<img src="${d.signature}"><div><span class="signed-ok">✓ Signé</span><div class="muted">${esc(d.clientSigner||d.clientName||'')}${d.signedAt?' · '+esc(new Date(d.signedAt).toLocaleString('fr-FR')):''}</div></div>`:`<div><span class="unsigned">Signature client à recueillir</span><div class="muted">Signature au doigt directement sur le téléphone.</div></div>`;openModal('Fiche d’intervention',`<div class="form"><div class="ultimate-banner"><b>📋 ${esc(interventionRef(d))}</b><p>${esc(d.clientName||'')} · ${esc(tradeOfDoc(d).label)}</p></div><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="intDate" value="${esc(d.date||todayISO())}"></div><div><label class="label">Technicien</label><input class="field" id="intTech" value="${esc(d.interventionTech||'JKBat Services')}"></div></div><div class="form two"><div><label class="label">Heure début</label><input type="time" class="field" id="intStart" value="${esc(d.interventionStart||'')}"></div><div><label class="label">Heure fin</label><input type="time" class="field" id="intEnd" value="${esc(d.interventionEnd||'')}"></div></div><div><label class="label">Nature / objet précis</label><input class="field" id="intNature" value="${esc(d.nature||d.interventionTitle||'')}"></div>${voiceField('intInspection','Constat / diagnostic',d.inspection||'')}${voiceField('intWork','Travaux réalisés',d.intervention||'')}${voiceField('intResult','Résultat / contrôle final',d.result||d.control||'')}${voiceField('intReco','Préconisations',d.recommendation||'')}<div><label class="label">Matériel / pièces utilisés</label><textarea class="field" id="intMaterials">${esc(d.materialsUsed||'')}</textarea></div><div><label class="label">Observations du client</label><textarea class="field" id="intClientObs">${esc(d.clientObservations||'')}</textarea></div><div><label class="label">Nom du signataire</label><input class="field" id="intSigner" value="${esc(d.clientSigner||d.clientName||'')}"></div><div class="int-form-sign-state">${sig}</div><div class="actions"><button class="btn primary" onclick="saveInterventionForm(${i},true)">Enregistrer la fiche</button><button class="btn" onclick="prepareInterventionSign(${i})">✍ Signature client</button></div><div class="actions"><button class="btn primary" onclick="saveAndPrintIntervention(${i})">📄 Créer le PDF</button><button class="btn" onclick="closeModal();showDocument(${i})">Retour dossier</button></div></div>`)}
function saveInterventionForm(i,closeAfter=false){let a=docs(),d=a[i];if(!d)return false;let val=id=>document.getElementById(id)?.value??'';d.date=val('intDate')||d.date||todayISO();d.interventionRef=d.interventionRef||interventionRef(d);d.interventionTech=val('intTech').trim()||'JKBat Services';d.interventionStart=val('intStart');d.interventionEnd=val('intEnd');d.nature=val('intNature').trim();d.inspection=val('intInspection').trim();d.intervention=val('intWork').trim();d.result=val('intResult').trim();d.recommendation=val('intReco').trim();d.materialsUsed=val('intMaterials').trim();d.clientObservations=val('intClientObs').trim();d.clientSigner=val('intSigner').trim();if(d.interventionStart&&d.interventionEnd){let [h1,m1]=d.interventionStart.split(':').map(Number),[h2,m2]=d.interventionEnd.split(':').map(Number),mins=(h2*60+m2)-(h1*60+m1);if(mins<0)mins+=1440;if(mins>=0){d.jobTimeMin=mins;d.duration=mins>=60?`${Math.floor(mins/60)} h ${String(mins%60).padStart(2,'0')}`:`${mins} min`}}d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);logActivity('INTERVENTION','Fiche intervention enregistrée',`${d.interventionRef} · ${d.clientName}`);saveAuto();renderAll();if(closeAfter){closeModal();toast('Fiche d’intervention enregistrée')}return true}
function prepareInterventionSign(i){if(!saveInterventionForm(i,false))return;openInterventionSignature(i)}
function openInterventionSignature(i){let d=docs()[i];_intSignIndex=i;_intSignDirty=false;openModal('Signature client',`<div class="ultimate-banner"><b>Signature de fin d’intervention</b><p>${esc(d.clientName||'')} · ${esc(interventionRef(d))}</p></div><div><label class="label">Nom du signataire</label><input class="field" id="intSignName" value="${esc(d.clientSigner||d.clientName||'')}"></div>${d.signature?`<div class="sig-preview" style="margin:10px 0"><img src="${d.signature}"></div><div class="muted">Une nouvelle signature remplacera celle-ci.</div>`:''}<p class="muted">Le client signe au doigt dans la zone blanche.</p><div class="canvas-wrap"><canvas id="intSigCanvas"></canvas></div><div class="actions"><button class="btn" onclick="clearInterventionCanvas()">Effacer</button><button class="btn primary" onclick="saveInterventionSignature()">Valider et enregistrer</button></div>`);setTimeout(initInterventionSignature,30)}
function initInterventionSignature(){let c=$('#intSigCanvas');if(!c)return;let r=c.getBoundingClientRect(),d=Math.max(1,window.devicePixelRatio||1);c.width=Math.round(r.width*d);c.height=Math.round(190*d);_sigCanvas=c;_sigCtx=c.getContext('2d');_sigCtx.scale(d,d);_sigCtx.lineWidth=2.5;_sigCtx.lineCap='round';_sigCtx.strokeStyle='#111';let pos=e=>{let rr=c.getBoundingClientRect(),t=e.touches?e.touches[0]:e;return{x:t.clientX-rr.left,y:t.clientY-rr.top}},down=e=>{e.preventDefault();_intSignDirty=true;_drawing=true;let p=pos(e);_sigCtx.beginPath();_sigCtx.moveTo(p.x,p.y)},move=e=>{if(!_drawing)return;e.preventDefault();let p=pos(e);_sigCtx.lineTo(p.x,p.y);_sigCtx.stroke()},up=e=>{if(e)e.preventDefault();_drawing=false};c.addEventListener('touchstart',down,{passive:false});c.addEventListener('touchmove',move,{passive:false});c.addEventListener('touchend',up,{passive:false});c.addEventListener('mousedown',down);c.addEventListener('mousemove',move);window.addEventListener('mouseup',up,{once:true})}
function clearInterventionCanvas(){if(_sigCtx&&_sigCanvas){_sigCtx.clearRect(0,0,_sigCanvas.width,_sigCanvas.height);_intSignDirty=false}}
function saveInterventionSignature(){if(_intSignIndex<0||!_sigCanvas)return;if(!_intSignDirty)return toast('Le client doit signer dans la zone blanche');let a=docs(),d=a[_intSignIndex];d.signature=_sigCanvas.toDataURL('image/png');d.signedAt=new Date().toISOString();d.clientSigner=$('#intSignName').value.trim()||d.clientName||'';d.workflow={...(d.workflow||{}),signature:true};a[_intSignIndex]=d;jset('jkbat_history',a);logActivity('SIGNATURE','Fiche intervention signée',`${interventionRef(d)} · ${d.clientSigner}`);saveAuto();let i=_intSignIndex;_intSignIndex=-1;closeModal();renderAll();toast('Signature client enregistrée');setTimeout(()=>openInterventionSheet(i),60)}
function saveAndPrintIntervention(i){if(!saveInterventionForm(i,false))return;let d=docs()[i];closeModal();showPrintDoc(d,'intervention')}
const _showPrintDoc62Base=showPrintDoc;showPrintDoc=function(d,type='invoice'){if(type!=='intervention')return _showPrintDoc62Base(d,type);$('#printLayer').innerHTML=`<div class="print-controls"><button class="btn primary" onclick="triggerPrint()">Créer le PDF / Imprimer</button><button class="btn" onclick="exitPrint()">Retour à l’application</button></div>${interventionSheetHtml(d)}`;document.body.classList.add('print-mode');window.scrollTo(0,0)}
function openInterventionPdf(i){let d=docs()[i];if(!d)return;closeModal();showPrintDoc(d,'intervention')}
function migrateV62(){if(LS.getItem('jkbat_v62_migrated'))return;let a=docs(),changed=false;a=a.map(d=>{for(let [k,v] of Object.entries({interventionRef:'',interventionTech:'',interventionStart:'',interventionEnd:'',materialsUsed:'',clientObservations:'',clientSigner:''})){if(d[k]==null){d[k]=v;changed=true}}return d});if(changed)jset('jkbat_history',a);LS.setItem('jkbat_v62_migrated','1')}
showDocument=function(i){let d=docs()[i];if(!d)return;let kids=docs().filter(x=>x.parentId===d.id),par=d.parentId?docs().find(x=>x.id===d.parentId):null,qr=qrSvg(docQrData(d));openModal(d.invoiceNo||d.kind,`<div>${invoiceHtml(d)}</div><div class="card" style="margin-top:12px"><div class="row-between"><div><b>Dossier numérique</b><div class="muted">${d.nature?esc(d.nature)+' · ':''}${d.jobTimeMin?esc(d.jobTimeMin)+' min · ':''}${d.signature?'signé':'signature à recueillir'}</div></div>${qr?`<div class="qrbox">${qr}</div>`:''}</div>${par?`<div class="tiny" style="margin-top:8px">Document parent : ${esc(par.invoiceNo)}</div>`:''}${kids.length?`<div class="tiny">Liés : ${kids.map(x=>esc(x.invoiceNo)).join(', ')}</div>`:''}</div>${d.kind==='FACTURE'?paymentHistoryHtml(d,i):''}<div class="actions"><button class="btn primary" onclick="openInterventionSheet(${i})">📋 Fiche d’intervention</button><button class="btn ${d.signature?'ok':'primary'}" onclick="openInterventionSheet(${i})">${d.signature?'✓ Fiche signée':'✍ Faire signer'}</button><button class="btn primary" onclick="openInterventionPdf(${i})">📄 PDF intervention</button></div><div class="actions"><button class="btn" onclick="openPrint(${i},'invoice')">Facture / devis PDF</button><button class="btn" onclick="openPrint(${i},'report')">Rapport 4 pages PDF</button>${d.kind==='FACTURE'?`<button class="btn ok" onclick="openPayment(${i})">€ Encaisser</button>`:''}<button class="btn" onclick="shareDoc(${i})">↗ Partager</button><button class="btn" onclick="closeModal();openDocument(false,docs()[${i}])">Modifier</button>${d.kind==='DEVIS'?`<button class="btn ok" onclick="convertToInvoice(${i})">→ Facture</button><button class="btn" onclick="createDeposit(${i})">Acompte</button>`:''}${d.kind==='FACTURE'?`<button class="btn" onclick="createCredit(${i})">Avoir</button>`:''}<button class="btn" onclick="chooseTimerDoc('${esc(d.id)}')">⏱ Chrono</button><button class="btn" onclick="duplicateDoc(${i})">Dupliquer</button><button class="btn danger" onclick="deleteDoc(${i})">Supprimer</button></div>`)}


// --- JKBat Pro 6.3 : fiche d'intervention visible et autonome ---
function nextInterventionRef63(date=todayISO()){
 const day=String(date||todayISO()).replace(/-/g,'');
 const prefix='INT-'+day+'-';
 const n=docs().filter(d=>d.kind==='FICHE'&&String(d.interventionRef||d.invoiceNo||'').startsWith(prefix)).length+1;
 return prefix+String(n).padStart(3,'0');
}
function interventionClientOptions63(selected=''){
 return clients().map((c,i)=>`<option value="${i}" ${String(c.id||'')===String(selected||'')?'selected':''}>${esc(c.name||'Client')}</option>`).join('')
}
function fillStandaloneClient63(){
 let v=$('#siClientPick')?.value;if(v==null||v==='')return;let c=clients()[Number(v)];if(!c)return;
 if($('#siClient'))$('#siClient').value=c.name||'';if($('#siAddress'))$('#siAddress').value=c.address||'';if($('#siPhone'))$('#siPhone').value=c.phone||'';if($('#siEmail'))$('#siEmail').value=c.email||'';if($('#siClientRef'))$('#siClientRef').value=c.ref||'PART';
}
function openStandaloneIntervention(clientId=''){
 let selected=clients().findIndex(c=>String(c.id||'')===String(clientId||''));
 let c=selected>=0?clients()[selected]:null;
 openModal('Nouvelle fiche d’intervention',`<div class="form"><div class="ultimate-banner"><b>📋 Fiche d’intervention</b><p>Indépendante d’un devis ou d’une facture. Tu pourras la faire signer puis créer le PDF.</p></div><div><label class="label">Client existant</label><select class="field" id="siClientPick" onchange="fillStandaloneClient63()"><option value="">— choisir ou saisir manuellement —</option>${clients().map((x,i)=>`<option value="${i}" ${i===selected?'selected':''}>${esc(x.name||'Client')}</option>`).join('')}</select></div><div class="form two"><div><label class="label">Client</label><input class="field" id="siClient" value="${esc(c?.name||'')}"></div><div><label class="label">Réf. client</label><input class="field" id="siClientRef" value="${esc(c?.ref||'PART')}"></div></div><div><label class="label">Adresse du chantier</label><textarea class="field" id="siAddress">${esc(c?.address||'')}</textarea></div><div class="form two"><div><label class="label">Téléphone</label><input class="field" id="siPhone" value="${esc(c?.phone||'')}"></div><div><label class="label">E-mail</label><input class="field" id="siEmail" value="${esc(c?.email||'')}"></div></div><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="siDate" value="${todayISO()}"></div><div><label class="label">Métier</label><select class="field" id="siTrade">${tradeSelectOptions('')}</select></div></div><div><label class="label">Nature / objet de l’intervention</label><input class="field" id="siNature" placeholder="Ex. Débouchage évier, dépannage électrique…"></div><button class="btn primary full" onclick="createStandaloneIntervention63()">Créer et ouvrir la fiche</button></div>`)
}
function createStandaloneIntervention63(){
 let val=id=>document.getElementById(id)?.value??'',clientName=val('siClient').trim();if(!clientName)return toast('Renseigne le nom du client');
 let pick=val('siClientPick'),c=pick!==''?clients()[Number(pick)]:null,date=val('siDate')||todayISO(),ref=nextInterventionRef63(date);
 let d={id:uid(),kind:'FICHE',status:'À SIGNER',date,invoiceNo:ref,interventionRef:ref,clientId:c?.id||'',clientRef:val('siClientRef').trim()||c?.ref||'PART',clientName,clientAddress:val('siAddress').trim(),clientPhone:val('siPhone').trim(),clientEmail:val('siEmail').trim(),jobType:val('siTrade'),nature:val('siNature').trim(),interventionTitle:val('siNature').trim(),inspection:'',intervention:'',control:'',result:'',recommendation:'',duration:'',interventionTech:'JKBat Services',interventionStart:'',interventionEnd:'',materialsUsed:'',clientObservations:'',clientSigner:clientName,rows:[],photos:[],signature:'',signedAt:'',workflow:{arrival:false,before:false,diagnosis:false,work:false,after:false,signature:false},savedAt:new Date().toISOString()};
 let a=docs();a.push(d);jset('jkbat_history',a);logActivity('INTERVENTION','Fiche intervention créée',`${ref} · ${clientName}`);saveAuto();closeModal();renderAll();let i=docs().findIndex(x=>x.id===d.id);setTimeout(()=>openInterventionSheet(i),60)
}
function renderInterventionForms63(){
 let el=$('#interventionFormsList'),count=$('#interventionFormCount');if(!el)return;
 let arr=docs().map((d,i)=>({...d,_i:i})).filter(d=>d.kind==='FICHE'||d.interventionRef).sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date))).slice(0,8);
 if(count)count.textContent=`${arr.length} récente(s)`;
 el.innerHTML=arr.length?arr.map(d=>{let t=tradeOfDoc(d),signed=!!d.signature;return `<div class="card intervention-list-card" style="--trade:${t.color}" onclick="openInterventionSheet(${d._i})"><div class="row-between"><div class="grow"><div class="int-ref-mini">${esc(interventionRef(d))}</div><b>${esc(d.clientName||'Client')}</b><div class="muted">${fmtDate(d.date)} · ${esc(d.nature||d.interventionTitle||d.intervention||'Intervention')}</div><div class="trade-doc-meta">${tradeBadge(d.jobType)}<span class="signed-state ${signed?'ok':'wait'}">${signed?'✓ Signée':'✍ À signer'}</span></div></div><span class="tap">›</span></div></div>`}).join(''):'<div class="empty">Aucune fiche créée. Appuie sur « Nouvelle fiche ».</div>'
}
const _docCard63Base=docCard;docCard=function(d,i){if(d.kind!=='FICHE')return _docCard63Base(d,i);let t=tradeOfDoc(d);return `<div class="card row trade-card" style="--trade:${t.color}" onclick="openInterventionSheet(${i})"><div class="trade-icon" style="--trade:${t.color}">${tradeIconSvg(t.icon)}</div><div class="grow"><b>${esc(interventionRef(d))} · ${esc(d.clientName||'Client')}</b><div class="muted">${fmtDate(d.date)} · ${esc(d.nature||d.intervention||'Fiche d’intervention')}</div><div class="trade-doc-meta">${tradeBadge(d.jobType)}<span class="chip ${d.signature?'ok':'warn'}">${d.signature?'SIGNÉE':'À SIGNER'}</span></div></div><span class="tap">›</span></div>`}
const _showDocument63Base=showDocument;showDocument=function(i){let d=docs()[i];if(d?.kind==='FICHE')return openInterventionSheet(i);return _showDocument63Base(i)}
openInterventionSheet=function(i){let d=docs()[i];if(!d)return toast('Fiche introuvable');let sig=d.signature?`<img src="${d.signature}"><div><span class="signed-ok">✓ Signé</span><div class="muted">${esc(d.clientSigner||d.clientName||'')}${d.signedAt?' · '+esc(new Date(d.signedAt).toLocaleString('fr-FR')):''}</div></div>`:`<div><span class="unsigned">Signature client à recueillir</span><div class="muted">Signature au doigt directement sur le téléphone.</div></div>`;openModal('Fiche d’intervention',`<div class="form"><div class="ultimate-banner"><b>📋 ${esc(interventionRef(d))}</b><p>${esc(d.clientName||'')} · ${esc(tradeOfDoc(d).label)}</p></div><div><label class="label">Client</label><input class="field" id="intClientName" value="${esc(d.clientName||'')}"></div><div><label class="label">Adresse du chantier</label><textarea class="field" id="intClientAddress">${esc(d.clientAddress||'')}</textarea></div><div class="form two"><div><label class="label">Téléphone</label><input class="field" id="intClientPhone" value="${esc(d.clientPhone||'')}"></div><div><label class="label">Réf. client</label><input class="field" id="intClientRef" value="${esc(d.clientRef||'PART')}"></div></div><div class="form two"><div><label class="label">Métier</label><select class="field" id="intJobType">${tradeSelectOptions(d.jobType||'')}</select></div><div><label class="label">Date</label><input type="date" class="field" id="intDate" value="${esc(d.date||todayISO())}"></div></div><div><label class="label">Technicien</label><input class="field" id="intTech" value="${esc(d.interventionTech||'JKBat Services')}"></div><div class="form two"><div><label class="label">Heure début</label><input type="time" class="field" id="intStart" value="${esc(d.interventionStart||'')}"></div><div><label class="label">Heure fin</label><input type="time" class="field" id="intEnd" value="${esc(d.interventionEnd||'')}"></div></div><div><label class="label">Nature / objet précis</label><input class="field" id="intNature" value="${esc(d.nature||d.interventionTitle||'')}"></div>${voiceField('intInspection','Constat / diagnostic',d.inspection||'')}${voiceField('intWork','Travaux réalisés',d.intervention||'')}${voiceField('intResult','Résultat / contrôle final',d.result||d.control||'')}${voiceField('intReco','Préconisations',d.recommendation||'')}<div><label class="label">Matériel / pièces utilisés</label><textarea class="field" id="intMaterials">${esc(d.materialsUsed||'')}</textarea></div><div><label class="label">Observations du client</label><textarea class="field" id="intClientObs">${esc(d.clientObservations||'')}</textarea></div><div><label class="label">Nom du signataire</label><input class="field" id="intSigner" value="${esc(d.clientSigner||d.clientName||'')}"></div><div class="int-form-sign-state">${sig}</div><div class="actions"><button class="btn primary" onclick="saveInterventionForm(${i},true)">Enregistrer la fiche</button><button class="btn" onclick="prepareInterventionSign(${i})">✍ Signature client</button></div><div class="actions"><button class="btn primary" onclick="saveAndPrintIntervention(${i})">📄 Créer le PDF</button>${d.kind==='FICHE'?`<button class="btn danger" onclick="deleteStandaloneIntervention63(${i})">Supprimer</button>`:`<button class="btn" onclick="closeModal();showDocument(${i})">Retour dossier</button>`}</div></div>`)}
saveInterventionForm=function(i,closeAfter=false){let a=docs(),d=a[i];if(!d)return false;let val=id=>document.getElementById(id)?.value??'';d.clientName=val('intClientName').trim()||d.clientName||'';d.clientAddress=val('intClientAddress').trim()||d.clientAddress||'';d.clientPhone=val('intClientPhone').trim()||d.clientPhone||'';d.clientRef=val('intClientRef').trim()||d.clientRef||'PART';d.jobType=val('intJobType')||d.jobType||'';d.date=val('intDate')||d.date||todayISO();d.interventionRef=d.interventionRef||interventionRef(d);d.invoiceNo=d.kind==='FICHE'?d.interventionRef:d.invoiceNo;d.interventionTech=val('intTech').trim()||'JKBat Services';d.interventionStart=val('intStart');d.interventionEnd=val('intEnd');d.nature=val('intNature').trim();d.interventionTitle=d.nature;d.inspection=val('intInspection').trim();d.intervention=val('intWork').trim();d.result=val('intResult').trim();d.recommendation=val('intReco').trim();d.materialsUsed=val('intMaterials').trim();d.clientObservations=val('intClientObs').trim();d.clientSigner=val('intSigner').trim();if(d.interventionStart&&d.interventionEnd){let [h1,m1]=d.interventionStart.split(':').map(Number),[h2,m2]=d.interventionEnd.split(':').map(Number),mins=(h2*60+m2)-(h1*60+m1);if(mins<0)mins+=1440;if(mins>=0){d.jobTimeMin=mins;d.duration=mins>=60?`${Math.floor(mins/60)} h ${String(mins%60).padStart(2,'0')}`:`${mins} min`}}d.status=d.signature?'SIGNÉE':'À SIGNER';d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);logActivity('INTERVENTION','Fiche intervention enregistrée',`${d.interventionRef} · ${d.clientName}`);saveAuto();renderAll();if(closeAfter){closeModal();toast('Fiche d’intervention enregistrée')}return true}
async function deleteStandaloneIntervention63(i){let d=docs()[i];if(!d||d.kind!=='FICHE')return;if(!await askConfirm6164('Supprimer cette fiche d’intervention ?'))return;let a=docs();a.splice(i,1);jset('jkbat_history',a);closeModal();renderAll();toast('Fiche supprimée')}
const _renderAll63Base=renderAll;renderAll=function(){_renderAll63Base();renderInterventionForms63();let q=$('#quickTools');if(q&&!q.querySelector('[data-int-form]'))q.insertAdjacentHTML('afterbegin','<button data-int-form="1" class="btn primary" onclick="openStandaloneIntervention()">📋 Fiche intervention</button>')}
fabAction=function(){haptic();openModal('Créer',`<div class="create-grid"><button class="create-tile primary-create" onclick="closeModal();openStandaloneIntervention()"><span>📋</span><b>Fiche intervention</b><small>Signature + PDF</small></button><button class="create-tile" onclick="closeModal();openExpress()"><span>⚡</span><b>Express</b><small>Dossier terrain</small></button><button class="create-tile" onclick="closeModal();openDocument(true)"><span>＋</span><b>Devis</b><small>Nouveau devis</small></button><button class="create-tile" onclick="closeModal();openDocument(true,{kind:'FACTURE'})"><span>€</span><b>Facture</b><small>Facturer</small></button><button class="create-tile" onclick="closeModal();openClient()"><span>◎</span><b>Client</b><small>Nouveau contact</small></button><button class="create-tile" onclick="closeModal();openAppointment()"><span>◫</span><b>Rendez-vous</b><small>Planifier</small></button></div>`)}

seed();migrate();applyBrandMigration();migrateV3();migrateV4();migrateV61();migrateV62();applyTheme();renderAll();dismissSplash();setTimeout(checkLock,100);


/* --- V6.4 FICHE HERO --- */
function interventionForms64(){return docs().filter(d=>d.kind==='FICHE')}
function renderInterventionHero64(){
 const a=interventionForms64(),today=todayISO(),todayN=a.filter(d=>d.date===today).length,open=a.filter(d=>!d.signature).length,signed=a.filter(d=>!!d.signature).length;
 const set=(id,v)=>{let e=document.getElementById(id);if(e)e.textContent=v};
 set('ficheHeroToday',todayN);set('ficheHeroOpen',open);set('ficheHeroSigned',signed);
 set('terrainFicheToday',`${todayN} aujourd’hui`);set('terrainFicheOpen',`${open} à signer`);set('terrainFicheSigned',`${signed} signée${signed>1?'s':''}`);
 let list=document.getElementById('interventionFormsList');
 if(list&&a.length===0)list.innerHTML=`<div class="fiche-empty-hero"><div class="big-icon">▤</div><h3>Ta première fiche est à un clic</h3><p>Crée-la, fais signer le client et génère le PDF directement.</p><button class="btn primary" onclick="openStandaloneIntervention()">＋ Commencer une fiche</button></div>`;
}
function goToFiches64(){go('terrain');setTimeout(()=>scrollToFiches64(),90)}
function scrollToFiches64(){let e=document.getElementById('ficheRecentSection')||document.getElementById('terrainFicheHero');if(e)e.scrollIntoView({behavior:'smooth',block:'start'})}
const _renderAll64Base=renderAll;renderAll=function(){_renderAll64Base();renderInterventionHero64()}

setTimeout(()=>{try{renderInterventionHero64()}catch(e){}},120);


/* --- V6.5 CHECK-LIST INTELLIGENTE + branding APK --- */
const JKBAT_INTERVENTION_THEMES={
 'PLOMBERIE':{color:'#2F6F9F',soft:'#EAF3F9',ink:'#FFFFFF'},
 'ÉLECTRICITÉ':{color:'#D9AD18',soft:'#FFF8D9',ink:'#1C1A12'},
 'PEINTURE':{color:'#A95F4F',soft:'#FAEEEB',ink:'#FFFFFF'},
 'SERRURERIE':{color:'#66717D',soft:'#EEF1F3',ink:'#FFFFFF'},
 'RÉNOVATION':{color:'#6C7E63',soft:'#EFF4EC',ink:'#FFFFFF'},
 'DÉPANNAGE DIVERS':{color:'#776B82',soft:'#F1EDF4',ink:'#FFFFFF'},
 '':{color:'#CC9447',soft:'#FBF4E8',ink:'#17130F'}
};
function interventionTheme65(v){let t=tradeById(v),k=t.id||'';return {...(JKBAT_INTERVENTION_THEMES[k]||JKBAT_INTERVENTION_THEMES['']),label:t.id?t.label:'Non catégorisé',id:k}}
function themeStyle65(v){let th=interventionTheme65(v);return `--int-trade:${th.color};--int-soft:${th.soft};--int-ink:${th.ink}`}
const _interventionSheetHtml65Base=interventionSheetHtml;
interventionSheetHtml=function(d){let h=_interventionSheetHtml65Base(d),st=themeStyle65(d?.jobType||'');return h.replaceAll('class="jk-doc-page intervention-sheet"',`class="jk-doc-page intervention-sheet" style="${st}"`)}
function applyInterventionFormTheme65(v){let th=interventionTheme65(v),el=document.getElementById('modalBody');if(!el)return;el.classList.add('int-form-themed');el.style.setProperty('--int-trade',th.color);el.style.setProperty('--int-soft',th.soft);el.style.setProperty('--int-ink',th.ink);let banner=el.querySelector('.ultimate-banner p');if(banner){let bits=banner.textContent.split('·');if(bits.length>1)banner.textContent=bits[0].trim()+' · '+th.label}}
const _openInterventionSheet65Base=openInterventionSheet;
openInterventionSheet=function(i){_openInterventionSheet65Base(i);let d=docs()[i];applyInterventionFormTheme65(d?.jobType||'');let sel=document.getElementById('intJobType');if(sel){sel.addEventListener('change',()=>applyInterventionFormTheme65(sel.value))}}
const _showPrintDoc65Base=showPrintDoc;
showPrintDoc=function(d,type='invoice'){_showPrintDoc65Base(d,type);let layer=document.getElementById('printLayer');if(!layer)return;if(type==='intervention'){let th=interventionTheme65(d?.jobType||'');layer.classList.add('int-trade-print');layer.style.setProperty('--int-trade',th.color);layer.style.setProperty('--int-ink',th.ink)}else{layer.classList.remove('int-trade-print');layer.style.removeProperty('--int-trade');layer.style.removeProperty('--int-ink')}}
function renderTradeLegend65(){let host=document.getElementById('terrainFicheHero');if(!host||document.getElementById('tradeLegend65'))return;host.insertAdjacentHTML('beforeend',`<div id="tradeLegend65" class="trade-color-legend">${JKBAT_TRADES.map(t=>{let th=interventionTheme65(t.id);return `<div class="trade-color-chip" style="--trade:${th.color}"><i></i><span><b>${esc(t.label)}</b><small>Fiche + PDF</small></span></div>`}).join('')}</div>`)}
const _renderAll65Base=renderAll;renderAll=function(){_renderAll65Base();renderTradeLegend65()}
setTimeout(()=>{try{renderTradeLegend65()}catch(e){}},180);



/* --- JKBat Pro 6.7 PHOTO FIX --- */
function goInvoices66(){go('documents');setTimeout(()=>{let f=document.getElementById('docFilter');if(f){f.value='FACTURE';renderDocs()}let t=document.getElementById('documentsTitle66');if(t)t.textContent='Factures';},30)}
function goAllDocuments66(){go('documents');setTimeout(()=>{let f=document.getElementById('docFilter');if(f){f.value='';renderDocs()}let t=document.getElementById('documentsTitle66');if(t)t.textContent='Tous les documents';},30)}

// Dictée: priorité au moteur Android natif. Le Web Speech reste un secours navigateur.
window.__jkSpeechTarget='';
function jkbatReceiveSpeech(text){let id=window.__jkSpeechTarget,el=id&&document.getElementById(id);if(el&&text){el.value=(el.value?el.value.trim()+' ':'')+String(text).trim();el.dispatchEvent(new Event('input',{bubbles:true}));toast('Dictée ajoutée')}else if(!text)toast('Aucun texte reconnu');window.__jkSpeechTarget=''}
dictateTo=function(id){window.__jkSpeechTarget=id;try{location.href='jkbatspeech://start';toast('Dictée Android…');return}catch(e){}let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return toast('Dictée indisponible');let r=new SR();r.lang='fr-FR';r.interimResults=false;r.maxAlternatives=1;r.onresult=e=>jkbatReceiveSpeech(e.results[0][0].transcript);r.onerror=()=>toast('Dictée interrompue');r.start();toast('Parle…')}
voiceField=function(id,label,value=''){return `<div><div class="row-between"><label class="label">${esc(label)}</label><button class="btn small voice-native" type="button" onclick="dictateTo('${id}')">🎙 Dictée Android</button></div><textarea class="field" id="${id}">${esc(value)}</textarea><div class="voice-state">Le texte dicté s’ajoute à ce champ.</div></div>`}

function intPhone66(d){return cleanPhone(d?.clientPhone||'')}
function intMap66(d){return d?.clientAddress?mapHref(d.clientAddress):''}
function intQuickActions66(d){let p=intPhone66(d),m=intMap66(d);return `<div class="int-quick-actions">${p?`<a class="int-quick-action primary" href="tel:${p}"><span>☎</span>Appeler</a><a class="int-quick-action" href="sms:${p}"><span>✉</span>SMS</a>`:`<div class="int-quick-action"><span>☎</span>Sans téléphone</div><div class="int-quick-action"><span>✉</span>Sans SMS</div>`}${m?`<a class="int-quick-action" href="${m}"><span>➤</span>Itinéraire</a>`:`<div class="int-quick-action"><span>➤</span>Sans adresse</div>`}</div>`}

function migrateV66(){if(LS.getItem('jkbat_v66_migrated'))return;let a=docs(),changed=false;a=a.map(d=>{if(!Array.isArray(d.beforePhotos)){d.beforePhotos=[];changed=true}if(!Array.isArray(d.afterPhotos)){d.afterPhotos=[];changed=true}if(d.kind==='FICHE'&&Array.isArray(d.photos)&&d.photos.length&&!d.beforePhotos.length&&!d.afterPhotos.length){d.afterPhotos=d.photos.filter(Boolean);changed=true}return d});if(changed)jset('jkbat_history',a);LS.setItem('jkbat_v66_migrated','1')}
function intPhotoGrid66(i,which){let d=docs()[i],arr=which==='before'?(d.beforePhotos||[]):(d.afterPhotos||[]);return arr.length?`<div class="int-photo-grid">${arr.map((p,n)=>`<div class="int-photo-thumb"><img src="${p}"><button type="button" onclick="removeInterventionPhoto66(${i},'${which}',${n})">×</button></div>`).join('')}</div>`:`<div class="int-photo-empty">Aucune photo ${which==='before'?'avant':'après'}.</div>`}
function intPhotoSection66(i,which){let d=docs()[i],arr=which==='before'?(d.beforePhotos||[]):(d.afterPhotos||[]),lab=which==='before'?'AVANT':'APRÈS';return `<div class="int-photo-section"><div class="int-photo-title"><b>📷 Photos ${lab}</b><small>${arr.length}/10</small></div><div class="int-photo-actions"><label class="btn file-label">🖼 Galerie (plusieurs)<input type="file" accept="image/*" multiple onchange="addInterventionPhotos66(${i},'${which}',this.files);this.value=''" /></label></div><div id="intPhotos_${which}_${i}">${intPhotoGrid66(i,which)}</div></div>`}
async function addInterventionPhotos66(i,which,files){if(!files||!files.length)return;let a=docs(),d=a[i];if(!d)return;let key=which==='before'?'beforePhotos':'afterPhotos',cur=Array.isArray(d[key])?d[key]:[],room=Math.max(0,10-cur.length);if(!room)return toast('Maximum 10 photos par partie');let list=[...files].slice(0,room);toast(`Ajout de ${list.length} photo(s)…`);try{let imgs=[];for(let f of list)imgs.push(await resizeImage(f,1000,.72));d[key]=[...cur,...imgs];d.workflow={...(d.workflow||{}),[which]:d[key].length>0};d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);saveAuto();let host=document.getElementById(`intPhotos_${which}_${i}`);if(host)host.innerHTML=intPhotoGrid66(i,which);toast(`${imgs.length} photo(s) ajoutée(s)`)}catch(e){toast('Impossible de lire une des photos')}}
function removeInterventionPhoto66(i,which,n){let a=docs(),d=a[i];if(!d)return;let key=which==='before'?'beforePhotos':'afterPhotos';d[key]=Array.isArray(d[key])?d[key]:[];d[key].splice(n,1);d.workflow={...(d.workflow||{}),[which]:d[key].length>0};a[i]=d;jset('jkbat_history',a);saveAuto();let host=document.getElementById(`intPhotos_${which}_${i}`);if(host)host.innerHTML=intPhotoGrid66(i,which)}

function interventionPhotoPages66(d){let pages=[],mk=(arr,title)=>{arr=Array.isArray(arr)?arr.filter(Boolean):[];for(let off=0;off<arr.length;off+=4){let part=arr.slice(off,off+4),th=interventionTheme65(d.jobType||'');pages.push(`<div class="jk-doc-page intervention-sheet photo-doc-page" style="${themeStyle65(d.jobType||'')}"><div class="int-head"><img class="jk-logo-img int-logo" src="${company().logo||'jkbat-logo.png'}"><div class="int-title-wrap"><div class="int-kicker">JKBat Services · photos chantier</div><div class="int-ref">${esc(interventionRef(d))} · ${esc(d.clientName||'')}</div></div></div><div class="int-gold-line"></div><div class="photo-doc-title">${title}</div><div class="photo-doc-grid">${part.map((p,n)=>`<figure><img src="${p}"><figcaption>${title.replace('PHOTOS ','')} · photo ${off+n+1}</figcaption></figure>`).join('')}</div><div class="int-footer"><span>${esc(company().name)} · ${esc(company().phone)}</span><span>${esc(interventionRef(d))} · photos</span></div></div>`)} };mk(d.beforePhotos,'PHOTOS AVANT INTERVENTION');mk(d.afterPhotos,'PHOTOS APRÈS INTERVENTION');return pages.join('')}
const _interventionSheetHtml66Base=interventionSheetHtml;
interventionSheetHtml=function(d){return _interventionSheetHtml66Base(d)+interventionPhotoPages66(d)}

openInterventionSheet=function(i){let d=docs()[i];if(!d)return toast('Fiche introuvable');let sig=d.signature?`<img src="${d.signature}"><div><span class="signed-ok">✓ Signé</span><div class="muted">${esc(d.clientSigner||d.clientName||'')}${d.signedAt?' · '+esc(new Date(d.signedAt).toLocaleString('fr-FR')):''}</div></div>`:`<div><span class="unsigned">Signature client à recueillir</span><div class="muted">Signature au doigt directement sur le téléphone.</div></div>`;openModal('Fiche d’intervention',`<div class="form"><div class="ultimate-banner"><b>📋 ${esc(interventionRef(d))}</b><p>${esc(d.clientName||'')} · ${esc(tradeOfDoc(d).label)}</p></div>${intQuickActions66(d)}<div><label class="label">Client</label><input class="field" id="intClientName" value="${esc(d.clientName||'')}"></div><div><label class="label">Adresse du chantier</label><textarea class="field" id="intClientAddress">${esc(d.clientAddress||'')}</textarea></div><div class="form two"><div><label class="label">Téléphone</label><input class="field" id="intClientPhone" value="${esc(d.clientPhone||'')}"></div><div><label class="label">Réf. client</label><input class="field" id="intClientRef" value="${esc(d.clientRef||'PART')}"></div></div><div class="form two"><div><label class="label">Métier</label><select class="field" id="intJobType">${tradeSelectOptions(d.jobType||'')}</select></div><div><label class="label">Date</label><input type="date" class="field" id="intDate" value="${esc(d.date||todayISO())}"></div></div><div><label class="label">Technicien</label><input class="field" id="intTech" value="${esc(d.interventionTech||'JKBat Services')}"></div><div class="form two"><div><label class="label">Heure début</label><input type="time" class="field" id="intStart" value="${esc(d.interventionStart||'')}"></div><div><label class="label">Heure fin</label><input type="time" class="field" id="intEnd" value="${esc(d.interventionEnd||'')}"></div></div><div><label class="label">Nature / objet précis</label><input class="field" id="intNature" value="${esc(d.nature||d.interventionTitle||'')}"></div>${voiceField('intInspection','Constat / diagnostic',d.inspection||'')}${voiceField('intWork','Travaux réalisés',d.intervention||'')}${voiceField('intResult','Résultat / contrôle final',d.result||d.control||'')}${voiceField('intReco','Préconisations',d.recommendation||'')}${intPhotoSection66(i,'before')}${intPhotoSection66(i,'after')}<div><label class="label">Matériel / pièces utilisés</label><textarea class="field" id="intMaterials">${esc(d.materialsUsed||'')}</textarea></div><div><label class="label">Observations du client</label><textarea class="field" id="intClientObs">${esc(d.clientObservations||'')}</textarea></div><div><label class="label">Nom du signataire</label><input class="field" id="intSigner" value="${esc(d.clientSigner||d.clientName||'')}"></div><div class="int-form-sign-state">${sig}</div><div class="actions"><button class="btn primary" onclick="saveInterventionForm(${i},true)">Enregistrer la fiche</button><button class="btn" onclick="prepareInterventionSign(${i})">✍ Signature client</button></div><div class="actions"><button class="btn primary" onclick="saveAndPrintIntervention(${i})">📄 Créer le PDF</button>${d.kind==='FICHE'?`<button class="btn danger" onclick="deleteStandaloneIntervention63(${i})">Supprimer</button>`:`<button class="btn" onclick="closeModal();showDocument(${i})">Retour dossier</button>`}</div></div>`);applyInterventionFormTheme65(d.jobType||'');let sel=document.getElementById('intJobType');if(sel)sel.addEventListener('change',()=>applyInterventionFormTheme65(sel.value))}

// L'onglet Factures doit rester filtré après les rendus globaux.
const _renderAll66Base=renderAll;renderAll=function(){_renderAll66Base();let t=document.getElementById('documentsTitle66');let f=document.getElementById('docFilter');if(currentScreen==='documents'&&f?.value==='FACTURE'&&t)t.textContent='Factures'}
migrateV66();renderAll();


/* --- JKBat Pro 6.8 GALERIE + FACTURE CLIENT --- */
function reportPhaseArray68(index){
  if(!_editingDoc)return [];
  let key=index===0?'beforePhotos':'afterPhotos';
  if(!Array.isArray(_editingDoc[key])){
    let legacy=(_editingDoc.photos||[])[index];
    _editingDoc[key]=legacy?[legacy]:[];
  }
  return _editingDoc[key];
}
function syncReportPrimary68(index){
  if(!_editingDoc)return;
  let arr=reportPhaseArray68(index);
  _editingDoc.photos=_editingDoc.photos||[];
  _editingDoc.photos[index]=arr[0]||'';
}
async function addReportPhotos68(files,index){
  if(!files||!files.length)return;
  let arr=reportPhaseArray68(index), room=Math.max(0,10-arr.length);
  if(!room)return toast('Maximum 10 photos par partie');
  let list=[...files].slice(0,room);
  toast(`Ajout de ${list.length} photo(s)…`);
  try{
    let imgs=[];
    for(let f of list) imgs.push(await resizeImage(f,1100,.76));
    let key=index===0?'beforePhotos':'afterPhotos';
    _editingDoc[key]=[...arr,...imgs].slice(0,10);
    syncReportPrimary68(index);
    renderPhotoEditor();
    scheduleDraft();
    toast(`${imgs.length} photo(s) ajoutée(s)`);
  }catch(e){toast('Impossible de lire une des photos')}
}
function removeReportPhoto68(index,n){
  let key=index===0?'beforePhotos':'afterPhotos',arr=reportPhaseArray68(index);
  arr.splice(n,1);_editingDoc[key]=arr;syncReportPrimary68(index);renderPhotoEditor();scheduleDraft();
}
function reportThumbs68(index){
  let arr=reportPhaseArray68(index);
  if(!arr.length)return '<div class="int-photo-empty" style="margin-top:9px">Aucune photo.</div>';
  return `<div class="report-photo-strip68">${arr.map((p,n)=>`<div class="report-photo-thumb68"><img src="${p}"><button type="button" onclick="removeReportPhoto68(${index},${n})">×</button></div>`).join('')}</div><div class="report-photo-count68">${arr.length}/10 · toutes les photos seront intégrées au rapport PDF</div>`;
}
renderPhotoEditor=function(){
  let el=document.getElementById('photoEditor');if(!el)return;
  let slot=(idx,title)=>{let arr=reportPhaseArray68(idx),main=arr[0]||'';return `<div class="photo-slot"><b>${title}</b><div class="photo" style="margin-top:8px">${main?`<img src="${main}">`:`<img src="jkbat-logo.png" style="object-fit:contain;background:#fff;padding:15px;opacity:.55">`}</div><div class="report-photo-actions68"><label class="btn file-label">🖼 Galerie (plusieurs)<input type="file" accept="image/*" multiple onchange="addReportPhotos68(this.files,${idx});this.value=''" /></label></div>${reportThumbs68(idx)}</div>`};
  el.innerHTML=`<div class="photo-pair-editor">${slot(0,'AVANT INTERVENTION')}${slot(1,'APRÈS INTERVENTION')}</div>`;
}
// Synchronise aussi les anciennes API de photo rapport avec la nouvelle galerie.
setReportPhoto=function(files,index){addReportPhotos68(files,index)};
removeReportPhoto=function(index){let key=index===0?'beforePhotos':'afterPhotos';_editingDoc[key]=[];syncReportPrimary68(index);renderPhotoEditor();scheduleDraft()};

// Fiche client: ajoute une création de facture explicite et préremplie.
showClient=function(i){
  let c=clients()[i],p=cleanPhone(c.phone),ds=docs().filter(d=>(c.id&&d.clientId===c.id)||String(d.clientName||'').toLowerCase()===String(c.name||'').toLowerCase()),inv=ds.filter(d=>d.kind==='FACTURE'),billed=inv.reduce((s,d)=>s+calc(d).total,0),paid=inv.reduce((s,d)=>s+paidAmount(d),0),ts=clientTrades(c);
  openModal(c.name||'Client',`<div class="card"><div class="row"><div class="avatar">${esc((c.name||'?').slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(c.name||'')}</b><div class="muted">${esc(c.address||'Adresse non renseignée').replace(/\n/g,'<br>')}</div><div class="trade-client-meta">${ts.length?ts.map(tradeBadge).join(''):tradeBadge('')}</div></div></div><div class="client-kpis"><div><span class="tiny">Facturé</span><b>${euro(billed)}</b></div><div><span class="tiny">Encaissé</span><b>${euro(paid)}</b></div><div><span class="tiny">Reste</span><b>${euro(Math.max(0,billed-paid))}</b></div></div><div class="actions">${p?`<a class="btn primary" href="tel:${p}">Appeler</a><a class="btn" href="sms:${p}">SMS</a>`:''}${c.email?`<a class="btn" href="mailto:${encodeURIComponent(c.email)}">E-mail</a>`:''}${c.address?`<a class="btn" href="${mapHref(c.address)}">Navigation</a>`:''}</div></div><div class="client-create-actions68"><button class="btn primary" onclick="closeModal();openClientTradeAction(${i})">＋ Intervention</button><button class="btn invoice68" onclick="closeModal();openDocument(true,{kind:'FACTURE'},${i})">€ Créer une facture</button><button class="btn" onclick="closeModal();openDocument(true,null,${i})">＋ Créer un devis</button><button class="btn" onclick="closeModal();openAppointment(null,${i})">◫ Créer un RDV</button></div><div class="actions"><button class="btn ghost" onclick="closeModal();openClient(${i})">Modifier le client</button></div><div class="section-title"><h3>Historique métier</h3><span>${ds.length} document(s)</span></div><div class="cards">${ds.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,8).map(d=>{let di=docs().findIndex(x=>x.id===d.id);return `<div class="card compact trade-card" style="--trade:${tradeOfDoc(d).color}" onclick="showDocument(${di})"><div class="row"><div class="grow"><b>${esc(d.invoiceNo||d.kind)}</b><div class="muted">${fmtDate(d.date)} · ${euro(calc(d).total)}</div></div>${tradeBadge(d.jobType)}</div></div>`}).join('')||'<div class="empty">Aucun document.</div>'}</div>`);
}

// Libellé galerie explicite dans la fiche d'intervention.
const _intPhotoSection68Base=intPhotoSection66;
intPhotoSection66=function(i,which){
  let html=_intPhotoSection68Base(i,which);
  return html.replace('＋ Plusieurs photos','🖼 Galerie (plusieurs)');
}


/* --- JKBat Pro 6.9 : toutes les photos dans le rapport + couleur catégorie --- */
function reportTheme69(d){let th=interventionTheme65(d?.jobType||'');return {color:th.color||'#CC9447',soft:th.soft||'#FBF4E8',ink:th.ink||'#17130F',label:th.label||'Non catégorisé'} }
function reportThemeStyle69(d){let th=reportTheme69(d);return `--report-trade:${th.color};--report-soft:${th.soft};--report-ink:${th.ink}`}
function reportPhotos69(d,which){
 let key=which==='before'?'beforePhotos':'afterPhotos',idx=which==='before'?0:1;
 let arr=Array.isArray(d?.[key])?d[key].filter(Boolean):[];
 // Compatibilité avec les anciens documents à une seule photo AVANT / APRÈS.
 if(!arr.length&&Array.isArray(d?.photos)&&d.photos[idx])arr=[d.photos[idx]];
 return arr.slice(0,10);
}
function reportPhotoChunks69(arr){if(!arr.length)return [[]];let out=[];for(let i=0;i<arr.length;i+=4)out.push(arr.slice(i,i+4));return out}
function reportPhotoPage69(d,phase,chunk,chunkIndex,chunkTotal,pageNo,totalPages){
 let th=reportTheme69(d),title=phase==='before'?'AVANT INTERVENTION':'APRÈS INTERVENTION',phaseLabel=phase==='before'?'Avant':'Après';
 let content=chunk.length?`<div class="report-photo-grid69 count-${chunk.length}">${chunk.map((src,n)=>`<figure class="report-photo-card69"><img src="${src}"><figcaption>${phaseLabel} · photo ${chunkIndex*4+n+1}${chunkTotal>1?' · série '+(chunkIndex+1)+'/'+chunkTotal:''}</figcaption></figure>`).join('')}</div>`:`<div class="report-photo-empty69"><img src="${company().logo||'jkbat-logo.png'}"><b>Aucune photo ${phase==='before'?'avant':'après'} enregistrée</b></div>`;
 return `<div class="jk-doc-page report-page report-themed69 report-photo-page69" style="${reportThemeStyle69(d)}"><div class="report-photo-title">${title}</div><div class="report-photo-trade69"><span>${esc(th.label)}</span></div><div class="report-photo-rule69"></div>${content}<div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page ${pageNo} / ${totalPages}</span></div></div>`;
}
reportHtml=function(d){
 let c=company(),th=reportTheme69(d),dur=esc(d.duration||'Intervention réalisée selon les constatations du rapport.'),before=reportPhotos69(d,'before'),after=reportPhotos69(d,'after'),beforeChunks=reportPhotoChunks69(before),afterChunks=reportPhotoChunks69(after),totalPages=2+beforeChunks.length+afterChunks.length,page=1;
 let p1=`<div class="jk-doc-page report-page report-themed69" style="${reportThemeStyle69(d)}"><img class="jk-logo-img report-logo-top" src="${c.logo||'jkbat-logo.png'}"><div class="report-title-wrap"><div class="report-title">RAPPORT D’INTERVENTION</div><div class="report-subtitle">Compte rendu d’intervention</div><div class="report-trade-chip">${esc(th.label)}</div></div><table class="report-info"><tr><td class="lab">CLIENT</td><td>${esc(d.clientName||'')}</td><td class="lab">DATE</td><td>${fmtDate(d.date)}</td></tr><tr><td class="lab">LIEU</td><td>${esc(d.clientAddress||'')}</td><td class="lab">RÉFÉRENCE</td><td>${esc(d.invoiceNo||interventionRef(d)||'')}</td></tr></table><div class="report-section"><h2>Constat initial</h2><p>${esc(d.inspection||'').replace(/\n/g,'<br>')}</p></div><div class="report-section"><h2>Travaux réalisés</h2><p>${esc(d.intervention||'').replace(/\n/g,'<br>')}</p></div><div class="report-section"><h2>Résultat</h2><div class="result-box"><p>${esc(d.result||d.control||'').replace(/\n/g,'<br>')}</p></div></div><div class="report-preco"><b>Préconisation :</b> ${esc(d.recommendation||'')}</div><div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page ${page++} / ${totalPages}</span></div></div>`;
 let photos='';beforeChunks.forEach((chunk,i)=>{photos+=reportPhotoPage69(d,'before',chunk,i,beforeChunks.length,page++,totalPages)});afterChunks.forEach((chunk,i)=>{photos+=reportPhotoPage69(d,'after',chunk,i,afterChunks.length,page++,totalPages)});
 let synth=`<div class="jk-doc-page report-page report-themed69" style="${reportThemeStyle69(d)}"><div class="report-synth-title">SYNTHÈSE D’INTERVENTION</div><div class="report-synth-trade69"><span>${esc(th.label)}</span></div><table class="report-synth"><thead><tr><th>Opération</th><th>Constat / résultat</th></tr></thead><tbody><tr><td>Constat / inspection</td><td>${esc(d.inspection||'')}</td></tr><tr><td>Travaux réalisés</td><td>${esc(d.intervention||'')}</td></tr><tr><td>Éléments accessibles</td><td>${esc(d.control||'')}</td></tr><tr><td>Contrôle final</td><td>${esc(d.result||'')}</td></tr><tr><td>Durée</td><td>${dur}</td></tr></tbody></table><div class="report-company-block"><h2>JKBat’ Services</h2>${esc(c.address).replace(/\n/g,'<br>')}<br>SIRET : ${esc(c.siret)}<br>Tél. : ${esc(c.phone)} - Mail : ${esc(c.email)}</div><div class="report-note">Rapport établi à partir des constatations réalisées lors de l’intervention et des photographies fournies.</div><div class="report-footer"><span>JKBat Services - Rapport d’intervention</span><span>Page ${page} / ${totalPages}</span></div></div>`;
 return p1+photos+synth;
}


/* --- JKBat Pro 6.11 DOCUMENTS + PHOTOS --- */
function docKindLabel610(k){return k==='FACTURE'?'Factures':k==='DEVIS'?'Devis':k==='FICHE'?'Fiches':'Documents'}
function docCounts610(){let a=docs();return {FACTURE:a.filter(d=>d.kind==='FACTURE').length,DEVIS:a.filter(d=>d.kind==='DEVIS').length,FICHE:a.filter(d=>d.kind==='FICHE').length}}
function ensureDocsHub610(){
  let sec=document.getElementById('documents');if(!sec)return;
  let search=sec.querySelector('.search');if(!search)return;
  let hub=document.getElementById('docsHub610');
  if(!hub){hub=document.createElement('div');hub.id='docsHub610';hub.className='docs-hub610';search.parentNode.insertBefore(hub,search)}
  let c=docCounts610(),f=document.getElementById('docFilter')?.value||'';
  hub.innerHTML=['FACTURE','DEVIS','FICHE'].map(k=>`<button class="${f===k?'active':''}" onclick="goDocs610('${k}')">${k==='FACTURE'?'€ Factures':k==='DEVIS'?'＋ Devis':'▤ Fiches'}<small>${c[k]} enregistré${c[k]>1?'s':''}</small></button>`).join('');
  let hint=document.getElementById('docsFind610');
  if(!hint){hint=document.createElement('div');hint.id='docsFind610';hint.className='docs-find610';search.parentNode.insertBefore(hint,search.nextSibling)}
  hint.innerHTML=`<div style="font-size:22px">📁</div><div><b>${docKindLabel610(f||'')}</b><span>Tout ce que tu enregistres reste ici. Utilise les 3 onglets ci-dessus.</span></div>`;
}
function goDocs610(kind='FACTURE',focusId=''){
  go('documents');
  setTimeout(()=>{let f=document.getElementById('docFilter');if(f)f.value=kind||'';let t=document.getElementById('documentsTitle66');if(t)t.textContent=docKindLabel610(kind);renderDocs();ensureDocsHub610();
    if(focusId){let node=document.querySelector(`[data-doc610="${CSS.escape(String(focusId))}"]`);if(node){node.classList.add('saved-flash610');node.scrollIntoView({block:'center',behavior:'smooth'})}}
  },45)
}
goInvoices66=function(){goDocs610('FACTURE')};
goAllDocuments66=function(){go('documents');setTimeout(()=>{let f=document.getElementById('docFilter');if(f)f.value='';let t=document.getElementById('documentsTitle66');if(t)t.textContent='Tous les documents';renderDocs();ensureDocsHub610()},45)};

// Wrap cards with a stable id so a newly saved document can be highlighted.
const _docCard610Base=docCard;
docCard=function(d,i){let html=_docCard610Base(d,i);return html.replace('class="card ',`data-doc610="${esc(d.id||'')}" class="card `)};

// Safer JPEG compression for local offline storage. 20 chantier photos remain practical.
function resizeImage610(file,max=760,q=.58){return new Promise((resolve,reject)=>{
  if(!file)return reject(new Error('no file'));let url='';
  let done=src=>{let img=new Image();img.onload=()=>{try{let scale=Math.min(1,max/Math.max(img.naturalWidth||img.width,img.naturalHeight||img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round((img.naturalWidth||img.width)*scale));c.height=Math.max(1,Math.round((img.naturalHeight||img.height)*scale));c.getContext('2d',{alpha:false}).drawImage(img,0,0,c.width,c.height);let out=c.toDataURL('image/jpeg',q);if(url)URL.revokeObjectURL(url);resolve(out)}catch(e){reject(e)}};img.onerror=e=>{if(url)URL.revokeObjectURL(url);reject(e)};img.src=src};
  try{url=URL.createObjectURL(file);done(url)}catch(e){let r=new FileReader();r.onload=x=>done(x.target.result);r.onerror=reject;r.readAsDataURL(file)}
})}

function persistEditingPhotos610(){
  if(!_editingDoc?.id)return true;let a=docs(),i=a.findIndex(x=>x.id===_editingDoc.id);if(i<0)return true;
  let p=Array.isArray(_editingDoc.photos)?_editingDoc.photos.slice(0,2):[];
  a[i]={...a[i],beforePhotos:Array.isArray(_editingDoc.beforePhotos)?_editingDoc.beforePhotos.slice(0,10):[],afterPhotos:Array.isArray(_editingDoc.afterPhotos)?_editingDoc.afterPhotos.slice(0,10):[],photos:p,savedAt:new Date().toISOString()};
  try{jset('jkbat_history',a);return true}catch(e){toast('Stockage photos saturé : retire quelques photos');return false}
}
async function addReportPhotos610(files,index){
  if(!files||!files.length)return;let arr=reportPhaseArray68(index),room=Math.max(0,10-arr.length);if(!room)return toast('Maximum 10 photos par partie');
  let list=Array.from(files).slice(0,room);toast(`Chargement de ${list.length} photo(s)…`);
  try{let imgs=[];for(let f of list){let img=await resizeImage610(f);if(img)imgs.push(img)};let key=index===0?'beforePhotos':'afterPhotos';_editingDoc[key]=[...arr,...imgs].slice(0,10);syncReportPrimary68(index);persistEditingPhotos610();renderPhotoEditor();scheduleDraft610();toast(`${imgs.length} photo(s) intégrée(s) au rapport`)}catch(e){console.error(e);toast('Photo illisible : essaie une autre image')}
}
function scheduleDraft610(){clearTimeout(_draftTimer);_draftTimer=setTimeout(()=>{if(!document.getElementById('dKind'))return;let d=editingDoc();_editingDoc={...d};let slim={...d,beforePhotos:[],afterPhotos:[],photos:[]};try{LS.setItem('jkbat_invoice_pwa',JSON.stringify(slim))}catch(e){}saveAuto()},250)}
addReportPhotos68=addReportPhotos610;setReportPhoto=function(files,index){addReportPhotos610(files,index)};

// Same robust photo loader on a saved intervention fiche.
addInterventionPhotos66=async function(i,which,files){
  if(!files||!files.length)return;let a=docs(),d=a[i];if(!d)return;let key=which==='before'?'beforePhotos':'afterPhotos',cur=Array.isArray(d[key])?d[key]:[],room=Math.max(0,10-cur.length);if(!room)return toast('Maximum 10 photos par partie');let list=Array.from(files).slice(0,room);toast(`Chargement de ${list.length} photo(s)…`);
  try{let imgs=[];for(let f of list)imgs.push(await resizeImage610(f));d[key]=[...cur,...imgs].slice(0,10);d.photos=Array.isArray(d.photos)?d.photos:[];d.photos[which==='before'?0:1]=d[key][0]||'';d.workflow={...(d.workflow||{}),[which]:d[key].length>0};d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);saveAuto();let host=document.getElementById(`intPhotos_${which}_${i}`);if(host)host.innerHTML=intPhotoGrid66(i,which);toast(`${imgs.length} photo(s) intégrée(s)`) }catch(e){console.error(e);toast('Impossible de charger une photo')}
};

// If a report is opened from a devis/facture, recover photos from the linked / nearest intervention fiche.
function relatedPhotoDoc610(d){
  let all=docs().filter(x=>x.id!==d.id),same=x=>(d.clientId&&x.clientId===d.clientId)||String(x.clientName||'').trim().toLowerCase()===String(d.clientName||'').trim().toLowerCase();
  let candidates=all.filter(x=>same(x)&&((x.beforePhotos||[]).length||(x.afterPhotos||[]).length));if(!candidates.length)return null;
  candidates.sort((a,b)=>{let sa=(a.parentId===d.id||d.parentId===a.id?100:0)+(a.date===d.date?30:0)+(a.kind==='FICHE'?20:0),sb=(b.parentId===d.id||d.parentId===b.id?100:0)+(b.date===d.date?30:0)+(b.kind==='FICHE'?20:0);if(sa!==sb)return sb-sa;return String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date))});return candidates[0]
}
reportPhotos69=function(d,which){let key=which==='before'?'beforePhotos':'afterPhotos',idx=which==='before'?0:1,arr=Array.isArray(d?.[key])?d[key].filter(Boolean):[];if(!arr.length&&Array.isArray(d?.photos)&&d.photos[idx])arr=[d.photos[idx]];if(!arr.length){let src=relatedPhotoDoc610(d);if(src)arr=Array.isArray(src[key])?src[key].filter(Boolean):[]}return arr.slice(0,10)};

function photoHealth610(d){let b=reportPhotos69(d,'before').length,a=reportPhotos69(d,'after').length;return `<div class="report-photo-health610 ${b||a?'ok':''}">📷 Rapport : ${b} photo(s) avant · ${a} photo(s) après${(b||a)?' · prêtes pour le PDF':''}</div>`}

// Save -> land directly where the document is stored. No more guessing.
saveDocument=function(){
  let d=editingDoc();if(!d.invoiceNo)return toast('Numéro requis');if(!d.clientName)return toast('Client requis');let c=clients().find(x=>String(x.name||'').toLowerCase()===d.clientName.toLowerCase());if(c)d.clientId=c.id||'';
  if(d.kind==='FACTURE'&&!d.dueDate)d.dueDate=addDaysISO(d.date,LS.getItem('jkbat_default_due_days'));if(d.kind==='DEVIS'&&!d.validUntil)d.validUntil=addDaysISO(d.date,LS.getItem('jkbat_default_quote_days'));if(d.status==='PAYÉ'){d.amountPaid=calc(d).total;if(!d.paidDate)d.paidDate=todayISO()}else if(d.kind==='FACTURE'&&d.amountPaid>0&&d.amountPaid<calc(d).total&&d.status==='BROUILLON')d.status='PARTIEL';
  d.beforePhotos=Array.isArray(_editingDoc?.beforePhotos)?_editingDoc.beforePhotos.slice(0,10):(d.beforePhotos||[]);d.afterPhotos=Array.isArray(_editingDoc?.afterPhotos)?_editingDoc.afterPhotos.slice(0,10):(d.afterPhotos||[]);d.photos=[d.beforePhotos[0]||d.photos?.[0]||'',d.afterPhotos[0]||d.photos?.[1]||''];d.savedAt=new Date().toISOString();let a=docs(),i=a.findIndex(x=>x.id===d.id),created=i<0;if(i>=0)a[i]=d;else a.push(d);
  try{jset('jkbat_history',a)}catch(e){return toast('Stockage plein : retire quelques photos avant d’enregistrer')}
  try{LS.setItem('jkbat_invoice_pwa','{}')}catch(e){}commitSeq(d);logActivity('DOCUMENT',created?'Document créé':'Document modifié',`${d.invoiceNo} · ${d.clientName} · ${euro(calc(d).total)}`);saveAuto();closeModal();renderAll();goDocs610(d.kind,d.id);toast(`${d.kind==='FACTURE'?'Facture':d.kind==='DEVIS'?'Devis':'Fiche'} enregistrée · retrouvée dans Documents > ${docKindLabel610(d.kind)}`)
};

// Keep hub/counts refreshed and expose photo counts on document cards.
const _renderDocs610Base=renderDocs;renderDocs=function(){_renderDocs610Base();ensureDocsHub610()};
const _showDocument610Base=showDocument;showDocument=function(i){_showDocument610Base(i);setTimeout(()=>{let body=document.getElementById('modalBody'),d=docs()[i];if(body&&d){let el=document.createElement('div');el.innerHTML=photoHealth610(d);let actions=body.querySelector('.actions');if(actions)body.insertBefore(el,actions);else body.appendChild(el)}},20)};

setTimeout(()=>{ensureDocsHub610()},120);


/* --- JKBat Pro 6.11 PREVIEW + STARTUP SOUND --- */
let _previewReturn611=null;
function previewDocTitle611(type,d){if(type==='report')return `Aperçu du rapport · ${d?.clientName||''}`;if(type==='intervention')return `Aperçu de la fiche · ${d?.clientName||''}`;return `Aperçu du document`}
function showPreview611(d,type='report',returnFn=null){
  if(!d)return toast('Document introuvable');
  _previewReturn611=returnFn||null;
  closeModal();
  let body=type==='report'?reportHtml(d):type==='intervention'?interventionSheetHtml(d):invoiceHtml(d);
  let label=type==='report'?'rapport d’intervention':type==='intervention'?'fiche d’intervention':'document';
  document.getElementById('printLayer').innerHTML=`<div class="preview-toolbar611"><button class="btn" onclick="exitPreview611()">← Retour</button><div class="preview-title611"><b>${esc(previewDocTitle611(type,d))}</b><span>Vérifie le rendu avant de créer ou imprimer le PDF.</span></div><button class="btn primary" onclick="triggerPrint()">📄 Créer PDF / Imprimer</button></div><div class="preview-info611">👁 Mode aperçu · rien n’est imprimé tant que tu n’appuies pas sur <b>Créer PDF / Imprimer</b>.</div>${body}`;
  document.body.classList.add('print-mode','preview-mode611');window.scrollTo(0,0)
}
function exitPreview611(){document.body.classList.remove('print-mode','preview-mode611');document.getElementById('printLayer').innerHTML='';let cb=_previewReturn611;_previewReturn611=null;if(typeof cb==='function')setTimeout(cb,30)}
function previewIntervention611(i,fromForm=false){if(fromForm&&!saveInterventionForm(i,false))return;let d=docs()[i];showPreview611(d,'intervention',()=>openInterventionSheet(i))}
function previewReport611(i,fromForm=false){if(fromForm&&!saveInterventionForm(i,false))return;let d=docs()[i];showPreview611(d,'report',()=>d?.kind==='FICHE'?openInterventionSheet(i):showDocument(i))}

// La fiche passe toujours par l'aperçu avant le système d'impression Android.
const _openInterventionSheet611Base=openInterventionSheet;
openInterventionSheet=function(i){_openInterventionSheet611Base(i);setTimeout(()=>{let body=document.getElementById('modalBody');if(!body)return;let pdf=[...body.querySelectorAll('button')].find(b=>(b.getAttribute('onclick')||'').includes('saveAndPrintIntervention'));if(pdf){pdf.textContent='👁 Aperçu fiche';pdf.setAttribute('onclick',`previewIntervention611(${i},true)`);let parent=pdf.parentElement;if(parent&&!parent.querySelector('[data-report-preview611]')){let r=document.createElement('button');r.type='button';r.className='btn';r.dataset.reportPreview611='1';r.textContent='👁 Aperçu rapport';r.onclick=()=>previewReport611(i,true);parent.insertBefore(r,pdf.nextSibling)}}},25)};

// Depuis un devis/facture enregistré, les boutons PDF deviennent des aperçus explicites.
const _showDocument611Base=showDocument;
showDocument=function(i){_showDocument611Base(i);setTimeout(()=>{let body=document.getElementById('modalBody');if(!body)return;for(let b of body.querySelectorAll('button')){let oc=b.getAttribute('onclick')||'';if(oc.includes('openInterventionPdf(')){b.textContent='👁 Aperçu fiche';b.setAttribute('onclick',`previewIntervention611(${i},false)`)}else if(oc.includes("openPrint(")&&oc.includes("'report'")){b.textContent='👁 Aperçu rapport';b.setAttribute('onclick',`previewReport611(${i},false)`)}}},30)};

// Même logique pour les appels historiques à openInterventionPdf : jamais d'impression sans aperçu.
openInterventionPdf=function(i){previewIntervention611(i,false)};
saveAndPrintIntervention=function(i){previewIntervention611(i,true)};
const _openPrint611Base=openPrint;openPrint=function(i,type='invoice'){if(type==='report')return previewReport611(i,false);return _openPrint611Base(i,type)};
const _openPrintDraft611Base=openPrintDraft;openPrintDraft=function(type='invoice'){if(type==='report'){let d=_editingDoc||editingDoc();_editingDoc=d;return showPreview611(d,'report',()=>openDocument(false,_editingDoc))}return _openPrintDraft611Base(type)};

function jkbatSoundEnabled611(){return LS.getItem('jkbat_start_sound')!=='off'}
function playStartupSound611(test=false){if(!test&&!jkbatSoundEnabled611())return;try{let a=new Audio('startup.wav');a.volume=.28;a.play().catch(()=>{})}catch(e){}}
function toggleStartupSound611(){let on=!jkbatSoundEnabled611();LS.setItem('jkbat_start_sound',on?'on':'off');renderStartupSoundSetting611();if(on)playStartupSound611(true);toast(on?'Son de démarrage activé':'Son de démarrage désactivé')}
function renderStartupSoundSetting611(){let b=document.getElementById('startSoundToggle611');if(b)b.classList.toggle('on',jkbatSoundEnabled611())}
function injectStartupSoundSetting611(){let sec=document.getElementById('settings');if(!sec||document.getElementById('startSoundSetting611'))return;let first=sec.querySelector('.card .form');if(!first)return;let row=document.createElement('div');row.id='startSoundSetting611';row.className='settings-switch611';row.innerHTML=`<div class="switch-info"><b>Son au démarrage</b><small>Petit jingle JKBat, court et discret.</small><button type="button" class="btn small" style="margin-top:7px" onclick="playStartupSound611(true)">▶ Tester</button></div><button type="button" id="startSoundToggle611" class="toggle611" onclick="toggleStartupSound611()" aria-label="Son au démarrage"><i></i></button>`;first.appendChild(row);renderStartupSoundSetting611()}
setTimeout(()=>{injectStartupSoundSetting611();playStartupSound611(false)},420);


/* --- JKBat Pro 6.12 RAPPORT DIRECT + SOUND PICKER --- */
const JKBAT_SOUNDS612={
 classic:{label:'Classique',file:'startup.wav',desc:'Le son actuel'},
 soft:{label:'Doux',file:'startup_soft.wav',desc:'Très discret'},
 gold:{label:'Signature',file:'startup_gold.wav',desc:'Petit jingle premium'},
 pulse:{label:'Pulse',file:'startup_pulse.wav',desc:'Court et moderne'}
};
function jkbatSoundChoice612(){let v=LS.getItem('jkbat_start_sound_choice')||'gold';return JKBAT_SOUNDS612[v]?v:'gold'}
function setStartupSound612(k){if(!JKBAT_SOUNDS612[k])return;LS.setItem('jkbat_start_sound_choice',k);LS.setItem('jkbat_start_sound','on');renderStartupSoundSetting611();playStartupSound611(true);toast(`Son d’ouverture : ${JKBAT_SOUNDS612[k].label}`)}
function playStartupSound611(test=false){if(!test&&!jkbatSoundEnabled611())return;let k=jkbatSoundChoice612(),cfg=JKBAT_SOUNDS612[k];try{let a=new Audio(cfg.file);a.volume=k==='pulse'?.22:k==='classic'?.25:.28;a.play().catch(()=>{})}catch(e){}}
function renderStartupSoundSetting611(){let b=document.getElementById('startSoundToggle611');if(b)b.classList.toggle('on',jkbatSoundEnabled611());let box=document.getElementById('soundPicker612');if(box){let cur=jkbatSoundChoice612();for(let el of box.querySelectorAll('[data-sound612]'))el.classList.toggle('active',el.dataset.sound612===cur)}}
function injectStartupSoundSetting611(){let sec=document.getElementById('settings');if(!sec)return;let old=document.getElementById('startSoundSetting611');if(old)old.remove();let first=sec.querySelector('.card .form');if(!first)return;let row=document.createElement('div');row.id='startSoundSetting611';row.className='settings-switch611';row.innerHTML=`<div class="switch-info" style="width:100%"><b>Son au démarrage</b><small>Choisis le jingle JKBat joué une seule fois à l’ouverture.</small><div class="sound-picker612" id="soundPicker612">${Object.entries(JKBAT_SOUNDS612).map(([k,v])=>`<button type="button" class="sound-option612" data-sound612="${k}" onclick="setStartupSound612('${k}')">${v.label}<small>${v.desc}</small></button>`).join('')}</div><div class="actions" style="margin-top:8px"><button type="button" class="btn small" onclick="playStartupSound611(true)">▶ Tester le son choisi</button></div></div><button type="button" id="startSoundToggle611" class="toggle611" onclick="toggleStartupSound611()" aria-label="Son au démarrage"><i></i></button>`;first.appendChild(row);renderStartupSoundSetting611()}
function createReportFromIntervention612(i){
 if(!saveInterventionForm(i,false))return;
 let d=docs()[i];if(!d)return toast('Fiche introuvable');
 toast('Rapport préparé depuis la fiche');
 showPreview611(d,'report',()=>openInterventionSheet(i));
}
const _reportHtml612Base=reportHtml;
reportHtml=function(d){let h=_reportHtml612Base(d);if(d?.signature){let when=d.signedAt?new Date(d.signedAt).toLocaleString('fr-FR'):'';let block=`<div class="report-sign612"><img src="${d.signature}"><div><b>Validation client</b><span>${esc(d.clientSigner||d.clientName||'Client')} ${when?'· '+esc(when):''}</span></div></div>`;h=h.replace('<div class="report-note">',block+'<div class="report-note">')}return h};
const _openInterventionSheet612Base=openInterventionSheet;
openInterventionSheet=function(i){
 _openInterventionSheet612Base(i);
 setTimeout(()=>{let body=document.getElementById('modalBody');if(!body)return;let actions=[...body.querySelectorAll('.actions')];let target=actions[actions.length-1]||body;
  if(!body.querySelector('[data-create-report612]')){
   let b=document.createElement('button');b.type='button';b.className='btn primary';b.dataset.createReport612='1';b.textContent='📄 Créer le rapport';b.onclick=()=>createReportFromIntervention612(i);
   let preview=body.querySelector('[data-report-preview611]');if(preview&&preview.parentElement)preview.parentElement.insertBefore(b,preview.nextSibling);else target.appendChild(b);
  }
  if(!body.querySelector('.report-create-note612')){let n=document.createElement('div');n.className='report-create-note612';n.textContent='Le rapport reprend automatiquement les informations, le métier, les photos et la signature de cette fiche.';target.parentElement?.insertBefore(n,target.nextSibling)}
 },70)
};
setTimeout(()=>injectStartupSoundSetting611(),520);


/* --- JKBat Pro 6.14 SMART TERRAIN CHECKLIST --- */
const TERRAIN_CHECKLISTS613={
 'PLOMBERIE':[
  {id:'plumb_secure',label:'Réseau d’eau sécurisé',hint:'Arrivées, vannes et zone d’intervention maîtrisées.'},
  {id:'plumb_leak',label:'Étanchéité contrôlée',hint:'Aucune fuite constatée après remise en service.'},
  {id:'plumb_flow',label:'Écoulement / évacuation testé',hint:'Débit et évacuation vérifiés en conditions réelles.'}
 ],
 'ÉLECTRICITÉ':[
  {id:'elec_identify',label:'Circuit identifié et sécurisé',hint:'Circuit, protection et zone de travail clairement identifiés.'},
  {id:'elec_safe',label:'Sécurité électrique vérifiée',hint:'Mise en sécurité adaptée avant intervention.'},
  {id:'elec_test',label:'Essai fonctionnel final réalisé',hint:'Fonctionnement contrôlé après remise en service.'}
 ],
 'PEINTURE':[
  {id:'paint_protect',label:'Surfaces et mobilier protégés',hint:'Zone protégée avant préparation et application.'},
  {id:'paint_support',label:'Support préparé et propre',hint:'Préparation compatible avec la finition réalisée.'},
  {id:'paint_finish',label:'Finition / raccords contrôlés',hint:'Aspect, reprises et zones de raccord vérifiés.'}
 ],
 'SERRURERIE':[
  {id:'lock_check',label:'Porte / serrure contrôlée avant travaux',hint:'État initial et cause du défaut vérifiés.'},
  {id:'lock_fix',label:'Fixations et mécanisme sécurisés',hint:'Ensemble correctement fixé et sans jeu anormal.'},
  {id:'lock_test',label:'Ouverture / fermeture testées',hint:'Plusieurs cycles de fonctionnement réalisés.'}
 ],
 'RÉNOVATION':[
  {id:'reno_protect',label:'Zone et existants protégés',hint:'Protection des surfaces conservées et du passage.'},
  {id:'reno_support',label:'Supports / fixations contrôlés',hint:'Stabilité et compatibilité des supports vérifiées.'},
  {id:'reno_finish',label:'Finitions contrôlées',hint:'Aspect final, raccords et remise en état vérifiés.'}
 ],
 'DÉPANNAGE DIVERS':[
  {id:'repair_secure',label:'Zone sécurisée',hint:'Risque immédiat écarté avant diagnostic.'},
  {id:'repair_cause',label:'Cause du défaut identifiée',hint:'Diagnostic confirmé avant la remise en service.'},
  {id:'repair_test',label:'Test fonctionnel final réalisé',hint:'Équipement ou installation testé après intervention.'}
 ],
 '':[
  {id:'generic_secure',label:'Zone de travail sécurisée',hint:'Protection et conditions d’intervention vérifiées.'},
  {id:'generic_test',label:'Essai final réalisé',hint:'Fonctionnement contrôlé avant départ.'}
 ]
};
const TERRAIN_GENERIC613=[
 {id:'arrival',label:'Arrivée / zone de travail confirmée',hint:'Client, lieu et objet de l’intervention vérifiés.',manual:true},
 {id:'safety',label:'Sécurité / protections mises en place',hint:'EPI et protections adaptés à la situation.',manual:true},
 {id:'before',label:'Photo AVANT enregistrée',hint:'Au moins une photo avant intervention.',auto:'before'},
 {id:'diagnosis',label:'Constat / diagnostic renseigné',hint:'Le constat initial est documenté.',auto:'diagnosis'},
 {id:'work',label:'Travaux réalisés renseignés',hint:'Les actions effectuées sont décrites.',auto:'work'},
 {id:'result',label:'Contrôle final / résultat renseigné',hint:'Le résultat de fin d’intervention est documenté.',auto:'result'},
 {id:'after',label:'Photo APRÈS enregistrée',hint:'Au moins une photo après intervention.',auto:'after'},
 {id:'cleanup',label:'Zone nettoyée / remise en état',hint:'Déchets, protections et zone de travail vérifiés.',manual:true},
 {id:'client_info',label:'Client informé du résultat',hint:'Résultat et préconisations expliqués au client.',manual:true},
 {id:'signature',label:'Signature client recueillie',hint:'Validation de fin d’intervention au doigt.',auto:'signature'}
];
function checklistTradeKey613(d){let t=tradeById(d?.jobType||'');return t.id||''}
function checklistItems613(d){let k=checklistTradeKey613(d);return [...TERRAIN_GENERIC613,...(TERRAIN_CHECKLISTS613[k]||TERRAIN_CHECKLISTS613[''])]}
function checklistManual613(d){return d?.terrainChecklist?.manual||{}}
function checklistAuto613(id,d,i){
 let val=x=>document.getElementById(x)?.value?.trim()||'';
 if(id==='before')return (d.beforePhotos||[]).filter(Boolean).length>0 || !!(d.photos||[])[0];
 if(id==='after')return (d.afterPhotos||[]).filter(Boolean).length>0 || !!(d.photos||[])[1];
 if(id==='diagnosis')return !!(val('intInspection')||d.inspection||'').trim();
 if(id==='work')return !!(val('intWork')||d.intervention||'').trim();
 if(id==='result')return !!(val('intResult')||d.result||d.control||'').trim();
 if(id==='signature')return !!d.signature;
 return false
}
function checklistStatus613(d,i){let manual=checklistManual613(d),items=checklistItems613(d);let rows=items.map(x=>({...x,done:x.auto?checklistAuto613(x.auto,d,i):!!manual[x.id]}));return {items:rows,done:rows.filter(x=>x.done).length,total:rows.length,complete:rows.length>0&&rows.every(x=>x.done)}}
function saveChecklistItem613(i,id,checked){let a=docs(),d=a[i];if(!d)return;d.terrainChecklist=d.terrainChecklist||{manual:{}};d.terrainChecklist.manual=d.terrainChecklist.manual||{};d.terrainChecklist.manual[id]=!!checked;d.terrainChecklist.trade=checklistTradeKey613(d);d.terrainChecklist.updatedAt=new Date().toISOString();d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);saveAuto();refreshChecklist613(i)}
function checklistGroup613(title,items,i){if(!items.length)return '';return `<div class="check-group613"><strong>${esc(title)}</strong>${items.map(x=>`<label class="check-item613 ${x.done?'done':''}"><input type="checkbox" ${x.done?'checked':''} ${x.auto?'disabled':''} ${x.auto?'':`onchange="saveChecklistItem613(${i},'${x.id}',this.checked)"`}><span class="check-copy613"><b>${esc(x.label)}</b><small>${esc(x.hint||'')}</small></span>${x.auto?'<span class="check-auto613">AUTO</span>':''}</label>`).join('')}</div>`}
function terrainChecklistHtml613(i,d){let t=tradeById(d.jobType||''),st=checklistStatus613(d,i),gen=st.items.slice(0,TERRAIN_GENERIC613.length),spec=st.items.slice(TERRAIN_GENERIC613.length),pct=st.total?Math.round(st.done/st.total*100):0;return `<div class="terrain-check613" id="terrainChecklist613" style="--check-trade:${t.color}"><div class="check-head613"><div><h3>✓ Check-list terrain obligatoire</h3><p>Elle s’adapte au métier. Les étapes AUTO se valident avec la fiche, les photos et la signature.</p></div><span class="check-trade613">${esc(t.label)}</span></div><div class="check-progress613"><div class="check-track613"><i style="width:${pct}%"></i></div><b>${st.done}/${st.total}</b></div>${checklistGroup613('Contrôles généraux',gen,i)}${checklistGroup613(`Contrôles ${t.label}`,spec,i)}${st.complete?'<div class="check-ready613">✓ Tous les contrôles sont validés. L’intervention peut être terminée.</div>':`<div class="check-warning613">${st.total-st.done} contrôle(s) restent à valider avant de pouvoir terminer l’intervention.</div>`}</div>`}
function refreshChecklist613(i){let d=docs()[i],host=document.getElementById('terrainChecklist613');if(!d||!host)return;let wrap=document.createElement('div');wrap.innerHTML=terrainChecklistHtml613(i,d);host.replaceWith(wrap.firstElementChild);refreshFinishButton613(i)}
function refreshFinishButton613(i){let d=docs()[i],b=document.getElementById('finishIntervention613');if(!d||!b)return;let st=checklistStatus613(d,i);b.disabled=!st.complete&&!d.interventionClosed;b.classList.toggle('done',!!d.interventionClosed);b.textContent=d.interventionClosed?'✓ Intervention terminée':st.complete?'✓ Terminer l’intervention':`🔒 Terminer · ${st.total-st.done} restant(s)`}
function injectChecklist613(i){let body=document.getElementById('modalBody'),d=docs()[i];if(!body||!d)return;let old=body.querySelector('#terrainChecklist613');if(old)old.remove();let sig=body.querySelector('.int-form-sign-state');let box=document.createElement('div');box.innerHTML=terrainChecklistHtml613(i,d);if(sig)sig.parentNode.insertBefore(box.firstElementChild,sig);else body.appendChild(box.firstElementChild);
 let lastActions=[...body.querySelectorAll('.actions')].pop()||body;let existing=document.getElementById('finishIntervention613');if(existing)existing.remove();let fin=document.createElement('button');fin.type='button';fin.id='finishIntervention613';fin.className='finish-int613'+(d.interventionClosed?' done':'');fin.style.setProperty('--check-trade',tradeById(d.jobType||'').color);fin.onclick=()=>finishIntervention613(i);lastActions.parentNode.insertBefore(fin,lastActions.nextSibling);refreshFinishButton613(i);
 ['intInspection','intWork','intResult'].forEach(id=>document.getElementById(id)?.addEventListener('input',()=>refreshChecklist613(i)));
 let sel=document.getElementById('intJobType');if(sel&&!sel.dataset.check613){sel.dataset.check613='1';sel.addEventListener('change',()=>setTimeout(()=>{let a=docs(),x=a[i];if(x){x.jobType=sel.value;x.terrainChecklist=x.terrainChecklist||{manual:{}};x.terrainChecklist.trade=checklistTradeKey613(x);a[i]=x;jset('jkbat_history',a)}injectChecklist613(i)},20));}
}
function finishIntervention613(i){if(!saveInterventionForm(i,false))return;let a=docs(),d=a[i];if(!d)return;let st=checklistStatus613(d,i);if(!st.complete){refreshChecklist613(i);document.getElementById('terrainChecklist613')?.scrollIntoView({behavior:'smooth',block:'center'});return toast(`Impossible de terminer : ${st.total-st.done} contrôle(s) manquant(s)`)}d.interventionClosed=true;d.closedAt=new Date().toISOString();d.status='TERMINÉE';d.terrainChecklist=d.terrainChecklist||{manual:{}};d.terrainChecklist.completedAt=d.closedAt;a[i]=d;jset('jkbat_history',a);logActivity('INTERVENTION','Intervention terminée',`${interventionRef(d)} · ${d.clientName}`);saveAuto();renderAll();closeModal();toast('✓ Intervention terminée et check-list validée')}
function checklistPdfSummary613(d){if(!d?.terrainChecklist)return '';let st=checklistStatus613(d,-1);if(!st.complete)return '';return `<div class="int-check-summary613"><h3>Contrôles terrain validés</h3><div class="int-check-grid613">${st.items.map(x=>`<span>${esc(x.label)}</span>`).join('')}</div></div>`}
const _interventionSheetHtml613Base=interventionSheetHtml;
interventionSheetHtml=function(d){let h=_interventionSheetHtml613Base(d),sum=checklistPdfSummary613(d);if(!sum)return h;let marker='<div class="int-sign-zone">';return h.includes(marker)?h.replace(marker,sum+marker):h+sum}
const _saveInterventionForm613Base=saveInterventionForm;
saveInterventionForm=function(i,closeAfter=false){let wasClosed=!!docs()[i]?.interventionClosed,ok=_saveInterventionForm613Base(i,closeAfter);if(ok&&wasClosed){let a=docs(),d=a[i];if(d){d.interventionClosed=true;d.status='TERMINÉE';a[i]=d;jset('jkbat_history',a);saveAuto();renderAll()}}return ok}
const _openInterventionSheet613Base=openInterventionSheet;
openInterventionSheet=function(i){_openInterventionSheet613Base(i);setTimeout(()=>injectChecklist613(i),145)}
const _addInterventionPhotos613Base=addInterventionPhotos66;
addInterventionPhotos66=async function(i,which,files){let r=await _addInterventionPhotos613Base(i,which,files);setTimeout(()=>refreshChecklist613(i),30);return r}
const _removeInterventionPhoto613Base=removeInterventionPhoto66;
removeInterventionPhoto66=function(i,which,n){let r=_removeInterventionPhoto613Base(i,which,n);setTimeout(()=>refreshChecklist613(i),20);return r}
const _renderInterventionForms613Base=renderInterventionForms63;
renderInterventionForms63=function(){_renderInterventionForms613Base();let cards=document.querySelectorAll('#interventionFormsList .intervention-list-card');let arr=docs().map((d,i)=>({...d,_i:i})).filter(d=>d.kind==='FICHE'||d.interventionRef).sort((a,b)=>String(b.savedAt||b.date).localeCompare(String(a.savedAt||a.date))).slice(0,8);cards.forEach((card,n)=>{let d=arr[n];if(!d)return;let st=checklistStatus613(d,d._i),meta=card.querySelector('.trade-doc-meta');if(meta&&!meta.querySelector('.checklist-mini613'))meta.insertAdjacentHTML('beforeend',`<span class="checklist-mini613 ${d.interventionClosed?'complete':''}">${d.interventionClosed?'✓ Terminée':`${st.done}/${st.total} contrôles`}</span>`)})}
const _statusClass613Base=statusClass;statusClass=function(s){return s==='TERMINÉE'?'ok':_statusClass613Base(s)}
const _renderInterventionHero613Base=renderInterventionHero64;
renderInterventionHero64=function(){_renderInterventionHero613Base();let a=interventionForms64(),unfinished=a.filter(d=>!d.interventionClosed).length,closed=a.filter(d=>!!d.interventionClosed).length;let o=document.getElementById('ficheHeroOpen'),s=document.getElementById('ficheHeroSigned'),to=document.getElementById('terrainFicheOpen'),ts=document.getElementById('terrainFicheSigned');if(o)o.textContent=unfinished;if(s)s.textContent=closed;if(to)to.textContent=`${unfinished} à terminer`;if(ts)ts.textContent=`${closed} terminée${closed>1?'s':''}`;let labels=document.querySelectorAll('#ficheSuperHero .fiche-mini-stat span');if(labels[1])labels[1].textContent='À terminer';if(labels[2])labels[2].textContent='Terminées'}
function migrateV613(){if(LS.getItem('jkbat_v613_migrated'))return;let a=docs(),ch=false;a=a.map(d=>{if((d.kind==='FICHE'||d.interventionRef)&&!d.terrainChecklist){d.terrainChecklist={manual:{},trade:checklistTradeKey613(d)};ch=true}return d});if(ch)jset('jkbat_history',a);LS.setItem('jkbat_v613_migrated','1')}
migrateV613();renderAll();


/* --- JKBat Pro 6.14 : CAMERA -> RAPPORT PDF FIABLE --- */
let _photoBusy614=0;
function sleep614(ms){return new Promise(r=>setTimeout(r,ms))}
function photoBusyUi614(){let old=document.getElementById('photoBusy614');if(_photoBusy614>0){if(!old){let e=document.createElement('div');e.id='photoBusy614';e.className='photo-processing614';e.textContent='📷 Traitement des photos…';document.body.appendChild(e)}}else old?.remove()}
function validPhoto614(v){return typeof v==='string'&&(v.startsWith('data:image/')||v.startsWith('blob:')||v.startsWith('file:')||v.startsWith('content:'))}
function readAsArrayBuffer614(file,attempt=0){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=async e=>{let b=e.target.result;if(b&&b.byteLength>128)return resolve(b);if(attempt<4){await sleep614(180+attempt*120);try{return resolve(await readAsArrayBuffer614(file,attempt+1))}catch(x){return reject(x)}}reject(new Error('Photo vide'))};r.onerror=async()=>{if(attempt<4){await sleep614(180+attempt*120);try{return resolve(await readAsArrayBuffer614(file,attempt+1))}catch(x){return reject(x)}}reject(r.error||new Error('Lecture photo impossible'))};try{r.readAsArrayBuffer(file)}catch(e){reject(e)}})}
function blobDataUrl614(blob){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=e=>resolve(e.target.result);r.onerror=()=>reject(r.error||new Error('Lecture blob impossible'));r.readAsDataURL(blob)})}
function imageFromSrc614(src){return new Promise((resolve,reject)=>{let im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(new Error('Décodage image impossible'));im.src=src})}
async function resizeImage614(file,max=860,q=.68){
 if(!file)throw new Error('Fichier absent');
 let buf=await readAsArrayBuffer614(file),type=(file.type&&file.type.startsWith('image/'))?file.type:'image/jpeg',blob=new Blob([buf],{type}),src=await blobDataUrl614(blob),img=await imageFromSrc614(src);
 let w=img.naturalWidth||img.width,h=img.naturalHeight||img.height;if(!w||!h)throw new Error('Dimensions image invalides');
 let scale=Math.min(1,max/Math.max(w,h)),cw=Math.max(1,Math.round(w*scale)),ch=Math.max(1,Math.round(h*scale)),quality=q,out='';
 for(let pass=0;pass<5;pass++){
  let c=document.createElement('canvas');c.width=cw;c.height=ch;let ctx=c.getContext('2d',{alpha:false});ctx.fillStyle='#fff';ctx.fillRect(0,0,cw,ch);ctx.drawImage(img,0,0,cw,ch);out=c.toDataURL('image/jpeg',quality);
  if(out.length<=155000||pass===4)break;cw=Math.max(320,Math.round(cw*.84));ch=Math.max(320,Math.round(ch*.84));quality=Math.max(.46,quality-.06)
 }
 if(!out.startsWith('data:image/jpeg'))throw new Error('Conversion JPEG impossible');return out
}
resizeImage610=resizeImage614;resizeImage=resizeImage614;
function photoCounts614(d){let b=reportPhotos69(d,'before').filter(validPhoto614).length,a=reportPhotos69(d,'after').filter(validPhoto614).length;return {b,a,total:b+a}}
function photoAuditHtml614(d,context='rapport'){let x=photoCounts614(d),cl=x.total?'ok':'warn';return `<div class="photo-audit614 ${cl}"><div><b>📷 Photos ${context}</b><small>${x.total?'Les photos sont enregistrées et prêtes à être rendues.':'Aucune photo attachée à ce dossier.'}</small></div><div class="counts"><span>AVANT · ${x.b}</span><span>APRÈS · ${x.a}</span></div></div>`}
function persistInterventionPhotos614(i,d){let a=docs();if(!a[i])return false;a[i]=d;try{jset('jkbat_history',a);saveAuto();return true}catch(e){console.error(e);toast('Stockage plein : retire quelques anciennes photos');return false}}
addInterventionPhotos66=async function(i,which,files){
 let list=files?Array.from(files):[];if(!list.length)return;let a=docs(),d=a[i];if(!d)return;let key=which==='before'?'beforePhotos':'afterPhotos',cur=Array.isArray(d[key])?d[key].filter(validPhoto614):[],room=Math.max(0,10-cur.length);if(!room)return toast('Maximum 10 photos par partie');list=list.slice(0,room);_photoBusy614++;photoBusyUi614();toast(`Lecture de ${list.length} photo(s)…`);
 try{let imgs=[];for(let f of list){let out=await resizeImage614(f);if(out)imgs.push(out)}d[key]=[...cur,...imgs].slice(0,10);d.photos=Array.isArray(d.photos)?d.photos:[];d.photos[which==='before'?0:1]=d[key][0]||'';d.workflow={...(d.workflow||{}),[which]:d[key].length>0};d.photoAudit={before:(d.beforePhotos||[]).length,after:(d.afterPhotos||[]).length,lastCaptureAt:new Date().toISOString()};d.savedAt=new Date().toISOString();if(!persistInterventionPhotos614(i,d))return;let saved=docs()[i],host=document.getElementById(`intPhotos_${which}_${i}`);if(host)host.innerHTML=intPhotoGrid66(i,which);refreshChecklist613?.(i);let c=photoCounts614(saved);toast(`✓ Photo(s) enregistrée(s) · rapport ${c.b} avant / ${c.a} après`)}catch(e){console.error(e);toast('La photo caméra n’a pas pu être convertie. Réessaie une fois.')}finally{_photoBusy614=Math.max(0,_photoBusy614-1);photoBusyUi614()}
};
addReportPhotos68=async function(files,index){
 let list=files?Array.from(files):[];if(!list.length||!_editingDoc)return;let arr=reportPhaseArray68(index).filter(validPhoto614),room=Math.max(0,10-arr.length);if(!room)return toast('Maximum 10 photos par partie');list=list.slice(0,room);_photoBusy614++;photoBusyUi614();
 try{let imgs=[];for(let f of list){let out=await resizeImage614(f);if(out)imgs.push(out)}let key=index===0?'beforePhotos':'afterPhotos';_editingDoc[key]=[...arr,...imgs].slice(0,10);syncReportPrimary68(index);persistEditingPhotos610();renderPhotoEditor();scheduleDraft610();let c=photoCounts614(_editingDoc);toast(`✓ Rapport : ${c.b} photo(s) avant · ${c.a} après`)}catch(e){console.error(e);toast('Impossible d’intégrer la photo au rapport')}finally{_photoBusy614=Math.max(0,_photoBusy614-1);photoBusyUi614()}
};
setReportPhoto=function(files,index){return addReportPhotos68(files,index)};
// Nettoyage des références invalides + récupération de la fiche liée.
const _reportPhotos614Base=reportPhotos69;
reportPhotos69=function(d,which){let arr=_reportPhotos614Base(d,which).filter(validPhoto614);if(!arr.length){let src=relatedPhotoDoc610?.(d);if(src){let key=which==='before'?'beforePhotos':'afterPhotos';arr=(Array.isArray(src[key])?src[key]:[]).filter(validPhoto614)}}return arr.slice(0,10)};
// Aperçu : afficher un diagnostic photo avant impression.
const _showPreview614Base=showPreview611;
showPreview611=function(d,type='report',returnFn=null){_showPreview614Base(d,type,returnFn);if(type==='report')setTimeout(()=>{let info=document.querySelector('#printLayer .preview-info611');if(info&&!document.getElementById('previewPhotoAudit614')){let wrap=document.createElement('div');wrap.id='previewPhotoAudit614';wrap.innerHTML=photoAuditHtml614(d,'du rapport');info.insertAdjacentElement('afterend',wrap.firstElementChild)}predecodeReport614()},50)};
async function predecodeReport614(){let imgs=[...document.querySelectorAll('#printLayer .report-photo-card69 img')];if(!imgs.length)return true;let ok=0;for(let im of imgs){try{if(im.complete&&im.naturalWidth>0)ok++;else if(im.decode){await Promise.race([im.decode(),sleep614(3500)]);if(im.naturalWidth>0)ok++}else await new Promise(r=>{im.onload=()=>{ok++;r()};im.onerror=r;setTimeout(r,3500)})}catch(e){}}return ok===imgs.length}
const _triggerPrint614Base=triggerPrint;
triggerPrint=async function(){if(_photoBusy614>0)return toast('Attends la fin du traitement des photos');let expected=document.querySelectorAll('#printLayer .report-photo-card69 img').length;if(expected){toast('Vérification des photos du rapport…');let good=await predecodeReport614();if(!good)return toast('Une photo du rapport n’est pas chargée : reste sur l’aperçu et réessaie')}return _triggerPrint614Base()};
// Ajouter le compteur dans la fiche d’intervention, juste sous les photos.
const _openInterventionSheet614Base=openInterventionSheet;
openInterventionSheet=function(i){_openInterventionSheet614Base(i);setTimeout(()=>{let body=document.getElementById('modalBody'),d=docs()[i];if(!body||!d||body.querySelector('#photoAudit614'))return;let sections=body.querySelectorAll('.int-photo-section');let target=sections.length?sections[sections.length-1]:body.querySelector('.int-form-sign-state');let w=document.createElement('div');w.id='photoAudit614';w.innerHTML=photoAuditHtml614(d,'du dossier');if(target)target.insertAdjacentElement('afterend',w.firstElementChild)},170)};
// Migration légère : harmoniser les anciens champs photos.
function migrateV614(){if(LS.getItem('jkbat_v614_migrated'))return;let a=docs(),ch=false;a=a.map(d=>{d.beforePhotos=Array.isArray(d.beforePhotos)?d.beforePhotos.filter(validPhoto614):[];d.afterPhotos=Array.isArray(d.afterPhotos)?d.afterPhotos.filter(validPhoto614):[];d.photos=Array.isArray(d.photos)?d.photos:[];if(!d.beforePhotos.length&&validPhoto614(d.photos[0])){d.beforePhotos=[d.photos[0]];ch=true}if(!d.afterPhotos.length&&validPhoto614(d.photos[1])){d.afterPhotos=[d.photos[1]];ch=true}d.photos=[d.beforePhotos[0]||'',d.afterPhotos[0]||''];return d});if(ch)try{jset('jkbat_history',a)}catch(e){}LS.setItem('jkbat_v614_migrated','1')}
migrateV614();


/* --- JKBat Pro 6.15.3 : suppression sûre du brouillon automatique --- */
async function deleteAutoDraft6153(){
  let draft=jget('jkbat_invoice_pwa',null);
  if(!draft||!draft.invoiceNo){LS.setItem('jkbat_invoice_pwa','{}');renderDocs();return toast('Aucun brouillon à supprimer')}
  if(!await askConfirm6164(`Supprimer le brouillon ${draft.invoiceNo} ?\n\nCette action ne supprime pas les factures/devis déjà enregistrés.`))return;
  clearTimeout(_draftTimer);
  LS.setItem('jkbat_invoice_pwa','{}');
  _editingDoc=null;_editingDocIndex=-1;_rows=[];
  saveAuto();renderDocs();
  toast('Brouillon supprimé');
}
const _renderDocs6153Base=renderDocs;
renderDocs=function(){
  _renderDocs6153Base();
  let draft=jget('jkbat_invoice_pwa',null),banner=document.getElementById('draftBanner');
  if(!banner)return;
  banner.innerHTML=draft&&draft.invoiceNo?`<div class="card draft-card6153" style="margin-bottom:10px"><div class="grow"><b>📝 Brouillon automatique</b><div class="muted">${esc(draft.invoiceNo)} · ${esc(draft.clientName||'sans client')}</div></div><div class="actions draft-actions6153"><button class="btn small" onclick="openDocument(false,jget('jkbat_invoice_pwa',{}))">Reprendre</button><button class="btn small danger" onclick="deleteAutoDraft6153()">🗑 Supprimer</button></div></div>`:'';
};
setTimeout(()=>{try{renderDocs()}catch(e){console.error(e)}},0);


/* --- JKBat Pro 6.15.4 : fiche sans photos, devis sans photos, facture + rapport avec photos --- */
(function(){
  const valid6154=v=>typeof v==='string'&&v.startsWith('data:image/');
  function arr6154(v){return Array.isArray(v)?v.filter(valid6154).slice(0,10):[]}

  // Migration sûre : les anciennes photos FICHE/DEVIS deviennent des photos de RAPPORT, puis disparaissent du document lui-même.
  function migratePhotoScope6154(){
    if(LS.getItem('jkbat_v6154_photo_scope'))return;
    let a=docs(),changed=false;
    a=a.map(d=>{
      if(d.kind==='FICHE'||d.kind==='DEVIS'){
        let b=arr6154(d.beforePhotos),af=arr6154(d.afterPhotos);
        if(!b.length&&valid6154(d.photos?.[0]))b=[d.photos[0]];
        if(!af.length&&valid6154(d.photos?.[1]))af=[d.photos[1]];
        if(!Array.isArray(d.reportBeforePhotos)&&b.length){d.reportBeforePhotos=b;changed=true}
        if(!Array.isArray(d.reportAfterPhotos)&&af.length){d.reportAfterPhotos=af;changed=true}
        if((d.beforePhotos||[]).length||(d.afterPhotos||[]).length||(d.photos||[]).length){d.beforePhotos=[];d.afterPhotos=[];d.photos=[];changed=true}
        if(d.workflow){d.workflow.before=false;d.workflow.after=false}
      }
      return d
    });
    if(changed)try{jset('jkbat_history',a)}catch(e){}
    LS.setItem('jkbat_v6154_photo_scope','1')
  }

  // Check-list fiche : les photos ne font plus partie des contrôles obligatoires de la fiche.
  try{
    for(const id of ['before','after']){let n=TERRAIN_GENERIC613.findIndex(x=>x.id===id);if(n>=0)TERRAIN_GENERIC613.splice(n,1)}
    const baseTerrain=terrainChecklistHtml613;
    terrainChecklistHtml613=function(i,d){return baseTerrain(i,d).replace('les photos et la signature','la fiche et la signature').replace('avec la fiche, les photos et la signature','avec la fiche et la signature')}
  }catch(e){console.warn('checklist 6154',e)}

  // Le PDF « Fiche d’intervention » ne contient jamais de pages photos.
  try{interventionPhotoPages66=function(){return ''}}catch(e){}

  function reportKey6154(which){return which==='before'?'reportBeforePhotos':'reportAfterPhotos'}
  function invoiceKey6154(which){return which==='before'?'beforePhotos':'afterPhotos'}
  function reportOwn6154(d,which){return arr6154(d?.[reportKey6154(which)])}
  function invoiceOwn6154(d,which){let a=arr6154(d?.[invoiceKey6154(which)]);if(!a.length&&valid6154(d?.photos?.[which==='before'?0:1]))a=[d.photos[which==='before'?0:1]];return a}
  function sameClient6154(a,b){return !!(a&&b)&&((a.clientId&&b.clientId&&a.clientId===b.clientId)||String(a.clientName||'').trim().toLowerCase()===String(b.clientName||'').trim().toLowerCase())}
  function latestInvoicePhotos6154(d,which){let cand=docs().filter(x=>x.kind==='FACTURE'&&sameClient6154(x,d)&&invoiceOwn6154(x,which).length).sort((a,b)=>String(b.savedAt||b.date||'').localeCompare(String(a.savedAt||a.date||'')))[0];return cand?invoiceOwn6154(cand,which):[]}

  // Le rapport lit uniquement ses propres photos ou, à défaut, celles d’une facture liée/même client.
  try{
    reportPhotos69=function(d,which){let a=reportOwn6154(d,which);if(a.length)return a;if(d?.kind==='FACTURE'){a=invoiceOwn6154(d,which);if(a.length)return a}return latestInvoicePhotos6154(d,which).slice(0,10)}
  }catch(e){}

  function reportGrid6154(i,which){let d=docs()[i],a=reportOwn6154(d,which);if(!a.length)return `<div class="report-photo-empty6154">Aucune photo ${which==='before'?'avant':'après'} pour le rapport.</div>`;return `<div class="report-photo-grid6154">${a.map((p,n)=>`<div class="report-photo-item6154"><img src="${p}"><button type="button" onclick="removeReportOnlyPhoto6154(${i},'${which}',${n})">×</button></div>`).join('')}</div>`}
  window.addReportOnlyPhotos6154=async function(i,which,files){let list=Array.from(files||[]);if(!list.length)return;let a=docs(),d=a[i];if(!d)return;let key=reportKey6154(which),cur=reportOwn6154(d,which),room=Math.max(0,10-cur.length);if(!room)return toast('Maximum 10 photos par partie');list=list.slice(0,room);toast(`Ajout de ${list.length} photo(s) au rapport…`);try{let out=[];for(let f of list){let x=await resizeImage614(f);if(x)out.push(x)}d[key]=[...cur,...out].slice(0,10);d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);saveAuto();let host=document.getElementById(`reportOnly_${which}_${i}`);if(host)host.innerHTML=reportGrid6154(i,which);toast(`${out.length} photo(s) ajoutée(s) au rapport`)}catch(e){console.error(e);toast('Impossible de charger une photo') }}
  window.removeReportOnlyPhoto6154=function(i,which,n){let a=docs(),d=a[i];if(!d)return;let key=reportKey6154(which),x=reportOwn6154(d,which);x.splice(n,1);d[key]=x;d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);saveAuto();let host=document.getElementById(`reportOnly_${which}_${i}`);if(host)host.innerHTML=reportGrid6154(i,which)}
  window.openReportPhotos6154=function(i){let d=docs()[i];if(!d)return toast('Document introuvable');openModal('Photos du rapport',`<div class="report-photo-manager6154"><div class="report-only-note6154">Ces photos appartiennent au <b>rapport</b>. Elles ne sont pas affichées dans la fiche d’intervention ni dans le devis.</div>${['before','after'].map(which=>{let label=which==='before'?'AVANT INTERVENTION':'APRÈS INTERVENTION',n=reportOwn6154(d,which).length;return `<div class="report-photo-zone6154"><div class="head"><b>${label}</b><span>${n}/10</span></div><label class="btn file-label full">🖼 Galerie (plusieurs)<input type="file" accept="image/*" multiple onchange="addReportOnlyPhotos6154(${i},'${which}',this.files);this.value=''" /></label><div id="reportOnly_${which}_${i}" style="margin-top:9px">${reportGrid6154(i,which)}</div></div>`}).join('')}<div class="actions"><button class="btn primary" onclick="closeModal();previewReport611(${i},false)">👁 Aperçu rapport</button><button class="btn" onclick="closeModal();${d.kind==='FICHE'?`openInterventionSheet(${i})`:`showDocument(${i})`}">Retour</button></div></div>`)}

  // La fiche n’affiche plus les blocs AVANT/APRÈS ni le diagnostic photo. Un bouton dédié ouvre le RAPPORT.
  try{
    const baseOpenInt=openInterventionSheet;
    openInterventionSheet=function(i){baseOpenInt(i);setTimeout(()=>{let body=document.getElementById('modalBody');if(!body)return;body.querySelectorAll('.int-photo-section,#photoAudit614').forEach(x=>x.remove());let note=body.querySelector('.report-create-note612');if(note)note.textContent='Les photos ne font pas partie de la fiche. Elles s’ajoutent séparément dans le rapport.';let actions=[...body.querySelectorAll('.actions')];let host=actions[actions.length-1]||body;if(!body.querySelector('[data-report-photos6154]')){let b=document.createElement('button');b.type='button';b.className='btn';b.dataset.reportPhotos6154='1';b.textContent='🖼 Photos du rapport';b.onclick=()=>openReportPhotos6154(i);host.appendChild(b)}},220)}
  }catch(e){console.warn('intervention 6154',e)}

  // « Créer le rapport » passe d’abord par l’espace photo du rapport.
  try{createReportFromIntervention612=function(i){if(!saveInterventionForm(i,false))return;openReportPhotos6154(i)}}catch(e){}

  // Dans Devis, aucune photo. Dans Facture, les photos sont clairement réservées à Facture/Rapport.
  function updateDocPhotoMode6154(){let k=document.getElementById('dKind')?.value||_editingDoc?.kind||'DEVIS',ed=document.getElementById('photoEditor');if(!ed)return;let title=ed.previousElementSibling;if(title?.classList.contains('section-title')){title.style.display=k==='FACTURE'?'':'none';let h=title.querySelector('h3'),sp=title.querySelector('span');if(h)h.textContent='Photos facture / rapport';if(sp)sp.textContent='Avant / Après · galerie'}ed.style.display=k==='FACTURE'?'':'none';for(const id of ['wfBefore','wfAfter']){let el=document.getElementById(id);if(el?.closest('label'))el.closest('label').style.display=k==='FACTURE'?'':'none'}}
  try{
    const baseOpenDoc=openDocument;openDocument=function(...args){baseOpenDoc(...args);setTimeout(updateDocPhotoMode6154,35)};
    const baseKind=kindChanged;kindChanged=function(){baseKind();setTimeout(updateDocPhotoMode6154,0)};
    const baseEdit=editingDoc;editingDoc=function(){let d=baseEdit();if(d?.kind==='DEVIS'){d.photos=[];d.beforePhotos=[];d.afterPhotos=[]}return d};
    const baseSave=saveDocument;saveDocument=function(){if(document.getElementById('dKind')?.value==='DEVIS'&&_editingDoc){_editingDoc.photos=[];_editingDoc.beforePhotos=[];_editingDoc.afterPhotos=[]}return baseSave()}
  }catch(e){console.warn('document 6154',e)}

  // Les anciens « Photo avant/après » du mode chantier ne s’affichent pas pour un devis.
  try{const baseFlow=workflowBox;workflowBox=function(d){let h=baseFlow(d);return h}}catch(e){}

  // Dans le détail Devis/Facture, accès explicite aux photos du rapport, sans les confondre avec le devis.
  try{
    const baseShowDoc=showDocument;showDocument=function(i){baseShowDoc(i);setTimeout(()=>{let d=docs()[i],body=document.getElementById('modalBody');if(!d||!body||d.kind==='FICHE'||body.querySelector('[data-report-photos6154]'))return;let actions=[...body.querySelectorAll('.actions')].pop()||body;let b=document.createElement('button');b.type='button';b.className='btn';b.dataset.reportPhotos6154='1';b.textContent='🖼 Photos du rapport';b.onclick=()=>openReportPhotos6154(i);actions.appendChild(b)},90)}
  }catch(e){}

  function clientEmail6154(d){if(d?.clientEmail)return d.clientEmail;let c=clients().find(x=>(d?.clientId&&x.id===d.clientId)||String(x.name||'').trim().toLowerCase()===String(d?.clientName||'').trim().toLowerCase());return c?.email||''}
  // E-mail client sur la facture uniquement, récupéré de la fiche client si besoin.
  try{
    const baseInvoiceHtml=invoiceHtml;
    invoiceHtml=function(d){let h=baseInvoiceHtml(d),mail=d?.kind==='FACTURE'?clientEmail6154(d):'';if(mail&&!h.includes('invoice-client-email6154'))h=h.replace('<div class="invoice-comments">',`<div class="invoice-client-email6154"><b>Mail client :</b> ${esc(mail)}</div><div class="invoice-comments">`);return h}
  }catch(e){}

  // Annexes photo imprimées uniquement avec une FACTURE. Jamais dans un devis ni dans la fiche.
  function invoiceAnnex6154(d){if(d?.kind!=='FACTURE')return '';let all=[...invoiceOwn6154(d,'before').map(x=>({x,label:'AVANT'})),...invoiceOwn6154(d,'after').map(x=>({x,label:'APRÈS'}))];if(!all.length)return '';let pages=[];for(let off=0;off<all.length;off+=4){let part=all.slice(off,off+4);pages.push(`<div class="jk-doc-page invoice-annex6154"><img class="jk-logo-img invoice-top-logo" src="${company().logo||'jkbat-logo.png'}"><h1>ANNEXE PHOTOS</h1><div class="sub">${esc(d.invoiceNo||'Facture')} · ${esc(d.clientName||'Client')}</div><div class="invoice-annex-grid6154">${part.map((p,n)=>`<figure><img src="${p.x}"><figcaption>${p.label} · photo ${off+n+1}</figcaption></figure>`).join('')}</div></div>`)}return pages.join('')}
  try{
    const basePrint=showPrintDoc;showPrintDoc=function(d,type='invoice'){basePrint(d,type);if(type==='invoice'&&d?.kind==='FACTURE'){let layer=document.getElementById('printLayer'),ann=invoiceAnnex6154(d);if(layer&&ann)layer.insertAdjacentHTML('beforeend',ann)}}
  }catch(e){}

  // Intervention Express : si le document choisi est un DEVIS, aucune photo n’est sauvegardée dans le devis.
  try{
    const baseExpress=saveExpress;saveExpress=async function(id=''){if(document.getElementById('xKind')?.value==='DEVIS'){let b=document.getElementById('xBefore'),a=document.getElementById('xAfter');if(b)b.value='';if(a)a.value=''}return baseExpress(id)}
  }catch(e){}

  migratePhotoScope6154();
  setTimeout(()=>{try{renderAll()}catch(e){}},20)
})();


/* --- JKBat Pro 6.15.5 : correction facture téléphone/mail + fiche Premium --- */
(function(){
  function clientEmailPremium6155(d){if(d?.clientEmail)return d.clientEmail;let c=clients().find(x=>(d?.clientId&&x.id===d.clientId)||String(x.name||'').trim().toLowerCase()===String(d?.clientName||'').trim().toLowerCase());return c?.email||''}
  // Facture : le téléphone et l'e-mail vivent dans un seul bloc client robuste, sans marge négative ni chevauchement.
  const invoiceHtml6155Base=invoiceHtml;
  invoiceHtml=function(d){
    let h=invoiceHtml6155Base(d);
    if(d?.kind!=='FACTURE')return h;
    let mail=clientEmailPremium6155(d),phone=d.clientPhone||'';
    let contact=`<div class="invoice-client invoice-client-premium6155"><div class="client-name6155">${esc(d.clientName||'')}</div><div class="addr">${esc(d.clientAddress||'').replace(/\n/g,'<br>')}</div>${phone||mail?`<div class="client-contacts6155">${phone?`<div class="client-contact6155"><b>Tél.</b>${esc(phone)}</div>`:''}${mail?`<div class="client-contact6155"><b>Mail</b>${esc(mail)}</div>`:''}</div>`:''}</div>`;
    h=h.replace(/<div class="invoice-client">[\s\S]*?<div class="addr">[\s\S]*?<\/div><\/div>/,contact);
    h=h.replace(/<div class="invoice-client-email6154">[\s\S]*?<\/div>/g,'');
    return h
  };

  // Sauvegarde fiche : conserve aussi l'e-mail lorsqu'il est modifié depuis la fiche Premium.
  const saveInterventionForm6155Base=saveInterventionForm;
  saveInterventionForm=function(i,closeAfter=false){
    let emailEl=document.getElementById('intClientEmail'),email=emailEl?emailEl.value.trim():null;
    let ok=saveInterventionForm6155Base(i,closeAfter);
    if(ok&&email!==null){let a=docs(),d=a[i];if(d){d.clientEmail=email;d.savedAt=new Date().toISOString();a[i]=d;jset('jkbat_history',a);saveAuto()}}
    return ok
  };

  window.saveInterventionPremium6155=function(i){if(saveInterventionForm(i,false)){try{refreshChecklist613(i)}catch(e){}toast('Fiche d’intervention enregistrée')}};

  // Refonte complète du formulaire fiche. Photos toujours exclues de la fiche : elles restent dans l'espace Rapport.
  openInterventionSheet=function(i){
    let d=docs()[i];if(!d)return toast('Fiche introuvable');
    let t=tradeOfDoc(d),signed=!!d.signature;
    let sig=signed?`<img src="${d.signature}"><div><span class="signed-ok">✓ Signé</span><div class="muted">${esc(d.clientSigner||d.clientName||'')}${d.signedAt?' · '+esc(new Date(d.signedAt).toLocaleString('fr-FR')):''}</div></div>`:`<div><span class="unsigned">Signature client à recueillir</span><div class="muted">Signature au doigt directement sur le téléphone.</div></div>`;
    openModal('Fiche d’intervention',`<div class="int-premium6155">
      <div class="int-premium-head6155">
        <div class="int-premium-kicker6155">Fiche terrain · ${esc(interventionRef(d))}</div>
        <div class="int-premium-title6155"><div><h3>${esc(d.clientName||'Client')}</h3><p>${esc(t.label||'Intervention')} · ${fmtDate(d.date||todayISO())}</p></div><span class="int-status6155 ${signed?'ok':'wait'}">${signed?'✓ SIGNÉE':'✍ À SIGNER'}</span></div>
        ${typeof intQuickActions66==='function'?intQuickActions66(d):''}
      </div>

      <section class="int-card6155">
        <div class="int-card-head6155"><span class="int-card-icon6155">⌂</span><div><b>Client & chantier</b><small>Coordonnées utiles sur le terrain</small></div></div>
        <div><label class="label">Client</label><input class="field" id="intClientName" value="${esc(d.clientName||'')}"></div>
        <div style="margin-top:8px"><label class="label">Adresse du chantier</label><textarea class="field" id="intClientAddress">${esc(d.clientAddress||'')}</textarea></div>
        <div class="form two" style="margin-top:8px"><div><label class="label">Téléphone</label><input class="field" id="intClientPhone" value="${esc(d.clientPhone||'')}"></div><div><label class="label">E-mail</label><input class="field" type="email" id="intClientEmail" value="${esc(clientEmailPremium6155(d))}"></div></div>
        <div style="margin-top:8px"><label class="label">Réf. client</label><input class="field" id="intClientRef" value="${esc(d.clientRef||'PART')}"></div>
      </section>

      <section class="int-card6155">
        <div class="int-card-head6155"><span class="int-card-icon6155">◫</span><div><b>Intervention</b><small>Métier, date, horaires et objet</small></div></div>
        <div class="form two"><div><label class="label">Métier</label><select class="field" id="intJobType">${tradeSelectOptions(d.jobType||'')}</select></div><div><label class="label">Date</label><input type="date" class="field" id="intDate" value="${esc(d.date||todayISO())}"></div></div>
        <div style="margin-top:8px"><label class="label">Technicien</label><input class="field" id="intTech" value="${esc(d.interventionTech||'JKBat Services')}"></div>
        <div class="form two" style="margin-top:8px"><div><label class="label">Heure début</label><input type="time" class="field" id="intStart" value="${esc(d.interventionStart||'')}"></div><div><label class="label">Heure fin</label><input type="time" class="field" id="intEnd" value="${esc(d.interventionEnd||'')}"></div></div>
        <div style="margin-top:8px"><label class="label">Nature / objet précis</label><input class="field" id="intNature" value="${esc(d.nature||d.interventionTitle||'')}"></div>
      </section>

      <section class="int-card6155">
        <div class="int-card-head6155"><span class="int-card-icon6155">✎</span><div><b>Compte-rendu</b><small>Diagnostic, travaux, contrôle et préconisations</small></div></div>
        <div class="form">${voiceField('intInspection','Constat / diagnostic',d.inspection||'')}${voiceField('intWork','Travaux réalisés',d.intervention||'')}${voiceField('intResult','Résultat / contrôle final',d.result||d.control||'')}${voiceField('intReco','Préconisations',d.recommendation||'')}</div>
      </section>

      <section class="int-card6155">
        <div class="int-card-head6155"><span class="int-card-icon6155">▦</span><div><b>Clôture chantier</b><small>Matériel et observations du client</small></div></div>
        <div><label class="label">Matériel / pièces utilisés</label><textarea class="field" id="intMaterials">${esc(d.materialsUsed||'')}</textarea></div>
        <div style="margin-top:8px"><label class="label">Observations du client</label><textarea class="field" id="intClientObs">${esc(d.clientObservations||'')}</textarea></div>
        <div style="margin-top:8px"><label class="label">Nom du signataire</label><input class="field" id="intSigner" value="${esc(d.clientSigner||d.clientName||'')}"></div>
      </section>

      <div class="int-form-sign-state">${sig}</div>
      <div class="actions int-premium-tools6155">
        <button class="btn" type="button" onclick="openReportPhotos6154(${i})">🖼 Photos du rapport</button>
        <button class="btn" type="button" onclick="previewReport611(${i},true)">👁 Aperçu rapport</button>
        ${d.kind==='FICHE'?`<button class="btn danger" type="button" onclick="deleteStandaloneIntervention63(${i})">Supprimer</button>`:`<button class="btn" type="button" onclick="closeModal();showDocument(${i})">Retour dossier</button>`}
      </div>
      <div class="int-fixed-actions6155">
        <button class="btn primary" type="button" onclick="saveInterventionPremium6155(${i})">✓ Enregistrer</button>
        <button class="btn" type="button" onclick="prepareInterventionSign(${i})">✍ Signature</button>
        <button class="btn" type="button" onclick="previewIntervention611(${i},true)">👁 Fiche PDF</button>
      </div>
    </div>`);
    try{applyInterventionFormTheme65(d.jobType||'')}catch(e){}
    setTimeout(()=>{try{injectChecklist613(i)}catch(e){}let sel=document.getElementById('intJobType');if(sel&&!sel.dataset.premium6155){sel.dataset.premium6155='1';sel.addEventListener('change',()=>{try{applyInterventionFormTheme65(sel.value)}catch(e){}})}},70)
  };

  // Marqueur de migration sans toucher aux données ni au moteur Android.
  if(!LS.getItem('jkbat_v6155_premium'))LS.setItem('jkbat_v6155_premium','1');
})();


/* --- JKBat Pro 6.15.6 : Documents Premium (base conservée) --- */
(function(){
 const kinds6156={"":{label:'Tous',icon:'▦'},FACTURE:{label:'Factures',icon:'€'},DEVIS:{label:'Devis',icon:'＋'},FICHE:{label:'Fiches',icon:'▤'}};
 function docKind6156(k){return kinds6156[k]||kinds6156['']}
 function docStatus6156(d){if(d.kind==='FICHE')return d.signature?'SIGNÉ':'À SIGNER';return String(d.status||'BROUILLON').toUpperCase()}
 function statusClass6156(s){return s==='PAYÉ'||s==='ACCEPTÉ'||s==='SIGNÉ'?'ok':s==='REFUSÉ'?'bad':s==='PARTIEL'||s==='À SIGNER'?'warn':statusClass(s)}
 function docAccent6156(d){if(d.kind==='FACTURE')return '#cc9447';if(d.kind==='DEVIS')return '#6f8fb7';return tradeOfDoc(d).color||'#8f7ab8'}
 function filteredDocs6156(){
  let q=(document.getElementById('docSearch')?.value||'').toLowerCase().trim(),f=document.getElementById('docFilter')?.value||'',st=document.getElementById('docStatus6156')?.value||'',sort=document.getElementById('docSort6156')?.value||'recent';
  let a=docs().map((d,i)=>({...d,_i:i})).filter(d=>(!f||d.kind===f)&&matchesTrade(d,_docTrade,'doc')&&(!st||docStatus6156(d)===st)&&(!q||[d.invoiceNo,d.clientName,d.clientAddress,d.clientPhone,d.clientEmail,d.intervention,d.nature,d.status,d.clientRef,d.jobType].join(' ').toLowerCase().includes(q)));
  if(sort==='client')a.sort((a,b)=>String(a.clientName||'').localeCompare(String(b.clientName||''),'fr',{sensitivity:'base'}));
  else if(sort==='amount')a.sort((a,b)=>calc(b).total-calc(a).total);
  else if(sort==='date')a.sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  else a.sort((a,b)=>String(b.savedAt||b.date||'').localeCompare(String(a.savedAt||a.date||'')));
  return a
 }
 function summary6156(f){
  let a=docs();
  if(f==='FACTURE'){let inv=a.filter(d=>d.kind==='FACTURE'),bill=inv.reduce((s,d)=>s+calc(d).total,0),paid=inv.reduce((s,d)=>s+paidAmount(d),0),left=inv.reduce((s,d)=>s+outstanding(d),0);return [['Facturé',euro(bill),''],['Encaissé',euro(paid),'ok'],['À encaisser',euro(left),left?'warn':'ok']]}
  if(f==='DEVIS'){let q=a.filter(d=>d.kind==='DEVIS'),total=q.reduce((s,d)=>s+calc(d).total,0),accepted=q.filter(d=>String(d.status).toUpperCase()==='ACCEPTÉ').length,pending=q.filter(d=>!['ACCEPTÉ','REFUSÉ'].includes(String(d.status).toUpperCase())).length;return [['Montant devis',euro(total),''],['Acceptés',accepted,'ok'],['En attente',pending,pending?'warn':'']]}
  if(f==='FICHE'){let x=a.filter(d=>d.kind==='FICHE'),signed=x.filter(d=>d.signature).length,open=x.length-signed;return [['Fiches',x.length,''],['Signées',signed,'ok'],['À signer',open,open?'warn':'ok']]}
  return [['Documents',a.length,''],['Factures',a.filter(d=>d.kind==='FACTURE').length,''],['Devis + fiches',a.filter(d=>d.kind!=='FACTURE').length,'']]
 }
 window.ensureDocsHub610=function(){
  let tabs=document.getElementById('docsTabs6156'),sum=document.getElementById('docsSummary6156'),f=document.getElementById('docFilter')?.value||'',counts=docCounts610();
  if(tabs)tabs.innerHTML=['','FACTURE','DEVIS','FICHE'].map(k=>{let n=k?counts[k]:docs().length,x=docKind6156(k);return `<button class="docs-tab6156 ${f===k?'active':''}" onclick="goDocs610('${k}')"><span><i>${x.icon}</i>${esc(x.label)} <em style="font-style:normal">${n}</em></span><small>${k===''?'Vue complète':k==='FACTURE'?'Encaissements':k==='DEVIS'?'Propositions':'Terrain & signatures'}</small></button>`}).join('');
  if(sum)sum.innerHTML=summary6156(f).map(x=>`<div class="docs-summary-item6156 ${x[2]}"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');
  let title=document.getElementById('documentsTitle66'),sub=document.getElementById('docsSubtitle6156');if(title)title.textContent=f?docKind6156(f).label:'Documents';if(sub)sub.textContent=f==='FACTURE'?'Suivi des factures, paiements et restes à encaisser.':f==='DEVIS'?'Retrouve les propositions envoyées et leur statut.':f==='FICHE'?'Fiches terrain, signatures client et PDF d’intervention.':'Factures, devis et fiches terrain au même endroit.'
 };
 window.docCard=function(d,i){
  let c=calc(d),s=docStatus6156(d),accent=docAccent6156(d),subject=d.nature||d.intervention||d.jobType||'Sans objet',kind=docKind6156(d.kind),side='',progress='';
  if(d.kind==='FACTURE'){let left=outstanding(d),paid=paidAmount(d),pct=c.total?Math.max(0,Math.min(100,Math.round(paid/c.total*100))):0;side=`<strong>${euro(c.total)}</strong><small class="${left>0?'doc-rest6156':''}">${left>0?'reste '+euro(left):'soldée'}</small><span class="doc-arrow6156">›</span>`;progress=`<div class="doc-progress6156"><i style="width:${pct}%"></i></div>`}
  else if(d.kind==='DEVIS')side=`<strong>${euro(c.total)}</strong><small>${String(d.status||'BROUILLON').toLowerCase()}</small><span class="doc-arrow6156">›</span>`;
  else side=`<strong>${d.signature?'✓ Signée':'À signer'}</strong><small>${fmtDate(d.date)}</small><span class="doc-arrow6156">›</span>`;
  return `<div data-doc610="${esc(d.id||'')}" class="card doc-premium6156 ${isOverdue(d)?'overdue':''}" style="--doc-accent:${accent}" onclick="showDocument(${i})"><div class="doc-kind-icon6156">${kind.icon}</div><div class="doc-main6156"><div class="doc-topline6156"><span class="doc-number6156">${esc(d.invoiceNo||kind.label)}</span><span class="chip ${statusClass6156(s)}">${esc(isOverdue(d)?'EN RETARD':s)}</span></div><h4>${esc(d.clientName||'Client')}</h4><div class="doc-sub6156">${fmtDate(d.date)} · ${esc(subject)}</div><div class="doc-meta6156">${tradeBadge(d.jobType||'')}${d.clientRef?`<span class="chip">${esc(d.clientRef)}</span>`:''}</div>${progress}</div><div class="doc-side6156">${side}</div></div>`
 };
 window.renderDocs=function(){
  let a=filteredDocs6156(),f=document.getElementById('docFilter')?.value||'',q=(document.getElementById('docSearch')?.value||'').trim(),st=document.getElementById('docStatus6156')?.value||'';
  let count=document.getElementById('docCount');if(count)count.textContent=`${a.length} ${a.length>1?'docs':'doc'}`;
  let list=document.getElementById('docList');if(list)list.innerHTML=a.length?a.map(d=>docCard(d,d._i)).join(''):`<div class="docs-empty6156"><div class="empty-icon6156">${docKind6156(f).icon}</div><b>${f==='FACTURE'?'Aucune facture':f==='DEVIS'?'Aucun devis':f==='FICHE'?'Aucune fiche':'Aucun document'}</b><p>${q||st||_docTrade!=='ALL'?'Aucun résultat avec les filtres actuels. Réinitialise les filtres pour tout afficher.':'Les prochains documents enregistrés apparaîtront ici.'}</p>${q||st||_docTrade!=='ALL'?'<button class="btn" onclick="resetDocsFilters6156()">Réinitialiser</button>':f==='FACTURE'?'<button class="btn primary" onclick="openDocument(true,{kind:\'FACTURE\'})">＋ Nouvelle facture</button>':f==='DEVIS'?'<button class="btn primary" onclick="openDocument(true)">＋ Nouveau devis</button>':f==='FICHE'?'<button class="btn primary" onclick="openStandaloneIntervention()">＋ Nouvelle fiche</button>':''}</div>`;
  let draft=jget('jkbat_invoice_pwa',null),db=document.getElementById('draftBanner');if(db)db.innerHTML=draft&&draft.invoiceNo?`<div class="doc-draft6156"><div class="doc-kind-icon6156">✎</div><div class="grow"><b>Brouillon automatique</b><div class="muted">${esc(draft.invoiceNo)} · ${esc(draft.clientName||'sans client')}</div></div><div class="actions"><button class="btn small primary" onclick="openDocument(false,jget('jkbat_invoice_pwa',{}))">Reprendre</button>${typeof deleteAutoDraft6153==='function'?'<button class="btn small danger" onclick="deleteAutoDraft6153();renderDocs()">×</button>':''}</div></div>`:'';
  let tf=document.getElementById('docTradeFilter');if(tf)tf.innerHTML=tradeFilterHtml(_docTrade,'setDocTrade');
  let label=document.getElementById('docsListLabel6156');if(label)label.textContent=`${f?docKind6156(f).label:'Tous les documents'} · ${a.length}`;
  let reset=document.getElementById('docsReset6156');if(reset)reset.classList.toggle('visible',!!(q||st||_docTrade!=='ALL'||(document.getElementById('docSort6156')?.value||'recent')!=='recent'));
  ensureDocsHub610()
 };
 window.goDocs610=function(kind='FACTURE',focusId=''){go('documents');setTimeout(()=>{let f=document.getElementById('docFilter');if(f)f.value=kind||'';renderDocs();if(focusId){let node=document.querySelector(`[data-doc610="${CSS.escape(String(focusId))}"]`);if(node){node.classList.add('saved-flash610');node.scrollIntoView({block:'center',behavior:'smooth'})}}},35)};
 window.goAllDocuments66=function(){goDocs610('')};
 window.resetDocsFilters6156=function(){let q=document.getElementById('docSearch'),st=document.getElementById('docStatus6156'),so=document.getElementById('docSort6156');if(q)q.value='';if(st)st.value='';if(so)so.value='recent';_docTrade='ALL';renderDocs()};
 const setDocTrade6156=setDocTrade;window.setDocTrade=function(v){_docTrade=v;renderDocs()};
 const renderAll6156Base=renderAll;window.renderAll=function(){renderAll6156Base();setTimeout(()=>{try{renderDocs()}catch(e){}},0)};
 if(!LS.getItem('jkbat_v6156_documents'))LS.setItem('jkbat_v6156_documents','1');
 setTimeout(()=>{try{renderDocs()}catch(e){console.error('Documents Premium',e)}},140)
})();


/* --- JKBat Pro 6.15.7 : ergonomie facture --- */
(function(){
  const PAYMENT_MODES6157=['Virement bancaire','Carte bancaire','Espèces','Chèque','Prélèvement'];

  function focusFirstLine6157(){
    setTimeout(()=>{let first=document.querySelector('#lines .lineitem2 input.field');if(first){try{first.focus({preventScroll:true})}catch(e){first.focus()}first.scrollIntoView({block:'nearest',behavior:'smooth'})}},35)
  }

  // Une nouvelle prestation est toujours ajoutée en haut de la liste.
  window.addLine=function(){
    _rows.unshift({label:'',description:'',qty:1,price:0});
    renderLines();scheduleDraft();focusFirstLine6157()
  };

  // Même comportement pour une prestation choisie dans le catalogue.
  window.addCatalogToRows=function(v){
    if(v==='')return;
    let x=catalog()[Number(v)];if(!x)return;
    if(document.getElementById('dJobType')&&!document.getElementById('dJobType').value){
      document.getElementById('dJobType').value=tradeOfCatalog(x).id;
      if(_editingDoc)_editingDoc.jobType=document.getElementById('dJobType').value
    }
    _rows.unshift({label:x.name,description:x.description||'',qty:1,price:Number(x.price)||0});
    renderLines();scheduleDraft();focusFirstLine6157();toast('Prestation ajoutée en haut')
  };

  function paymentSelect6157(){
    let old=document.getElementById('dPaymentMode');if(!old||old.tagName==='SELECT')return;
    let value=String(old.value||'').trim(),sel=document.createElement('select');
    sel.className=(old.className||'field')+' payment-select6157';sel.id='dPaymentMode';
    let values=['',...PAYMENT_MODES6157];if(value&&!values.includes(value))values.push(value);
    sel.innerHTML=values.map(v=>`<option value="${esc(v)}" ${v===value?'selected':''}>${v?esc(v):'— Choisir —'}</option>`).join('');
    sel.addEventListener('change',()=>scheduleDraft());old.replaceWith(sel)
  }

  function noVatForm6157(){
    let vat=document.getElementById('dVat');
    if(vat){vat.value='0';if(_editingDoc)_editingDoc.vat=0;let box=vat.parentElement,grid=box?.parentElement;if(box)box.style.display='none';if(grid?.classList.contains('two'))grid.style.gridTemplateColumns='1fr'}
    let total=document.getElementById('dTotal');if(total){let label=total.previousElementSibling;if(label)label.textContent='Total à payer';total.closest('.card')?.classList.add('invoice-no-vat6157')}
    paymentSelect6157();updateTotal()
  }

  // TVA désactivée pour les nouvelles saisies et les brouillons, sans réécrire les factures finalisées.
  function migrateNoVat6157(){
    LS.setItem('jkbat_default_vat','0');
    try{let a=docs(),changed=false;a.forEach(d=>{if((d.kind==='FACTURE'||d.kind==='DEVIS')&&String(d.status||'BROUILLON').toUpperCase()==='BROUILLON'&&Number(d.vat||0)!==0){d.vat=0;changed=true}});if(changed)jset('jkbat_history',a)}catch(e){}
  }

  const openDocument6157Base=openDocument;
  window.openDocument=function(isNew=true,existing=null,clientIndex=null){
    openDocument6157Base(isNew,existing,clientIndex);
    setTimeout(noVatForm6157,0)
  };

  const openExpress6157Base=typeof openExpress==='function'?openExpress:null;
  if(openExpress6157Base)window.openExpress=function(appointmentId=''){
    openExpress6157Base(appointmentId);setTimeout(()=>{let v=document.getElementById('xVat');if(v){v.value='0';let box=v.parentElement;if(box)box.style.display='none'}},0)
  };

  const renderSettings6157Base=renderSettings;
  window.renderSettings=function(){
    renderSettings6157Base();
    let v=document.getElementById('setVat');if(v){v.value='0';let box=v.parentElement,grid=box?.parentElement;if(box)box.style.display='none';if(grid?.classList.contains('two'))grid.style.gridTemplateColumns='1fr'}
  };

  // Aucun affichage de TVA dans le calcul de l'éditeur.
  window.updateTotal=function(){
    if(!document.getElementById('dTotal'))return;
    let d=editingDoc();d.vat=0;let c=calc(d);
    document.getElementById('dTotal').textContent=euro(c.after);
    let b=document.getElementById('dBreakdown');if(b)b.textContent=c.disc?`Sous-total ${euro(c.sub)} · remise ${c.disc}%`:`Montant ${euro(c.after)}`
  };

  // L'aperçu d'une facture en cours conserve tout le formulaire et revient dessus.
  window.previewEditing=function(){
    let d=editingDoc();d.vat=0;
    d.beforePhotos=Array.isArray(_editingDoc?.beforePhotos)?_editingDoc.beforePhotos.slice(0,10):(d.beforePhotos||[]);
    d.afterPhotos=Array.isArray(_editingDoc?.afterPhotos)?_editingDoc.afterPhotos.slice(0,10):(d.afterPhotos||[]);
    d.photos=Array.isArray(_editingDoc?.photos)?_editingDoc.photos.slice(0,2):(d.photos||[]);
    _editingDoc={...d};
    // Sauvegarde de secours immédiate du brouillon avant de quitter le formulaire.
    try{let slim={...d,beforePhotos:[],afterPhotos:[],photos:[]};LS.setItem('jkbat_invoice_pwa',JSON.stringify(slim))}catch(e){}
    if(typeof showPreview611==='function')return showPreview611(d,'invoice',()=>openDocument(false,_editingDoc));
    openModal('Aperçu',invoiceHtml(d)+`<div class="actions"><button class="btn" onclick="closeModal();openDocument(false,_editingDoc)">← Retour modifier</button></div>`)
  };

  migrateNoVat6157();
  if(!LS.getItem('jkbat_v6157_invoice_ergonomy'))LS.setItem('jkbat_v6157_invoice_ergonomy','1');
  setTimeout(()=>{try{renderSettings();if(document.getElementById('dKind'))noVatForm6157()}catch(e){}},120)
})();


/* --- JKBat Pro 6.16.0 : statut facture À encaisser / Payé --- */
(function(){
  const INVOICE_DUE6158='À ENCAISSER', INVOICE_PAID6158='PAYÉ';
  function normalizeInvoiceStatus6158(s){return String(s||'').toUpperCase()===INVOICE_PAID6158?INVOICE_PAID6158:INVOICE_DUE6158}
  function invoiceStatusLabel6158(s){return normalizeInvoiceStatus6158(s)===INVOICE_PAID6158?'Payé':'À encaisser'}

  // Une facture ne propose plus que les deux états utiles au terrain.
  const statusOptions6158Base=statusOptions;
  window.statusOptions=function(kind,current){
    if(kind!=='FACTURE')return statusOptions6158Base(kind,current);
    let cur=normalizeInvoiceStatus6158(current);
    return `<option value="${INVOICE_DUE6158}" ${cur===INVOICE_DUE6158?'selected':''}>À encaisser</option><option value="${INVOICE_PAID6158}" ${cur===INVOICE_PAID6158?'selected':''}>Payé</option>`
  };

  // Les anciens statuts facture (brouillon, envoyé, partiel...) deviennent « À encaisser ».
  function migrateInvoiceStatus6158(){
    try{
      let a=docs(),changed=false;
      a.forEach(d=>{if(d.kind==='FACTURE'){let n=normalizeInvoiceStatus6158(d.status);if(d.status!==n){d.status=n;changed=true}}});
      if(changed)jset('jkbat_history',a)
    }catch(e){console.error('Migration statut facture',e)}
    try{
      let d=jget('jkbat_invoice_pwa',null);if(d&&d.kind==='FACTURE'){d.status=normalizeInvoiceStatus6158(d.status);jset('jkbat_invoice_pwa',d)}
    }catch(e){}
  }

  const editingDoc6158Base=editingDoc;
  window.editingDoc=function(){
    let d=editingDoc6158Base();
    if(d&&d.kind==='FACTURE'){
      d.status=normalizeInvoiceStatus6158(d.status);
      if(d.status===INVOICE_PAID6158){d.amountPaid=calc(d).total;if(!d.paidDate)d.paidDate=todayISO()}
    }
    return d
  };

  // Ouvrir une facture ancienne la présente directement avec le nouveau statut.
  const openDocument6158Base=openDocument;
  window.openDocument=function(isNew=true,existing=null,clientIndex=null){
    if(existing&&existing.kind==='FACTURE')existing={...existing,status:normalizeInvoiceStatus6158(existing.status)};
    openDocument6158Base(isNew,existing,clientIndex);
    setTimeout(()=>{
      let k=document.getElementById('dKind'),st=document.getElementById('dStatus');
      if(k&&st&&k.value==='FACTURE'){
        let current=normalizeInvoiceStatus6158(st.value||_editingDoc?.status);
        st.innerHTML=statusOptions('FACTURE',current);st.value=current;st.classList.add('status-invoice6158');
        if(_editingDoc)_editingDoc.status=current
      }
    },0)
  };

  // Le changement Devis -> Facture sélectionne « À encaisser » par défaut.
  const kindChanged6158Base=kindChanged;
  window.kindChanged=function(){
    kindChanged6158Base();
    let k=document.getElementById('dKind'),st=document.getElementById('dStatus');
    if(k&&st&&k.value==='FACTURE'){st.innerHTML=statusOptions('FACTURE',INVOICE_DUE6158);st.value=INVOICE_DUE6158;if(_editingDoc)_editingDoc.status=INVOICE_DUE6158}
    scheduleDraft()
  };

  // Couleurs : orange = à encaisser, vert = payé.
  const statusClass6158Base=statusClass;
  window.statusClass=function(s){let x=String(s||'').toUpperCase();if(x===INVOICE_DUE6158)return 'warn';if(x===INVOICE_PAID6158)return 'ok';return statusClass6158Base(s)};
  if(typeof statusClass6156==='function'){
    const statusClass61586156Base=statusClass6156;
    window.statusClass6156=function(s){if(String(s||'').toUpperCase()===INVOICE_DUE6158)return 'warn';if(String(s||'').toUpperCase()===INVOICE_PAID6158)return 'ok';return statusClass61586156Base(s)}
  }
  if(typeof docStatus6156==='function'){
    const docStatus61586156Base=docStatus6156;
    window.docStatus6156=function(d){return d?.kind==='FACTURE'?normalizeInvoiceStatus6158(d.status):docStatus61586156Base(d)}
  }

  // Un encaissement partiel reste simplement « À encaisser » ; seul le solde complet passe à « Payé ».
  const savePayment6158Base=typeof savePayment==='function'?savePayment:null;
  if(savePayment6158Base)window.savePayment=function(i){
    let a=docs(),d=a[i],amt=Number(document.getElementById('pAmount')?.value)||0;if(!d||amt<=0)return toast('Montant invalide');
    d.payments=Array.isArray(d.payments)?d.payments:[];d.payments.push({id:uid(),date:document.getElementById('pDate')?.value||todayISO(),amount:amt,mode:document.getElementById('pMode')?.value||'',note:document.getElementById('pNote')?.value.trim()||''});
    let rem=Math.max(0,calc(d).total-d.payments.reduce((s,p)=>s+(Number(p.amount)||0),0));d.status=rem<.01?INVOICE_PAID6158:INVOICE_DUE6158;if(d.status===INVOICE_PAID6158)d.paidDate=document.getElementById('pDate')?.value||todayISO();
    a[i]=d;jset('jkbat_history',a);logActivity('PAIEMENT','Paiement encaissé',`${d.invoiceNo} · ${euro(amt)}`);closeModal();renderAll();toast(rem<.01?'Facture soldée':'Paiement enregistré · reste à encaisser')
  };

  // Sur la facture/PDF on affiche les libellés lisibles, jamais « BROUILLON ».
  const invoiceHtml6158Base=invoiceHtml;
  window.invoiceHtml=function(d){
    let x=d&&d.kind==='FACTURE'?{...d,status:normalizeInvoiceStatus6158(d.status)}:d;
    let h=invoiceHtml6158Base(x);
    if(x&&x.kind==='FACTURE')h=h.replace('<b>Statut :</b> Payée','<b>Statut :</b> Payé').replace('<b>Statut :</b> À ENCAISSER','<b>Statut :</b> À encaisser');
    return h
  };

  function updateDocsStatusFilter6158(){
    let s=document.getElementById('docStatus6156');if(!s)return;
    let keep=s.value,kind=document.getElementById('docFilter')?.value||'';
    let opts=kind==='FACTURE'?
      [['','Tous les statuts'],[INVOICE_DUE6158,'À encaisser'],[INVOICE_PAID6158,'Payé']]:
      kind==='DEVIS'?
      [['','Tous les statuts'],['BROUILLON','Brouillon'],['ENVOYÉ','Envoyé'],['ACCEPTÉ','Accepté'],['REFUSÉ','Refusé'],['EXPIRÉ','Expiré']]:
      kind==='FICHE'?
      [['','Tous les statuts'],['SIGNÉ','Signée'],['À SIGNER','À signer']]:
      [['','Tous les statuts'],[INVOICE_DUE6158,'À encaisser'],[INVOICE_PAID6158,'Payé'],['BROUILLON','Brouillon devis'],['ENVOYÉ','Envoyé devis'],['ACCEPTÉ','Accepté'],['REFUSÉ','Refusé'],['SIGNÉ','Signée'],['À SIGNER','À signer']];
    s.innerHTML=opts.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join('');
    if(opts.some(o=>o[0]===keep))s.value=keep
  }

  const renderDocs6158Base=renderDocs;
  window.renderDocs=function(){updateDocsStatusFilter6158();renderDocs6158Base()};
  const goDocs6158Base=goDocs610;
  window.goDocs610=function(kind='FACTURE',focusId=''){
    goDocs6158Base(kind,focusId);setTimeout(()=>{updateDocsStatusFilter6158();try{renderDocs6158Base()}catch(e){}},45)
  };

  migrateInvoiceStatus6158();
  if(!LS.getItem('jkbat_v6158_invoice_status'))LS.setItem('jkbat_v6158_invoice_status','1');
  setTimeout(()=>{try{updateDocsStatusFilter6158();renderDocs()}catch(e){}},180)
})();


/* --- JKBat Pro 6.16.0 : synchronisation Cloud téléphone <-> PC --- */
(function(){
  'use strict';
  const SYNC_VER='6.16.0';
  const K_URL='jkbat_sync_url',K_KEY='jkbat_sync_public_key',K_CODE='jkbat_sync_code',K_TIMES='jkbat_sync_key_times',K_LAST='jkbat_sync_last_ok',K_DEVICE='jkbat_sync_device_id';
  const LOCAL_ONLY=new Set(['jkbat_invoice_pwa','jkbat_last_autosave','jkbat_theme','jkbat_start_sound','jkbat_start_sound_choice','jkbat_pin_hash','jkbat_job_timer','jkbat_brand_version']);
  let syncBusy6159=false,syncTimer6159=null,syncApplying6159=false;
  const rawSet6159=Storage.prototype.setItem,rawRemove6159=Storage.prototype.removeItem;
  function isSyncKey6159(k){k=String(k||'');if(!k.startsWith('jkbat_')||k.startsWith('jkbat_sync_'))return false;if(LOCAL_ONLY.has(k))return false;if(/^jkbat_v\d/i.test(k))return false;return true}
  function readTimes6159(){try{return JSON.parse(localStorage.getItem(K_TIMES)||'{}')||{}}catch{return {}}}
  function writeTimes6159(o){try{rawSet6159.call(localStorage,K_TIMES,JSON.stringify(o||{}))}catch(e){}}
  function touchKey6159(k){if(syncApplying6159||!isSyncKey6159(k))return;let t=readTimes6159();t[k]=new Date().toISOString();writeTimes6159(t);setSyncState6159('waiting','En attente de synchro');scheduleSync6159(1300)}
  Storage.prototype.setItem=function(k,v){let r=rawSet6159.call(this,k,v);if(this===localStorage)touchKey6159(k);return r};
  Storage.prototype.removeItem=function(k){let was=this===localStorage&&isSyncKey6159(k);let r=rawRemove6159.call(this,k);if(was)touchKey6159(k);return r};

  function syncConfig6159(){return {url:(localStorage.getItem(K_URL)||'').trim().replace(/\/+$/,''),key:(localStorage.getItem(K_KEY)||'').trim(),code:(localStorage.getItem(K_CODE)||'').trim()}}
  function configured6159(){let c=syncConfig6159();return /^https:\/\//i.test(c.url)&&c.key.length>15&&c.code.length>=12}
  function deviceId6159(){let x=localStorage.getItem(K_DEVICE);if(x)return x;x='dev-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);rawSet6159.call(localStorage,K_DEVICE,x);return x}
  function setSyncState6159(state,text,detail=''){
    let b=document.getElementById('syncBadge6159'),i=document.getElementById('syncInfo6159');
    if(b){b.textContent=text;b.style.fontWeight='700';b.style.color=state==='ok'?'#2b7a4b':state==='error'?'#b43c3c':state==='waiting'?'#b36a18':''}
    if(i)i.textContent=detail||text;
  }
  function renderSyncSettings6159(){
    let c=syncConfig6159(),u=document.getElementById('syncUrl6159'),k=document.getElementById('syncKey6159'),co=document.getElementById('syncCode6159');
    if(u&&document.activeElement!==u)u.value=c.url;if(k&&document.activeElement!==k)k.value=c.key;if(co&&document.activeElement!==co)co.value=c.code;
    let last=localStorage.getItem(K_LAST);
    if(!configured6159())setSyncState6159('off','Non configurée','Renseigne les 3 champs une seule fois sur le téléphone et le PC.');
    else if(!navigator.onLine)setSyncState6159('waiting','Hors ligne','Les modifications restent sur cet appareil et seront synchronisées dès le retour d’Internet.');
    else if(last){let d=new Date(last);setSyncState6159('ok','Synchronisée',`Dernière synchronisation : ${isNaN(d)?last:d.toLocaleString('fr-FR')}`)}
    else setSyncState6159('waiting','Prête','Configuration enregistrée. Lance une première synchronisation.');
  }
  const renderSettings6159Base=window.renderSettings;
  if(typeof renderSettings6159Base==='function')window.renderSettings=function(){renderSettings6159Base();renderSyncSettings6159()};

  window.generateSyncCode6159=function(){
    const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';let out='';
    try{let a=new Uint8Array(24);crypto.getRandomValues(a);for(let x of a)out+=alphabet[x%alphabet.length]}catch(e){out='JKBat-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12)}
    let el=document.getElementById('syncCode6159');if(el)el.value=out;toast('Code privé généré')
  };
  window.saveSyncSettings6159=function(){
    let u=(document.getElementById('syncUrl6159')?.value||'').trim().replace(/\/+$/,''),k=(document.getElementById('syncKey6159')?.value||'').trim(),c=(document.getElementById('syncCode6159')?.value||'').trim();
    if(!/^https:\/\//i.test(u))return toast('Adresse Cloud invalide');if(k.length<15)return toast('Clé publique invalide');if(c.length<12)return toast('Code privé trop court');
    rawSet6159.call(localStorage,K_URL,u);rawSet6159.call(localStorage,K_KEY,k);rawSet6159.call(localStorage,K_CODE,c);renderSyncSettings6159();toast('Synchronisation activée');setTimeout(()=>syncNow6159(true),150)
  };
  window.disableSync6159=async function(){
    if(!await askConfirm6164('Désactiver la synchronisation sur cet appareil ? Les données locales seront conservées.'))return;
    [K_URL,K_KEY,K_CODE,K_LAST].forEach(k=>rawRemove6159.call(localStorage,k));renderSyncSettings6159();toast('Synchronisation désactivée')
  };

  function localSnapshot6159(){
    let values={},times=readTimes6159();
    for(let i=0;i<localStorage.length;i++){let k=localStorage.key(i);if(isSyncKey6159(k))values[k]=localStorage.getItem(k)}
    return {format:'JKBatSync',version:1,appVersion:SYNC_VER,deviceId:deviceId6159(),updatedAt:new Date().toISOString(),values,times}
  }
  function stableObj6159(o){let out={};Object.keys(o||{}).sort().forEach(k=>out[k]=o[k]);return out}
  function snapshotCore6159(s){return JSON.stringify({values:stableObj6159(s?.values||{}),times:stableObj6159(s?.times||{})})}
  function mergeSnapshots6159(local,remote){
    let lv=local?.values||{},rv=remote?.values||{},lt=local?.times||{},rt=remote?.times||{},keys=new Set([...Object.keys(lv),...Object.keys(rv),...Object.keys(lt),...Object.keys(rt)]),values={},times={};
    for(let k of keys){if(!isSyncKey6159(k))continue;let lms=Date.parse(lt[k]||0)||0,rms=Date.parse(rt[k]||0)||0,chooseRemote=rms>lms||(rms===lms&&rv[k]!==undefined&&lv[k]!==rv[k]);
      if(chooseRemote){if(rv[k]!==undefined)values[k]=rv[k];times[k]=rt[k]||lt[k]||new Date(0).toISOString()}
      else{if(lv[k]!==undefined)values[k]=lv[k];times[k]=lt[k]||rt[k]||new Date(0).toISOString()}
    }
    return {format:'JKBatSync',version:1,appVersion:SYNC_VER,deviceId:deviceId6159(),updatedAt:new Date().toISOString(),values,times}
  }
  function stampCurrentKeys6159(){let t=readTimes6159(),now=new Date().toISOString(),changed=false;for(let i=0;i<localStorage.length;i++){let k=localStorage.key(i);if(isSyncKey6159(k)&&!t[k]){t[k]=now;changed=true}}if(changed)writeTimes6159(t)}
  function applySnapshot6159(s){
    let values=s?.values||{},times=s?.times||{};syncApplying6159=true;
    try{
      let current=[];for(let i=0;i<localStorage.length;i++){let k=localStorage.key(i);if(isSyncKey6159(k))current.push(k)}
      current.forEach(k=>{if(values[k]===undefined)rawRemove6159.call(localStorage,k)});
      Object.entries(values).forEach(([k,v])=>{if(isSyncKey6159(k))rawSet6159.call(localStorage,k,String(v))});writeTimes6159(times);
    }finally{syncApplying6159=false}
    try{if(typeof migrate==='function')migrate();if(typeof applyTheme==='function')applyTheme();if(typeof renderAll==='function')renderAll()}catch(e){console.error(e)}
  }
  async function rpc6159(name,body){
    let c=syncConfig6159(),ctrl=new AbortController(),tm=setTimeout(()=>ctrl.abort(),15000);
    try{let r=await fetch(`${c.url}/rest/v1/rpc/${name}`,{method:'POST',headers:{'apikey':c.key,'Authorization':`Bearer ${c.key}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:ctrl.signal});
      let txt=await r.text();if(!r.ok)throw new Error(`Cloud ${r.status}: ${txt.slice(0,180)}`);if(!txt)return null;try{return JSON.parse(txt)}catch{return txt}
    }finally{clearTimeout(tm)}
  }
  async function pull6159(){let c=syncConfig6159(),x=await rpc6159('jkbat_sync_pull',{p_sync_id:c.code});if(!Array.isArray(x)||!x.length||!x[0]?.payload)return null;try{return JSON.parse(x[0].payload)}catch(e){throw new Error('Données cloud illisibles')}}
  async function push6159(s){let c=syncConfig6159();await rpc6159('jkbat_sync_push',{p_sync_id:c.code,p_payload:JSON.stringify(s),p_updated_at:new Date().toISOString()})}
  function scheduleSync6159(delay=1800){clearTimeout(syncTimer6159);if(!configured6159())return;syncTimer6159=setTimeout(()=>syncNow6159(false),delay)}
  window.syncNow6159=async function(manual=false){
    if(syncBusy6159)return;if(!configured6159()){if(manual)toast('Configure d’abord la synchronisation dans Réglages');renderSyncSettings6159();return}if(!navigator.onLine){setSyncState6159('waiting','Hors ligne','Les changements sont conservés localement.');if(manual)toast('Pas de connexion Internet');return}
    syncBusy6159=true;setSyncState6159('waiting','Synchronisation…','Échange sécurisé avec le Cloud JKBat en cours.');
    try{
      let remote=await pull6159();
      if(!remote){stampCurrentKeys6159();let first=localSnapshot6159();await push6159(first);rawSet6159.call(localStorage,K_LAST,new Date().toISOString());setSyncState6159('ok','Synchronisée','Première copie envoyée au Cloud JKBat.');window.setJKBatCloudOnline6167?.('Synchronisation Cloud réussie');if(manual)toast('Synchronisation terminée');return}
      let local=localSnapshot6159(),merged=mergeSnapshots6159(local,remote),localCore=snapshotCore6159(local),remoteCore=snapshotCore6159(remote),mergedCore=snapshotCore6159(merged);
      if(mergedCore!==localCore)applySnapshot6159(merged);
      if(mergedCore!==remoteCore)await push6159(merged);
      rawSet6159.call(localStorage,K_LAST,new Date().toISOString());setSyncState6159('ok','Synchronisée','Téléphone et PC sont à jour.');window.setJKBatCloudOnline6167?.('Synchronisation Cloud réussie');if(manual)toast('Téléphone et PC synchronisés')
    }catch(e){console.error('JKBat sync',e);setSyncState6159('error','Erreur synchro',String(e?.message||e));if(manual)toast('Synchronisation impossible')}
    finally{syncBusy6159=false}
  };
  window.addEventListener('online',()=>scheduleSync6159(500));window.addEventListener('offline',()=>renderSyncSettings6159());
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')scheduleSync6159(700)});
  setInterval(()=>{if(configured6159()&&navigator.onLine)syncNow6159(false)},60000);
  setTimeout(()=>{renderSyncSettings6159();scheduleSync6159(1800)},1200);
})();



/* --- JKBat Pro 6.16.0 : administrateur du chat JKBat'Services --- */
(function(){
 'use strict';
 const A='jkp_chat_access_6160',R='jkp_chat_refresh_6160',U='jkp_chat_user_6160',E='jkp_chat_exp_6160',READ='jkp_chat_read_6160';
 let state={conversations:[],profiles:{},messages:[],admin:false,loading:false,current:null,lastError:'',filter:'all'},poll=null;
 function cloud(){return {url:(localStorage.getItem('jkbat_sync_url')||'').trim().replace(/\/+$/,''),key:(localStorage.getItem('jkbat_sync_public_key')||'').trim()}}
 function cloudReady(){let c=cloud();return /^https:\/\//i.test(c.url)&&c.key.length>15}
 function sess(){let user=null;try{user=JSON.parse(localStorage.getItem(U)||'null')}catch(e){}return {access:localStorage.getItem(A)||'',refresh:localStorage.getItem(R)||'',exp:Number(localStorage.getItem(E)||0),user}}
 function saveSess(j){if(j?.access_token)localStorage.setItem(A,j.access_token);if(j?.refresh_token)localStorage.setItem(R,j.refresh_token);if(j?.user)localStorage.setItem(U,JSON.stringify(j.user));if(j?.expires_in)localStorage.setItem(E,String(Date.now()+Number(j.expires_in)*1000));else if(j?.access_token)localStorage.setItem(E,String(Date.now()+3300000))}
 function clearSess(){[A,R,U,E].forEach(k=>localStorage.removeItem(k));state.admin=false;state.conversations=[];state.messages=[];state.profiles={}}
 function readMap(){try{return JSON.parse(localStorage.getItem(READ)||'{}')||{}}catch(e){return {}}}
 function writeRead(x){localStorage.setItem(READ,JSON.stringify(x||{}))}
 function status(kind,text,detail=''){let d=document.getElementById('chatDot6160'),t=document.getElementById('chatStatus6160'),z=document.getElementById('chatStatusDetail6160');if(d)d.className='chat6160-dot '+(kind==='ok'?'ok':kind==='bad'?'bad':'warn');if(t)t.textContent=text;if(z)z.textContent=detail}
 function fmt(t){let d=new Date(t);return isNaN(d)?'':d.toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}
 function short(x,n=90){x=String(x||'').replace(/\s+/g,' ').trim();return x.length>n?x.slice(0,n-1)+'…':x}
 async function auth(path,body){let c=cloud();if(!cloudReady())throw new Error('Configure d’abord le Cloud dans Réglages');let r=await fetch(c.url+path,{method:'POST',headers:{'apikey':c.key,'Content-Type':'application/json'},body:JSON.stringify(body||{})});let txt=await r.text(),j=null;try{j=txt?JSON.parse(txt):null}catch(e){}if(!r.ok)throw new Error(j?.msg||j?.error_description||j?.error||('Connexion '+r.status));return j}
 async function access(){let s=sess();if(!s.access)return '';if(s.exp>Date.now()+90000)return s.access;if(!s.refresh){clearSess();return ''}try{let j=await auth('/auth/v1/token?grant_type=refresh_token',{refresh_token:s.refresh});saveSess(j);return sess().access}catch(e){clearSess();throw new Error('Session expirée, reconnecte-toi') }}
 async function api(path,opt={}){let c=cloud(),tok=await access();if(!tok)throw new Error('Connexion administrateur requise');let headers={'apikey':c.key,'Authorization':'Bearer '+tok,'Content-Type':'application/json',...(opt.headers||{})};let r=await fetch(c.url+'/rest/v1/'+path,{...opt,headers});let txt=await r.text(),j=null;try{j=txt?JSON.parse(txt):null}catch(e){}if(!r.ok)throw new Error((j?.message||j?.hint||j?.details||txt||('Cloud '+r.status)).slice(0,240));return j}
 async function verifyAdmin(){let x=await api('rpc/jkbat_is_admin',{method:'POST',body:'{}'});state.admin=x===true;return state.admin}
 const PUSH61611='jkp_admin_fcm_61611';
 let pendingAdminFcm61611=localStorage.getItem(PUSH61611)||'';
 async function registerAdminPush61611(){
   if(!pendingAdminFcm61611||!state.admin||!sess().access||!cloudReady())return;
   try{
     await api('rpc/jkbat_register_push_token',{method:'POST',body:JSON.stringify({p_token:pendingAdminFcm61611,p_platform:'android-admin'})});
     localStorage.setItem('jkp_admin_push_registered_for_61611',sess().user?.id||'');
   }catch(e){console.warn('Admin push registration failed',e)}
 }
 async function unregisterAdminPush61611(){
   if(!pendingAdminFcm61611||!sess().access||!cloudReady())return;
   try{await api('rpc/jkbat_unregister_push_token',{method:'POST',body:JSON.stringify({p_token:pendingAdminFcm61611})})}catch(e){}
 }
 window.jkbatReceiveFcmToken=function(t){
   if(!t)return;
   pendingAdminFcm61611=String(t);
   localStorage.setItem(PUSH61611,pendingAdminFcm61611);
   registerAdminPush61611();
 };
 window.jkbatOpenAdminChatFromNotification=async function(conversationId){
   try{
     go('messages');
     if(!sess().access||!cloudReady())return;
     if(!state.admin)state.admin=await verifyAdmin();
     if(!state.admin)return;
     await registerAdminPush61611();
     await load(false);
     if(conversationId&&state.conversations.some(c=>c.id===conversationId))openConv(conversationId,true);
   }catch(e){console.warn('Open admin push conversation failed',e)}
 };
 async function login(){let email=(document.getElementById('chatEmail6160')?.value||'').trim(),password=document.getElementById('chatPassword6160')?.value||'';if(!email||!password)return toast('E-mail et mot de passe requis');try{status('warn','Connexion…');let j=await auth('/auth/v1/token?grant_type=password',{email,password});saveSess(j);let ok=await verifyAdmin();if(!ok){renderChat6160();let id=sess().user?.id||'';let note=document.getElementById('chatLoginNote6160');if(note)note.innerHTML=`Compte authentifié mais pas encore administrateur.<br><span class="chat6160-id">${esc(id)}</span><br>Ajoute cet UUID dans <b>jkbat_admins</b> depuis Supabase.`;status('bad','Compte non administrateur','Déclare ce compte dans jkbat_admins.');return toast('Compte à déclarer administrateur')};await registerAdminPush61611();document.getElementById('chatPassword6160').value='';renderChat6160();await load(true);toast('Messagerie connectée')}catch(e){console.error(e);status('bad','Connexion impossible',e.message);toast(e.message)}}
 async function logout(){try{await unregisterAdminPush61611()}catch(e){}clearSess();renderChat6160();status('warn','Déconnectée','Compte professionnel non connecté');toast('Messagerie déconnectée')}
 function profileFor(id){return state.profiles[id]||{id,full_name:'Client',email:'',phone:''}}
 function convMessages(id){return state.messages.filter(m=>m.conversation_id===id)}
 function unreadFor(id){let rd=readMap()[id]||'',rms=Date.parse(rd||0)||0;return convMessages(id).filter(m=>m.sender_role==='client'&&(Date.parse(m.created_at)||0)>rms).length}
 function latestFor(id){let a=convMessages(id);return a.length?a.reduce((x,y)=>(String(x.created_at)>String(y.created_at)?x:y)):null}
 function updateMenuBadge(){let total=state.conversations.reduce((n,c)=>n+unreadFor(c.id),0),els=[document.getElementById('chatMenuBadge6160'),document.getElementById('chatNavBadge6161')];els.forEach(b=>{if(b){b.textContent=total>99?'99+':String(total);b.classList.toggle('show',total>0)}});let u=document.getElementById('chatUnread6161'),t=document.getElementById('chatTotal6161');if(u)u.textContent=String(total);if(t)t.textContent=String(state.conversations.length);return total}

 function mediaLabel61617(m){return String(m?.media_type||'')==='video'?'🎥 Vidéo':'📷 Photo'}
 function messagePreview61617(m){if(!m)return'';let b=String(m.body||'').trim();if(m.media_type&&(!b||b===mediaLabel61617(m)))return mediaLabel61617(m);return b||mediaLabel61617(m)}
 function messageText61617(m){let b=String(m?.body||'').trim();return m?.media_type&&b===mediaLabel61617(m)?'':b}
 function mediaHtml61617(m){if(!m?.media_type||!m?.media_path)return'';return `<div class="chat-media61617" data-media-path="${esc(m.media_path)}" data-media-type="${esc(m.media_type)}" data-media-name="${esc(m.media_name||mediaLabel61617(m))}">Chargement du média…</div>`}
 async function signChatMedia61617(path){path=String(path||'').replace(/^\/+/,'');if(!path)return'';let c=cloud(),tok=await access();if(!tok)throw new Error('Connexion requise');let enc=path.split('/').map(encodeURIComponent).join('/'),r=await fetch(c.url+'/storage/v1/object/sign/jkbat-chat-media/'+enc,{method:'POST',headers:{'apikey':c.key,'Authorization':'Bearer '+tok,'Content-Type':'application/json'},body:JSON.stringify({expiresIn:3600})}),txt=await r.text(),j=null;try{j=txt?JSON.parse(txt):null}catch(e){}if(!r.ok)throw new Error(j?.message||j?.error||'Média indisponible');let signed=String(j?.signedURL||j?.signedUrl||'');if(signed&&!/^https?:\/\//i.test(signed))signed=c.url+'/storage/v1'+(signed.startsWith('/')?signed:'/'+signed);return signed}
 async function hydrateChatMedia61617(){let boxes=[...document.querySelectorAll('.chat-media61617[data-media-path]')];for(const box of boxes){if(box.dataset.loaded==='1')continue;box.dataset.loaded='1';try{let url=await signChatMedia61617(box.dataset.mediaPath);if(!url)throw new Error('Lien indisponible');box.innerHTML='';if(box.dataset.mediaType==='video'){let v=document.createElement('video');v.src=url;v.controls=true;v.preload='metadata';v.playsInline=true;box.appendChild(v)}else{let img=document.createElement('img');img.src=url;img.alt=box.dataset.mediaName||'Photo';box.appendChild(img)}}catch(e){box.innerHTML='<div class="chat-media-error61617">Média indisponible</div>'}}}
 async function deleteChatMediaObject61617(path){path=String(path||'').replace(/^\/+/,'');if(!path)return;let c=cloud(),tok=await access();if(!tok)return;let enc=path.split('/').map(encodeURIComponent).join('/');let r=await fetch(c.url+'/storage/v1/object/jkbat-chat-media/'+enc,{method:'DELETE',headers:{'apikey':c.key,'Authorization':'Bearer '+tok}});if(!r.ok&&r.status!==404){let txt=await r.text();throw new Error(txt||'Suppression média impossible')}}

 let adminMedia61618=null,adminMediaUploadActive61618=false,adminMediaCancelled61618=false;
 const nativeUploadWaiters61618=new Map();
 function adminMediaType61618(file){
   let t=String(file?.type||'').toLowerCase(),n=String(file?.name||'').toLowerCase();
   if(t.startsWith('image/')||/\.(jpg|jpeg|png|webp|gif|heic|heif)$/.test(n))return'image';
   if(t.startsWith('video/')||/\.(mp4|mov|m4v|webm|3gp|3gpp)$/.test(n))return'video';
   return'';
 }
 function safeMediaName61618(name){
   let x=String(name||'media').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9._-]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
   return (x||'media').slice(-120);
 }
 function adminMediaMime61618(file,type){
   let t=String(file?.type||'').toLowerCase();if((type==='image'&&t.startsWith('image/'))||(type==='video'&&t.startsWith('video/')))return t;
   let n=String(file?.name||'').toLowerCase();
   if(/\.jpe?g$/.test(n))return'image/jpeg';if(/\.png$/.test(n))return'image/png';if(/\.webp$/.test(n))return'image/webp';if(/\.gif$/.test(n))return'image/gif';if(/\.heic$/.test(n))return'image/heic';if(/\.heif$/.test(n))return'image/heif';
   if(/\.webm$/.test(n))return'video/webm';if(/\.(mov)$/.test(n))return'video/quicktime';if(/\.(3gp|3gpp)$/.test(n))return'video/3gpp';return type==='video'?'video/mp4':'image/jpeg';
 }
 function mediaSizeLabel61618(bytes){let n=Number(bytes)||0;if(n>=1024*1024)return (n/1024/1024).toFixed(n>=10?1:2)+' Mo';return Math.max(1,Math.round(n/1024))+' Ko'}
 function nativeMediaAvailable61618(){try{return !!window.JKBatNative&&typeof window.JKBatNative.uploadSelectedMedia==='function'&&window.JKBatNative.hasSelectedFile()}catch(e){return false}}
 function setAdminMediaProgress61618(percent,label){
   let box=document.getElementById('chatMediaProgress61618'),fill=document.getElementById('chatMediaProgressFill61618'),txt=document.getElementById('chatMediaProgressText61618'),pct=document.getElementById('chatMediaProgressPct61618');
   let p=Math.max(0,Math.min(100,Number(percent)||0));if(box)box.classList.toggle('show',adminMediaUploadActive61618);if(fill)fill.style.width=p+'%';if(txt)txt.textContent=label||'Envoi du média…';if(pct)pct.textContent=Math.round(p)+' %';
 }
 window.jkbatProNativeUploadProgress=function(requestId,percent){
   let w=nativeUploadWaiters61618.get(String(requestId));if(!w)return;
   let kind=w.type==='video'?'vidéo':'photo';setAdminMediaProgress61618(percent,'Envoi '+kind+'…');
 }
 window.jkbatProNativeUploadDone=function(requestId,status,response){
   let k=String(requestId),w=nativeUploadWaiters61618.get(k);if(!w)return;nativeUploadWaiters61618.delete(k);w.resolve({status:Number(status)||0,text:String(response||'')});
 }
 function renderAdminMediaSelection61618(){
   let box=document.getElementById('chatMediaPick61618'),name=document.getElementById('chatMediaName61618'),meta=document.getElementById('chatMediaMeta61618');
   if(!box)return;
   if(!adminMedia61618){box.classList.remove('show');if(name)name.textContent='';if(meta)meta.textContent='';return}
   let type=adminMediaType61618(adminMedia61618);box.classList.add('show');
   if(name)name.textContent=(type==='video'?'🎥 ':'📷 ')+(adminMedia61618.name||mediaLabel61617({media_type:type}));
   if(meta)meta.textContent=(type==='video'?'Vidéo':'Photo')+' · '+mediaSizeLabel61618(adminMedia61618.size);
 }
 function prepareAdminMedia61618(files){
   let f=files&&files[0];if(!f){adminMedia61618=null;renderAdminMediaSelection61618();return}
   let type=adminMediaType61618(f);if(!type){toast('Format non pris en charge');let inp=document.getElementById('chatMediaInput61618');if(inp)inp.value='';return}
   let max=type==='video'?50*1024*1024:15*1024*1024;
   if(Number(f.size||0)>max){toast(type==='video'?'Vidéo trop volumineuse (50 Mo max)':'Photo trop volumineuse (15 Mo max)');let inp=document.getElementById('chatMediaInput61618');if(inp)inp.value='';return}
   adminMedia61618=f;renderAdminMediaSelection61618();
 }
 function clearAdminMedia61618(){
   if(adminMediaUploadActive61618){adminMediaCancelled61618=true;try{window.JKBatNative?.cancelMediaUpload?.()}catch(e){}return}
   adminMedia61618=null;let inp=document.getElementById('chatMediaInput61618');if(inp)inp.value='';renderAdminMediaSelection61618();
 }
 async function refreshAdminToken61618(){
   let s=sess();if(!s.refresh)throw new Error('Session expirée, reconnecte-toi');
   let j=await auth('/auth/v1/token?grant_type=refresh_token',{refresh_token:s.refresh});saveSess(j);return sess().access
 }
 async function uploadAdminMediaNative61618(file,path,type,retry=true){
   if(!nativeMediaAvailable61618())throw new Error('Envoi média natif indisponible');
   let c=cloud(),tok=await access(),enc=path.split('/').map(encodeURIComponent).join('/'),url=c.url+'/storage/v1/object/jkbat-chat-media/'+enc,requestId='pro-media-'+Date.now()+'-'+Math.random().toString(36).slice(2);
   let result=await new Promise((resolve,reject)=>{nativeUploadWaiters61618.set(requestId,{resolve,reject,type});try{window.JKBatNative.uploadSelectedMedia(url,adminMediaMime61618(file,type),tok,c.key,requestId)}catch(e){nativeUploadWaiters61618.delete(requestId);reject(e)}});
   if(result.status===401&&retry){await refreshAdminToken61618();return uploadAdminMediaNative61618(file,path,type,false)}
   if(result.status<200||result.status>=300){
     let msg=adminMediaCancelled61618?'Envoi annulé':'Le média n’a pas pu être envoyé';
     try{let j=JSON.parse(result.text||'{}');msg=j.message||j.error||msg}catch(e){if(result.text&&result.text.length<180)msg=result.text}
     if(result.status===0&&!adminMediaCancelled61618)msg=result.text||'Connexion interrompue pendant l’envoi';
     throw new Error(msg);
   }
 }
 async function uploadAdminMediaStandard61618(file,path,retry=true){
   let c=cloud(),tok=await access(),enc=path.split('/').map(encodeURIComponent).join('/');
   setAdminMediaProgress61618(12,'Envoi de la photo…');
   let r=await fetch(c.url+'/storage/v1/object/jkbat-chat-media/'+enc,{method:'POST',headers:{'apikey':c.key,'Authorization':'Bearer '+tok,'x-upsert':'false','Content-Type':adminMediaMime61618(file,'image')},body:file});
   if(r.status===401&&retry){await refreshAdminToken61618();return uploadAdminMediaStandard61618(file,path,false)}
   if(!r.ok){let txt=await r.text(),msg='Envoi du média impossible';try{let j=JSON.parse(txt||'{}');msg=j.message||j.error||msg}catch(e){if(txt&&txt.length<180)msg=txt}throw new Error(msg)}
   setAdminMediaProgress61618(100,'Photo envoyée · finalisation…');
 }
 async function uploadAdminMedia61618(file,conversationId){
   let type=adminMediaType61618(file);if(!type)throw new Error('Format non pris en charge');
   let s=sess();if(!s.user?.id)throw new Error('Reconnecte le compte JKBat');
   let name=safeMediaName61618(file.name||(type==='video'?'video.mp4':'photo.jpg')),path=`${conversationId}/${s.user.id}/${Date.now()}-${name}`;
   adminMediaUploadActive61618=true;adminMediaCancelled61618=false;setAdminMediaProgress61618(1,type==='video'?'Préparation de la vidéo…':'Préparation de la photo…');
   try{
     if(type==='video'&&nativeMediaAvailable61618())await uploadAdminMediaNative61618(file,path,type);
     else if(type==='video')throw new Error('Cette version Android ne permet pas encore l’envoi vidéo natif');
     else await uploadAdminMediaStandard61618(file,path);
     return{media_type:type,media_path:path,media_name:file.name||name,media_mime:adminMediaMime61618(file,type),media_size:Number(file.size)||0};
   }finally{
     adminMediaUploadActive61618=false;setAdminMediaProgress61618(100,'Finalisation…');
   }
 }

 async function fetchAdminMessageRows61617(cids){if(!cids.length)return[];let q='jkbat_messages?conversation_id=in.('+cids.join(',')+')&order=created_at.asc&limit=2000';try{return await api(q+'&select=id,conversation_id,sender_id,sender_role,body,created_at,media_type,media_path,media_name,media_mime,media_size')||[]}catch(e){return await api(q+'&select=id,conversation_id,sender_id,sender_role,body,created_at')||[]}}
 async function load(manual=false){if(state.loading)return;if(!cloudReady()){renderChat6160();return}if(!sess().access){renderChat6160();return}state.loading=true;try{if(!state.admin&&!(await verifyAdmin())){renderChat6160();return}if(manual)status('warn','Actualisation…');let cs=await api('jkbat_conversations?select=id,client_id,created_at,updated_at&order=updated_at.desc&limit=250')||[];state.conversations=cs;let ids=[...new Set(cs.map(x=>x.client_id).filter(Boolean))],cids=cs.map(x=>x.id).filter(Boolean);let ps=[],ms=[];if(ids.length)ps=await api('jkbat_client_profiles?id=in.('+ids.join(',')+')&select=id,full_name,phone,email,address')||[];ms=await fetchAdminMessageRows61617(cids);state.profiles=Object.fromEntries(ps.map(p=>[p.id,p]));state.messages=ms;status('ok','Connectée',`${cs.length} conversation(s) · ${updateMenuBadge()} non lu(s)`);window.setJKBatCloudOnline6167?.('Messagerie Cloud connectée');renderChat6160();renderList()}catch(e){console.error('chat6160',e);state.lastError=e.message;status('bad','Erreur messagerie',e.message);if(manual)toast('Impossible de charger les messages')}finally{state.loading=false}}
 function renderChat6160(){let login=document.getElementById('chatLoginBox6160'),main=document.getElementById('chatMain6160'),s=sess();if(!login||!main)return;if(!cloudReady()){login.style.display='block';main.style.display='none';let note=document.getElementById('chatLoginNote6160');if(note)note.innerHTML='Configure d’abord <b>Réglages → Synchronisation téléphone ↔ PC</b> avec l’URL et la clé publique du même projet Supabase que JKBat’Services.';status('warn','Cloud non configuré','URL et clé publique manquantes.');return}if(!s.access||!state.admin){login.style.display='block';main.style.display='none';if(s.user&&!state.admin){let note=document.getElementById('chatLoginNote6160');if(note)note.innerHTML=`Compte authentifié : <b>${esc(s.user.email||'')}</b><br>UUID : <span class="chat6160-id">${esc(s.user.id||'')}</span><br>Il doit être ajouté dans <b>jkbat_admins</b>.`;}else status('warn','Compte à connecter','Connecte le compte professionnel JKBat.');return}login.style.display='none';main.style.display='block';let a=document.getElementById('chatAccount6160'),sub=document.getElementById('chatAccountSub6160');if(a)a.textContent=s.user?.email||'JKBat';if(sub)sub.textContent='Administrateur JKBat’Services';renderList()}
 function setFilter(filter,btn){state.filter=filter==='unread'?'unread':'all';document.querySelectorAll('.chat6161-tab').forEach(x=>x.classList.toggle('active',x.dataset.filter===state.filter));renderList()}
 function renderList(){let box=document.getElementById('chatList6160');if(!box)return;let q=(document.getElementById('chatSearch6160')?.value||'').trim().toLowerCase(),arr=state.conversations.slice().sort((a,b)=>String(b.updated_at).localeCompare(String(a.updated_at))).filter(c=>{let p=profileFor(c.client_id),l=latestFor(c.id),ok=!q||[p.full_name,p.email,p.phone,messagePreview61617(l)].join(' ').toLowerCase().includes(q);if(state.filter==='unread')ok=ok&&unreadFor(c.id)>0;return ok});let count=document.getElementById('chatCount6160');if(count)count.textContent=`${arr.length} affichée${arr.length>1?'s':''}`;updateMenuBadge();if(!arr.length){box.innerHTML=`<div class="chat6160-empty">${state.filter==='unread'?'Aucun message non lu.':'Aucune conversation client pour le moment.'}</div>`;return}box.innerHTML=arr.map(c=>{let p=profileFor(c.client_id),l=latestFor(c.id),u=unreadFor(c.id),initial=(p.full_name||p.email||'C').trim().split(/\s+/).map(x=>x[0]||'').join('').slice(0,2).toUpperCase(),who=l?(l.sender_role==='business'?'Vous : ':''):'';return `<div class="card chat6160-card ${u?'unread':''}" onclick="openChatConversation6160('${c.id}')"><div class="chat6160-avatar">${esc(initial||'C')}</div><div class="chat6160-card-main"><div class="chat6160-name-line"><b>${esc(p.full_name||p.email||'Client')}</b></div><div class="chat6160-preview">${l?`${who}${esc(short(messagePreview61617(l),105))}`:'Conversation ouverte'}</div><div class="chat6160-contact">${esc(p.phone||p.email||'Client JKBat’Services')}</div></div><div class="chat6160-meta"><span class="chat6160-time">${l?fmt(l.created_at):fmt(c.updated_at)}</span>${u?`<span class="chat6160-badge">${u}</span>`:'<span class="chat6160-chevron">›</span>'}</div></div>`}).join('')}
 function openConv(id,refresh=false){let c=state.conversations.find(x=>x.id===id);if(!c)return;adminMedia61618=null;adminMediaUploadActive61618=false;adminMediaCancelled61618=false;state.current=id;let p=profileFor(c.client_id),a=convMessages(id).slice().sort((x,y)=>String(x.created_at).localeCompare(String(y.created_at)));let last=a[a.length-1]?.created_at||new Date().toISOString(),rm=readMap();rm[id]=last;writeRead(rm);renderList();let thread=a.length?a.map(m=>{let text=messageText61617(m),content=mediaHtml61617(m)+(text?`<div class="chat-media-text61617">${esc(text).replace(/\n/g,'<br>')}</div>`:'');return `<div class="chat6160-bubble ${m.sender_role==='business'?'business':'client'}">${content}<small class="chat-meta61612"><span>${m.sender_role==='business'?'Vous':'Client'} · ${fmt(m.created_at)}</span><button class="chat-delete61612" aria-label="Supprimer le message" title="Supprimer" onclick="event.stopPropagation();deleteChatMessage61612('${esc(String(m.id||''))}','${esc(String(id||''))}')">🗑 Supprimer</button></small></div>`}).join(''):'<div class="chat6160-empty">Aucun message. Tu peux écrire le premier message.</div>';openModal(p.full_name||p.email||'Conversation',`<div class="muted" style="margin-bottom:9px">${esc(p.phone||'')} ${p.email?'· '+esc(p.email):''}</div><div class="chat6160-thread" id="chatThread6160">${thread}</div><div class="chat6160-compose"><textarea class="field" id="chatReply6160" maxlength="2000" placeholder="Écrire au client…"></textarea><div class="chat-media-pick61618" id="chatMediaPick61618"><div class="grow"><b id="chatMediaName61618"></b><small id="chatMediaMeta61618"></small></div><button type="button" onclick="clearAdminMedia61618()" aria-label="Retirer le média">×</button></div><div class="chat-media-progress61618" id="chatMediaProgress61618"><div class="line"><span id="chatMediaProgressText61618">Préparation…</span><span id="chatMediaProgressPct61618">0 %</span></div><div class="track"><div class="fill" id="chatMediaProgressFill61618"></div></div></div><div class="actions media61618"><button class="btn primary wide61618" id="chatSendBtn61618" onclick="sendAdminMessage6160('${id}')">Envoyer</button><label class="btn chat-attach61618">📷 Photo / vidéo<input id="chatMediaInput61618" type="file" accept="image/*,video/mp4,video/webm,video/quicktime,video/3gpp" onchange="prepareAdminMedia61618(this.files)"></label><button class="btn" onclick="openClientDocument6162('${id}')">📎 Document</button><button class="btn" onclick="manageClientDocuments6163('${id}')">📂 Documents envoyés</button><button class="btn" onclick="loadChats6160(true)">↻ Actualiser</button></div></div>`);setTimeout(async()=>{await hydrateChatMedia61617();let t=document.getElementById('chatThread6160');if(t)t.scrollTop=t.scrollHeight},30)}

 function safeName6162(name){
   let x=String(name||'document').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9._-]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
   return (x||'document').slice(-100)
 }
 function kindFromFile6162(file){let n=String(file?.name||'').toLowerCase();return /\.(jpg|jpeg|png|webp|heic|heif)$/.test(n)?'Photo':'Document'}
 function openClientDocument6162(id){
   let c=state.conversations.find(x=>x.id===id);if(!c)return toast('Conversation introuvable');
   let p=profileFor(c.client_id);
   openModal('Envoyer un document',`<div class="docsend6162-note"><b>${esc(p.full_name||p.email||'Client')}</b><br>Le fichier sera stocké dans l’espace privé de ce client et apparaîtra dans <b>Mes documents</b>.</div><div class="form" style="margin-top:10px"><div><label class="label">Type</label><select class="field" id="docSendKind6162"><option>Devis</option><option>Facture</option><option>Photo</option><option>Attestation</option><option>Rapport</option><option>Autre</option></select></div><div><label class="label">Titre affiché au client</label><input class="field" id="docSendTitle6162" placeholder="Ex. Devis salle de bain"></div><div class="form two"><div><label class="label">Statut</label><select class="field" id="docSendStatus6162"><option>Disponible</option><option>À signer</option><option>Payée</option><option>Archivé</option></select></div><div><label class="label">Montant (€)</label><input class="field" id="docSendAmount6162" inputmode="decimal" type="number" step="0.01" min="0" placeholder="Optionnel"></div></div><label class="docsend6162-file file-label"><span>📎</span><span class="grow"><b>Choisir un PDF ou une photo</b><small id="docSendFileName6162">Aucun fichier choisi</small></span><input id="docSendFile6162" type="file" accept="application/pdf,image/*,.pdf" onchange="prepareClientDocument6162(this.files)"></label><button class="btn primary full" id="docSendBtn6162" onclick="uploadClientDocument6162('${id}')">Envoyer au client</button></div>`)
 }
 function prepareClientDocument6162(files){
   let f=files&&files[0],n=document.getElementById('docSendFileName6162'),t=document.getElementById('docSendTitle6162'),k=document.getElementById('docSendKind6162');
   if(!f){if(n)n.textContent='Aucun fichier choisi';return}
   if(n)n.textContent=`${f.name} · ${Math.max(1,Math.round(f.size/1024))} Ko`;
   if(t&&!t.value)t.value=String(f.name||'Document').replace(/\.[^.]+$/,'').replace(/[-_]+/g,' ');
   if(k&&kindFromFile6162(f)==='Photo')k.value='Photo'
 }
 async function storageUpload6162(clientId,file){
   let c=cloud(),tok=await access();if(!tok)throw new Error('Connexion administrateur requise');
   if(!file)throw new Error('Choisis un fichier');
   if(file.size>20*1024*1024)throw new Error('Fichier trop volumineux (20 Mo max)');
   let fn=`${Date.now()}-${safeName6162(file.name)}`,path=`${clientId}/${fn}`,enc=path.split('/').map(encodeURIComponent).join('/');
   let r=await fetch(c.url+'/storage/v1/object/jkbat-client-documents/'+enc,{method:'POST',headers:{'apikey':c.key,'Authorization':'Bearer '+tok,'x-upsert':'false','Content-Type':file.type||'application/octet-stream'},body:file});
   let txt=await r.text();if(!r.ok){let j=null;try{j=txt?JSON.parse(txt):null}catch(e){}throw new Error((j?.message||j?.error||txt||('Storage '+r.status)).slice(0,220))}
   return path
 }
 async function uploadClientDocument6162(id){
   let c=state.conversations.find(x=>x.id===id);if(!c)return toast('Conversation introuvable');
   let input=document.getElementById('docSendFile6162'),file=input?.files?.[0];if(!file)return toast('Choisis un PDF ou une photo');
   let title=(document.getElementById('docSendTitle6162')?.value||'').trim();if(!title)return toast('Indique un titre');
   let kind=document.getElementById('docSendKind6162')?.value||'Document',statusDoc=document.getElementById('docSendStatus6162')?.value||'Disponible',raw=(document.getElementById('docSendAmount6162')?.value||'').trim(),amount=raw===''?null:Number(raw.replace(',','.'));
   if(amount!==null&&!Number.isFinite(amount))return toast('Montant invalide');
   let btn=document.getElementById('docSendBtn6162');if(btn){btn.disabled=true;btn.textContent='Envoi en cours…'}
   let uploadedPath='';
   try{
     if(!state.admin&&!(await verifyAdmin()))throw new Error('Compte JKBat non administrateur');
     uploadedPath=await storageUpload6162(c.client_id,file);
     await api('jkbat_client_documents',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify({client_id:c.client_id,kind,title,status:statusDoc,amount,file_url:'storage:'+uploadedPath})});
     let s=sess(),body=`Nouveau document disponible : ${title}`;
     try{await api('jkbat_messages',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify({conversation_id:id,sender_id:s.user.id,sender_role:'business',body})})}catch(e){console.warn('Notification document',e)}
     await load(false);openConv(id,true);toast('Document envoyé au client')
   }catch(e){console.error('Document client',e);toast(e.message||'Envoi impossible');if(btn){btn.disabled=false;btn.textContent='Envoyer au client'}}
 }
 async function storageDelete6163(fileUrl){
   let ref=String(fileUrl||'').trim();
   if(!ref||!ref.toLowerCase().startsWith('storage:'))return;
   let path=ref.slice(8).replace(/^\/+/, '');
   if(path.toLowerCase().startsWith('jkbat-client-documents/'))path=path.slice('jkbat-client-documents/'.length);
   if(!path)return;
   let c=cloud(),tok=await access();if(!tok)throw new Error('Connexion administrateur requise');
   let enc=path.split('/').map(encodeURIComponent).join('/');
   let r=await fetch(c.url+'/storage/v1/object/jkbat-client-documents/'+enc,{method:'DELETE',headers:{'apikey':c.key,'Authorization':'Bearer '+tok}});
   if(!r.ok&&r.status!==404){let txt=await r.text(),j=null;try{j=txt?JSON.parse(txt):null}catch(e){}throw new Error((j?.message||j?.error||txt||('Storage '+r.status)).slice(0,220))}
 }
 function docAmount6163(v){if(v===null||v===undefined||v==='')return '';let n=Number(v);return Number.isFinite(n)?n.toLocaleString('fr-FR',{style:'currency',currency:'EUR'}):''}
 async function manageClientDocuments6163(id){
   let c=state.conversations.find(x=>x.id===id);if(!c)return toast('Conversation introuvable');
   let p=profileFor(c.client_id);
   try{
     if(!state.admin&&!(await verifyAdmin()))throw new Error('Compte JKBat non administrateur');
     let docsClient=await api(`jkbat_client_documents?client_id=eq.${encodeURIComponent(c.client_id)}&select=id,kind,title,status,amount,file_url,created_at&order=created_at.desc`)||[];
     let cards=docsClient.length?docsClient.map(d=>`<div class="card" style="margin-bottom:8px"><div style="display:flex;align-items:flex-start;gap:9px"><div class="grow"><b>${esc(d.title||d.kind||'Document')}</b><div class="muted" style="margin-top:3px">${esc(d.kind||'Document')} · ${fmt(d.created_at)}${d.amount!=null?' · '+esc(docAmount6163(d.amount)):''}</div><div class="muted" style="margin-top:2px">${esc(d.status||'Disponible')}</div></div></div><div class="actions" style="margin-top:9px;gap:6px;flex-wrap:wrap"><button class="btn small" onclick="editClientDocument6165('${id}','${esc(String(d.id||''))}')">✏️ Modifier</button><button class="btn small" onclick="replaceClientDocument6165('${id}','${esc(String(d.id||''))}')">🔄 Remplacer</button><button class="btn danger small" onclick="deleteClientDocument6163('${id}','${esc(String(d.id||''))}')">Supprimer</button></div></div>`).join(''):'<div class="chat6160-empty">Aucun document envoyé à ce client.</div>';
     window._jkbatClientDocs6163=docsClient;
     openModal('Documents du client',`<div class="docsend6162-note"><b>${esc(p.full_name||p.email||'Client')}</b><br>Tu peux modifier les informations, remplacer le fichier ou supprimer définitivement le document du compte client.</div><div style="margin-top:10px">${cards}</div><div class="actions"><button class="btn" onclick="closeModal();openChatConversation6160('${id}')">Retour à la conversation</button></div>`)
   }catch(e){console.error('Liste documents client',e);toast(e.message||'Impossible de charger les documents')}
 }
 function clientDoc6165(docId){return (window._jkbatClientDocs6163||[]).find(x=>String(x.id)===String(docId))}
 function editClientDocument6165(convId,docId){
   let d=clientDoc6165(docId);if(!d)return toast('Document introuvable');
   let amount=d.amount===null||d.amount===undefined?'':String(d.amount);
   openModal('Modifier le document',`<div class="docsend6162-note"><b>${esc(d.title||d.kind||'Document')}</b><br>Les modifications seront visibles dans <b>Mes documents</b> du client et une notification sera envoyée si une information change.</div><div class="form" style="margin-top:10px"><div><label class="label">Titre</label><input class="field" id="docEditTitle6165" value="${esc(d.title||'')}"></div><div class="form two"><div><label class="label">Type</label><select class="field" id="docEditKind6165"><option${d.kind==='Devis'?' selected':''}>Devis</option><option${d.kind==='Facture'?' selected':''}>Facture</option><option${d.kind==='Photo'?' selected':''}>Photo</option><option${d.kind==='Attestation'?' selected':''}>Attestation</option><option${d.kind==='Rapport'?' selected':''}>Rapport</option><option${!['Devis','Facture','Photo','Attestation','Rapport'].includes(d.kind)?' selected':''}>Autre</option></select></div><div><label class="label">Statut</label><select class="field" id="docEditStatus6165"><option${d.status==='Disponible'?' selected':''}>Disponible</option><option${d.status==='À signer'?' selected':''}>À signer</option><option${d.status==='Signé'?' selected':''}>Signé</option><option${d.status==='Payée'?' selected':''}>Payée</option><option${d.status==='Archivé'?' selected':''}>Archivé</option></select></div></div><div><label class="label">Montant (€)</label><input class="field" id="docEditAmount6165" type="number" inputmode="decimal" step="0.01" min="0" value="${esc(amount)}" placeholder="Optionnel"></div><div class="actions"><button class="btn primary" id="docEditSave6165" onclick="saveClientDocument6165('${convId}','${esc(String(d.id||''))}')">Enregistrer</button><button class="btn" onclick="manageClientDocuments6163('${convId}')">Annuler</button></div></div>`)
 }
 async function saveClientDocument6165(convId,docId){
   let d=clientDoc6165(docId);if(!d)return toast('Document introuvable');
   let title=(document.getElementById('docEditTitle6165')?.value||'').trim();if(!title)return toast('Indique un titre');
   let kind=document.getElementById('docEditKind6165')?.value||'Autre',statusDoc=document.getElementById('docEditStatus6165')?.value||'Disponible',raw=(document.getElementById('docEditAmount6165')?.value||'').trim(),amount=raw===''?null:Number(raw.replace(',','.'));
   if(amount!==null&&!Number.isFinite(amount))return toast('Montant invalide');
   let oldAmount=(d.amount===null||d.amount===undefined||d.amount==='')?null:Number(d.amount);
   let changedTitle=String(d.title||'')!==title,changedKind=String(d.kind||'')!==kind,changedStatus=String(d.status||'Disponible')!==statusDoc;
   let changedAmount=(oldAmount===null)!==(amount===null)||(oldAmount!==null&&amount!==null&&Math.abs(oldAmount-amount)>0.005);
   let hasChanges=changedTitle||changedKind||changedStatus||changedAmount;
   let btn=document.getElementById('docEditSave6165');if(btn){btn.disabled=true;btn.textContent='Enregistrement…'}
   try{
     if(!state.admin&&!(await verifyAdmin()))throw new Error('Compte JKBat non administrateur');
     await api(`jkbat_client_documents?id=eq.${encodeURIComponent(d.id)}`,{method:'PATCH',headers:{'Prefer':'return=minimal'},body:JSON.stringify({title,kind,status:statusDoc,amount})});
     if(hasChanges){
       let body='';
       if(changedTitle&&changedStatus)body=`Document mis à jour : ${title} — statut : ${statusDoc}`;
       else if(changedTitle)body=`Document renommé : ${title}`;
       else if(changedStatus)body=`Statut du document mis à jour : ${title} — ${statusDoc}`;
       else body=`Document mis à jour : ${title}`;
       let s=sess();
       try{await api('jkbat_messages',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify({conversation_id:convId,sender_id:s.user.id,sender_role:'business',body})})}catch(e){console.warn('Notification modification document',e)}
     }
     await load(false);toast(hasChanges?'Document mis à jour et client notifié':'Aucune modification');await manageClientDocuments6163(convId)
   }catch(e){console.error('Modification document client',e);toast(e.message||'Modification impossible');if(btn){btn.disabled=false;btn.textContent='Enregistrer'}}
 }
 function replaceClientDocument6165(convId,docId){
   let d=clientDoc6165(docId);if(!d)return toast('Document introuvable');
   openModal('Remplacer le document',`<div class="docsend6162-note"><b>${esc(d.title||d.kind||'Document')}</b><br>Le nouveau fichier remplacera celui actuellement visible par le client. Le titre et le statut restent inchangés.</div><div class="form" style="margin-top:10px"><label class="docsend6162-file file-label"><span>🔄</span><span class="grow"><b>Choisir le nouveau PDF ou la nouvelle photo</b><small id="docReplaceFileName6165">Aucun fichier choisi</small></span><input id="docReplaceFile6165" type="file" accept="application/pdf,image/*,.pdf" onchange="prepareReplacement6165(this.files)"></label><div class="actions"><button class="btn primary" id="docReplaceBtn6165" onclick="saveReplacement6165('${convId}','${esc(String(d.id||''))}')">Remplacer le fichier</button><button class="btn" onclick="manageClientDocuments6163('${convId}')">Annuler</button></div></div>`)
 }
 function prepareReplacement6165(files){let f=files&&files[0],n=document.getElementById('docReplaceFileName6165');if(n)n.textContent=f?`${f.name} · ${Math.max(1,Math.round(f.size/1024))} Ko`:'Aucun fichier choisi'}
 async function saveReplacement6165(convId,docId){
   let d=clientDoc6165(docId);if(!d)return toast('Document introuvable');
   let c=state.conversations.find(x=>x.id===convId);if(!c)return toast('Conversation introuvable');
   let file=document.getElementById('docReplaceFile6165')?.files?.[0];if(!file)return toast('Choisis le nouveau fichier');
   let btn=document.getElementById('docReplaceBtn6165');if(btn){btn.disabled=true;btn.textContent='Remplacement…'}
   let newPath='';
   try{
     if(!state.admin&&!(await verifyAdmin()))throw new Error('Compte JKBat non administrateur');
     newPath=await storageUpload6162(c.client_id,file);
     try{
       await api(`jkbat_client_documents?id=eq.${encodeURIComponent(d.id)}`,{method:'PATCH',headers:{'Prefer':'return=minimal'},body:JSON.stringify({file_url:'storage:'+newPath})});
     }catch(e){try{await storageDelete6163('storage:'+newPath)}catch(_){};throw e}
     try{await storageDelete6163(d.file_url)}catch(e){console.warn('Ancien fichier non effacé',e)}
     let s=sess(),body=`Document mis à jour : ${d.title||d.kind||'Document'}`;
     try{await api('jkbat_messages',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify({conversation_id:convId,sender_id:s.user.id,sender_role:'business',body})})}catch(e){console.warn('Notification remplacement document',e)}
     await load(false);toast('Document remplacé pour le client');await manageClientDocuments6163(convId)
   }catch(e){console.error('Remplacement document client',e);toast(e.message||'Remplacement impossible');if(btn){btn.disabled=false;btn.textContent='Remplacer le fichier'}}
 }

 async function deleteClientDocument6163(convId,docId){
   let docsClient=window._jkbatClientDocs6163||[],d=docsClient.find(x=>String(x.id)===String(docId));
   if(!d)return toast('Document introuvable');
   if(!await askConfirm6164(`Supprimer définitivement « ${d.title||d.kind||'ce document'} » pour vous et pour le client ?`))return;
   try{
     if(!state.admin&&!(await verifyAdmin()))throw new Error('Compte JKBat non administrateur');
     await storageDelete6163(d.file_url);
     await api(`jkbat_client_documents?id=eq.${encodeURIComponent(d.id)}`,{method:'DELETE',headers:{'Prefer':'return=minimal'}});
     toast('Document supprimé pour vous et le client');
     await manageClientDocuments6163(convId)
   }catch(e){console.error('Suppression document client',e);toast(e.message||'Suppression impossible')}
 }


 async function deleteChatMessage61612(messageId,convId){
   let msg=state.messages.find(x=>String(x.id)===String(messageId));
   if(!msg)return toast('Message introuvable');
   if(!await askConfirm6164('Supprimer définitivement ce message pour vous et pour le client ?'))return;
   try{
     if(!state.admin&&!(await verifyAdmin()))throw new Error('Compte JKBat non administrateur');
     if(msg.media_path){try{await deleteChatMediaObject61617(msg.media_path)}catch(e){console.warn('Suppression média',e)}}
     await api(`jkbat_messages?id=eq.${encodeURIComponent(messageId)}`,{method:'DELETE',headers:{'Prefer':'return=minimal'}});
     state.messages=state.messages.filter(x=>String(x.id)!==String(messageId));
     await load(false);
     if(state.conversations.some(c=>String(c.id)===String(convId)))openConv(convId,true);
     toast('Message supprimé pour vous et le client');
   }catch(e){
     console.error('Suppression message',e);
     toast(e.message||'Suppression impossible');
   }
 }

 async function send(id){let el=document.getElementById('chatReply6160'),btn=document.getElementById('chatSendBtn61618'),body=(el?.value||'').trim(),file=adminMedia61618;if(!body&&!file)return;if(body.length>2000)return toast('Message trop long');let s=sess();if(!s.user?.id)return toast('Reconnecte le compte JKBat');let media=null;if(el)el.disabled=true;if(btn){btn.disabled=true;btn.textContent=file?'Envoi du média…':'Envoi…'}try{if(file)media=await uploadAdminMedia61618(file,id);let finalBody=body||(media?mediaLabel61617(media):'');let payload={conversation_id:id,sender_id:s.user.id,sender_role:'business',body:finalBody};if(media)Object.assign(payload,media);await api('jkbat_messages',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify(payload)});if(el)el.value='';adminMedia61618=null;let inp=document.getElementById('chatMediaInput61618');if(inp)inp.value='';await load(false);openConv(id,true);toast(media?(media.media_type==='video'?'Vidéo envoyée':'Photo envoyée'):'Message envoyé')}catch(e){console.error('Envoi média admin',e);if(media?.media_path)try{await deleteChatMediaObject61617(media.media_path)}catch(x){}if(el){el.disabled=false;el.value=body}if(btn){btn.disabled=false;btn.textContent='Envoyer'}adminMediaUploadActive61618=false;setAdminMediaProgress61618(0,'');renderAdminMediaSelection61618();toast(e.message||'Envoi impossible')}}
 function onScreen(){return document.getElementById('messages')?.classList.contains('active')}
 function startPoll(){if(poll)return;poll=setInterval(()=>{if(navigator.onLine&&sess().access&&(onScreen()||document.visibilityState==='visible'))load(false)},4000)}
 const baseGo=window.go;window.go=function(id){baseGo(id);if(id==='messages'){renderChat6160();load(false)}};
 window.chatLogin6160=login;window.chatLogout6160=logout;window.loadChats6160=load;window.renderChatList6160=renderList;window.setChatFilter6161=setFilter;window.openChatConversation6160=openConv;window.sendAdminMessage6160=send;window.openClientDocument6162=openClientDocument6162;window.prepareClientDocument6162=prepareClientDocument6162;window.uploadClientDocument6162=uploadClientDocument6162;window.manageClientDocuments6163=manageClientDocuments6163;window.deleteClientDocument6163=deleteClientDocument6163;window.editClientDocument6165=editClientDocument6165;window.saveClientDocument6165=saveClientDocument6165;window.replaceClientDocument6165=replaceClientDocument6165;window.prepareReplacement6165=prepareReplacement6165;window.saveReplacement6165=saveReplacement6165;window.deleteChatMessage61612=deleteChatMessage61612;window.prepareAdminMedia61618=prepareAdminMedia61618;window.clearAdminMedia61618=clearAdminMedia61618;
 window.addEventListener('online',()=>{if(sess().access)load(false)});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&sess().access)load(false)});
 setTimeout(async()=>{renderChat6160();startPoll();if(sess().access&&cloudReady()){try{state.admin=await verifyAdmin();if(state.admin){await registerAdminPush61611();await load(false)}else renderChat6160()}catch(e){renderChat6160()}}},1500);
})();

/* --- JKBat Pro 6.16.7 : statut Cloud réel dans l’en-tête --- */
(function(){
  'use strict';
  const K_URL='jkbat_sync_url', K_KEY='jkbat_sync_public_key';
  let busy=false, lastOk=0, retryTimer=null;

  function cloudConfig6167(){
    return {
      url:(localStorage.getItem(K_URL)||'').trim().replace(/\/+$/,''),
      key:(localStorage.getItem(K_KEY)||'').trim()
    };
  }
  function paint6167(state,text,detail=''){
    const dot=document.getElementById('serviceStatusDot6167');
    const label=document.getElementById('serviceStatusText6167');
    const pill=document.getElementById('homeCloudPill6167');
    if(label){label.textContent=text;label.title=detail||text}
    if(pill){pill.textContent=state==='online'?'● EN LIGNE':state==='offline'?'● HORS LIGNE':state==='local'?'● LOCAL':'● CONNEXION';pill.title=detail||text}
    if(!dot)return;
    const styles={
      online:['#42a678','0 0 0 3px rgba(66,166,120,.13)'],
      checking:['#cc9447','0 0 0 3px rgba(204,148,71,.13)'],
      local:['#cc9447','0 0 0 3px rgba(204,148,71,.13)'],
      offline:['#c95c5c','0 0 0 3px rgba(201,92,92,.13)']
    };
    const st=styles[state]||styles.checking;
    dot.style.background=st[0];dot.style.boxShadow=st[1];dot.title=detail||text;
  }
  function markOnline6167(detail='Cloud JKBat accessible'){
    lastOk=Date.now();paint6167('online','en ligne',detail)
  }
  function markOffline6167(detail='Cloud JKBat inaccessible'){
    paint6167('offline','hors ligne',detail)
  }
  async function checkCloud6167(force=false){
    if(!navigator.onLine){markOffline6167('Aucune connexion Internet');return false}
    const c=cloudConfig6167();
    if(!/^https:\/\//i.test(c.url)||c.key.length<15){paint6167('local','local','Cloud non configuré');return false}
    if(busy&&!force)return false;
    busy=true;paint6167('checking','connexion…','Vérification du Cloud JKBat');
    const ctrl=new AbortController(),tm=setTimeout(()=>ctrl.abort(),8000);
    try{
      // Endpoint Auth léger : il confirme que le projet Supabase répond avec la clé publique.
      let r=await fetch(c.url+'/auth/v1/settings',{method:'GET',headers:{'apikey':c.key},cache:'no-store',signal:ctrl.signal});
      if(!r.ok){
        // Repli PostgREST pour les projets dont le endpoint Auth ne répond pas comme attendu.
        r=await fetch(c.url+'/rest/v1/',{method:'GET',headers:{'apikey':c.key,'Authorization':'Bearer '+c.key},cache:'no-store',signal:ctrl.signal});
      }
      if(!r.ok)throw new Error('Cloud '+r.status);
      markOnline6167();return true;
    }catch(e){
      // Évite de faire clignoter « hors ligne » sur un timeout isolé juste après un échange réussi.
      if(lastOk&&Date.now()-lastOk<90000){paint6167('online','en ligne','Dernière réponse Cloud récente');return true}
      markOffline6167(navigator.onLine?'Cloud JKBat momentanément inaccessible':'Aucune connexion Internet');return false;
    }finally{clearTimeout(tm);busy=false}
  }

  window.setJKBatCloudOnline6167=markOnline6167;
  window.checkJKBatCloud6167=checkCloud6167;
  window.addEventListener('online',()=>checkCloud6167(true));
  window.addEventListener('offline',()=>markOffline6167('Aucune connexion Internet'));
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')checkCloud6167(true)});
  setInterval(()=>checkCloud6167(false),30000);
  setTimeout(()=>checkCloud6167(true),500);
})();



(function(){
'use strict';
const TECH_KEY6168='jkbat_technicians';
window.technicians6168=function(){return jget(TECH_KEY6168,[])};
function activeTechnicians6168(){return technicians6168().filter(t=>t.active!==false)}
function techName6168(id,name=''){if(name)return name;let t=technicians6168().find(x=>x.id===id);return t?.name||''}
function techOptions6168(selectedId='',selectedName=''){
  let arr=activeTechnicians6168(),sel=selectedId||'',name=selectedName||'';
  let opts=['<option value="">Non assigné</option>'];
  for(let t of arr) opts.push(`<option value="${esc(t.id)}" ${t.id===sel?'selected':''}>${esc(t.name)}</option>`);
  if(!sel&&name&&!arr.some(t=>t.name===name))opts.push(`<option value="__legacy__" selected>${esc(name)}</option>`);
  return opts.join('');
}
function techChip6168(id,name=''){
  let n=techName6168(id,name);
  return n?`<span class="tech-chip6168"><i class="tech-dot6168"></i>${esc(n)}</span>`:`<span class="tech-chip6168 home-plan-unassigned6168">Non assigné</span>`;
}
window.techChip6168=techChip6168;

window.openTechnicians6168=function(){
  let a=technicians6168();
  openModal('Équipe / techniciens',`<div class="assignment-note6168">Les techniciens sont synchronisés avec le PC via la synchronisation JKBat. L'affectation organise le planning ; elle n'envoie pas encore de notification au technicien.</div><div class="actions"><button class="btn primary" onclick="openTechnician6168()">＋ Ajouter un technicien</button></div><div class="team-list6168">${a.length?a.map(t=>`<div class="team-card6168 row"><div class="team-avatar6168">${esc((t.name||'?').slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(t.name||'Technicien')}</b><div class="muted">${esc(t.phone||'Téléphone non renseigné')} · ${t.active===false?'Inactif':'Actif'}</div></div><button class="btn small" onclick="openTechnician6168('${esc(t.id)}')">Modifier</button></div>`).join(''):'<div class="team-empty6168">Aucun technicien enregistré. Ajoute ton équipe pour pouvoir affecter les rendez-vous et les tâches.</div>'}</div>`)
};
window.openTechnician6168=function(id=''){
  let t=id?technicians6168().find(x=>x.id===id)||{}:{};
  openModal(id?'Modifier le technicien':'Nouveau technicien',`<div class="form"><div><label class="label">Nom</label><input class="field" id="techName6168" value="${esc(t.name||'')}"></div><div><label class="label">Téléphone</label><input class="field" id="techPhone6168" inputmode="tel" value="${esc(t.phone||'')}"></div><div><label class="label">Statut</label><select class="field" id="techActive6168"><option value="1" ${t.active!==false?'selected':''}>Actif</option><option value="0" ${t.active===false?'selected':''}>Inactif</option></select></div><button class="btn primary" onclick="saveTechnician6168('${esc(t.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteTechnician6168('${esc(id)}')">Supprimer</button>`:''}</div>`)
};
window.saveTechnician6168=function(id=''){
  let name=$('#techName6168')?.value.trim()||'',phone=$('#techPhone6168')?.value.trim()||'';
  if(!name)return toast('Nom du technicien requis');
  let a=technicians6168(),i=a.findIndex(x=>x.id===id),x={id:id||uid(),name,phone,active:($('#techActive6168')?.value||'1')==='1'};
  if(i>=0)a[i]={...a[i],...x};else a.push(x);
  jset(TECH_KEY6168,a);logActivity('ÉQUIPE',i>=0?'Technicien modifié':'Technicien ajouté',name);closeModal();renderAll();toast('Technicien enregistré')
};
window.deleteTechnician6168=async function(id){
  let t=technicians6168().find(x=>x.id===id);if(!t)return;
  if(!await askConfirm6164(`Supprimer ${t.name} de l'équipe ?\nLes rendez-vous et tâches déjà affectés conserveront son nom.`))return;
  jset(TECH_KEY6168,technicians6168().filter(x=>x.id!==id));closeModal();renderAll();toast('Technicien supprimé')
};

/* Rendez-vous : ajoute l'affectation technicien. */
window.openAppointment=function(id=null,clientIndex=null){
  let a=id?appointments().find(x=>x.id===id):{},c=clientIndex==null?null:clients()[clientIndex];
  a={...a,clientId:a.clientId||c?.id||'',client:a.client||c?.name||'',address:a.address||c?.address||'',phone:a.phone||c?.phone||'',status:a.status||'À FAIRE',jobType:a.jobType||''};
  openModal(id?'Modifier le rendez-vous':'Nouveau rendez-vous',`<div class="form"><div><label class="label">Métier</label><select class="field trade-select" id="aTrade">${tradeSelectOptions(a.jobType)}</select></div><div class="form two"><div><label class="label">Titre / client</label><input class="field" id="aTitle" value="${esc(a.title||a.client||'')}"></div><div><label class="label">Statut</label><select class="field" id="aStatus"><option ${a.status==='À FAIRE'?'selected':''}>À FAIRE</option><option ${a.status==='CONFIRMÉ'?'selected':''}>CONFIRMÉ</option><option ${a.status==='TERMINÉ'?'selected':''}>TERMINÉ</option><option ${a.status==='ANNULÉ'?'selected':''}>ANNULÉ</option></select></div></div><div class="form two"><div><label class="label">Date</label><input type="date" class="field" id="aDate" value="${esc(a.date||todayISO())}"></div><div><label class="label">Heure</label><input type="time" class="field" id="aTime" value="${esc(a.time||'09:00')}"></div></div><div><label class="label">Technicien affecté</label><select class="field" id="aTech6168">${techOptions6168(a.technicianId||'',a.technicianName||'')}</select></div><div><label class="label">Adresse</label><textarea class="field" id="aAddress">${esc(a.address||'')}</textarea></div><div><label class="label">Téléphone</label><input class="field" id="aPhone" value="${esc(a.phone||'')}"></div><div><label class="label">Référence document</label><input class="field" id="aDocRef" value="${esc(a.docRef||'')}"></div><div><label class="label">Notes</label><textarea class="field" id="aNotes">${esc(a.notes||'')}</textarea></div><button class="btn primary" onclick="saveAppointment('${esc(a.id||'')}','${esc(a.clientId||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteAppointment('${esc(id)}')">Supprimer</button>`:''}</div>`)
};
window.saveAppointment=function(id,clientId=''){
  let old=id?appointments().find(x=>x.id===id):{},techId=$('#aTech6168')?.value||'',tech=technicians6168().find(x=>x.id===techId),o={...old,id:id||uid(),clientId:clientId||old?.clientId||'',jobType:$('#aTrade')?.value||'',title:$('#aTitle').value.trim(),client:$('#aTitle').value.trim(),status:$('#aStatus').value,date:$('#aDate').value,time:$('#aTime').value,address:$('#aAddress').value.trim(),phone:$('#aPhone').value.trim(),docRef:$('#aDocRef').value.trim(),notes:$('#aNotes').value.trim(),technicianId:techId==='__legacy__'?(old.technicianId||''):techId,technicianName:techId==='__legacy__'?(old.technicianName||''):(tech?.name||'')};
  if(!o.title||!o.date)return toast('Titre et date requis');let a=appointments(),i=a.findIndex(x=>x.id===o.id);if(i>=0)a[i]=o;else a.push(o);jset('jkbat_appointments',a);logActivity('AGENDA',i>=0?'Rendez-vous modifié':'Rendez-vous créé',`${tradeById(o.jobType).label} · ${o.title} · ${fmtDate(o.date)} ${o.time}${o.technicianName?' · '+o.technicianName:''}`);saveAuto();closeModal();renderAll();toast('Rendez-vous enregistré')
};

/* Tâches : heure + technicien. */
window.openTask=function(id=null){
  let a=id?tasks().find(x=>x.id===id):{};
  openModal(id?'Modifier la tâche':'Nouvelle tâche',`<div class="form"><div><label class="label">Tâche / relance</label><input class="field" id="tTitle" value="${esc(a.title||'')}"></div><div class="form two"><div><label class="label">Échéance</label><input type="date" class="field" id="tDate" value="${esc(a.date||todayISO())}"></div><div><label class="label">Heure</label><input type="time" class="field" id="tTime6168" value="${esc(a.time||'')}"></div></div><div class="form two"><div><label class="label">Priorité</label><select class="field" id="tPriority"><option>NORMALE</option><option>HAUTE</option><option>BASSE</option></select></div><div><label class="label">Technicien</label><select class="field" id="tTech6168">${techOptions6168(a.technicianId||'',a.technicianName||'')}</select></div></div><div><label class="label">Note</label><textarea class="field" id="tNote">${esc(a.note||'')}</textarea></div><button class="btn primary" onclick="saveTask('${esc(a.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteTask('${esc(id)}')">Supprimer</button>`:''}</div>`);if(a.priority&&$('#tPriority'))$('#tPriority').value=a.priority
};
window.saveTask=function(id){
  let old=id?tasks().find(y=>y.id===id):{},techId=$('#tTech6168')?.value||'',tech=technicians6168().find(x=>x.id===techId),x={...old,id:id||uid(),title:$('#tTitle').value.trim(),date:$('#tDate').value,time:$('#tTime6168')?.value||'',priority:$('#tPriority').value,note:$('#tNote').value.trim(),technicianId:techId==='__legacy__'?(old.technicianId||''):techId,technicianName:techId==='__legacy__'?(old.technicianName||''):(tech?.name||''),done:id?(old?.done||false):false};
  if(!x.title)return toast('Tâche requise');let a=tasks(),i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i]=x;else a.push(x);jset('jkbat_tasks',a);logActivity('TÂCHE',i>=0?'Tâche modifiée':'Tâche créée',`${x.title}${x.technicianName?' · '+x.technicianName:''}`);closeModal();renderAll();toast('Tâche enregistrée')
};

/* Accueil : le bloc Priorité intelligente devient Planning du jour. */
window.renderMaxFocus=function(){
  let el=$('#maxFocus');if(!el)return;let today=todayISO();
  let aps=appointments().filter(a=>a.date===today&&a.status!=='ANNULÉ').map(a=>({kind:'RDV',id:a.id,time:a.time||'',title:a.title||a.client||'Rendez-vous',sub:a.address||a.client||'',techId:a.technicianId||'',techName:a.technicianName||'',done:a.status==='TERMINÉ',act:`openAppointment('${esc(a.id)}')`}));
  let ts=tasks().filter(t=>t.date===today&&!t.done).map(t=>({kind:'TÂCHE',id:t.id,time:t.time||'',title:t.title||'Tâche',sub:t.priority||'NORMALE',techId:t.technicianId||'',techName:t.technicianName||'',done:false,act:`openTask('${esc(t.id)}')`}));
  let items=[...aps,...ts].sort((a,b)=>String(a.time||'99:99').localeCompare(String(b.time||'99:99'))).slice(0,4),assigned=new Set(items.map(x=>x.techName).filter(Boolean)).size;
  el.innerHTML=`<div class="home-planning6168"><div class="home-planning-head6168"><div class="home-planning-title6168"><div class="home-planning-icon6168">◫</div><div><b>Planning du jour</b><small>${items.length?`${items.length} élément(s) · ${assigned} technicien(s) affecté(s)`:'Aucun rendez-vous ni tâche aujourd’hui'}</small></div></div><button class="btn small" onclick="go('agenda')">Semaine ›</button></div><div class="home-planning-list6168">${items.length?items.map(x=>`<div class="home-plan-row6168" onclick="${x.act}"><div class="home-plan-time6168">${esc(x.time||'—')}</div><div class="home-plan-main6168"><b>${esc(x.title)}</b><small>${esc(x.kind)}${x.sub?' · '+esc(x.sub):''}</small></div>${techChip6168(x.techId,x.techName)}</div>`).join(''):'<div class="team-empty6168">Ta journée est libre. Ajoute un rendez-vous ou une tâche et affecte-la à un technicien.</div>'}</div><div class="home-planning-actions6168"><button class="btn primary" onclick="openAppointment()">＋ Rendez-vous</button><button class="btn" onclick="openTask()">＋ Tâche</button><button class="btn" onclick="openTechnicians6168()">👷 Équipe</button><button class="btn" onclick="go('agenda')">Voir le planning</button></div></div>`
};

/* Planning semaine : rendez-vous + tâches avec technicien. */
window.renderAgenda=function(){
  if(!$('#weekStrip'))return;let days=weekDays(),today=todayISO(),allRaw=appointments(),appts=allRaw.filter(a=>matchesTrade(a,_agendaTrade,'appointment')),allTasks=tasks();
  if(!_maxSelectedDate||!days.some(d=>isoLocal(d)===_maxSelectedDate))_maxSelectedDate=days.some(d=>isoLocal(d)===today)?today:isoLocal(days[0]);
  let opts={weekday:'short'},monthA=days[0].toLocaleDateString('fr-FR',{day:'numeric',month:'short'}),monthB=days[6].toLocaleDateString('fr-FR',{day:'numeric',month:'short',year:'numeric'});
  $('#weekLabel').textContent=`${monthA} — ${monthB}`;$('#agendaCount').textContent=`${allRaw.length} RDV · ${allTasks.filter(t=>!t.done).length} tâche(s)`;
  $('#weekStrip').innerHTML=days.map(d=>{let iso=isoLocal(d),n=appts.filter(a=>a.date===iso).length+allTasks.filter(t=>t.date===iso&&!t.done).length;return `<button class="week-day ${iso===today?'today':''} ${iso===_maxSelectedDate?'selected':''} ${n?'has':''}" onclick="selectWeekDate('${iso}')"><span class="wd">${d.toLocaleDateString('fr-FR',opts).replace('.','')}</span><span class="dn">${d.getDate()}</span><i class="dot"></i></button>`}).join('');
  let dayAppts=appts.filter(a=>a.date===_maxSelectedDate).map(a=>({kind:'RDV',time:a.time||'',obj:a})),dayTasks=allTasks.filter(t=>t.date===_maxSelectedDate).map(t=>({kind:'TÂCHE',time:t.time||'',obj:t})),arr=[...dayAppts,...dayTasks].sort((a,b)=>String(a.time||'99:99').localeCompare(String(b.time||'99:99'))),d=new Date(_maxSelectedDate+'T12:00:00');
  $('#daySummary').innerHTML=`<div class="day-summary-card"><div><b>${d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'}).replace(/^./,c=>c.toUpperCase())}</b><span>${arr.length?`${arr.length} élément(s) planifié(s)`:'Journée disponible'}</span></div><span class="chip ${arr.length?'badge-gold':'ok'}">${arr.length?arr.length+' ÉLÉM.':'LIBRE'}</span></div>`;
  $('#agendaList').innerHTML=arr.length?arr.map(it=>{if(it.kind==='RDV'){let x=it.obj,t=tradeOfAppointment(x);return `<div class="card row trade-agenda-card planning-item6168" style="--trade:${t.color}"><div class="agenda-time">${esc(x.time||'--:--')}</div>${tradeIcon(x.jobType)}<div class="grow"><b>${esc(x.title||x.client||'Rendez-vous')}</b><div class="muted">${esc(x.client||'')} ${x.address?'· '+esc(x.address):''}</div><div class="trade-doc-meta">${tradeBadge(x.jobType)}<span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span>${techChip6168(x.technicianId||'',x.technicianName||'')}</div></div><button class="btn small" onclick="openAppointment('${esc(x.id)}')">›</button></div>`}let x=it.obj;return `<div class="card row planning-task6168 planning-item6168 ${x.done?'done':''}"><div class="agenda-time">${esc(x.time||'—')}</div><div class="focus-symbol" style="width:36px;height:36px;border-radius:12px;font-size:16px">✓</div><div class="grow"><b>${esc(x.title)}</b><div class="muted">Tâche · ${esc(x.priority||'NORMALE')}${x.note?' · '+esc(x.note):''}</div><div class="task-tech-line6168">${techChip6168(x.technicianId||'',x.technicianName||'')}<span class="chip ${x.done?'ok':''}">${x.done?'TERMINÉE':'À FAIRE'}</span></div></div><button class="btn small" onclick="openTask('${esc(x.id)}')">›</button></div>`}).join(''):'<div class="empty">Aucun élément ce jour. Ajoute un rendez-vous ou une tâche.</div>';
  if($('#agendaTradeFilter'))$('#agendaTradeFilter').innerHTML=tradeFilterHtml(_agendaTrade,'setAgendaTrade')
};

/* Pilotage : affiche l'affectation sur les tâches. */
const renderPilotage6168Base=window.renderPilotage;
window.renderPilotage=function(){renderPilotage6168Base?.();let el=$('#taskList');if(!el)return;let a=tasks();el.innerHTML=a.length?a.slice().sort((x,y)=>(x.done-y.done)||String(x.date).localeCompare(String(y.date))||String(x.time||'').localeCompare(String(y.time||''))).map(x=>`<div class="card compact row ${x.done?'done':''}"><button class="btn small ${x.done?'ok':''}" onclick="toggleTask('${esc(x.id)}')">${x.done?'✓':'○'}</button><div class="grow"><b>${esc(x.title)}</b><div class="muted">${fmtDate(x.date)} ${x.time?esc(x.time)+' · ':''}${esc(x.priority||'NORMALE')}</div><div class="task-tech-line6168">${techChip6168(x.technicianId||'',x.technicianName||'')}</div></div><button class="btn small" onclick="openTask('${esc(x.id)}')">✎</button></div>`).join(''):'<div class="empty">Aucune tâche.</div>'};

/* Recherche : permet aussi de retrouver un technicien. */
const commandSearch6168Base=window.commandSearch;
window.commandSearch=function(q){let r=commandSearch6168Base?commandSearch6168Base(q):[];let s=String(q||'').trim().toLowerCase();if(s)technicians6168().forEach(t=>{if([t.name,t.phone].join(' ').toLowerCase().includes(s))r.push({t:'Technicien',name:t.name||'',sub:t.phone||'',act:`closeModal();openTechnician6168('${esc(t.id)}')`})});return r.slice(0,16)};

setTimeout(()=>{try{renderAll()}catch(e){console.error('6168 init',e)}},120);
})();


(function(){
'use strict';
window.JKBAT_PLANNING_TECH_6169=true;
let agendaTech6169='all';
const TECH_PALETTE6169=['#2563eb','#16a34a','#f59e0b','#dc2626','#7c3aed','#0891b2','#db2777','#475569'];
function hash6169(s=''){let h=0;for(let i=0;i<s.length;i++)h=((h<<5)-h+s.charCodeAt(i))|0;return Math.abs(h)}
function techColor6169(id='',name=''){
  let t=(window.technicians6168?.()||[]).find(x=>x.id===id)||(!id&&name?(window.technicians6168?.()||[]).find(x=>x.name===name):null);
  return t?.color||TECH_PALETTE6169[hash6169(id||name||'non-assigne')%TECH_PALETTE6169.length];
}
window.techColor6169=techColor6169;
function assignedName6169(o){return o?.technicianName||((window.technicians6168?.()||[]).find(t=>t.id===o?.technicianId)?.name)||''}
function matchesTech6169(o){
  if(agendaTech6169==='all')return true;
  if(agendaTech6169==='none')return !o?.technicianId&&!assignedName6169(o);
  return o?.technicianId===agendaTech6169;
}
function techFilterHtml6169(){
  let techs=(window.technicians6168?.()||[]).filter(t=>t.active!==false);
  let out=[`<button class="tech-filter-btn6169 ${agendaTech6169==='all'?'active':''}" style="--tech-color:var(--accent)" onclick="setAgendaTech6169('all')">Tous</button>`,`<button class="tech-filter-btn6169 ${agendaTech6169==='none'?'active':''} agenda-unassigned6169" onclick="setAgendaTech6169('none')"><i class="tech-filter-dot6169"></i>Non assigné</button>`];
  for(let t of techs){let c=techColor6169(t.id,t.name);out.push(`<button class="tech-filter-btn6169 ${agendaTech6169===t.id?'active':''}" style="--tech-color:${c}" onclick="setAgendaTech6169('${esc(t.id)}')"><i class="tech-filter-dot6169"></i>${esc(t.name)}</button>`)}
  return `<div class="agenda-tech-filter-wrap6169"><div class="agenda-tech-filter-label6169">Technicien</div><div class="tech-filter6169">${out.join('')}</div></div>`;
}
window.setAgendaTech6169=function(v){agendaTech6169=v||'all';renderAgenda()};

/* Couleur dans les pastilles technicien. */
window.techChip6168=function(id,name=''){
  let n=name||((window.technicians6168?.()||[]).find(x=>x.id===id)?.name)||'';
  if(!n)return `<span class="tech-chip6168 home-plan-unassigned6168" style="--chip-tech:#8a94a3">Non assigné</span>`;
  let c=techColor6169(id,n);return `<span class="tech-chip6168" style="--chip-tech:${c}"><i class="tech-dot6168"></i>${esc(n)}</span>`
};

/* Équipe : couleur visible et modifiable. */
window.openTechnicians6168=function(){
  let a=window.technicians6168?.()||[];
  openModal('Équipe / techniciens',`<div class="assignment-note6168">Chaque technicien possède maintenant sa couleur dans le planning. Utilise ensuite le filtre Technicien pour afficher uniquement sa journée.</div><div class="actions"><button class="btn primary" onclick="openTechnician6168()">＋ Ajouter un technicien</button></div><div class="team-list6168">${a.length?a.map(t=>{let c=techColor6169(t.id,t.name);return `<div class="team-card6168 row" style="--tech-color:${c}"><div class="team-avatar6168" style="--tech-color:${c}">${esc((t.name||'?').slice(0,2).toUpperCase())}</div><div class="grow"><b>${esc(t.name||'Technicien')}</b><div class="muted">${esc(t.phone||'Téléphone non renseigné')} · ${t.active===false?'Inactif':'Actif'}</div></div><button class="btn small" onclick="openTechnician6168('${esc(t.id)}')">Modifier</button></div>`}).join(''):'<div class="team-empty6168">Aucun technicien enregistré.</div>'}</div>`)
};
window.openTechnician6168=function(id=''){
  let t=id?(window.technicians6168?.()||[]).find(x=>x.id===id)||{}:{},color=t.color||techColor6169(t.id||'nouveau',t.name||'');
  openModal(id?'Modifier le technicien':'Nouveau technicien',`<div class="form"><div><label class="label">Nom</label><input class="field" id="techName6168" value="${esc(t.name||'')}"></div><div><label class="label">Téléphone</label><input class="field" id="techPhone6168" inputmode="tel" value="${esc(t.phone||'')}"></div><div><label class="label">Couleur planning</label><div class="tech-color-row6169"><input type="color" class="tech-color6169" id="techColor6169" value="${esc(color)}" oninput="document.getElementById('techColorPreview6169').style.setProperty('--tech-color',this.value)"><div class="tech-color-preview6169" id="techColorPreview6169" style="--tech-color:${esc(color)}"><i></i>Couleur du technicien</div></div></div><div><label class="label">Statut</label><select class="field" id="techActive6168"><option value="1" ${t.active!==false?'selected':''}>Actif</option><option value="0" ${t.active===false?'selected':''}>Inactif</option></select></div><button class="btn primary" onclick="saveTechnician6169('${esc(t.id||'')}')">Enregistrer</button>${id?`<button class="btn danger" onclick="deleteTechnician6168('${esc(id)}')">Supprimer</button>`:''}</div>`)
};
window.saveTechnician6169=function(id=''){
  let name=$('#techName6168')?.value.trim()||'',phone=$('#techPhone6168')?.value.trim()||'',color=$('#techColor6169')?.value||TECH_PALETTE6169[0];
  if(!name)return toast('Nom du technicien requis');
  let a=window.technicians6168?.()||[],i=a.findIndex(x=>x.id===id),x={id:id||uid(),name,phone,color,active:($('#techActive6168')?.value||'1')==='1'};
  if(i>=0)a[i]={...a[i],...x};else a.push(x);
  jset('jkbat_technicians',a);logActivity('ÉQUIPE',i>=0?'Technicien modifié':'Technicien ajouté',name);closeModal();renderAll();toast('Technicien enregistré')
};

/* Accueil : bordure de couleur du technicien. */
window.renderMaxFocus=function(){
  let el=$('#maxFocus');if(!el)return;let today=todayISO();
  let aps=appointments().filter(a=>a.date===today&&a.status!=='ANNULÉ').map(a=>({kind:'RDV',id:a.id,time:a.time||'',title:a.title||a.client||'Rendez-vous',sub:a.address||a.client||'',techId:a.technicianId||'',techName:a.technicianName||'',act:`openAppointment('${esc(a.id)}')`}));
  let ts=tasks().filter(t=>t.date===today&&!t.done).map(t=>({kind:'TÂCHE',id:t.id,time:t.time||'',title:t.title||'Tâche',sub:t.priority||'NORMALE',techId:t.technicianId||'',techName:t.technicianName||'',act:`openTask('${esc(t.id)}')`}));
  let items=[...aps,...ts].sort((a,b)=>String(a.time||'99:99').localeCompare(String(b.time||'99:99'))).slice(0,4),assigned=new Set(items.map(x=>x.techName).filter(Boolean)).size;
  el.innerHTML=`<div class="home-planning6168"><div class="home-planning-head6168"><div class="home-planning-title6168"><div class="home-planning-icon6168">◫</div><div><b>Planning du jour</b><small>${items.length?`${items.length} élément(s) · ${assigned} technicien(s) affecté(s)`:'Aucun rendez-vous ni tâche aujourd’hui'}</small></div></div><button class="btn small" onclick="go('agenda')">Semaine ›</button></div><div class="home-planning-list6168">${items.length?items.map(x=>{let c=x.techId||x.techName?techColor6169(x.techId,x.techName):'#8a94a3';return `<div class="home-plan-row6168" style="--tech-color:${c}" onclick="${x.act}"><div class="home-plan-time6168">${esc(x.time||'—')}</div><div class="home-plan-main6168"><b>${esc(x.title)}</b><small>${esc(x.kind)}${x.sub?' · '+esc(x.sub):''}</small></div>${techChip6168(x.techId,x.techName)}</div>`}).join(''):'<div class="team-empty6168">Ta journée est libre.</div>'}</div><div class="home-planning-actions6168"><button class="btn primary" onclick="openAppointment()">＋ Rendez-vous</button><button class="btn" onclick="openTask()">＋ Tâche</button><button class="btn" onclick="openTechnicians6168()">👷 Équipe</button><button class="btn" onclick="go('agenda')">Voir le planning</button></div></div>`
};

/* Planning semaine : filtre métier + technicien + couleur. */
window.renderAgenda=function(){
  if(!$('#weekStrip'))return;let days=weekDays(),today=todayISO(),allRaw=appointments(),allTasksRaw=tasks();
  let appts=allRaw.filter(a=>matchesTrade(a,_agendaTrade,'appointment')).filter(matchesTech6169),allTasks=allTasksRaw.filter(matchesTech6169);
  if(!_maxSelectedDate||!days.some(d=>isoLocal(d)===_maxSelectedDate))_maxSelectedDate=days.some(d=>isoLocal(d)===today)?today:isoLocal(days[0]);
  let opts={weekday:'short'},monthA=days[0].toLocaleDateString('fr-FR',{day:'numeric',month:'short'}),monthB=days[6].toLocaleDateString('fr-FR',{day:'numeric',month:'short',year:'numeric'}),techs=(window.technicians6168?.()||[]).filter(t=>t.active!==false);
  $('#weekLabel').textContent=`${monthA} — ${monthB}`;$('#agendaCount').textContent=`${appts.length} RDV · ${allTasks.filter(t=>!t.done).length} tâche(s)`;
  $('#weekStrip').innerHTML=days.map(d=>{let iso=isoLocal(d),n=appts.filter(a=>a.date===iso).length+allTasks.filter(t=>t.date===iso&&!t.done).length;return `<button class="week-day ${iso===today?'today':''} ${iso===_maxSelectedDate?'selected':''} ${n?'has':''}" onclick="selectWeekDate('${iso}')"><span class="wd">${d.toLocaleDateString('fr-FR',opts).replace('.','')}</span><span class="dn">${d.getDate()}</span><i class="dot"></i></button>`}).join('');
  let dayAppts=appts.filter(a=>a.date===_maxSelectedDate).map(a=>({kind:'RDV',time:a.time||'',obj:a})),dayTasks=allTasks.filter(t=>t.date===_maxSelectedDate).map(t=>({kind:'TÂCHE',time:t.time||'',obj:t})),arr=[...dayAppts,...dayTasks].sort((a,b)=>String(a.time||'99:99').localeCompare(String(b.time||'99:99'))),d=new Date(_maxSelectedDate+'T12:00:00');
  let filterLabel=agendaTech6169==='all'?'Tous les techniciens':agendaTech6169==='none'?'Non assigné':((window.technicians6168?.()||[]).find(t=>t.id===agendaTech6169)?.name||'Technicien');
  $('#daySummary').innerHTML=`<div class="day-summary-card"><div><b>${d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'}).replace(/^./,c=>c.toUpperCase())}</b><span>${arr.length?`${arr.length} élément(s) · ${esc(filterLabel)}`:`Aucun élément · ${esc(filterLabel)}`}</span></div><span class="chip ${arr.length?'badge-gold':'ok'}">${arr.length?arr.length+' ÉLÉM.':'LIBRE'}</span></div>`;
  $('#agendaList').innerHTML=arr.length?arr.map(it=>{let x=it.obj,c=x.technicianId||x.technicianName?techColor6169(x.technicianId||'',x.technicianName||''):'#8a94a3';if(it.kind==='RDV'){let tr=tradeOfAppointment(x);return `<div class="card row trade-agenda-card planning-item6168 planning-tech-card6169" style="--trade:${tr.color};--tech-color:${c}"><div class="agenda-time">${esc(x.time||'--:--')}</div>${tradeIcon(x.jobType)}<div class="grow"><b>${esc(x.title||x.client||'Rendez-vous')}</b><div class="muted">${esc(x.client||'')} ${x.address?'· '+esc(x.address):''}</div><div class="trade-doc-meta">${tradeBadge(x.jobType)}<span class="chip ${statusClass(x.status)}">${esc(x.status||'À FAIRE')}</span>${techChip6168(x.technicianId||'',x.technicianName||'')}</div></div><button class="btn small" onclick="openAppointment('${esc(x.id)}')">›</button></div>`}return `<div class="card row planning-task6168 planning-item6168 planning-tech-card6169 ${x.done?'done':''}" style="--tech-color:${c}"><div class="agenda-time">${esc(x.time||'—')}</div><div class="focus-symbol" style="width:36px;height:36px;border-radius:12px;font-size:16px">✓</div><div class="grow"><b>${esc(x.title)}</b><div class="muted">Tâche · ${esc(x.priority||'NORMALE')}${x.note?' · '+esc(x.note):''}</div><div class="task-tech-line6168">${techChip6168(x.technicianId||'',x.technicianName||'')}<span class="chip ${x.done?'ok':''}">${x.done?'TERMINÉE':'À FAIRE'}</span></div></div><button class="btn small" onclick="openTask('${esc(x.id)}')">›</button></div>`}).join(''):'<div class="empty">Aucun élément ce jour avec ce filtre.</div>';
  if($('#agendaTradeFilter'))$('#agendaTradeFilter').innerHTML=tradeFilterHtml(_agendaTrade,'setAgendaTrade')+techFilterHtml6169();
};

setTimeout(()=>{try{renderAll()}catch(e){console.error('6169 init',e)}},150);
})();


/* --- JKBat Pro 6.16.13 : Documents simplifiés --- */
(function(){
 'use strict';
 let filtersOpen61613=false,draftOpen61613=false;

 window.toggleDocsFilters61613=function(force){
   filtersOpen61613=typeof force==='boolean'?force:!filtersOpen61613;
   updateDocsSimple61613()
 };
 window.toggleDocsDraft61613=function(force){
   draftOpen61613=typeof force==='boolean'?force:!draftOpen61613;
   updateDocsSimple61613()
 };

 function activeFilterCount61613(){
   let st=document.getElementById('docStatus6156')?.value||'',
       so=document.getElementById('docSort6156')?.value||'recent';
   return (st?1:0)+(so!=='recent'?1:0)+((typeof _docTrade!=='undefined'&&_docTrade!=='ALL')?1:0)
 }

 function updateDocsSimple61613(){
   let panel=document.getElementById('docsFiltersPanel61613'),
       toggle=document.getElementById('docsFilterToggle61613'),
       fc=document.getElementById('docsFilterCount61613'),
       n=activeFilterCount61613();
   if(panel)panel.classList.toggle('open61613',filtersOpen61613);
   if(toggle){
     toggle.classList.toggle('active61613',filtersOpen61613);
     toggle.classList.toggle('has-filters61613',n>0);
     toggle.setAttribute('aria-expanded',filtersOpen61613?'true':'false')
   }
   if(fc)fc.textContent=String(n);

   let f=document.getElementById('docFilter')?.value||'',
       summary=document.getElementById('docsSummary6156');
   if(summary)summary.classList.toggle('is-visible61613',f==='FACTURE');

   let draft=document.getElementById('draftBanner'),
       wrap=document.getElementById('docsDraftWrap61613'),
       dc=document.getElementById('docsDraftCount61613'),
       dt=wrap?.querySelector('.docs-draft-toggle61613'),
       has=!!(draft&&draft.innerHTML.trim());
   if(wrap){
     wrap.classList.toggle('has-draft61613',has);
     wrap.classList.toggle('open61613',has&&draftOpen61613)
   }
   if(dc)dc.textContent=has?'1':'0';
   if(dt)dt.setAttribute('aria-expanded',has&&draftOpen61613?'true':'false');

   let hint=document.querySelector('.docs-create-hint61613');
   if(hint)hint.textContent='Utilise le bouton + pour créer'
 }

 const renderDocs61613Base=window.renderDocs;
 if(typeof renderDocs61613Base==='function'){
   window.renderDocs=function(){
     let r=renderDocs61613Base.apply(this,arguments);
     setTimeout(updateDocsSimple61613,0);
     return r
   }
 }
 const resetDocs61613Base=window.resetDocsFilters6156;
 if(typeof resetDocs61613Base==='function'){
   window.resetDocsFilters6156=function(){
     let r=resetDocs61613Base.apply(this,arguments);
     filtersOpen61613=false;
     setTimeout(updateDocsSimple61613,0);
     return r
   }
 }

 // Sur l'écran Documents, le bouton flottant + reste l'unique accès à la création.
 const fabAction61613Base=window.fabAction;
 window.fabAction=function(){
   if(window.currentScreen==='documents' || (typeof currentScreen!=='undefined'&&currentScreen==='documents')){
     haptic();
     openModal('Nouveau document',`<div class="create-grid"><button class="create-tile primary-create" onclick="closeModal();openDocument(true,{kind:'FACTURE'})"><span>€</span><b>Facture</b><small>Créer une facture</small></button><button class="create-tile" onclick="closeModal();openDocument(true)"><span>＋</span><b>Devis</b><small>Créer un devis</small></button><button class="create-tile" onclick="closeModal();openStandaloneIntervention()"><span>▤</span><b>Fiche</b><small>Fiche terrain</small></button></div>`);
     return
   }
   return fabAction61613Base.apply(this,arguments)
 };

 if(!localStorage.getItem('jkbat_v61613_documents_simple'))localStorage.setItem('jkbat_v61613_documents_simple','1');
 setTimeout(()=>{try{renderDocs();updateDocsSimple61613()}catch(e){console.error('61613 documents',e)}},220)
})();


/* --- JKBat Pro 6.16.15 : Accueil simplifié + Pilotage complet --- */
(function(){
 'use strict';
 let pilotagePeriod61615=localStorage.getItem('jkbat_pilotage_period_61615')||'month';

 function iso61615(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
 function monday61615(d){let x=new Date(d.getFullYear(),d.getMonth(),d.getDate()),day=(x.getDay()+6)%7;x.setDate(x.getDate()-day);return x}
 function periodInfo61615(){
   let now=new Date(),today=iso61615(now),y=String(now.getFullYear()),m=y+'-'+String(now.getMonth()+1).padStart(2,'0');
   if(pilotagePeriod61615==='day')return{label:'Aujourd’hui',test:v=>String(v||'').slice(0,10)===today};
   if(pilotagePeriod61615==='week'){
     let a=monday61615(now),b=new Date(a);b.setDate(a.getDate()+6),ai=iso61615(a),bi=iso61615(b);
     return{label:'Cette semaine',test:v=>{v=String(v||'').slice(0,10);return v>=ai&&v<=bi}}
   }
   if(pilotagePeriod61615==='year')return{label:'Cette année',test:v=>String(v||'').startsWith(y)};
   return{label:'Ce mois',test:v=>String(v||'').startsWith(m)}
 }
 window.setPilotagePeriod61615=function(p){
   if(!['day','week','month','year'].includes(p))p='month';
   pilotagePeriod61615=p;localStorage.setItem('jkbat_pilotage_period_61615',p);renderPilotage61615()
 };
 function updatePeriodButtons61615(){
   document.querySelectorAll('#pilotagePeriod61615 button').forEach(b=>b.classList.toggle('active',b.dataset.period===pilotagePeriod61615));
 }
 function renderBars61615(){
   let el=document.getElementById('pilotageRevenueBars61615');if(!el)return;
   let now=new Date(),months=[];for(let i=5;i>=0;i--){let d=new Date(now.getFullYear(),now.getMonth()-i,1),k=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');months.push({k,label:d.toLocaleDateString('fr-FR',{month:'short'}),v:0})}
   docs().filter(d=>d.kind==='FACTURE').forEach(d=>{let x=months.find(m=>String(d.date||'').startsWith(m.k));if(x)x.v+=calc(d).total});
   let max=Math.max(1,...months.map(x=>x.v));el.innerHTML=months.map(x=>`<div class="bar" title="${euro(x.v)}"><i style="height:${Math.max(4,x.v/max*68)}px"></i><small>${esc(x.label)}</small></div>`).join('')
 }
 function renderPilotage61615(){
   let info=periodInfo61615(),ds=docs(),periodDs=ds.filter(d=>info.test(d.date)),inv=periodDs.filter(d=>d.kind==='FACTURE'),quotes=periodDs.filter(d=>d.kind==='DEVIS'),ex=expenses().filter(e=>info.test(e.date));
   let paid=inv.reduce((s,d)=>s+paidAmount(d),0),billed=inv.reduce((s,d)=>s+calc(d).total,0),due=inv.reduce((s,d)=>s+outstanding(d),0),pipeline=quotes.filter(d=>!['REFUSÉ','EXPIRÉ'].includes(d.status)).reduce((s,d)=>s+calc(d).total,0),cost=ex.reduce((s,e)=>s+(Number(e.amount)||0),0),result=paid-cost;
   let uniqueClients=new Set(periodDs.map(d=>String(d.clientId||d.clientName||'').trim().toLowerCase()).filter(Boolean)).size;
   let label=document.getElementById('pilotagePeriodLabel61615');if(label)label.textContent=info.label;
   updatePeriodButtons61615();
   let st=document.getElementById('proStats');if(st)st.innerHTML=`<div class="stat"><i>▤</i><span>Facturé</span><b>${euro(billed)}</b></div><div class="stat"><i>€</i><span>CA encaissé</span><b>${euro(paid)}</b></div><div class="stat"><i>⌛</i><span>À encaisser</span><b>${euro(due)}</b></div><div class="stat"><i>↗</i><span>Devis actifs</span><b>${euro(pipeline)}</b></div><div class="stat"><i>◆</i><span>Résultat suivi</span><b>${euro(result)}</b></div><div class="stat"><i>♟</i><span>Clients</span><b>${uniqueClients}</b></div>`;
   let overdue=inv.filter(isOverdue),overdueAmount=overdue.reduce((s,d)=>s+outstanding(d),0),rate=billed?Math.min(100,Math.round(paid/billed*100)):0,pay=document.getElementById('pilotagePaymentSummary61615');
   if(pay)pay.innerHTML=`<div class="pilotage-pay61615"><div class="ok"><span>Encaissé</span><b>${euro(paid)}</b></div><div><span>Reste</span><b>${euro(due)}</b></div><div class="${overdue.length?'bad':''}"><span>Retards</span><b>${overdue.length} · ${euro(overdueAmount)}</b></div></div><div class="tiny" style="margin:6px 4px 0;color:var(--muted)">${rate}% du montant facturé sur la période est encaissé.</div>`;
   let trade=document.getElementById('tradePilotage');if(trade){let max=Math.max(1,...JKBAT_TRADES.map(t=>inv.filter(d=>tradeOfDoc(d).id===t.id).reduce((s,d)=>s+calc(d).total,0)));trade.innerHTML=`<div class="trade-pilotage"><div class="section-title"><div><span class="section-kicker">Par activité</span><h3>CA par métier</h3></div><span>${esc(info.label)}</span></div><div class="card">${JKBAT_TRADES.map(t=>{let a=inv.filter(d=>tradeOfDoc(d).id===t.id),ca=a.reduce((s,d)=>s+calc(d).total,0),rest=a.reduce((s,d)=>s+outstanding(d),0);return `<div class="trade-revenue-row" style="--trade:${t.color}" onclick="openTradeHub('${t.id}')">${tradeIcon(t.id)}<div><b>${esc(t.label)}</b><div class="trade-bar"><i style="width:${Math.round(ca/max*100)}%"></i></div><small>${a.length} facture(s)${rest>.01?' · '+euro(rest)+' à encaisser':''}</small></div><strong>${euro(ca)}</strong></div>`}).join('')}</div></div>`}
   renderBars61615()
 }
 const renderPilotage61615Base=window.renderPilotage;
 window.renderPilotage=function(){let r=renderPilotage61615Base?.apply(this,arguments);setTimeout(renderPilotage61615,0);return r};
 const renderAll61615Base=window.renderAll;
 window.renderAll=function(){let r=renderAll61615Base?.apply(this,arguments);setTimeout(renderPilotage61615,0);return r};
 window.renderPilotage61615=renderPilotage61615;
 if(!localStorage.getItem('jkbat_v61615_home_pilotage'))localStorage.setItem('jkbat_v61615_home_pilotage','1');
 setTimeout(()=>{try{renderPilotage61615()}catch(e){console.error('61615 pilotage',e)}},260)
})();


/* --- JKBat Pro 6.16.18 : Messagerie médias complète --- */
(function(){
 'use strict';
 function polish61616(){
   const head=document.querySelector('#documents .docs-list-head-simple61613');
   const list=document.getElementById('docList');
   if(head&&list){
     const hasDocs=!!list.querySelector('.doc-premium6156,.card:not(.docs-empty6156)');
     head.classList.toggle('is-empty61616',!hasDocs);
   }
   const draft=document.getElementById('docsDraftWrap61613');
   if(draft&&!draft.classList.contains('has-draft61613'))draft.classList.remove('open61613');
 }
 const baseRenderDocs=window.renderDocs;
 if(typeof baseRenderDocs==='function'){
   window.renderDocs=function(){const r=baseRenderDocs.apply(this,arguments);setTimeout(polish61616,0);return r}
 }
 const baseRenderAll=window.renderAll;
 if(typeof baseRenderAll==='function'){
   window.renderAll=function(){const r=baseRenderAll.apply(this,arguments);setTimeout(polish61616,0);return r}
 }
 window.polish61616=polish61616;
 setTimeout(polish61616,320);
})();
