package com.jkbat.pro.v615;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class JkbatFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "jkbat_admin_messages";

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        getSharedPreferences("jkbat_admin_push", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
        MainActivity activity = MainActivity.getInstance();
        if (activity != null) activity.onFcmTokenAvailable(token);
    }

    @Override public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Map<String,String> data = remoteMessage.getData();
        String title = data.get("title");
        String body = data.get("body");
        String conversationId = data.get("conversation_id");
        if ((title == null || title.isEmpty()) && remoteMessage.getNotification() != null) title = remoteMessage.getNotification().getTitle();
        if ((body == null || body.isEmpty()) && remoteMessage.getNotification() != null) body = remoteMessage.getNotification().getBody();
        if (title == null || title.isEmpty()) title = "JKBat Pro";
        if (body == null || body.isEmpty()) body = "Nouvelle activité client.";

        createChannel();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("open_messages", true);
        if (conversationId != null) intent.putExtra("conversation_id", conversationId);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 611, intent, flags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setDefaults(Notification.DEFAULT_ALL);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Activité clients JKBat", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Nouveaux messages et demandes des clients JKBat'Services");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(c);
        }
    }
}
