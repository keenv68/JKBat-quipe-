package com.jkbat.pro.v615;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.print.PrintManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;

import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 5173;
    private static final int REQ_SPEECH = 5174;
    private static final int REQ_CAMERA = 5175;
    private static final int REQ_NOTIFICATIONS = 4201;

    private static MainActivity instance;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private boolean pageReady = false;
    private String pendingFcmToken;
    private String pendingConversationId;
    private volatile Uri lastSelectedFileUri;
    private volatile HttpURLConnection activeMediaUpload;
    private int bottomSystemInset = 0;

    public static MainActivity getInstance() { return instance; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new NativeBridge(), "JKBatNative");

        // Android navigation bar inset: expose the REAL system-bar height to the Web UI.
        // On high-density Samsung devices the WindowInsets value is in physical pixels;
        // pushSystemInsetsToWeb() converts it to dp/CSS pixels before positioning the nav.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            webView.setOnApplyWindowInsetsListener((v, insets) -> {
                int bottom;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    bottom = insets.getInsets(android.view.WindowInsets.Type.navigationBars()).bottom;
                } else {
                    bottom = insets.getSystemWindowInsetBottom();
                }
                bottomSystemInset = Math.max(0, bottom);
                v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), 0);
                pushSystemInsetsToWeb();
                return insets;
            });
            webView.requestApplyInsets();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.rgb(246, 242, 235));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @Override @SuppressWarnings("deprecation") public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                pushSystemInsetsToWeb();
                flushPendingEvents();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                lastSelectedFileUri = null;
                try {
                    if (params != null && params.isCaptureEnabled()) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, "JKBat_intervention.jpg");
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                        if (cameraUri == null) throw new IllegalStateException("camera uri");
                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        startActivityForResult(camera, REQ_CAMERA);
                    } else {
                        Intent chooser = params != null ? params.createIntent() : new Intent(Intent.ACTION_GET_CONTENT);
                        chooser.addCategory(Intent.CATEGORY_OPENABLE);
                        chooser.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(chooser, REQ_FILE);
                    }
                    return true;
                } catch (Exception e) {
                    if (fileCallback != null) fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    return false;
                }
            }
        });

        setContentView(webView);
        consumeIntent(getIntent());
        webView.loadUrl("file:///android_asset/index.html");
        requestNotificationPermissionIfNeeded();
        refreshFcmToken();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        consumeIntent(intent);
        flushPendingEvents();
    }

    @Override protected void onDestroy() {
        if (activeMediaUpload != null) {
            try { activeMediaUpload.disconnect(); } catch (Exception ignored) {}
            activeMediaUpload = null;
        }
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private boolean handleUrl(String url) {
        if (url == null) return false;
        try {
            if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("mailto:") || url.startsWith("geo:")) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }
            if (url.startsWith("jkbatspeech:")) {
                Intent speech = new Intent("android.speech.action.RECOGNIZE_SPEECH");
                speech.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
                speech.putExtra("android.speech.extra.LANGUAGE", "fr-FR");
                startActivityForResult(speech, REQ_SPEECH);
                return true;
            }
            if (url.startsWith("jkbatprint:")) {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm != null) pm.print("JKBat Document", webView.createPrintDocumentAdapter("JKBat Document"), null);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_SPEECH) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra("android.speech.extra.RESULTS");
                if (results != null && !results.isEmpty()) {
                    String js = "window.jkbatReceiveSpeech && window.jkbatReceiveSpeech(" + JSONObject.quote(results.get(0)) + ");";
                    eval(js);
                }
            }
            return;
        }

        if (fileCallback == null) return;
        Uri[] result = null;
        if (requestCode == REQ_CAMERA) {
            if (resultCode == RESULT_OK && cameraUri != null) {
                result = new Uri[]{cameraUri};
                lastSelectedFileUri = cameraUri;
            }
            cameraUri = null;
        } else if (requestCode == REQ_FILE && resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                if (count > 0) lastSelectedFileUri = result[0];
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
                lastSelectedFileUri = data.getData();
            } else {
                result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                if (result != null && result.length > 0) lastSelectedFileUri = result[0];
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    private void consumeIntent(Intent intent) {
        if (intent == null) return;
        if (intent.getBooleanExtra("open_messages", false)) {
            pendingConversationId = intent.getStringExtra("conversation_id");
            if (pendingConversationId == null) pendingConversationId = "";
        }
    }

    private void refreshFcmToken() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) return;
            String token = task.getResult();
            if (token != null && !token.isEmpty()) onFcmTokenAvailable(token);
        });
    }

    public void onFcmTokenAvailable(String token) {
        getSharedPreferences("jkbat_admin_push", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
        pendingFcmToken = token;
        flushPendingEvents();
    }

    private void pushSystemInsetsToWeb() {
        if (!pageReady || webView == null) return;

        // WindowInsets are physical Android pixels. The HTML viewport uses CSS pixels / dp.
        // Convert before applying the value; this is essential on the Galaxy S21 Ultra.
        final float density = Math.max(1f, getResources().getDisplayMetrics().density);
        final int cssBottom = Math.max(0, Math.min(80, Math.round(bottomSystemInset / density)));

        eval("document.documentElement.style.setProperty('--android-nav-inset', '" + cssBottom + "px');"
                + "window.dispatchEvent(new Event('jkbat-system-insets'));"
                + "window.dispatchEvent(new Event('resize'));" );
    }

    private void flushPendingEvents() {
        if (!pageReady || webView == null) return;
        if (pendingFcmToken == null || pendingFcmToken.isEmpty()) {
            pendingFcmToken = getSharedPreferences("jkbat_admin_push", MODE_PRIVATE).getString("fcm_token", "");
        }
        if (pendingFcmToken != null && !pendingFcmToken.isEmpty()) {
            eval("window.jkbatReceiveFcmToken && window.jkbatReceiveFcmToken(" + JSONObject.quote(pendingFcmToken) + ");");
        }
        if (pendingConversationId != null) {
            eval("window.jkbatOpenAdminChatFromNotification && window.jkbatOpenAdminChatFromNotification(" + JSONObject.quote(pendingConversationId) + ");");
            pendingConversationId = null;
        }
    }

    private void eval(String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private long selectedFileSize(Uri uri) {
        if (uri == null) return -1;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0 && !cursor.isNull(idx)) return cursor.getLong(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return -1;
    }

    private static String readResponse(InputStream stream) {
        if (stream == null) return "";
        try (InputStream in = stream; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1 && out.size() < 512 * 1024) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return "";
        }
    }

    private class NativeBridge {
        @JavascriptInterface
        public boolean hasSelectedFile() {
            return lastSelectedFileUri != null;
        }

        @JavascriptInterface
        public void cancelMediaUpload() {
            HttpURLConnection c = activeMediaUpload;
            if (c != null) {
                try { c.disconnect(); } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface
        public void uploadSelectedMedia(String uploadUrl, String mimeType, String accessToken, String anonKey, String requestId) {
            final Uri uri = lastSelectedFileUri;
            if (uri == null) {
                eval("window.jkbatProNativeUploadDone && window.jkbatProNativeUploadDone(" + JSONObject.quote(requestId) + ",0," + JSONObject.quote("Fichier sélectionné introuvable") + ");");
                return;
            }
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(uploadUrl);
                    conn = (HttpURLConnection) url.openConnection();
                    activeMediaUpload = conn;
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(30000);
                    conn.setReadTimeout(180000);
                    conn.setRequestProperty("Authorization", "Bearer " + accessToken);
                    conn.setRequestProperty("apikey", anonKey);
                    conn.setRequestProperty("x-upsert", "false");
                    conn.setRequestProperty("Content-Type", (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType);

                    long total = selectedFileSize(uri);
                    if (total >= 0) conn.setFixedLengthStreamingMode(total);
                    else conn.setChunkedStreamingMode(256 * 1024);

                    try (InputStream raw = getContentResolver().openInputStream(uri);
                         InputStream in = raw == null ? null : new BufferedInputStream(raw, 256 * 1024);
                         OutputStream out = new BufferedOutputStream(conn.getOutputStream(), 256 * 1024)) {
                        if (in == null) throw new Exception("Impossible d'ouvrir le fichier sélectionné");
                        byte[] buffer = new byte[256 * 1024];
                        long sent = 0;
                        int n;
                        long lastCallback = 0;
                        while ((n = in.read(buffer)) != -1) {
                            out.write(buffer, 0, n);
                            sent += n;
                            long now = System.currentTimeMillis();
                            if (now - lastCallback >= 180 || (total > 0 && sent >= total)) {
                                lastCallback = now;
                                int percent = total > 0 ? (int) Math.min(99, Math.round((sent * 100.0) / total)) : 0;
                                eval("window.jkbatProNativeUploadProgress && window.jkbatProNativeUploadProgress(" + JSONObject.quote(requestId) + "," + percent + ");");
                            }
                        }
                        out.flush();
                    }

                    int status = conn.getResponseCode();
                    String response = readResponse(status >= 400 ? conn.getErrorStream() : conn.getInputStream());
                    if (status >= 200 && status < 300) {
                        eval("window.jkbatProNativeUploadProgress && window.jkbatProNativeUploadProgress(" + JSONObject.quote(requestId) + ",100);");
                    }
                    eval("window.jkbatProNativeUploadDone && window.jkbatProNativeUploadDone(" + JSONObject.quote(requestId) + "," + status + "," + JSONObject.quote(response) + ");");
                } catch (Exception e) {
                    eval("window.jkbatProNativeUploadDone && window.jkbatProNativeUploadDone(" + JSONObject.quote(requestId) + ",0," + JSONObject.quote(e.getMessage() == null ? "Erreur réseau pendant l'envoi" : e.getMessage()) + ");");
                } finally {
                    if (conn != null) conn.disconnect();
                    if (activeMediaUpload == conn) activeMediaUpload = null;
                }
            }, "jkbat-pro-media-upload").start();
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }
}
