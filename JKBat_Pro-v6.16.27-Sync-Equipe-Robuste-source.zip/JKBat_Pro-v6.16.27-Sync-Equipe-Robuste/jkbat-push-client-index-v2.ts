import { createClient } from "npm:@supabase/supabase-js@2";

type ServiceAccount = { project_id: string; client_email: string; private_key: string; token_uri?: string };
type MessageRecord = { id: number; conversation_id: string; sender_id: string; sender_role: "client" | "business"; body: string; created_at: string };
type DbWebhook = { type?: string; table?: string; schema?: string; record?: MessageRecord };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8" } });
function base64Url(bytes: Uint8Array): string { let binary=""; for(const b of bytes) binary+=String.fromCharCode(b); return btoa(binary).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"") }
function utf8Base64Url(value:string):string { return base64Url(new TextEncoder().encode(value)) }
function pemToBytes(pem:string):Uint8Array { const raw=pem.replace(/-----BEGIN PRIVATE KEY-----/g,"").replace(/-----END PRIVATE KEY-----/g,"").replace(/\s+/g,""); const binary=atob(raw); return Uint8Array.from(binary,c=>c.charCodeAt(0)) }
async function getGoogleAccessToken(service:ServiceAccount):Promise<string>{
  const now=Math.floor(Date.now()/1000), header={alg:"RS256",typ:"JWT"}, claims={iss:service.client_email,scope:"https://www.googleapis.com/auth/firebase.messaging",aud:service.token_uri||"https://oauth2.googleapis.com/token",iat:now,exp:now+3600};
  const unsigned=`${utf8Base64Url(JSON.stringify(header))}.${utf8Base64Url(JSON.stringify(claims))}`;
  const key=await crypto.subtle.importKey("pkcs8",pemToBytes(service.private_key),{name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"},false,["sign"]);
  const signature=new Uint8Array(await crypto.subtle.sign("RSASSA-PKCS1-v1_5",key,new TextEncoder().encode(unsigned)));
  const assertion=`${unsigned}.${base64Url(signature)}`;
  const response=await fetch(service.token_uri||"https://oauth2.googleapis.com/token",{method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body:new URLSearchParams({grant_type:"urn:ietf:params:oauth:grant-type:jwt-bearer",assertion})});
  const payload=await response.json(); if(!response.ok||!payload.access_token) throw new Error(`OAuth Firebase refusé (${response.status})`); return payload.access_token as string;
}

Deno.serve(async(req)=>{
  if(req.method!=="POST") return json({error:"method_not_allowed"},405);
  const expectedSecret=Deno.env.get("JKBAT_PUSH_WEBHOOK_SECRET")||"";
  if(!expectedSecret||req.headers.get("x-jkbat-secret")!==expectedSecret) return json({error:"unauthorized"},401);
  const serviceRaw=Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON"), supabaseUrl=Deno.env.get("SUPABASE_URL"), serviceRole=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if(!serviceRaw||!supabaseUrl||!serviceRole) return json({error:"server_not_configured"},500);
  let payload:DbWebhook; try{payload=await req.json()}catch{return json({error:"invalid_json"},400)}
  const message=payload.record; if(!message||payload.table!=="jkbat_messages"||!['client','business'].includes(message.sender_role)) return json({ok:true,skipped:true});
  const supabase=createClient(supabaseUrl,serviceRole,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:conversation,error:conversationError}=await supabase.from("jkbat_conversations").select("client_id").eq("id",message.conversation_id).single();
  if(conversationError||!conversation?.client_id) return json({error:"conversation_not_found"},404);

  let targetUserIds:string[]=[]; let title="";
  if(message.sender_role==='business'){
    targetUserIds=[conversation.client_id]; title="Nouveau message de JKBat";
  }else{
    const {data:admins,error:adminError}=await supabase.from("jkbat_admins").select("user_id");
    if(adminError) return json({error:"admin_lookup_failed"},500);
    targetUserIds=(admins||[]).map((a:any)=>a.user_id).filter(Boolean);
    if(!targetUserIds.length) return json({ok:true,sent:0,reason:"no_admin"});
    const {data:profile}=await supabase.from("jkbat_client_profiles").select("full_name,email").eq("id",message.sender_id).maybeSingle();
    const clientName=(profile?.full_name||profile?.email||"un client").trim();
    title=message.body?.toLowerCase().startsWith("nouvelle demande d’intervention") ? `Nouvelle demande de ${clientName}` : `Nouveau message de ${clientName}`;
  }

  const {data:devices,error:deviceError}=await supabase.from("jkbat_push_tokens").select("id,token,user_id").in("user_id",targetUserIds);
  if(deviceError) return json({error:"token_lookup_failed"},500);
  if(!devices?.length) return json({ok:true,sent:0,reason:"no_registered_device"});
  let service:ServiceAccount; try{service=JSON.parse(serviceRaw)}catch{return json({error:"invalid_firebase_service_account_secret"},500)}
  const accessToken=await getGoogleAccessToken(service), endpoint=`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(service.project_id)}/messages:send`, bodyPreview=message.body.length>180?`${message.body.slice(0,177)}…`:message.body;
  let sent=0; const invalidIds:number[]=[]; const errors:string[]=[];
  for(const device of devices){
    const fcmResponse=await fetch(endpoint,{method:"POST",headers:{authorization:`Bearer ${accessToken}`,"content-type":"application/json"},body:JSON.stringify({message:{token:device.token,android:{priority:"HIGH"},data:{title,body:bodyPreview,conversation_id:message.conversation_id,message_id:String(message.id),sender_role:message.sender_role}}})});
    if(fcmResponse.ok){sent++;continue} const errText=await fcmResponse.text(); if(fcmResponse.status===404||errText.includes("UNREGISTERED")) invalidIds.push(device.id); else errors.push(`${fcmResponse.status}:${errText.slice(0,220)}`);
  }
  if(invalidIds.length) await supabase.from("jkbat_push_tokens").delete().in("id",invalidIds);
  return json({ok:errors.length===0,sent,direction:message.sender_role==='client'?'client_to_admin':'business_to_client',removed_invalid:invalidIds.length,errors});
});
