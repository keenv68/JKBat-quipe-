-- JKBat'Services v1.3.4 — signature client des documents
-- À exécuter UNE FOIS dans Supabase > SQL Editor.

alter table public.jkbat_client_documents
  add column if not exists signature_data text,
  add column if not exists signer_name text,
  add column if not exists signed_at timestamptz;

create or replace function public.jkbat_client_sign_document(
  p_document_id text,
  p_signature_data text,
  p_signer_name text default ''
) returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_sig text := trim(coalesce(p_signature_data,''));
  v_name text := trim(coalesce(p_signer_name,''));
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if length(v_sig) < 100 or position('data:image/' in lower(v_sig)) <> 1 then
    raise exception 'signature required';
  end if;
  if length(v_sig) > 700000 then raise exception 'signature too large'; end if;

  update public.jkbat_client_documents
     set signature_data=v_sig,
         signer_name=nullif(v_name,''),
         signed_at=now(),
         status='SIGNÉ CLIENT'
   where id::text=p_document_id
     and client_id=auth.uid();

  if not found then raise exception 'document not found'; end if;
end;
$$;

revoke all on function public.jkbat_client_sign_document(text,text,text) from public;
grant execute on function public.jkbat_client_sign_document(text,text,text) to authenticated;
