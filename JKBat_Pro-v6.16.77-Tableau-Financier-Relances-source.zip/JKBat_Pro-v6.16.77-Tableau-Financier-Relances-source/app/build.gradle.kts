plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.jkbat.pro.v615"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jkbat.pro.v6154scope"
        minSdk = 23
        targetSdk = 35
        versionCode = 61677
        versionName = "6.16.77"
    }

    signingConfigs {
        create("jkbatRelease") {
            val ks = System.getenv("JKBAT_KEYSTORE") ?: rootProject.file("jkbat-pro-release.jks").absolutePath
            storeFile = file(ks)
            storePassword = System.getenv("JKBAT_STOREPASS") ?: ""
            keyAlias = System.getenv("JKBAT_ALIAS") ?: "jkbat-pro"
            keyPassword = System.getenv("JKBAT_KEYPASS") ?: (System.getenv("JKBAT_STOREPASS") ?: "")
        }
    }

    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
        getByName("release") {
            signingConfig = signingConfigs.getByName("jkbatRelease")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation(platform("com.google.firebase:firebase-bom:34.18.0"))
    implementation("com.google.firebase:firebase-messaging")
}
